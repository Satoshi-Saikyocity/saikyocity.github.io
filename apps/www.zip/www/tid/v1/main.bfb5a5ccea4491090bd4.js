(window.webpackJsonp = window.webpackJsonp || []).push([[3], {
    "/GRb": function(e, t, n) {
        "use strict";
        var r = n("mrSG")
          , s = n("cXGI")
          , i = n("PJcQ")
          , o = n("8Y7J")
          , a = n("IheW")
          , c = n("Snpo")
          , l = n("HIK+");
        let u = ( () => {
            class e extends c.a {
                constructor(e, t) {
                    super(e, t)
                }
                get(e=null) {
                    const t = new a.j("GET",`assets/i18n/resource${e ? `_${e}` : ""}.json`);
                    return this.request(t)
                }
            }
            return e.ngInjectableDef = o.Qb({
                factory: function() {
                    return new e(o.Rb(a.c),o.Rb(l.a))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        n.d(t, "a", function() {
            return h
        });
        let h = ( () => {
            class e extends s.a {
                constructor(e) {
                    super(),
                    this.resourceApi = e,
                    this.resources = Object.create(null)
                }
                get(e, ...t) {
                    if (!e)
                        return;
                    let n = this.resources[e];
                    return t && t.length > 0 && (n = i.a.formatString(n, ...t)),
                    n
                }
                init() {
                    return r.a(this, void 0, void 0, function*() {
                        try {
                            const t = (yield this.resourceApi.get()).body;
                            if (t) {
                                const e = Object.keys(t);
                                for (let n = 0, r = e.length; n < r; n++) {
                                    const r = e[n];
                                    this.resources[r] = t[r]
                                }
                            }
                        } catch (e) {
                            throw console.error(`[Resource] Failed to get resource. detail=${e.message || "Unknown"}`),
                            e
                        }
                    })
                }
            }
            return e.ngInjectableDef = o.Qb({
                factory: function() {
                    return new e(o.Rb(u))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )()
    },
    "/HVE": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return a
        }),
        n.d(t, "b", function() {
            return c
        }),
        n.d(t, "e", function() {
            return l
        }),
        n.d(t, "f", function() {
            return d
        }),
        n.d(t, "d", function() {
            return f
        }),
        n.d(t, "c", function() {
            return u
        });
        var r = n("8Y7J")
          , s = n("SVse");
        let i;
        try {
            i = "undefined" != typeof Intl && Intl.v8BreakIterator
        } catch (p) {
            i = !1
        }
        let o, a = ( () => {
            class e {
                constructor(e) {
                    this._platformId = e,
                    this.isBrowser = this._platformId ? Object(s.s)(this._platformId) : "object" == typeof document && !!document,
                    this.EDGE = this.isBrowser && /(edge)/i.test(navigator.userAgent),
                    this.TRIDENT = this.isBrowser && /(msie|trident)/i.test(navigator.userAgent),
                    this.BLINK = this.isBrowser && !(!window.chrome && !i) && "undefined" != typeof CSS && !this.EDGE && !this.TRIDENT,
                    this.WEBKIT = this.isBrowser && /AppleWebKit/i.test(navigator.userAgent) && !this.BLINK && !this.EDGE && !this.TRIDENT,
                    this.IOS = this.isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent) && !("MSStream"in window),
                    this.FIREFOX = this.isBrowser && /(firefox|minefield)/i.test(navigator.userAgent),
                    this.ANDROID = this.isBrowser && /android/i.test(navigator.userAgent) && !this.TRIDENT,
                    this.SAFARI = this.isBrowser && /safari/i.test(navigator.userAgent) && this.WEBKIT
                }
            }
            return e.ngInjectableDef = Object(r.Qb)({
                factory: function() {
                    return new e(Object(r.Rb)(r.A, 8))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        class c {
        }
        function l(e) {
            return function() {
                if (null == o && "undefined" != typeof window)
                    try {
                        window.addEventListener("test", null, Object.defineProperty({}, "passive", {
                            get: () => o = !0
                        }))
                    } finally {
                        o = o || !1
                    }
                return o
            }() ? e : !!e.capture
        }
        const u = function() {
            var e = {
                NORMAL: 0,
                NEGATED: 1,
                INVERTED: 2
            };
            return e[e.NORMAL] = "NORMAL",
            e[e.NEGATED] = "NEGATED",
            e[e.INVERTED] = "INVERTED",
            e
        }();
        let h;
        function d() {
            return !!("object" == typeof document && "scrollBehavior"in document.documentElement.style)
        }
        function f() {
            if ("object" != typeof document || !document)
                return u.NORMAL;
            if (!h) {
                const e = document.createElement("div")
                  , t = e.style;
                e.dir = "rtl",
                t.height = "1px",
                t.width = "1px",
                t.overflow = "auto",
                t.visibility = "hidden",
                t.pointerEvents = "none",
                t.position = "absolute";
                const n = document.createElement("div")
                  , r = n.style;
                r.width = "2px",
                r.height = "1px",
                e.appendChild(n),
                document.body.appendChild(e),
                h = u.NORMAL,
                0 === e.scrollLeft && (e.scrollLeft = 1,
                h = 0 === e.scrollLeft ? u.NEGATED : u.INVERTED),
                e.parentNode.removeChild(e)
            }
            return h
        }
    },
    "/uUt": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("7o/Q");
        function s(e, t) {
            return n => n.lift(new i(e,t))
        }
        class i {
            constructor(e, t) {
                this.compare = e,
                this.keySelector = t
            }
            call(e, t) {
                return t.subscribe(new o(e,this.compare,this.keySelector))
            }
        }
        class o extends r.a {
            constructor(e, t, n) {
                super(e),
                this.keySelector = n,
                this.hasKey = !1,
                "function" == typeof t && (this.compare = t)
            }
            compare(e, t) {
                return e === t
            }
            _next(e) {
                let t;
                try {
                    const {keySelector: n} = this;
                    t = n ? n(e) : e
                } catch (r) {
                    return this.destination.error(r)
                }
                let n = !1;
                if (this.hasKey)
                    try {
                        const {compare: e} = this;
                        n = e(this.key, t)
                    } catch (r) {
                        return this.destination.error(r)
                    }
                else
                    this.hasKey = !0;
                n || (this.key = t,
                this.destination.next(e))
            }
        }
    },
    0: function(e, t, n) {
        e.exports = n("zUnb")
    },
    "0EUg": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("bHdf");
        function s() {
            return Object(r.a)(1)
        }
    },
    "2QA8": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        const r = "function" == typeof Symbol ? Symbol("rxSubscriber") : "@@rxSubscriber_" + Math.random()
    },
    "2Vo4": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        var r = n("XNiG")
          , s = n("9ppp");
        class i extends r.a {
            constructor(e) {
                super(),
                this._value = e
            }
            get value() {
                return this.getValue()
            }
            _subscribe(e) {
                const t = super._subscribe(e);
                return t && !t.closed && e.next(this._value),
                t
            }
            getValue() {
                if (this.hasError)
                    throw this.thrownError;
                if (this.closed)
                    throw new s.a;
                return this._value
            }
            next(e) {
                super.next(this._value = e)
            }
        }
    },
    "2fFW": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        let r = !1;
        const s = {
            Promise: void 0,
            set useDeprecatedSynchronousErrorHandling(e) {
                if (e) {
                    const e = new Error;
                    console.warn("DEPRECATED! RxJS was set to use deprecated synchronous error handling behavior by code at: \n" + e.stack)
                } else
                    r && console.log("RxJS: Back to a better error behavior. Thank you. <3");
                r = e
            },
            get useDeprecatedSynchronousErrorHandling() {
                return r
            }
        }
    },
    "2mKN": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return c
        });
        var r = n("DQLy")
          , s = n("m73C")
          , i = n("LPws");
        const o = Object.assign({}, s.a, {
            now: void 0,
            updateSpan: 30
        })
          , a = Object(r.w)(o, Object(r.z)(i.c, (e, t) => Object.assign({}, e, t.payload)), Object(r.z)(i.d, (e, t) => Object.assign({}, e, t.payload)), Object(r.z)(i.a, e => Object.assign({}, e, {
            updateSpan: l(e.updateSpan)
        })));
        function c(e, t) {
            return a(e, t)
        }
        function l(e) {
            switch (e) {
            case 10:
                return 30;
            case 30:
                return 60;
            case 60:
                return;
            default:
                return 10
            }
        }
    },
    "3N8a": function(e, t, n) {
        "use strict";
        var r = n("quSY");
        class s extends r.a {
            constructor(e, t) {
                super()
            }
            schedule(e, t=0) {
                return this
            }
        }
        n.d(t, "a", function() {
            return i
        });
        class i extends s {
            constructor(e, t) {
                super(e, t),
                this.scheduler = e,
                this.work = t,
                this.pending = !1
            }
            schedule(e, t=0) {
                if (this.closed)
                    return this;
                this.state = e;
                const n = this.id
                  , r = this.scheduler;
                return null != n && (this.id = this.recycleAsyncId(r, n, t)),
                this.pending = !0,
                this.delay = t,
                this.id = this.id || this.requestAsyncId(r, this.id, t),
                this
            }
            requestAsyncId(e, t, n=0) {
                return setInterval(e.flush.bind(e, this), n)
            }
            recycleAsyncId(e, t, n=0) {
                if (null !== n && this.delay === n && !1 === this.pending)
                    return t;
                clearInterval(t)
            }
            execute(e, t) {
                if (this.closed)
                    return new Error("executing a cancelled action");
                this.pending = !1;
                const n = this._execute(e, t);
                if (n)
                    return n;
                !1 === this.pending && null != this.id && (this.id = this.recycleAsyncId(this.scheduler, this.id, null))
            }
            _execute(e, t) {
                let n = !1
                  , r = void 0;
                try {
                    this.work(e)
                } catch (s) {
                    n = !0,
                    r = !!s && s || new Error(s)
                }
                if (n)
                    return this.unsubscribe(),
                    r
            }
            _unsubscribe() {
                const e = this.id
                  , t = this.scheduler
                  , n = t.actions
                  , r = n.indexOf(this);
                this.work = null,
                this.state = null,
                this.pending = !1,
                this.scheduler = null,
                -1 !== r && n.splice(r, 1),
                null != e && (this.id = this.recycleAsyncId(t, e, null)),
                this.delay = null
            }
        }
    },
    "3kxW": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o
        });
        var r = n("cXGI")
          , s = n("eD/y")
          , i = n("8Y7J");
        let o = ( () => {
            class e extends r.a {
                constructor() {
                    super()
                }
                get(e) {
                    const t = this.getLocalStorage(e);
                    let n;
                    switch (e) {
                    case s.b.IsDisplayService:
                    case s.b.IsDisplayLegend:
                    case s.b.IsDisplayCongestion:
                        return "1" === t;
                    case s.b.AutoUpdateSpan:
                        return (n = ["-", "10", "30", "60"].find(e => e === t)) ? "-" === n ? void 0 : +n : 30;
                    case s.b.LastCautionDate:
                        return n = new Date(t),
                        isNaN(n) ? 0 : n;
                    default:
                        return t
                    }
                }
                set(e, t) {
                    let n;
                    switch (e) {
                    case s.b.IsDisplayService:
                    case s.b.IsDisplayLegend:
                    case s.b.IsDisplayCongestion:
                        n = t ? "1" : "0";
                        break;
                    case s.b.AutoUpdateSpan:
                        n = t ? String(t) : "-";
                        break;
                    case s.b.LastCautionDate:
                    default:
                        n = t
                    }
                    this.setLocalStorage(e, n)
                }
                getLocalStorage(e) {
                    let t;
                    try {
                        t = window.localStorage.getItem(s.a + e)
                    } catch (n) {
                        console.error(n)
                    }
                    return t
                }
                setLocalStorage(e, t) {
                    try {
                        window.localStorage.setItem(s.a + e, t)
                    } catch (n) {
                        console.error(n)
                    }
                }
            }
            return e.ngInjectableDef = i.Qb({
                factory: function() {
                    return new e
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )()
    },
    "4I5i": function(e, t, n) {
        "use strict";
        function r() {
            return Error.call(this),
            this.message = "argument out of range",
            this.name = "ArgumentOutOfRangeError",
            this
        }
        n.d(t, "a", function() {
            return s
        }),
        r.prototype = Object.create(Error.prototype);
        const s = r
    },
    "5+tZ": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return c
        });
        var r = n("ZUHj")
          , s = n("l7GE")
          , i = n("51Dv")
          , o = n("lJxs")
          , a = n("Cfvw");
        function c(e, t, n=Number.POSITIVE_INFINITY) {
            return "function" == typeof t ? r => r.pipe(c( (n, r) => Object(a.a)(e(n, r)).pipe(Object(o.a)( (e, s) => t(n, e, r, s))), n)) : ("number" == typeof t && (n = t),
            t => t.lift(new l(e,n)))
        }
        class l {
            constructor(e, t=Number.POSITIVE_INFINITY) {
                this.project = e,
                this.concurrent = t
            }
            call(e, t) {
                return t.subscribe(new u(e,this.project,this.concurrent))
            }
        }
        class u extends s.a {
            constructor(e, t, n=Number.POSITIVE_INFINITY) {
                super(e),
                this.project = t,
                this.concurrent = n,
                this.hasCompleted = !1,
                this.buffer = [],
                this.active = 0,
                this.index = 0
            }
            _next(e) {
                this.active < this.concurrent ? this._tryNext(e) : this.buffer.push(e)
            }
            _tryNext(e) {
                let t;
                const n = this.index++;
                try {
                    t = this.project(e, n)
                } catch (r) {
                    return void this.destination.error(r)
                }
                this.active++,
                this._innerSub(t, e, n)
            }
            _innerSub(e, t, n) {
                const s = new i.a(this,void 0,void 0);
                this.destination.add(s),
                Object(r.a)(this, e, t, n, s)
            }
            _complete() {
                this.hasCompleted = !0,
                0 === this.active && 0 === this.buffer.length && this.destination.complete(),
                this.unsubscribe()
            }
            notifyNext(e, t, n, r, s) {
                this.destination.next(t)
            }
            notifyComplete(e) {
                const t = this.buffer;
                this.remove(e),
                this.active--,
                t.length > 0 ? this._next(t.shift()) : 0 === this.active && this.hasCompleted && this.destination.complete()
            }
        }
    },
    "51Dv": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("7o/Q");
        class s extends r.a {
            constructor(e, t, n) {
                super(),
                this.parent = e,
                this.outerValue = t,
                this.outerIndex = n,
                this.index = 0
            }
            _next(e) {
                this.parent.notifyNext(this.outerValue, e, this.outerIndex, this.index++, this)
            }
            _error(e) {
                this.parent.notifyError(e, this),
                this.unsubscribe()
            }
            _complete() {
                this.parent.notifyComplete(this),
                this.unsubscribe()
            }
        }
    },
    "5GAg": function(e, t, n) {
        "use strict";
        n.d(t, "c", function() {
            return b
        }),
        n.d(t, "e", function() {
            return E
        }),
        n.d(t, "f", function() {
            return T
        }),
        n.d(t, "d", function() {
            return O
        }),
        n.d(t, "b", function() {
            return I
        }),
        n.d(t, "g", function() {
            return A
        }),
        n.d(t, "a", function() {
            return D
        });
        var r = n("SVse")
          , s = n("8Y7J")
          , i = n("XNiG")
          , o = n("quSY")
          , a = n("LRne")
          , c = n("dvZr")
          , l = n("vkgz")
          , u = n("Kj3r")
          , h = n("pLZG")
          , d = n("lJxs")
          , f = n("IzEk")
          , p = n("/HVE")
          , m = n("KCVW");
        class g {
            constructor(e) {
                this._items = e,
                this._activeItemIndex = -1,
                this._activeItem = null,
                this._wrap = !1,
                this._letterKeyStream = new i.a,
                this._typeaheadSubscription = o.a.EMPTY,
                this._vertical = !0,
                this._allowedModifierKeys = [],
                this._skipPredicateFn = e => e.disabled,
                this._pressedLetters = [],
                this.tabOut = new i.a,
                this.change = new i.a,
                e instanceof s.C && e.changes.subscribe(e => {
                    if (this._activeItem) {
                        const t = e.toArray().indexOf(this._activeItem);
                        t > -1 && t !== this._activeItemIndex && (this._activeItemIndex = t)
                    }
                }
                )
            }
            skipPredicate(e) {
                return this._skipPredicateFn = e,
                this
            }
            withWrap(e=!0) {
                return this._wrap = e,
                this
            }
            withVerticalOrientation(e=!0) {
                return this._vertical = e,
                this
            }
            withHorizontalOrientation(e) {
                return this._horizontal = e,
                this
            }
            withAllowedModifierKeys(e) {
                return this._allowedModifierKeys = e,
                this
            }
            withTypeAhead(e=200) {
                if (this._items.length && this._items.some(e => "function" != typeof e.getLabel))
                    throw Error("ListKeyManager items in typeahead mode must implement the `getLabel` method.");
                return this._typeaheadSubscription.unsubscribe(),
                this._typeaheadSubscription = this._letterKeyStream.pipe(Object(l.a)(e => this._pressedLetters.push(e)), Object(u.a)(e), Object(h.a)( () => this._pressedLetters.length > 0), Object(d.a)( () => this._pressedLetters.join(""))).subscribe(e => {
                    const t = this._getItemsArray();
                    for (let n = 1; n < t.length + 1; n++) {
                        const r = (this._activeItemIndex + n) % t.length
                          , s = t[r];
                        if (!this._skipPredicateFn(s) && 0 === s.getLabel().toUpperCase().trim().indexOf(e)) {
                            this.setActiveItem(r);
                            break
                        }
                    }
                    this._pressedLetters = []
                }
                ),
                this
            }
            setActiveItem(e) {
                const t = this._activeItemIndex;
                this.updateActiveItem(e),
                this._activeItemIndex !== t && this.change.next(this._activeItemIndex)
            }
            onKeydown(e) {
                const t = e.keyCode
                  , n = ["altKey", "ctrlKey", "metaKey", "shiftKey"].every(t => !e[t] || this._allowedModifierKeys.indexOf(t) > -1);
                switch (t) {
                case c.k:
                    return void this.tabOut.next();
                case c.b:
                    if (this._vertical && n) {
                        this.setNextItemActive();
                        break
                    }
                    return;
                case c.l:
                    if (this._vertical && n) {
                        this.setPreviousItemActive();
                        break
                    }
                    return;
                case c.i:
                    if (this._horizontal && n) {
                        "rtl" === this._horizontal ? this.setPreviousItemActive() : this.setNextItemActive();
                        break
                    }
                    return;
                case c.g:
                    if (this._horizontal && n) {
                        "rtl" === this._horizontal ? this.setNextItemActive() : this.setPreviousItemActive();
                        break
                    }
                    return;
                default:
                    return void ((n || Object(c.o)(e, "shiftKey")) && (e.key && 1 === e.key.length ? this._letterKeyStream.next(e.key.toLocaleUpperCase()) : (t >= c.a && t <= c.m || t >= c.n && t <= c.h) && this._letterKeyStream.next(String.fromCharCode(t))))
                }
                this._pressedLetters = [],
                e.preventDefault()
            }
            get activeItemIndex() {
                return this._activeItemIndex
            }
            get activeItem() {
                return this._activeItem
            }
            setFirstItemActive() {
                this._setActiveItemByIndex(0, 1)
            }
            setLastItemActive() {
                this._setActiveItemByIndex(this._items.length - 1, -1)
            }
            setNextItemActive() {
                this._activeItemIndex < 0 ? this.setFirstItemActive() : this._setActiveItemByDelta(1)
            }
            setPreviousItemActive() {
                this._activeItemIndex < 0 && this._wrap ? this.setLastItemActive() : this._setActiveItemByDelta(-1)
            }
            updateActiveItem(e) {
                const t = this._getItemsArray()
                  , n = "number" == typeof e ? e : t.indexOf(e)
                  , r = t[n];
                this._activeItem = null == r ? null : r,
                this._activeItemIndex = n
            }
            updateActiveItemIndex(e) {
                this.updateActiveItem(e)
            }
            _setActiveItemByDelta(e) {
                this._wrap ? this._setActiveInWrapMode(e) : this._setActiveInDefaultMode(e)
            }
            _setActiveInWrapMode(e) {
                const t = this._getItemsArray();
                for (let n = 1; n <= t.length; n++) {
                    const r = (this._activeItemIndex + e * n + t.length) % t.length;
                    if (!this._skipPredicateFn(t[r]))
                        return void this.setActiveItem(r)
                }
            }
            _setActiveInDefaultMode(e) {
                this._setActiveItemByIndex(this._activeItemIndex + e, e)
            }
            _setActiveItemByIndex(e, t) {
                const n = this._getItemsArray();
                if (n[e]) {
                    for (; this._skipPredicateFn(n[e]); )
                        if (!n[e += t])
                            return;
                    this.setActiveItem(e)
                }
            }
            _getItemsArray() {
                return this._items instanceof s.C ? this._items.toArray() : this._items
            }
        }
        class b extends g {
            constructor() {
                super(...arguments),
                this._origin = "program"
            }
            setFocusOrigin(e) {
                return this._origin = e,
                this
            }
            setActiveItem(e) {
                super.setActiveItem(e),
                this.activeItem && this.activeItem.focus(this._origin)
            }
        }
        let y = ( () => {
            class e {
                constructor(e) {
                    this._platform = e
                }
                isDisabled(e) {
                    return e.hasAttribute("disabled")
                }
                isVisible(e) {
                    return function(e) {
                        return !!(e.offsetWidth || e.offsetHeight || "function" == typeof e.getClientRects && e.getClientRects().length)
                    }(e) && "visible" === getComputedStyle(e).visibility
                }
                isTabbable(e) {
                    if (!this._platform.isBrowser)
                        return !1;
                    const t = function(e) {
                        try {
                            return e.frameElement
                        } catch (t) {
                            return null
                        }
                    }((n = e).ownerDocument && n.ownerDocument.defaultView || window);
                    var n;
                    if (t) {
                        const e = t && t.nodeName.toLowerCase();
                        if (-1 === _(t))
                            return !1;
                        if ((this._platform.BLINK || this._platform.WEBKIT) && "object" === e)
                            return !1;
                        if ((this._platform.BLINK || this._platform.WEBKIT) && !this.isVisible(t))
                            return !1
                    }
                    let r = e.nodeName.toLowerCase()
                      , s = _(e);
                    if (e.hasAttribute("contenteditable"))
                        return -1 !== s;
                    if ("iframe" === r)
                        return !1;
                    if ("audio" === r) {
                        if (!e.hasAttribute("controls"))
                            return !1;
                        if (this._platform.BLINK)
                            return !0
                    }
                    if ("video" === r) {
                        if (!e.hasAttribute("controls") && this._platform.TRIDENT)
                            return !1;
                        if (this._platform.BLINK || this._platform.FIREFOX)
                            return !0
                    }
                    return ("object" !== r || !this._platform.BLINK && !this._platform.WEBKIT) && !(this._platform.WEBKIT && this._platform.IOS && !function(e) {
                        let t = e.nodeName.toLowerCase()
                          , n = "input" === t && e.type;
                        return "text" === n || "password" === n || "select" === t || "textarea" === t
                    }(e)) && e.tabIndex >= 0
                }
                isFocusable(e) {
                    return function(e) {
                        return !function(e) {
                            return function(e) {
                                return "input" == e.nodeName.toLowerCase()
                            }(e) && "hidden" == e.type
                        }(e) && (function(e) {
                            let t = e.nodeName.toLowerCase();
                            return "input" === t || "select" === t || "button" === t || "textarea" === t
                        }(e) || function(e) {
                            return function(e) {
                                return "a" == e.nodeName.toLowerCase()
                            }(e) && e.hasAttribute("href")
                        }(e) || e.hasAttribute("contenteditable") || v(e))
                    }(e) && !this.isDisabled(e) && this.isVisible(e)
                }
            }
            return e.ngInjectableDef = Object(s.Qb)({
                factory: function() {
                    return new e(Object(s.Rb)(p.a))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        function v(e) {
            if (!e.hasAttribute("tabindex") || void 0 === e.tabIndex)
                return !1;
            let t = e.getAttribute("tabindex");
            return "-32768" != t && !(!t || isNaN(parseInt(t, 10)))
        }
        function _(e) {
            if (!v(e))
                return null;
            const t = parseInt(e.getAttribute("tabindex") || "", 10);
            return isNaN(t) ? -1 : t
        }
        class w {
            constructor(e, t, n, r, s=!1) {
                this._element = e,
                this._checker = t,
                this._ngZone = n,
                this._document = r,
                this._hasAttached = !1,
                this.startAnchorListener = () => this.focusLastTabbableElement(),
                this.endAnchorListener = () => this.focusFirstTabbableElement(),
                this._enabled = !0,
                s || this.attachAnchors()
            }
            get enabled() {
                return this._enabled
            }
            set enabled(e) {
                this._enabled = e,
                this._startAnchor && this._endAnchor && (this._toggleAnchorTabIndex(e, this._startAnchor),
                this._toggleAnchorTabIndex(e, this._endAnchor))
            }
            destroy() {
                const e = this._startAnchor
                  , t = this._endAnchor;
                e && (e.removeEventListener("focus", this.startAnchorListener),
                e.parentNode && e.parentNode.removeChild(e)),
                t && (t.removeEventListener("focus", this.endAnchorListener),
                t.parentNode && t.parentNode.removeChild(t)),
                this._startAnchor = this._endAnchor = null
            }
            attachAnchors() {
                return !!this._hasAttached || (this._ngZone.runOutsideAngular( () => {
                    this._startAnchor || (this._startAnchor = this._createAnchor(),
                    this._startAnchor.addEventListener("focus", this.startAnchorListener)),
                    this._endAnchor || (this._endAnchor = this._createAnchor(),
                    this._endAnchor.addEventListener("focus", this.endAnchorListener))
                }
                ),
                this._element.parentNode && (this._element.parentNode.insertBefore(this._startAnchor, this._element),
                this._element.parentNode.insertBefore(this._endAnchor, this._element.nextSibling),
                this._hasAttached = !0),
                this._hasAttached)
            }
            focusInitialElementWhenReady() {
                return new Promise(e => {
                    this._executeOnStable( () => e(this.focusInitialElement()))
                }
                )
            }
            focusFirstTabbableElementWhenReady() {
                return new Promise(e => {
                    this._executeOnStable( () => e(this.focusFirstTabbableElement()))
                }
                )
            }
            focusLastTabbableElementWhenReady() {
                return new Promise(e => {
                    this._executeOnStable( () => e(this.focusLastTabbableElement()))
                }
                )
            }
            _getRegionBoundary(e) {
                let t = this._element.querySelectorAll(`[cdk-focus-region-${e}], ` + `[cdkFocusRegion${e}], ` + `[cdk-focus-${e}]`);
                for (let n = 0; n < t.length; n++)
                    t[n].hasAttribute(`cdk-focus-${e}`) ? console.warn(`Found use of deprecated attribute 'cdk-focus-${e}', ` + `use 'cdkFocusRegion${e}' instead. The deprecated ` + "attribute will be removed in 8.0.0.", t[n]) : t[n].hasAttribute(`cdk-focus-region-${e}`) && console.warn(`Found use of deprecated attribute 'cdk-focus-region-${e}', ` + `use 'cdkFocusRegion${e}' instead. The deprecated attribute ` + "will be removed in 8.0.0.", t[n]);
                return "start" == e ? t.length ? t[0] : this._getFirstTabbableElement(this._element) : t.length ? t[t.length - 1] : this._getLastTabbableElement(this._element)
            }
            focusInitialElement() {
                const e = this._element.querySelector("[cdk-focus-initial], [cdkFocusInitial]");
                return e ? (e.hasAttribute("cdk-focus-initial") && console.warn("Found use of deprecated attribute 'cdk-focus-initial', use 'cdkFocusInitial' instead. The deprecated attribute will be removed in 8.0.0", e),
                Object(s.W)() && !this._checker.isFocusable(e) && console.warn("Element matching '[cdkFocusInitial]' is not focusable.", e),
                e.focus(),
                !0) : this.focusFirstTabbableElement()
            }
            focusFirstTabbableElement() {
                const e = this._getRegionBoundary("start");
                return e && e.focus(),
                !!e
            }
            focusLastTabbableElement() {
                const e = this._getRegionBoundary("end");
                return e && e.focus(),
                !!e
            }
            hasAttached() {
                return this._hasAttached
            }
            _getFirstTabbableElement(e) {
                if (this._checker.isFocusable(e) && this._checker.isTabbable(e))
                    return e;
                let t = e.children || e.childNodes;
                for (let n = 0; n < t.length; n++) {
                    let e = t[n].nodeType === this._document.ELEMENT_NODE ? this._getFirstTabbableElement(t[n]) : null;
                    if (e)
                        return e
                }
                return null
            }
            _getLastTabbableElement(e) {
                if (this._checker.isFocusable(e) && this._checker.isTabbable(e))
                    return e;
                let t = e.children || e.childNodes;
                for (let n = t.length - 1; n >= 0; n--) {
                    let e = t[n].nodeType === this._document.ELEMENT_NODE ? this._getLastTabbableElement(t[n]) : null;
                    if (e)
                        return e
                }
                return null
            }
            _createAnchor() {
                const e = this._document.createElement("div");
                return this._toggleAnchorTabIndex(this._enabled, e),
                e.classList.add("cdk-visually-hidden"),
                e.classList.add("cdk-focus-trap-anchor"),
                e.setAttribute("aria-hidden", "true"),
                e
            }
            _toggleAnchorTabIndex(e, t) {
                e ? t.setAttribute("tabindex", "0") : t.removeAttribute("tabindex")
            }
            _executeOnStable(e) {
                this._ngZone.isStable ? e() : this._ngZone.onStable.asObservable().pipe(Object(f.a)(1)).subscribe(e)
            }
        }
        let E = ( () => {
            class e {
                constructor(e, t, n) {
                    this._checker = e,
                    this._ngZone = t,
                    this._document = n
                }
                create(e, t=!1) {
                    return new w(e,this._checker,this._ngZone,this._document,t)
                }
            }
            return e.ngInjectableDef = Object(s.Qb)({
                factory: function() {
                    return new e(Object(s.Rb)(y),Object(s.Rb)(s.y),Object(s.Rb)(r.d))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        const S = new s.p("liveAnnouncerElement",{
            providedIn: "root",
            factory: function() {
                return null
            }
        })
          , C = new s.p("LIVE_ANNOUNCER_DEFAULT_OPTIONS");
        let T = ( () => {
            class e {
                constructor(e, t, n, r) {
                    this._ngZone = t,
                    this._defaultOptions = r,
                    this._document = n,
                    this._liveElement = e || this._createLiveElement()
                }
                announce(e, ...t) {
                    const n = this._defaultOptions;
                    let r, s;
                    return 1 === t.length && "number" == typeof t[0] ? s = t[0] : [r,s] = t,
                    this.clear(),
                    clearTimeout(this._previousTimeout),
                    r || (r = n && n.politeness ? n.politeness : "polite"),
                    null == s && n && (s = n.duration),
                    this._liveElement.setAttribute("aria-live", r),
                    this._ngZone.runOutsideAngular( () => new Promise(t => {
                        clearTimeout(this._previousTimeout),
                        this._previousTimeout = setTimeout( () => {
                            this._liveElement.textContent = e,
                            t(),
                            "number" == typeof s && (this._previousTimeout = setTimeout( () => this.clear(), s))
                        }
                        , 100)
                    }
                    ))
                }
                clear() {
                    this._liveElement && (this._liveElement.textContent = "")
                }
                ngOnDestroy() {
                    clearTimeout(this._previousTimeout),
                    this._liveElement && this._liveElement.parentNode && (this._liveElement.parentNode.removeChild(this._liveElement),
                    this._liveElement = null)
                }
                _createLiveElement() {
                    const e = this._document.getElementsByClassName("cdk-live-announcer-element")
                      , t = this._document.createElement("div");
                    for (let n = 0; n < e.length; n++)
                        e[n].parentNode.removeChild(e[n]);
                    return t.classList.add("cdk-live-announcer-element"),
                    t.classList.add("cdk-visually-hidden"),
                    t.setAttribute("aria-atomic", "true"),
                    t.setAttribute("aria-live", "polite"),
                    this._document.body.appendChild(t),
                    t
                }
            }
            return e.ngInjectableDef = Object(s.Qb)({
                factory: function() {
                    return new e(Object(s.Rb)(S, 8),Object(s.Rb)(s.y),Object(s.Rb)(r.d),Object(s.Rb)(C, 8))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        const x = 650
          , k = Object(p.e)({
            passive: !0,
            capture: !0
        });
        let O = ( () => {
            class e {
                constructor(e, t) {
                    this._ngZone = e,
                    this._platform = t,
                    this._origin = null,
                    this._windowFocused = !1,
                    this._elementInfo = new Map,
                    this._monitoredElementCount = 0,
                    this._documentKeydownListener = () => {
                        this._lastTouchTarget = null,
                        this._setOriginForCurrentEventQueue("keyboard")
                    }
                    ,
                    this._documentMousedownListener = () => {
                        this._lastTouchTarget || this._setOriginForCurrentEventQueue("mouse")
                    }
                    ,
                    this._documentTouchstartListener = e => {
                        null != this._touchTimeoutId && clearTimeout(this._touchTimeoutId),
                        this._lastTouchTarget = e.target,
                        this._touchTimeoutId = setTimeout( () => this._lastTouchTarget = null, x)
                    }
                    ,
                    this._windowFocusListener = () => {
                        this._windowFocused = !0,
                        this._windowFocusTimeoutId = setTimeout( () => this._windowFocused = !1)
                    }
                }
                monitor(e, t=!1) {
                    if (!this._platform.isBrowser)
                        return Object(a.a)(null);
                    const n = Object(m.d)(e);
                    if (this._elementInfo.has(n)) {
                        let e = this._elementInfo.get(n);
                        return e.checkChildren = t,
                        e.subject.asObservable()
                    }
                    let r = {
                        unlisten: () => {}
                        ,
                        checkChildren: t,
                        subject: new i.a
                    };
                    this._elementInfo.set(n, r),
                    this._incrementMonitoredElementCount();
                    let s = e => this._onFocus(e, n)
                      , o = e => this._onBlur(e, n);
                    return this._ngZone.runOutsideAngular( () => {
                        n.addEventListener("focus", s, !0),
                        n.addEventListener("blur", o, !0)
                    }
                    ),
                    r.unlisten = () => {
                        n.removeEventListener("focus", s, !0),
                        n.removeEventListener("blur", o, !0)
                    }
                    ,
                    r.subject.asObservable()
                }
                stopMonitoring(e) {
                    const t = Object(m.d)(e)
                      , n = this._elementInfo.get(t);
                    n && (n.unlisten(),
                    n.subject.complete(),
                    this._setClasses(t),
                    this._elementInfo.delete(t),
                    this._decrementMonitoredElementCount())
                }
                focusVia(e, t, n) {
                    const r = Object(m.d)(e);
                    this._setOriginForCurrentEventQueue(t),
                    "function" == typeof r.focus && r.focus(n)
                }
                ngOnDestroy() {
                    this._elementInfo.forEach( (e, t) => this.stopMonitoring(t))
                }
                _toggleClass(e, t, n) {
                    n ? e.classList.add(t) : e.classList.remove(t)
                }
                _setClasses(e, t) {
                    this._elementInfo.get(e) && (this._toggleClass(e, "cdk-focused", !!t),
                    this._toggleClass(e, "cdk-touch-focused", "touch" === t),
                    this._toggleClass(e, "cdk-keyboard-focused", "keyboard" === t),
                    this._toggleClass(e, "cdk-mouse-focused", "mouse" === t),
                    this._toggleClass(e, "cdk-program-focused", "program" === t))
                }
                _setOriginForCurrentEventQueue(e) {
                    this._ngZone.runOutsideAngular( () => {
                        this._origin = e,
                        this._originTimeoutId = setTimeout( () => this._origin = null, 1)
                    }
                    )
                }
                _wasCausedByTouch(e) {
                    let t = e.target;
                    return this._lastTouchTarget instanceof Node && t instanceof Node && (t === this._lastTouchTarget || t.contains(this._lastTouchTarget))
                }
                _onFocus(e, t) {
                    const n = this._elementInfo.get(t);
                    if (!n || !n.checkChildren && t !== e.target)
                        return;
                    let r = this._origin;
                    r || (r = this._windowFocused && this._lastFocusOrigin ? this._lastFocusOrigin : this._wasCausedByTouch(e) ? "touch" : "program"),
                    this._setClasses(t, r),
                    this._emitOrigin(n.subject, r),
                    this._lastFocusOrigin = r
                }
                _onBlur(e, t) {
                    const n = this._elementInfo.get(t);
                    !n || n.checkChildren && e.relatedTarget instanceof Node && t.contains(e.relatedTarget) || (this._setClasses(t),
                    this._emitOrigin(n.subject, null))
                }
                _emitOrigin(e, t) {
                    this._ngZone.run( () => e.next(t))
                }
                _incrementMonitoredElementCount() {
                    1 == ++this._monitoredElementCount && this._platform.isBrowser && this._ngZone.runOutsideAngular( () => {
                        document.addEventListener("keydown", this._documentKeydownListener, k),
                        document.addEventListener("mousedown", this._documentMousedownListener, k),
                        document.addEventListener("touchstart", this._documentTouchstartListener, k),
                        window.addEventListener("focus", this._windowFocusListener)
                    }
                    )
                }
                _decrementMonitoredElementCount() {
                    --this._monitoredElementCount || (document.removeEventListener("keydown", this._documentKeydownListener, k),
                    document.removeEventListener("mousedown", this._documentMousedownListener, k),
                    document.removeEventListener("touchstart", this._documentTouchstartListener, k),
                    window.removeEventListener("focus", this._windowFocusListener),
                    clearTimeout(this._windowFocusTimeoutId),
                    clearTimeout(this._touchTimeoutId),
                    clearTimeout(this._originTimeoutId))
                }
            }
            return e.ngInjectableDef = Object(s.Qb)({
                factory: function() {
                    return new e(Object(s.Rb)(s.y),Object(s.Rb)(p.a))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        class I {
            constructor(e, t) {
                this._elementRef = e,
                this._focusMonitor = t,
                this.cdkFocusChange = new s.m,
                this._monitorSubscription = this._focusMonitor.monitor(this._elementRef, this._elementRef.nativeElement.hasAttribute("cdkMonitorSubtreeFocus")).subscribe(e => this.cdkFocusChange.emit(e))
            }
            ngOnDestroy() {
                this._focusMonitor.stopMonitoring(this._elementRef),
                this._monitorSubscription.unsubscribe()
            }
        }
        function A(e) {
            return 0 === e.buttons
        }
        class D {
        }
    },
    "7o/Q": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return l
        });
        var r = n("n6bG")
          , s = n("gRHU")
          , i = n("quSY")
          , o = n("2QA8")
          , a = n("2fFW")
          , c = n("NJ4a");
        class l extends i.a {
            constructor(e, t, n) {
                switch (super(),
                this.syncErrorValue = null,
                this.syncErrorThrown = !1,
                this.syncErrorThrowable = !1,
                this.isStopped = !1,
                arguments.length) {
                case 0:
                    this.destination = s.a;
                    break;
                case 1:
                    if (!e) {
                        this.destination = s.a;
                        break
                    }
                    if ("object" == typeof e) {
                        e instanceof l ? (this.syncErrorThrowable = e.syncErrorThrowable,
                        this.destination = e,
                        e.add(this)) : (this.syncErrorThrowable = !0,
                        this.destination = new u(this,e));
                        break
                    }
                default:
                    this.syncErrorThrowable = !0,
                    this.destination = new u(this,e,t,n)
                }
            }
            [o.a]() {
                return this
            }
            static create(e, t, n) {
                const r = new l(e,t,n);
                return r.syncErrorThrowable = !1,
                r
            }
            next(e) {
                this.isStopped || this._next(e)
            }
            error(e) {
                this.isStopped || (this.isStopped = !0,
                this._error(e))
            }
            complete() {
                this.isStopped || (this.isStopped = !0,
                this._complete())
            }
            unsubscribe() {
                this.closed || (this.isStopped = !0,
                super.unsubscribe())
            }
            _next(e) {
                this.destination.next(e)
            }
            _error(e) {
                this.destination.error(e),
                this.unsubscribe()
            }
            _complete() {
                this.destination.complete(),
                this.unsubscribe()
            }
            _unsubscribeAndRecycle() {
                const {_parent: e, _parents: t} = this;
                return this._parent = null,
                this._parents = null,
                this.unsubscribe(),
                this.closed = !1,
                this.isStopped = !1,
                this._parent = e,
                this._parents = t,
                this
            }
        }
        class u extends l {
            constructor(e, t, n, i) {
                let o;
                super(),
                this._parentSubscriber = e;
                let a = this;
                Object(r.a)(t) ? o = t : t && (o = t.next,
                n = t.error,
                i = t.complete,
                t !== s.a && (a = Object.create(t),
                Object(r.a)(a.unsubscribe) && this.add(a.unsubscribe.bind(a)),
                a.unsubscribe = this.unsubscribe.bind(this))),
                this._context = a,
                this._next = o,
                this._error = n,
                this._complete = i
            }
            next(e) {
                if (!this.isStopped && this._next) {
                    const {_parentSubscriber: t} = this;
                    a.a.useDeprecatedSynchronousErrorHandling && t.syncErrorThrowable ? this.__tryOrSetError(t, this._next, e) && this.unsubscribe() : this.__tryOrUnsub(this._next, e)
                }
            }
            error(e) {
                if (!this.isStopped) {
                    const {_parentSubscriber: t} = this
                      , {useDeprecatedSynchronousErrorHandling: n} = a.a;
                    if (this._error)
                        n && t.syncErrorThrowable ? (this.__tryOrSetError(t, this._error, e),
                        this.unsubscribe()) : (this.__tryOrUnsub(this._error, e),
                        this.unsubscribe());
                    else if (t.syncErrorThrowable)
                        n ? (t.syncErrorValue = e,
                        t.syncErrorThrown = !0) : Object(c.a)(e),
                        this.unsubscribe();
                    else {
                        if (this.unsubscribe(),
                        n)
                            throw e;
                        Object(c.a)(e)
                    }
                }
            }
            complete() {
                if (!this.isStopped) {
                    const {_parentSubscriber: e} = this;
                    if (this._complete) {
                        const t = () => this._complete.call(this._context);
                        a.a.useDeprecatedSynchronousErrorHandling && e.syncErrorThrowable ? (this.__tryOrSetError(e, t),
                        this.unsubscribe()) : (this.__tryOrUnsub(t),
                        this.unsubscribe())
                    } else
                        this.unsubscribe()
                }
            }
            __tryOrUnsub(e, t) {
                try {
                    e.call(this._context, t)
                } catch (n) {
                    if (this.unsubscribe(),
                    a.a.useDeprecatedSynchronousErrorHandling)
                        throw n;
                    Object(c.a)(n)
                }
            }
            __tryOrSetError(e, t, n) {
                if (!a.a.useDeprecatedSynchronousErrorHandling)
                    throw new Error("bad call");
                try {
                    t.call(this._context, n)
                } catch (r) {
                    return a.a.useDeprecatedSynchronousErrorHandling ? (e.syncErrorValue = r,
                    e.syncErrorThrown = !0,
                    !0) : (Object(c.a)(r),
                    !0)
                }
                return !1
            }
            _unsubscribe() {
                const {_parentSubscriber: e} = this;
                this._context = null,
                this._parentSubscriber = null,
                e.unsubscribe()
            }
        }
    },
    "8Y7J": function(e, t, n) {
        "use strict";
        var r = n("XNiG")
          , s = n("quSY")
          , i = n("HDdC")
          , o = n("VRyK")
          , a = n("7o/Q");
        function c() {
            return function(e) {
                return e.lift(new l(e))
            }
        }
        class l {
            constructor(e) {
                this.connectable = e
            }
            call(e, t) {
                const {connectable: n} = this;
                n._refCount++;
                const r = new u(e,n)
                  , s = t.subscribe(r);
                return r.closed || (r.connection = n.connect()),
                s
            }
        }
        class u extends a.a {
            constructor(e, t) {
                super(e),
                this.connectable = t
            }
            _unsubscribe() {
                const {connectable: e} = this;
                if (!e)
                    return void (this.connection = null);
                this.connectable = null;
                const t = e._refCount;
                if (t <= 0)
                    return void (this.connection = null);
                if (e._refCount = t - 1,
                t > 1)
                    return void (this.connection = null);
                const {connection: n} = this
                  , r = e._connection;
                this.connection = null,
                !r || n && r !== n || r.unsubscribe()
            }
        }
        const h = class extends i.a {
            constructor(e, t) {
                super(),
                this.source = e,
                this.subjectFactory = t,
                this._refCount = 0,
                this._isComplete = !1
            }
            _subscribe(e) {
                return this.getSubject().subscribe(e)
            }
            getSubject() {
                const e = this._subject;
                return e && !e.isStopped || (this._subject = this.subjectFactory()),
                this._subject
            }
            connect() {
                let e = this._connection;
                return e || (this._isComplete = !1,
                (e = this._connection = new s.a).add(this.source.subscribe(new f(this.getSubject(),this))),
                e.closed ? (this._connection = null,
                e = s.a.EMPTY) : this._connection = e),
                e
            }
            refCount() {
                return c()(this)
            }
        }
        .prototype
          , d = {
            operator: {
                value: null
            },
            _refCount: {
                value: 0,
                writable: !0
            },
            _subject: {
                value: null,
                writable: !0
            },
            _connection: {
                value: null,
                writable: !0
            },
            _subscribe: {
                value: h._subscribe
            },
            _isComplete: {
                value: h._isComplete,
                writable: !0
            },
            getSubject: {
                value: h.getSubject
            },
            connect: {
                value: h.connect
            },
            refCount: {
                value: h.refCount
            }
        };
        class f extends r.b {
            constructor(e, t) {
                super(e),
                this.connectable = t
            }
            _error(e) {
                this._unsubscribe(),
                super._error(e)
            }
            _complete() {
                this.connectable._isComplete = !0,
                this._unsubscribe(),
                super._complete()
            }
            _unsubscribe() {
                const e = this.connectable;
                if (e) {
                    this.connectable = null;
                    const t = e._connection;
                    e._refCount = 0,
                    e._subject = null,
                    e._connection = null,
                    t && t.unsubscribe()
                }
            }
        }
        function p() {
            return new r.a
        }
        n.d(t, "kb", function() {
            return Wo
        }),
        n.d(t, "lb", function() {
            return Zo
        }),
        n.d(t, "mb", function() {
            return Yo
        }),
        n.d(t, "nb", function() {
            return Jo
        }),
        n.d(t, "jb", function() {
            return Bi
        }),
        n.d(t, "ib", function() {
            return xi
        }),
        n.d(t, "g", function() {
            return jo
        }),
        n.d(t, "R", function() {
            return Io
        }),
        n.d(t, "x", function() {
            return Oo
        }),
        n.d(t, "S", function() {
            return wt
        }),
        n.d(t, "W", function() {
            return _t
        }),
        n.d(t, "c", function() {
            return Hi
        }),
        n.d(t, "B", function() {
            return $i
        }),
        n.d(t, "A", function() {
            return qi
        }),
        n.d(t, "b", function() {
            return Qi
        }),
        n.d(t, "d", function() {
            return Ui
        }),
        n.d(t, "e", function() {
            return zi
        }),
        n.d(t, "U", function() {
            return Qo
        }),
        n.d(t, "M", function() {
            return vo
        }),
        n.d(t, "Y", function() {
            return Eo
        }),
        n.d(t, "t", function() {
            return Ki
        }),
        n.d(t, "f", function() {
            return Xo
        }),
        n.d(t, "m", function() {
            return Mi
        }),
        n.d(t, "l", function() {
            return bt
        }),
        n.d(t, "G", function() {
            return qt
        }),
        n.d(t, "H", function() {
            return $t
        }),
        n.d(t, "a", function() {
            return Dn
        }),
        n.d(t, "P", function() {
            return ne
        }),
        n.d(t, "N", function() {
            return gr
        }),
        n.d(t, "Qb", function() {
            return S
        }),
        n.d(t, "T", function() {
            return O
        }),
        n.d(t, "q", function() {
            return En
        }),
        n.d(t, "Rb", function() {
            return G
        }),
        n.d(t, "V", function() {
            return K
        }),
        n.d(t, "n", function() {
            return M
        }),
        n.d(t, "p", function() {
            return P
        }),
        n.d(t, "o", function() {
            return b
        }),
        n.d(t, "z", function() {
            return y
        }),
        n.d(t, "I", function() {
            return _
        }),
        n.d(t, "y", function() {
            return ho
        }),
        n.d(t, "D", function() {
            return pr
        }),
        n.d(t, "E", function() {
            return dr
        }),
        n.d(t, "F", function() {
            return fr
        }),
        n.d(t, "i", function() {
            return to
        }),
        n.d(t, "j", function() {
            return ir
        }),
        n.d(t, "k", function() {
            return lr
        }),
        n.d(t, "u", function() {
            return J
        }),
        n.d(t, "w", function() {
            return Y
        }),
        n.d(t, "v", function() {
            return Po
        }),
        n.d(t, "C", function() {
            return Fi
        }),
        n.d(t, "J", function() {
            return zo
        }),
        n.d(t, "K", function() {
            return Fo
        }),
        n.d(t, "L", function() {
            return jr
        }),
        n.d(t, "O", function() {
            return Pr
        }),
        n.d(t, "h", function() {
            return yn
        }),
        n.d(t, "r", function() {
            return Or
        }),
        n.d(t, "s", function() {
            return Ir
        }),
        n.d(t, "Q", function() {
            return Ln
        }),
        n.d(t, "X", function() {
            return Ko
        }),
        n.d(t, "wb", function() {
            return Fn
        }),
        n.d(t, "bb", function() {
            return Gi
        }),
        n.d(t, "Z", function() {
            return _n
        }),
        n.d(t, "ab", function() {
            return or
        }),
        n.d(t, "eb", function() {
            return Bt
        }),
        n.d(t, "fb", function() {
            return Kt
        }),
        n.d(t, "gb", function() {
            return Tt
        }),
        n.d(t, "vb", function() {
            return N
        }),
        n.d(t, "zb", function() {
            return Pn
        }),
        n.d(t, "Jb", function() {
            return x
        }),
        n.d(t, "xb", function() {
            return Jn
        }),
        n.d(t, "yb", function() {
            return Yn
        }),
        n.d(t, "ub", function() {
            return Di
        }),
        n.d(t, "tb", function() {
            return Ri
        }),
        n.d(t, "cb", function() {
            return ki
        }),
        n.d(t, "db", function() {
            return Oi
        }),
        n.d(t, "Pb", function() {
            return de
        }),
        n.d(t, "Nb", function() {
            return Rn
        }),
        n.d(t, "Tb", function() {
            return zn
        }),
        n.d(t, "Sb", function() {
            return Hn
        }),
        n.d(t, "Ob", function() {
            return Bn
        }),
        n.d(t, "Ub", function() {
            return qn
        }),
        n.d(t, "hb", function() {
            return ea
        }),
        n.d(t, "ob", function() {
            return Us
        }),
        n.d(t, "pb", function() {
            return Cc
        }),
        n.d(t, "qb", function() {
            return es
        }),
        n.d(t, "rb", function() {
            return li
        }),
        n.d(t, "sb", function() {
            return ta
        }),
        n.d(t, "Ab", function() {
            return Rs
        }),
        n.d(t, "Bb", function() {
            return Ds
        }),
        n.d(t, "Cb", function() {
            return ha
        }),
        n.d(t, "Db", function() {
            return Zs
        }),
        n.d(t, "Eb", function() {
            return ui
        }),
        n.d(t, "Hb", function() {
            return hi
        }),
        n.d(t, "Fb", function() {
            return pa
        }),
        n.d(t, "Gb", function() {
            return fa
        }),
        n.d(t, "Ib", function() {
            return oa
        }),
        n.d(t, "Kb", function() {
            return ga
        }),
        n.d(t, "Lb", function() {
            return Yr
        }),
        n.d(t, "Mb", function() {
            return va
        });
        const m = "__parameters__";
        function g(e, t, n) {
            const r = function(e) {
                return function(...t) {
                    if (e) {
                        const n = e(...t);
                        for (const e in n)
                            this[e] = n[e]
                    }
                }
            }(t);
            function s(...e) {
                if (this instanceof s)
                    return r.apply(this, e),
                    this;
                const t = new s(...e);
                return n.annotation = t,
                n;
                function n(e, n, r) {
                    const s = e.hasOwnProperty(m) ? e[m] : Object.defineProperty(e, m, {
                        value: []
                    })[m];
                    for (; s.length <= r; )
                        s.push(null);
                    return (s[r] = s[r] || []).push(t),
                    e
                }
            }
            return n && (s.prototype = Object.create(n.prototype)),
            s.prototype.ngMetadataName = e,
            s.annotationCls = s,
            s
        }
        const b = g("Inject", e => ({
            token: e
        }))
          , y = g("Optional")
          , v = g("Self")
          , _ = g("SkipSelf");
        var w = function(e) {
            return e[e.Default = 0] = "Default",
            e[e.Host = 1] = "Host",
            e[e.Self = 2] = "Self",
            e[e.SkipSelf = 4] = "SkipSelf",
            e[e.Optional = 8] = "Optional",
            e
        }({});
        function E(e) {
            for (let t in e)
                if (e[t] === E)
                    return t;
            throw Error("Could not find renamed property on target object.")
        }
        function S(e) {
            return {
                token: e.token,
                providedIn: e.providedIn || null,
                factory: e.factory,
                value: void 0
            }
        }
        function C(e) {
            const t = e[T];
            return t && t.token === e ? t : null
        }
        const T = E({
            ngInjectableDef: E
        });
        function x(e) {
            if ("string" == typeof e)
                return e;
            if (e instanceof Array)
                return "[" + e.map(x).join(", ") + "]";
            if (null == e)
                return "" + e;
            if (e.overriddenName)
                return `${e.overriddenName}`;
            if (e.name)
                return `${e.name}`;
            const t = e.toString();
            if (null == t)
                return "" + t;
            const n = t.indexOf("\n");
            return -1 === n ? t : t.substring(0, n)
        }
        const k = E({
            __forward_ref__: E
        });
        function O(e) {
            return e.__forward_ref__ = O,
            e.toString = function() {
                return x(this())
            }
            ,
            e
        }
        function I(e) {
            const t = e;
            return "function" == typeof t && t.hasOwnProperty(k) && t.__forward_ref__ === O ? t() : e
        }
        const A = "undefined" != typeof globalThis && globalThis
          , D = "undefined" != typeof window && window
          , R = "undefined" != typeof self && "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope && self
          , j = "undefined" != typeof global && global
          , N = A || j || D || R;
        class P {
            constructor(e, t) {
                this._desc = e,
                this.ngMetadataName = "InjectionToken",
                this.ngInjectableDef = void 0,
                "number" == typeof t ? this.__NG_ELEMENT_ID__ = t : void 0 !== t && (this.ngInjectableDef = S({
                    token: this,
                    providedIn: t.providedIn || "root",
                    factory: t.factory
                }))
            }
            toString() {
                return `InjectionToken ${this._desc}`
            }
        }
        const M = new P("INJECTOR",-1)
          , L = new Object
          , F = "ngTempTokenPath"
          , U = "ngTokenPath"
          , z = /\n/gm
          , H = "ɵ"
          , B = "__source"
          , V = E({
            provide: String,
            useValue: E
        });
        let $, q = void 0;
        function Q(e) {
            const t = q;
            return q = e,
            t
        }
        function G(e, t=w.Default) {
            return ($ || function(e, t=w.Default) {
                if (void 0 === q)
                    throw new Error("inject() must be called from an injection context");
                return null === q ? function(e, t, n) {
                    const r = C(e);
                    if (r && "root" == r.providedIn)
                        return void 0 === r.value ? r.value = r.factory() : r.value;
                    if (n & w.Optional)
                        return null;
                    throw new Error(`Injector: NOT_FOUND [${x(e)}]`)
                }(e, 0, t) : q.get(e, t & w.Optional ? null : void 0, t)
            }
            )(e, t)
        }
        const K = G;
        class W {
            get(e, t=L) {
                if (t === L) {
                    const t = new Error(`NullInjectorError: No provider for ${x(e)}!`);
                    throw t.name = "NullInjectorError",
                    t
                }
                return t
            }
        }
        function Z(e, t, n, r=null) {
            e = e && "\n" === e.charAt(0) && e.charAt(1) == H ? e.substr(2) : e;
            let s = x(t);
            if (t instanceof Array)
                s = t.map(x).join(" -> ");
            else if ("object" == typeof t) {
                let e = [];
                for (let n in t)
                    if (t.hasOwnProperty(n)) {
                        let r = t[n];
                        e.push(n + ":" + ("string" == typeof r ? JSON.stringify(r) : x(r)))
                    }
                s = `{${e.join(", ")}}`
            }
            return `${n}${r ? "(" + r + ")" : ""}[${s}]: ${e.replace(z, "\n  ")}`
        }
        class Y {
        }
        class J {
        }
        function X(e, t, n) {
            t >= e.length ? e.push(n) : e.splice(t, 0, n)
        }
        function ee(e, t) {
            return t >= e.length - 1 ? e.pop() : e.splice(t, 1)[0]
        }
        const te = function() {
            var e = {
                OnPush: 0,
                Default: 1
            };
            return e[e.OnPush] = "OnPush",
            e[e.Default] = "Default",
            e
        }()
          , ne = function() {
            var e = {
                Emulated: 0,
                Native: 1,
                None: 2,
                ShadowDom: 3
            };
            return e[e.Emulated] = "Emulated",
            e[e.Native] = "Native",
            e[e.None] = "None",
            e[e.ShadowDom] = "ShadowDom",
            e
        }()
          , re = {}
          , se = []
          , ie = E({
            ngComponentDef: E
        })
          , oe = E({
            ngDirectiveDef: E
        })
          , ae = E({
            ngPipeDef: E
        });
        let ce = 0;
        function le(e) {
            return function(e) {
                return e[ie] || null
            }(e) || function(e) {
                return e[oe] || null
            }(e)
        }
        function ue(e) {
            return function(e) {
                return e[ae] || null
            }(e)
        }
        function he(e, t) {
            if (null == e)
                return re;
            const n = {};
            for (const r in e)
                if (e.hasOwnProperty(r)) {
                    let s = e[r]
                      , i = s;
                    Array.isArray(s) && (i = s[1],
                    s = s[0]),
                    n[s] = r,
                    t && (t[s] = i)
                }
            return n
        }
        const de = function(e) {
            const t = e.type
              , n = t.prototype
              , r = {}
              , s = {
                type: t,
                providersResolver: null,
                consts: e.consts,
                vars: e.vars,
                factory: e.factory,
                template: e.template || null,
                ngContentSelectors: e.ngContentSelectors,
                hostBindings: e.hostBindings || null,
                contentQueries: e.contentQueries || null,
                declaredInputs: r,
                inputs: null,
                outputs: null,
                exportAs: e.exportAs || null,
                onChanges: null,
                onInit: n.ngOnInit || null,
                doCheck: n.ngDoCheck || null,
                afterContentInit: n.ngAfterContentInit || null,
                afterContentChecked: n.ngAfterContentChecked || null,
                afterViewInit: n.ngAfterViewInit || null,
                afterViewChecked: n.ngAfterViewChecked || null,
                onDestroy: n.ngOnDestroy || null,
                onPush: e.changeDetection === te.OnPush,
                directiveDefs: null,
                pipeDefs: null,
                selectors: e.selectors,
                viewQuery: e.viewQuery || null,
                features: e.features || null,
                data: e.data || {},
                encapsulation: e.encapsulation || ne.Emulated,
                id: "c",
                styles: e.styles || se,
                _: null,
                setInput: null,
                schemas: e.schemas || null,
                tView: null
            };
            return s._ = "" + {
                toString: () => {
                    const n = e.directives
                      , i = e.features
                      , o = e.pipes;
                    s.id += ce++,
                    s.inputs = he(e.inputs, r),
                    s.outputs = he(e.outputs),
                    i && i.forEach(e => e(s)),
                    s.directiveDefs = n ? () => ("function" == typeof n ? n() : n).map(le) : null,
                    s.pipeDefs = o ? () => ("function" == typeof o ? o() : o).map(ue) : null,
                    t.hasOwnProperty(T) || (t[T] = S({
                        token: t,
                        factory: e.factory
                    }))
                }
            },
            s
        }
          , fe = 0
          , pe = 1
          , me = 7
          , ge = 12
          , be = 19;
        let ye = null;
        const ve = new Map;
        let _e = null;
        const we = 1
          , Ee = 0;
        function Se(e, t) {
            return _e && e === _e || (_e = e,
            t && (ye = ve.get(e) || null),
            ye = ye || {
                classesBitMask: Ee,
                classesIndex: we,
                stylesBitMask: Ee,
                stylesIndex: we
            }),
            ye
        }
        function Ce(e, t) {
            return function(e) {
                for (; Array.isArray(e); )
                    e = e[fe];
                return e
            }(t[e.index])
        }
        function Te(e, t) {
            return t[pe].data[e + be]
        }
        let xe = null;
        function ke() {
            return Ie
        }
        let Oe, Ie, Ae, De = 1, Re = 0, je = 0, Ne = -1;
        function Pe() {
            return Ne
        }
        function Me() {
            return Ae
        }
        const Le = ( () => ("undefined" != typeof requestAnimationFrame && requestAnimationFrame || setTimeout).bind(N))()
          , Fe = "--MAP--"
          , Ue = 0;
        function ze(e, t) {
            t === Ue ? e[2] > Ue && function(e) {
                Be(e, 2 | He(e))
            }(e) : e[2] = t
        }
        function He(e) {
            return e[1]
        }
        function Be(e, t) {
            e[1] = t
        }
        function Ve(e, t) {
            return e[t + 2]
        }
        function $e(e, t) {
            return 1 & e[t + 0]
        }
        function qe(e, t) {
            return (1 & $e(e, t)) > 0
        }
        function Qe(e, t) {
            return e[t + 0] >> 1
        }
        function Ge(e, t, n) {
            const r = $e(e, t);
            e[t + 0] = r | n << 1
        }
        function Ke(e, t) {
            return e[t + 1]
        }
        function We(e, t, n) {
            return e[t + 3 + n]
        }
        function Ze(e, t) {
            return !(!e || t !== e[2])
        }
        function Ye(e) {
            return (1 & He(e)) > 0
        }
        function Je(e) {
            return (2 & He(e)) > 0
        }
        function Xe(e) {
            return 6 + e[4]
        }
        function et(e, t) {
            let n = Array.isArray(e) ? e[0] : e
              , r = Array.isArray(t) ? t[0] : t;
            return n instanceof String && (n = n.toString()),
            r instanceof String && (r = r.toString()),
            !(n != n && r != r) && n !== r
        }
        function tt(e) {
            return null != e && "" !== e
        }
        function nt(e, t, n=" ") {
            return e + (t.length && e.length ? n : "") + t
        }
        function rt(e) {
            return e.replace(/[a-z][A-Z]/g, e => e.charAt(0) + "-" + e.charAt(1)).toLowerCase()
        }
        function st(e) {
            return it(e) ? e[0] : e
        }
        function it(e) {
            return Array.isArray(e) && e.length >= 6 && "string" != typeof e[1]
        }
        function ot(e, t) {
            return e[t + 0]
        }
        function at(e, t, n) {
            e[t + 1] = n
        }
        function ct(e, t) {
            return e[t + 1]
        }
        const lt = function() {
            var e = {
                Important: 1,
                DashCase: 2
            };
            return e[e.Important] = "Important",
            e[e.DashCase] = "DashCase",
            e
        }();
        function ut(e) {
            return !!e.listen
        }
        const ht = "ngDebugContext"
          , dt = "ngOriginalError"
          , ft = "ngErrorLogger";
        function pt(e) {
            return e[ht]
        }
        function mt(e) {
            return e[dt]
        }
        function gt(e, ...t) {
            e.error(...t)
        }
        class bt {
            constructor() {
                this._console = console
            }
            handleError(e) {
                const t = this._findOriginalError(e)
                  , n = this._findContext(e)
                  , r = function(e) {
                    return e[ft] || gt
                }(e);
                r(this._console, "ERROR", e),
                t && r(this._console, "ORIGINAL ERROR", t),
                n && r(this._console, "ERROR CONTEXT", n)
            }
            _findContext(e) {
                return e ? pt(e) ? pt(e) : this._findContext(mt(e)) : null
            }
            _findOriginalError(e) {
                let t = mt(e);
                for (; t && mt(t); )
                    t = mt(t);
                return t
            }
        }
        let yt = !0
          , vt = !1;
        function _t() {
            return vt = !0,
            yt
        }
        function wt() {
            if (vt)
                throw new Error("Cannot enable prod mode after platform setup.");
            yt = !1
        }
        class Et {
            constructor(e) {
                if (this.defaultDoc = e,
                this.inertDocument = this.defaultDoc.implementation.createHTMLDocument("sanitization-inert"),
                this.inertBodyElement = this.inertDocument.body,
                null == this.inertBodyElement) {
                    const e = this.inertDocument.createElement("html");
                    this.inertDocument.appendChild(e),
                    this.inertBodyElement = this.inertDocument.createElement("body"),
                    e.appendChild(this.inertBodyElement)
                }
                this.inertBodyElement.innerHTML = '<svg><g onload="this.parentNode.remove()"></g></svg>',
                !this.inertBodyElement.querySelector || this.inertBodyElement.querySelector("svg") ? (this.inertBodyElement.innerHTML = '<svg><p><style><img src="</style><img src=x onerror=alert(1)//">',
                this.getInertBodyElement = this.inertBodyElement.querySelector && this.inertBodyElement.querySelector("svg img") && function() {
                    try {
                        return !!window.DOMParser
                    } catch (e) {
                        return !1
                    }
                }() ? this.getInertBodyElement_DOMParser : this.getInertBodyElement_InertDocument) : this.getInertBodyElement = this.getInertBodyElement_XHR
            }
            getInertBodyElement_XHR(e) {
                e = "<body><remove></remove>" + e + "</body>";
                try {
                    e = encodeURI(e)
                } catch (r) {
                    return null
                }
                const t = new XMLHttpRequest;
                t.responseType = "document",
                t.open("GET", "data:text/html;charset=utf-8," + e, !1),
                t.send(void 0);
                const n = t.response.body;
                return n.removeChild(n.firstChild),
                n
            }
            getInertBodyElement_DOMParser(e) {
                e = "<body><remove></remove>" + e + "</body>";
                try {
                    const n = (new window.DOMParser).parseFromString(e, "text/html").body;
                    return n.removeChild(n.firstChild),
                    n
                } catch (t) {
                    return null
                }
            }
            getInertBodyElement_InertDocument(e) {
                const t = this.inertDocument.createElement("template");
                return "content"in t ? (t.innerHTML = e,
                t) : (this.inertBodyElement.innerHTML = e,
                this.defaultDoc.documentMode && this.stripCustomNsAttrs(this.inertBodyElement),
                this.inertBodyElement)
            }
            stripCustomNsAttrs(e) {
                const t = e.attributes;
                for (let r = t.length - 1; 0 < r; r--) {
                    const n = t.item(r).name;
                    "xmlns:ns1" !== n && 0 !== n.indexOf("ns1:") || e.removeAttribute(n)
                }
                let n = e.firstChild;
                for (; n; )
                    n.nodeType === Node.ELEMENT_NODE && this.stripCustomNsAttrs(n),
                    n = n.nextSibling
            }
        }
        const St = /^(?:(?:https?|mailto|ftp|tel|file):|[^&:\/?#]*(?:[\/?#]|$))/gi
          , Ct = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[a-z0-9+\/]+=*$/i;
        function Tt(e) {
            return (e = String(e)).match(St) || e.match(Ct) ? e : (_t() && console.warn(`WARNING: sanitizing unsafe URL value ${e} (see http://g.co/ng/security#xss)`),
            "unsafe:" + e)
        }
        function xt(e) {
            const t = {};
            for (const n of e.split(","))
                t[n] = !0;
            return t
        }
        function kt(...e) {
            const t = {};
            for (const n of e)
                for (const e in n)
                    n.hasOwnProperty(e) && (t[e] = !0);
            return t
        }
        const Ot = xt("area,br,col,hr,img,wbr")
          , It = xt("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr")
          , At = xt("rp,rt")
          , Dt = kt(At, It)
          , Rt = kt(Ot, kt(It, xt("address,article,aside,blockquote,caption,center,del,details,dialog,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,main,map,menu,nav,ol,pre,section,summary,table,ul")), kt(At, xt("a,abbr,acronym,audio,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,picture,q,ruby,rp,rt,s,samp,small,source,span,strike,strong,sub,sup,time,track,tt,u,var,video")), Dt)
          , jt = xt("background,cite,href,itemtype,longdesc,poster,src,xlink:href")
          , Nt = xt("srcset")
          , Pt = kt(jt, Nt, xt("abbr,accesskey,align,alt,autoplay,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,controls,coords,datetime,default,dir,download,face,headers,height,hidden,hreflang,hspace,ismap,itemscope,itemprop,kind,label,lang,language,loop,media,muted,nohref,nowrap,open,preload,rel,rev,role,rows,rowspan,rules,scope,scrolling,shape,size,sizes,span,srclang,start,summary,tabindex,target,title,translate,type,usemap,valign,value,vspace,width"), xt("aria-activedescendant,aria-atomic,aria-autocomplete,aria-busy,aria-checked,aria-colcount,aria-colindex,aria-colspan,aria-controls,aria-current,aria-describedby,aria-details,aria-disabled,aria-dropeffect,aria-errormessage,aria-expanded,aria-flowto,aria-grabbed,aria-haspopup,aria-hidden,aria-invalid,aria-keyshortcuts,aria-label,aria-labelledby,aria-level,aria-live,aria-modal,aria-multiline,aria-multiselectable,aria-orientation,aria-owns,aria-placeholder,aria-posinset,aria-pressed,aria-readonly,aria-relevant,aria-required,aria-roledescription,aria-rowcount,aria-rowindex,aria-rowspan,aria-selected,aria-setsize,aria-sort,aria-valuemax,aria-valuemin,aria-valuenow,aria-valuetext"))
          , Mt = xt("script,style,template");
        class Lt {
            constructor() {
                this.sanitizedSomething = !1,
                this.buf = []
            }
            sanitizeChildren(e) {
                let t = e.firstChild
                  , n = !0;
                for (; t; )
                    if (t.nodeType === Node.ELEMENT_NODE ? n = this.startElement(t) : t.nodeType === Node.TEXT_NODE ? this.chars(t.nodeValue) : this.sanitizedSomething = !0,
                    n && t.firstChild)
                        t = t.firstChild;
                    else
                        for (; t; ) {
                            t.nodeType === Node.ELEMENT_NODE && this.endElement(t);
                            let e = this.checkClobberedElement(t, t.nextSibling);
                            if (e) {
                                t = e;
                                break
                            }
                            t = this.checkClobberedElement(t, t.parentNode)
                        }
                return this.buf.join("")
            }
            startElement(e) {
                const t = e.nodeName.toLowerCase();
                if (!Rt.hasOwnProperty(t))
                    return this.sanitizedSomething = !0,
                    !Mt.hasOwnProperty(t);
                this.buf.push("<"),
                this.buf.push(t);
                const n = e.attributes;
                for (let s = 0; s < n.length; s++) {
                    const e = n.item(s)
                      , t = e.name
                      , i = t.toLowerCase();
                    if (!Pt.hasOwnProperty(i)) {
                        this.sanitizedSomething = !0;
                        continue
                    }
                    let o = e.value;
                    jt[i] && (o = Tt(o)),
                    Nt[i] && (r = o,
                    o = (r = String(r)).split(",").map(e => Tt(e.trim())).join(", ")),
                    this.buf.push(" ", t, '="', zt(o), '"')
                }
                var r;
                return this.buf.push(">"),
                !0
            }
            endElement(e) {
                const t = e.nodeName.toLowerCase();
                Rt.hasOwnProperty(t) && !Ot.hasOwnProperty(t) && (this.buf.push("</"),
                this.buf.push(t),
                this.buf.push(">"))
            }
            chars(e) {
                this.buf.push(zt(e))
            }
            checkClobberedElement(e, t) {
                if (t && (e.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY) === Node.DOCUMENT_POSITION_CONTAINED_BY)
                    throw new Error(`Failed to sanitize html because the element is clobbered: ${e.outerHTML}`);
                return t
            }
        }
        const Ft = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g
          , Ut = /([^\#-~ |!])/g;
        function zt(e) {
            return e.replace(/&/g, "&amp;").replace(Ft, function(e) {
                return "&#" + (1024 * (e.charCodeAt(0) - 55296) + (e.charCodeAt(1) - 56320) + 65536) + ";"
            }).replace(Ut, function(e) {
                return "&#" + e.charCodeAt(0) + ";"
            }).replace(/</g, "&lt;").replace(/>/g, "&gt;")
        }
        let Ht;
        function Bt(e, t) {
            let n = null;
            try {
                Ht = Ht || new Et(e);
                let r = t ? String(t) : "";
                n = Ht.getInertBodyElement(r);
                let s = 5
                  , i = r;
                do {
                    if (0 === s)
                        throw new Error("Failed to sanitize html because the input is unstable");
                    s--,
                    r = i,
                    i = n.innerHTML,
                    n = Ht.getInertBodyElement(r)
                } while (r !== i);
                const o = new Lt
                  , a = o.sanitizeChildren(Vt(n) || n);
                return _t() && o.sanitizedSomething && console.warn("WARNING: sanitizing HTML stripped some content, see http://g.co/ng/security#xss"),
                a
            } finally {
                if (n) {
                    const e = Vt(n) || n;
                    for (; e.firstChild; )
                        e.removeChild(e.firstChild)
                }
            }
        }
        function Vt(e) {
            return "content"in e && function(e) {
                return e.nodeType === Node.ELEMENT_NODE && "TEMPLATE" === e.nodeName
            }(e) ? e.content : null
        }
        const $t = function() {
            var e = {
                NONE: 0,
                HTML: 1,
                STYLE: 2,
                SCRIPT: 3,
                URL: 4,
                RESOURCE_URL: 5
            };
            return e[e.NONE] = "NONE",
            e[e.HTML] = "HTML",
            e[e.STYLE] = "STYLE",
            e[e.SCRIPT] = "SCRIPT",
            e[e.URL] = "URL",
            e[e.RESOURCE_URL] = "RESOURCE_URL",
            e
        }();
        class qt {
        }
        const Qt = new RegExp("^([-,.\"'%_!# a-zA-Z0-9]+|(?:(?:matrix|translate|scale|rotate|skew|perspective)(?:X|Y|Z|3d)?|(?:rgb|hsl)a?|(?:repeating-)?(?:linear|radial)-gradient|(?:calc|attr))\\([-0-9.%, #a-zA-Z]+\\))$","g")
          , Gt = /^url\(([^)]+)\)$/;
        function Kt(e) {
            if (!(e = String(e).trim()))
                return "";
            const t = e.match(Gt);
            return t && Tt(t[1]) === t[1] || e.match(Qt) && function(e) {
                let t = !0
                  , n = !0;
                for (let r = 0; r < e.length; r++) {
                    const s = e.charAt(r);
                    "'" === s && n ? t = !t : '"' === s && t && (n = !n)
                }
                return t && n
            }(e) ? e : (_t() && console.warn(`WARNING: sanitizing unsafe style value ${e} (see http://g.co/ng/security#xss).`),
            "unsafe")
        }
        const Wt = /([A-Z])/g;
        function Zt(e) {
            try {
                return null != e ? e.toString().slice(0, 30) : e
            } catch (t) {
                return "[ERROR] Exception while trying to serialize the value"
            }
        }
        const Yt = 1
          , Jt = 0
          , Xt = null
          , en = 1;
        let tn = [];
        function nn(e, t, n, r, s, i, o, a, c) {
            Ye(e) || (o ? function(e, t, n, r, s) {
                tn.unshift(e, t, n, r, s)
            }(e, n, r, s, c) : (tn.length && rn(),
            sn(e, n, r, s, c)));
            const l = a || et(t[s], i);
            return l && (t[s] = i),
            l
        }
        function rn() {
            let e = 0;
            for (; e < tn.length; )
                sn(tn[e++], tn[e++], tn[e++], tn[e++], tn[e++]);
            tn.length = 0
        }
        function sn(e, t, n, r, s) {
            let i = !1;
            if (n) {
                let o = !1
                  , a = Xe(e);
                for (; a < e.length; ) {
                    const i = Ke(e, a)
                      , c = Ve(e, a);
                    if (o = n <= c) {
                        n < c && on(e, a, n, s),
                        an(e, !1, a, r, t);
                        break
                    }
                    a += 3 + i
                }
                o || (on(e, e.length, n, s),
                an(e, !1, a, r, t),
                i = !0)
            } else
                an(e, !0, 3, r, t),
                i = !0;
            return i
        }
        function on(e, t, n, r) {
            e.splice(t, 0, r ? 1 : 0, en, n, Xt),
            Ge(e, t, Yt)
        }
        function an(e, t, n, r, s) {
            const i = n + 3;
            let o = i + Ke(e, n);
            if (t || o--,
            "number" == typeof r) {
                for (let t = i; t <= o; t++)
                    if (e[t] === r)
                        return;
                e.splice(o, 0, r),
                e[n + 1]++,
                Ge(e, n, Qe(e, n) | 1 << s)
            } else
                null !== r && null == e[o] && (e[o] = r)
        }
        function cn(e, t, n, r, s, i, o, a) {
            return s && r && (function(e) {
                if (!Ye(e)) {
                    const t = st(e);
                    t && function(e, t) {
                        for (let n = 1; n < t.length; n += 2) {
                            const r = ct(t, n);
                            r && sn(e, -1, ot(t, n), r, !1)
                        }
                    }(e, t),
                    function(e) {
                        Be(e, 1 | He(e))
                    }(e)
                }
            }(r),
            function(e, t) {
                return e && t > Ee
            }(r, i)) ? (function(e, t, n, r, s, i, o) {
                const a = !0 === (c = s) ? -1 : !1 === c ? 0 : c;
                var c;
                const l = ln
                  , u = (a & Qe(e, 3)) > 0 ? 1 : 0;
                let h = Xe(e);
                for (; h < e.length; ) {
                    const s = Ke(e, h);
                    if (a & Qe(e, h)) {
                        let a = !1;
                        const c = Ve(e, h)
                          , d = s - 1
                          , f = We(e, h, d);
                        for (let s = 0; s < d; s++) {
                            const l = We(e, h, s)
                              , u = r[l];
                            if (tt(u)) {
                                i(t, n, c, o && qe(e, h) ? o(c, u, 2) : u, l),
                                a = !0;
                                break
                            }
                        }
                        if (l) {
                            const s = l(e, t, n, r, i, o, u | (a ? 4 : 2), c, f);
                            a = a || s
                        }
                        a || i(t, n, c, f)
                    }
                    h += 3 + s
                }
                l && l(e, t, n, r, i, o, u)
            }(r, e, t, n, i, o, a),
            !0) : s
        }
        let ln = null;
        const un = (e, t, n, r) => {
            const s = t.style;
            r ? (r = r.toString(),
            e && ut(e) ? e.setStyle(t, n, r, lt.DashCase) : s && s.setProperty(n, r)) : e && ut(e) ? e.removeStyle(t, n, lt.DashCase) : s && s.removeProperty(n)
        }
          , hn = (e, t, n, r) => {
            if ("" !== n) {
                const s = t.classList;
                r ? e && ut(e) ? e.addClass(t, n) : s && s.add(n) : e && ut(e) ? e.removeClass(t, n) : s && s.remove(n)
            }
        }
          , dn = {}
          , fn = (e, t, n, r, s, i, o, a, c) => {
            let l = !1;
            if (Ke(e, 3)) {
                let u = !0;
                const h = !a;
                h && -2 & o && (u = !1,
                l = !0),
                u && (l = function e(t, n, r, s, i, o, a, c, l, u) {
                    let h = !1;
                    if (l < Ke(t, 3)) {
                        const d = We(t, 3, l)
                          , f = s[d];
                        let p = function(e) {
                            return e >= gn.length && gn.push(1),
                            gn[e]
                        }(l);
                        for (; p < f.length; ) {
                            const m = ot(f, p)
                              , g = c && m > c
                              , b = !g && m === c
                              , y = ct(f, p)
                              , v = tt(y);
                            let _ = e(t, n, r, s, i, o, g ? a : pn(a, v, b), g ? c : m, l + 1, u);
                            if (g) {
                                h || (h = _);
                                break
                            }
                            if (!_ && mn(a, b)) {
                                const e = b && !v
                                  , t = e ? u : y
                                  , s = e ? d : null;
                                i(n, r, m, o ? o(m, t, 3) : t, s),
                                _ = !0
                            }
                            h = _ && b,
                            p += 2
                        }
                        if (gn[l] = p,
                        1 === f.length || !c)
                            return e(t, n, r, s, i, o, a, c, l + 1, u)
                    }
                    return h
                }(e, t, n, r, s, i, o, a || null, 0, c || null)),
                h && function() {
                    for (let e = 0; e < gn.length; e++)
                        gn[e] = 1
                }()
            }
            return l
        }
        ;
        function pn(e, t, n) {
            let r = e;
            return t || 4 & e || !(n || 1 & e) ? (r |= 4,
            r &= -3) : (r |= 2,
            r &= -5),
            r
        }
        function mn(e, t) {
            let n = (1 & e) > 0;
            return n ? 4 & e && t && (n = !1) : 2 & e && (n = t),
            n
        }
        const gn = [];
        function bn(e, t, n, r) {
            for (let s = 1; s < e.length; s += 2) {
                const i = ot(e, s);
                if (t <= i) {
                    let o = !1;
                    if (i === t) {
                        const t = e[s];
                        !r && tt(t) || (o = !0,
                        at(e, s, n))
                    } else
                        o = !0,
                        e.splice(s, 0, t, n);
                    return o
                }
            }
            return e.push(t, n),
            !0
        }
        let yn = ( () => {
            class e {
            }
            return e.__NG_ELEMENT_ID__ = () => vn(),
            e
        }
        )();
        const vn = (...e) => {}
          , _n = new P("The presence of this token marks an injector as being the root injector.")
          , wn = function(e, t, n) {
            return new On(e,t,n)
        };
        let En = ( () => {
            class e {
                static create(e, t) {
                    return Array.isArray(e) ? wn(e, t, "") : wn(e.providers, e.parent, e.name || "")
                }
            }
            return e.THROW_IF_NOT_FOUND = L,
            e.NULL = new W,
            e.ngInjectableDef = S({
                token: e,
                providedIn: "any",
                factory: () => G(M)
            }),
            e.__NG_ELEMENT_ID__ = -1,
            e
        }
        )();
        const Sn = function(e) {
            return e
        }
          , Cn = []
          , Tn = Sn
          , xn = function() {
            return Array.prototype.slice.call(arguments)
        }
          , kn = "ɵ";
        class On {
            constructor(e, t=En.NULL, n=null) {
                this.parent = t,
                this.source = n;
                const r = this._records = new Map;
                r.set(En, {
                    token: En,
                    fn: Sn,
                    deps: Cn,
                    value: this,
                    useNew: !1
                }),
                r.set(M, {
                    token: M,
                    fn: Sn,
                    deps: Cn,
                    value: this,
                    useNew: !1
                }),
                function e(t, n) {
                    if (n)
                        if ((n = I(n))instanceof Array)
                            for (let r = 0; r < n.length; r++)
                                e(t, n[r]);
                        else {
                            if ("function" == typeof n)
                                throw An("Function/Class not supported", n);
                            if (!n || "object" != typeof n || !n.provide)
                                throw An("Unexpected provider", n);
                            {
                                let e = I(n.provide);
                                const r = function(e) {
                                    const t = function(e) {
                                        let t = Cn;
                                        const n = e.deps;
                                        if (n && n.length) {
                                            t = [];
                                            for (let e = 0; e < n.length; e++) {
                                                let r = 6
                                                  , s = I(n[e]);
                                                if (s instanceof Array)
                                                    for (let e = 0, t = s; e < t.length; e++) {
                                                        const n = t[e];
                                                        n instanceof y || n == y ? r |= 1 : n instanceof _ || n == _ ? r &= -3 : n instanceof v || n == v ? r &= -5 : s = n instanceof b ? n.token : I(n)
                                                    }
                                                t.push({
                                                    token: s,
                                                    options: r
                                                })
                                            }
                                        } else if (e.useExisting)
                                            t = [{
                                                token: I(e.useExisting),
                                                options: 6
                                            }];
                                        else if (!(n || V in e))
                                            throw An("'deps' required", e);
                                        return t
                                    }(e);
                                    let n = Sn
                                      , r = Cn
                                      , s = !1
                                      , i = I(e.provide);
                                    if (V in e)
                                        r = e.useValue;
                                    else if (e.useFactory)
                                        n = e.useFactory;
                                    else if (e.useExisting)
                                        ;
                                    else if (e.useClass)
                                        s = !0,
                                        n = I(e.useClass);
                                    else {
                                        if ("function" != typeof i)
                                            throw An("StaticProvider does not have [useValue|useFactory|useExisting|useClass] or [provide] is not newable", e);
                                        s = !0,
                                        n = i
                                    }
                                    return {
                                        deps: t,
                                        fn: n,
                                        useNew: s,
                                        value: r
                                    }
                                }(n);
                                if (!0 === n.multi) {
                                    let r = t.get(e);
                                    if (r) {
                                        if (r.fn !== xn)
                                            throw In(e)
                                    } else
                                        t.set(e, r = {
                                            token: n.provide,
                                            deps: [],
                                            useNew: !1,
                                            fn: xn,
                                            value: Cn
                                        });
                                    r.deps.push({
                                        token: e = n,
                                        options: 6
                                    })
                                }
                                const s = t.get(e);
                                if (s && s.fn == xn)
                                    throw In(e);
                                t.set(e, r)
                            }
                        }
                }(r, e)
            }
            get(e, t, n=w.Default) {
                const r = this._records.get(e);
                try {
                    return function e(t, n, r, s, i, o) {
                        try {
                            return function(t, n, r, s, i, o) {
                                let a;
                                if (!n || o & w.SkipSelf)
                                    o & w.Self || (a = s.get(t, i, w.Default));
                                else {
                                    if ((a = n.value) == Tn)
                                        throw Error(kn + "Circular dependency");
                                    if (a === Cn) {
                                        n.value = Tn;
                                        let t = void 0
                                          , i = n.useNew
                                          , o = n.fn
                                          , c = n.deps
                                          , l = Cn;
                                        if (c.length) {
                                            l = [];
                                            for (let t = 0; t < c.length; t++) {
                                                const n = c[t]
                                                  , i = n.options
                                                  , o = 2 & i ? r.get(n.token) : void 0;
                                                l.push(e(n.token, o, r, o || 4 & i ? s : En.NULL, 1 & i ? null : En.THROW_IF_NOT_FOUND, w.Default))
                                            }
                                        }
                                        n.value = a = i ? new o(...l) : o.apply(t, l)
                                    }
                                }
                                return a
                            }(t, n, r, s, i, o)
                        } catch (a) {
                            throw a instanceof Error || (a = new Error(a)),
                            (a[F] = a[F] || []).unshift(t),
                            n && n.value == Tn && (n.value = Cn),
                            a
                        }
                    }(e, r, this._records, this.parent, t, n)
                } catch (s) {
                    return function(e, t, n, r) {
                        const s = e[F];
                        throw t[B] && s.unshift(t[B]),
                        e.message = Z("\n" + e.message, s, "StaticInjectorError", r),
                        e[U] = s,
                        e[F] = null,
                        e
                    }(s, e, 0, this.source)
                }
            }
            toString() {
                const e = [];
                return this._records.forEach( (t, n) => e.push(x(n))),
                `StaticInjector[${e.join(", ")}]`
            }
        }
        function In(e) {
            return An("Cannot mix multi providers and regular providers", e)
        }
        function An(e, t) {
            return new Error(Z(e, t, "StaticInjectorError"))
        }
        const Dn = new P("AnalyzeForEntryComponents");
        function Rn(e) {
            const t = ke()
              , n = t[pe];
            n.firstTemplatePass && (function(e, t, n) {
                const r = e.expandoInstructions
                  , s = r.length;
                s >= 2 && r[s - 2] === t.hostBindings ? r[s - 1] = r[s - 1] + n : r.push(t.hostBindings, n)
            }(n, xe, e),
            function(e, t, n) {
                for (let r = 0; r < n; r++)
                    t.push(dn),
                    e.blueprint.push(dn),
                    e.data.push(null)
            }(n, t, e))
        }
        let jn = null;
        function Nn() {
            if (!jn) {
                const e = N.Symbol;
                if (e && e.iterator)
                    jn = e.iterator;
                else {
                    const e = Object.getOwnPropertyNames(Map.prototype);
                    for (let t = 0; t < e.length; ++t) {
                        const n = e[t];
                        "entries" !== n && "size" !== n && Map.prototype[n] === Map.prototype.entries && (jn = n)
                    }
                }
            }
            return jn
        }
        function Pn(e, t) {
            return e === t || "number" == typeof e && "number" == typeof t && isNaN(e) && isNaN(t)
        }
        function Mn(e, t) {
            const n = Fn(e)
              , r = Fn(t);
            if (n && r)
                return function(e, t, n) {
                    const r = e[Nn()]()
                      , s = t[Nn()]();
                    for (; ; ) {
                        const e = r.next()
                          , t = s.next();
                        if (e.done && t.done)
                            return !0;
                        if (e.done || t.done)
                            return !1;
                        if (!n(e.value, t.value))
                            return !1
                    }
                }(e, t, Mn);
            {
                const s = e && ("object" == typeof e || "function" == typeof e)
                  , i = t && ("object" == typeof t || "function" == typeof t);
                return !(n || !s || r || !i) || Pn(e, t)
            }
        }
        class Ln {
            constructor(e) {
                this.wrapped = e
            }
            static wrap(e) {
                return new Ln(e)
            }
            static unwrap(e) {
                return Ln.isWrapped(e) ? e.wrapped : e
            }
            static isWrapped(e) {
                return e instanceof Ln
            }
        }
        function Fn(e) {
            return !!Un(e) && (Array.isArray(e) || !(e instanceof Map) && Nn()in e)
        }
        function Un(e) {
            return null !== e && ("function" == typeof e || "object" == typeof e)
        }
        function zn() {
            var e, t;
            ke()[pe].firstTemplatePass && (e = Oe,
            t = Qn(),
            ze(Kn(e), t),
            ze(Gn(e), t))
        }
        function Hn(e) {
            const t = Pe()
              , n = ke()
              , r = Te(t, n)
              , s = Gn(r)
              , i = Qn()
              , o = n[me]++;
            !i && function(e) {
                return 0 != (16 & e.flags)
            }(r) && e !== dn && ($n(s, n, r, o, e, !1),
            e = dn),
            Vn(t, s, o, e, !1, Zn())
        }
        function Bn(e) {
            !function(e, t) {
                const n = ke()
                  , r = Te(e, n)
                  , s = Kn(r)
                  , i = Qn()
                  , o = n[me]++;
                !i && function(e) {
                    return 0 != (8 & e.flags)
                }(r) && t !== dn && ($n(s, n, r, o, t, !0),
                t = dn),
                Vn(e, s, o, t, !0, Zn())
            }(Pe(), e)
        }
        function Vn(e, t, n, r, s, i) {
            ln = fn;
            const o = ke();
            let a = !1;
            if (r !== dn) {
                const c = Ce(Te(e, o), o)
                  , l = o[n];
                a = et(l, r);
                const u = function(e, t, n) {
                    const r = Array.isArray(e) ? e : [null];
                    r[0] = t || null;
                    for (let a = 1; a < r.length; a += 2)
                        at(r, a, null);
                    let s, i = null, o = !1;
                    if ("string" == typeof t ? t.length && (i = t.split(/\s+/),
                    o = !0) : (i = t ? Object.keys(t) : null,
                    s = t),
                    i)
                        for (let a = 0; a < i.length; a++) {
                            const e = i[a];
                            bn(r, n ? rt(e) : e, !!o || s[e], !0)
                        }
                    return r
                }(l, r, !s);
                s ? function(e, t, n, r, s, i, o, a) {
                    const l = Se(c, Je(e))
                      , u = Jt;
                    !nn(e, t, u, null, s, i, o, a, !1) && !a || (l.classesBitMask |= 1 << u)
                }(t, o, 0, 0, n, u, i, a) : function(e, t, n, r, s, i, o, a, c) {
                    const l = Se(n, Je(e))
                      , u = Jt;
                    !nn(e, t, u, null, s, i, a, c, !0) && !c || (l.stylesBitMask |= 1 << u)
                }(t, o, c, 0, n, u, Me(), i, a)
            }
            return a
        }
        function $n(e, t, n, r, s, i) {
            t[r] !== s && ((s || Ye(e)) && function(e, t, n) {
                const r = e[pe];
                for (let s = 0; s < t.length; ) {
                    const i = t[s++]
                      , o = t[s++]
                      , a = t[s++]
                      , c = e[i]
                      , l = r.data[i];
                    l.setInput ? l.setInput(c, n, o, a) : c[a] = n
                }
            }(t, n.inputs[i ? "class" : "style"], function(e, t, n) {
                let r = t;
                var s;
                return e.length > 0 && (r = n ? nt(e, ((s = t) && "string" != typeof s && (s = Object.keys(s).join(" ")),
                s || "")) : nt(e, function(e) {
                    let t = "";
                    if (e) {
                        const n = Object.keys(e);
                        for (let r = 0; r < n.length; r++) {
                            const s = n[r];
                            t = nt(t, `${s}:${e[s]}`, ";")
                        }
                    }
                    return t
                }(t), ";")),
                r
            }(function(e) {
                const t = st(e);
                return t && t[0] || ""
            }(e), s, i)),
            t[r] = s)
        }
        function qn() {
            const e = Pe()
              , t = ke()
              , n = Te(e, t)
              , r = function(e, t) {
                return 3 === e.type ? t[ge] : null
            }(n, t)
              , s = Ce(n, t)
              , i = Qn()
              , o = Me();
            (function(e, t, n, r, s, i, o) {
                const a = n ? Je(n) : !!r && Je(r)
                  , c = Ze(n, i)
                  , l = Ze(r, i);
                tn.length && (c || l) && rn();
                const u = Se(s, a)
                  , h = cn(e, s, t, n, c, u.classesBitMask, hn, null)
                  , d = cn(e, s, t, r, l, u.stylesBitMask, un, o);
                h && d ? (ye = null,
                _e = null,
                a && function(e) {
                    ve.delete(e)
                }(s)) : a && function(e, t) {
                    ve.set(e, t)
                }(s, u)
            }
            )(r, t, Kn(n), Gn(n), s, i, o),
            Ae = null
        }
        function Qn() {
            return De + Re
        }
        function Gn(e) {
            return Wn(e, !1)
        }
        function Kn(e) {
            return Wn(e, !0)
        }
        function Wn(e, t) {
            let n = t ? e.classes : e.styles;
            return it(n) || (n = [n || [""], 0, Ue, 1, 0, Fe],
            t ? e.classes = n : e.styles = n),
            n
        }
        function Zn() {
            return je > 0
        }
        function Yn(e) {
            return !!e && "function" == typeof e.then
        }
        function Jn(e) {
            return !!e && "function" == typeof e.subscribe
        }
        class Xn {
            constructor(e, t, n) {
                this.previousValue = e,
                this.currentValue = t,
                this.firstChange = n
            }
            isFirstChange() {
                return this.firstChange
            }
        }
        class er {
        }
        class tr {
        }
        function nr(e) {
            const t = Error(`No component factory found for ${x(e)}. Did you add it to @NgModule.entryComponents?`);
            return t[rr] = e,
            t
        }
        const rr = "ngComponent";
        class sr {
            resolveComponentFactory(e) {
                throw nr(e)
            }
        }
        let ir = ( () => {
            class e {
            }
            return e.NULL = new sr,
            e
        }
        )();
        class or {
            constructor(e, t, n) {
                this._parent = t,
                this._ngModule = n,
                this._factories = new Map;
                for (let r = 0; r < e.length; r++) {
                    const t = e[r];
                    this._factories.set(t.componentType, t)
                }
            }
            resolveComponentFactory(e) {
                let t = this._factories.get(e);
                if (!t && this._parent && (t = this._parent.resolveComponentFactory(e)),
                !t)
                    throw nr(e);
                return new ar(t,this._ngModule)
            }
        }
        class ar extends tr {
            constructor(e, t) {
                super(),
                this.factory = e,
                this.ngModule = t,
                this.selector = e.selector,
                this.componentType = e.componentType,
                this.ngContentSelectors = e.ngContentSelectors,
                this.inputs = e.inputs,
                this.outputs = e.outputs
            }
            create(e, t, n, r) {
                return this.factory.create(e, t, n, r || this.ngModule)
            }
        }
        function cr(...e) {}
        let lr = ( () => {
            class e {
                constructor(e) {
                    this.nativeElement = e
                }
            }
            return e.__NG_ELEMENT_ID__ = () => ur(e),
            e
        }
        )();
        const ur = cr;
        class hr {
        }
        class dr {
        }
        const fr = function() {
            var e = {
                Important: 1,
                DashCase: 2
            };
            return e[e.Important] = "Important",
            e[e.DashCase] = "DashCase",
            e
        }();
        let pr = ( () => {
            class e {
            }
            return e.__NG_ELEMENT_ID__ = () => mr(),
            e
        }
        )();
        const mr = cr;
        class gr {
            constructor(e) {
                this.full = e,
                this.major = e.split(".")[0],
                this.minor = e.split(".")[1],
                this.patch = e.split(".").slice(2).join(".")
            }
        }
        const br = new gr("8.2.4");
        class yr {
            constructor() {}
            supports(e) {
                return Fn(e)
            }
            create(e) {
                return new _r(e)
            }
        }
        const vr = (e, t) => t;
        class _r {
            constructor(e) {
                this.length = 0,
                this._linkedRecords = null,
                this._unlinkedRecords = null,
                this._previousItHead = null,
                this._itHead = null,
                this._itTail = null,
                this._additionsHead = null,
                this._additionsTail = null,
                this._movesHead = null,
                this._movesTail = null,
                this._removalsHead = null,
                this._removalsTail = null,
                this._identityChangesHead = null,
                this._identityChangesTail = null,
                this._trackByFn = e || vr
            }
            forEachItem(e) {
                let t;
                for (t = this._itHead; null !== t; t = t._next)
                    e(t)
            }
            forEachOperation(e) {
                let t = this._itHead
                  , n = this._removalsHead
                  , r = 0
                  , s = null;
                for (; t || n; ) {
                    const i = !n || t && t.currentIndex < Cr(n, r, s) ? t : n
                      , o = Cr(i, r, s)
                      , a = i.currentIndex;
                    if (i === n)
                        r--,
                        n = n._nextRemoved;
                    else if (t = t._next,
                    null == i.previousIndex)
                        r++;
                    else {
                        s || (s = []);
                        const e = o - r
                          , t = a - r;
                        if (e != t) {
                            for (let n = 0; n < e; n++) {
                                const r = n < s.length ? s[n] : s[n] = 0
                                  , i = r + n;
                                t <= i && i < e && (s[n] = r + 1)
                            }
                            s[i.previousIndex] = t - e
                        }
                    }
                    o !== a && e(i, o, a)
                }
            }
            forEachPreviousItem(e) {
                let t;
                for (t = this._previousItHead; null !== t; t = t._nextPrevious)
                    e(t)
            }
            forEachAddedItem(e) {
                let t;
                for (t = this._additionsHead; null !== t; t = t._nextAdded)
                    e(t)
            }
            forEachMovedItem(e) {
                let t;
                for (t = this._movesHead; null !== t; t = t._nextMoved)
                    e(t)
            }
            forEachRemovedItem(e) {
                let t;
                for (t = this._removalsHead; null !== t; t = t._nextRemoved)
                    e(t)
            }
            forEachIdentityChange(e) {
                let t;
                for (t = this._identityChangesHead; null !== t; t = t._nextIdentityChange)
                    e(t)
            }
            diff(e) {
                if (null == e && (e = []),
                !Fn(e))
                    throw new Error(`Error trying to diff '${x(e)}'. Only arrays and iterables are allowed`);
                return this.check(e) ? this : null
            }
            onDestroy() {}
            check(e) {
                this._reset();
                let t, n, r, s = this._itHead, i = !1;
                if (Array.isArray(e)) {
                    this.length = e.length;
                    for (let t = 0; t < this.length; t++)
                        r = this._trackByFn(t, n = e[t]),
                        null !== s && Pn(s.trackById, r) ? (i && (s = this._verifyReinsertion(s, n, r, t)),
                        Pn(s.item, n) || this._addIdentityChange(s, n)) : (s = this._mismatch(s, n, r, t),
                        i = !0),
                        s = s._next
                } else
                    t = 0,
                    function(e, t) {
                        if (Array.isArray(e))
                            for (let n = 0; n < e.length; n++)
                                t(e[n]);
                        else {
                            const n = e[Nn()]();
                            let r;
                            for (; !(r = n.next()).done; )
                                t(r.value)
                        }
                    }(e, e => {
                        r = this._trackByFn(t, e),
                        null !== s && Pn(s.trackById, r) ? (i && (s = this._verifyReinsertion(s, e, r, t)),
                        Pn(s.item, e) || this._addIdentityChange(s, e)) : (s = this._mismatch(s, e, r, t),
                        i = !0),
                        s = s._next,
                        t++
                    }
                    ),
                    this.length = t;
                return this._truncate(s),
                this.collection = e,
                this.isDirty
            }
            get isDirty() {
                return null !== this._additionsHead || null !== this._movesHead || null !== this._removalsHead || null !== this._identityChangesHead
            }
            _reset() {
                if (this.isDirty) {
                    let e, t;
                    for (e = this._previousItHead = this._itHead; null !== e; e = e._next)
                        e._nextPrevious = e._next;
                    for (e = this._additionsHead; null !== e; e = e._nextAdded)
                        e.previousIndex = e.currentIndex;
                    for (this._additionsHead = this._additionsTail = null,
                    e = this._movesHead; null !== e; e = t)
                        e.previousIndex = e.currentIndex,
                        t = e._nextMoved;
                    this._movesHead = this._movesTail = null,
                    this._removalsHead = this._removalsTail = null,
                    this._identityChangesHead = this._identityChangesTail = null
                }
            }
            _mismatch(e, t, n, r) {
                let s;
                return null === e ? s = this._itTail : (s = e._prev,
                this._remove(e)),
                null !== (e = null === this._linkedRecords ? null : this._linkedRecords.get(n, r)) ? (Pn(e.item, t) || this._addIdentityChange(e, t),
                this._moveAfter(e, s, r)) : null !== (e = null === this._unlinkedRecords ? null : this._unlinkedRecords.get(n, null)) ? (Pn(e.item, t) || this._addIdentityChange(e, t),
                this._reinsertAfter(e, s, r)) : e = this._addAfter(new wr(t,n), s, r),
                e
            }
            _verifyReinsertion(e, t, n, r) {
                let s = null === this._unlinkedRecords ? null : this._unlinkedRecords.get(n, null);
                return null !== s ? e = this._reinsertAfter(s, e._prev, r) : e.currentIndex != r && (e.currentIndex = r,
                this._addToMoves(e, r)),
                e
            }
            _truncate(e) {
                for (; null !== e; ) {
                    const t = e._next;
                    this._addToRemovals(this._unlink(e)),
                    e = t
                }
                null !== this._unlinkedRecords && this._unlinkedRecords.clear(),
                null !== this._additionsTail && (this._additionsTail._nextAdded = null),
                null !== this._movesTail && (this._movesTail._nextMoved = null),
                null !== this._itTail && (this._itTail._next = null),
                null !== this._removalsTail && (this._removalsTail._nextRemoved = null),
                null !== this._identityChangesTail && (this._identityChangesTail._nextIdentityChange = null)
            }
            _reinsertAfter(e, t, n) {
                null !== this._unlinkedRecords && this._unlinkedRecords.remove(e);
                const r = e._prevRemoved
                  , s = e._nextRemoved;
                return null === r ? this._removalsHead = s : r._nextRemoved = s,
                null === s ? this._removalsTail = r : s._prevRemoved = r,
                this._insertAfter(e, t, n),
                this._addToMoves(e, n),
                e
            }
            _moveAfter(e, t, n) {
                return this._unlink(e),
                this._insertAfter(e, t, n),
                this._addToMoves(e, n),
                e
            }
            _addAfter(e, t, n) {
                return this._insertAfter(e, t, n),
                this._additionsTail = null === this._additionsTail ? this._additionsHead = e : this._additionsTail._nextAdded = e,
                e
            }
            _insertAfter(e, t, n) {
                const r = null === t ? this._itHead : t._next;
                return e._next = r,
                e._prev = t,
                null === r ? this._itTail = e : r._prev = e,
                null === t ? this._itHead = e : t._next = e,
                null === this._linkedRecords && (this._linkedRecords = new Sr),
                this._linkedRecords.put(e),
                e.currentIndex = n,
                e
            }
            _remove(e) {
                return this._addToRemovals(this._unlink(e))
            }
            _unlink(e) {
                null !== this._linkedRecords && this._linkedRecords.remove(e);
                const t = e._prev
                  , n = e._next;
                return null === t ? this._itHead = n : t._next = n,
                null === n ? this._itTail = t : n._prev = t,
                e
            }
            _addToMoves(e, t) {
                return e.previousIndex === t ? e : (this._movesTail = null === this._movesTail ? this._movesHead = e : this._movesTail._nextMoved = e,
                e)
            }
            _addToRemovals(e) {
                return null === this._unlinkedRecords && (this._unlinkedRecords = new Sr),
                this._unlinkedRecords.put(e),
                e.currentIndex = null,
                e._nextRemoved = null,
                null === this._removalsTail ? (this._removalsTail = this._removalsHead = e,
                e._prevRemoved = null) : (e._prevRemoved = this._removalsTail,
                this._removalsTail = this._removalsTail._nextRemoved = e),
                e
            }
            _addIdentityChange(e, t) {
                return e.item = t,
                this._identityChangesTail = null === this._identityChangesTail ? this._identityChangesHead = e : this._identityChangesTail._nextIdentityChange = e,
                e
            }
        }
        class wr {
            constructor(e, t) {
                this.item = e,
                this.trackById = t,
                this.currentIndex = null,
                this.previousIndex = null,
                this._nextPrevious = null,
                this._prev = null,
                this._next = null,
                this._prevDup = null,
                this._nextDup = null,
                this._prevRemoved = null,
                this._nextRemoved = null,
                this._nextAdded = null,
                this._nextMoved = null,
                this._nextIdentityChange = null
            }
        }
        class Er {
            constructor() {
                this._head = null,
                this._tail = null
            }
            add(e) {
                null === this._head ? (this._head = this._tail = e,
                e._nextDup = null,
                e._prevDup = null) : (this._tail._nextDup = e,
                e._prevDup = this._tail,
                e._nextDup = null,
                this._tail = e)
            }
            get(e, t) {
                let n;
                for (n = this._head; null !== n; n = n._nextDup)
                    if ((null === t || t <= n.currentIndex) && Pn(n.trackById, e))
                        return n;
                return null
            }
            remove(e) {
                const t = e._prevDup
                  , n = e._nextDup;
                return null === t ? this._head = n : t._nextDup = n,
                null === n ? this._tail = t : n._prevDup = t,
                null === this._head
            }
        }
        class Sr {
            constructor() {
                this.map = new Map
            }
            put(e) {
                const t = e.trackById;
                let n = this.map.get(t);
                n || (n = new Er,
                this.map.set(t, n)),
                n.add(e)
            }
            get(e, t) {
                const n = this.map.get(e);
                return n ? n.get(e, t) : null
            }
            remove(e) {
                const t = e.trackById;
                return this.map.get(t).remove(e) && this.map.delete(t),
                e
            }
            get isEmpty() {
                return 0 === this.map.size
            }
            clear() {
                this.map.clear()
            }
        }
        function Cr(e, t, n) {
            const r = e.previousIndex;
            if (null === r)
                return r;
            let s = 0;
            return n && r < n.length && (s = n[r]),
            r + t + s
        }
        class Tr {
            constructor() {}
            supports(e) {
                return e instanceof Map || Un(e)
            }
            create() {
                return new xr
            }
        }
        class xr {
            constructor() {
                this._records = new Map,
                this._mapHead = null,
                this._appendAfter = null,
                this._previousMapHead = null,
                this._changesHead = null,
                this._changesTail = null,
                this._additionsHead = null,
                this._additionsTail = null,
                this._removalsHead = null,
                this._removalsTail = null
            }
            get isDirty() {
                return null !== this._additionsHead || null !== this._changesHead || null !== this._removalsHead
            }
            forEachItem(e) {
                let t;
                for (t = this._mapHead; null !== t; t = t._next)
                    e(t)
            }
            forEachPreviousItem(e) {
                let t;
                for (t = this._previousMapHead; null !== t; t = t._nextPrevious)
                    e(t)
            }
            forEachChangedItem(e) {
                let t;
                for (t = this._changesHead; null !== t; t = t._nextChanged)
                    e(t)
            }
            forEachAddedItem(e) {
                let t;
                for (t = this._additionsHead; null !== t; t = t._nextAdded)
                    e(t)
            }
            forEachRemovedItem(e) {
                let t;
                for (t = this._removalsHead; null !== t; t = t._nextRemoved)
                    e(t)
            }
            diff(e) {
                if (e) {
                    if (!(e instanceof Map || Un(e)))
                        throw new Error(`Error trying to diff '${x(e)}'. Only maps and objects are allowed`)
                } else
                    e = new Map;
                return this.check(e) ? this : null
            }
            onDestroy() {}
            check(e) {
                this._reset();
                let t = this._mapHead;
                if (this._appendAfter = null,
                this._forEach(e, (e, n) => {
                    if (t && t.key === n)
                        this._maybeAddToChanges(t, e),
                        this._appendAfter = t,
                        t = t._next;
                    else {
                        const r = this._getOrCreateRecordForKey(n, e);
                        t = this._insertBeforeOrAppend(t, r)
                    }
                }
                ),
                t) {
                    t._prev && (t._prev._next = null),
                    this._removalsHead = t;
                    for (let e = t; null !== e; e = e._nextRemoved)
                        e === this._mapHead && (this._mapHead = null),
                        this._records.delete(e.key),
                        e._nextRemoved = e._next,
                        e.previousValue = e.currentValue,
                        e.currentValue = null,
                        e._prev = null,
                        e._next = null
                }
                return this._changesTail && (this._changesTail._nextChanged = null),
                this._additionsTail && (this._additionsTail._nextAdded = null),
                this.isDirty
            }
            _insertBeforeOrAppend(e, t) {
                if (e) {
                    const n = e._prev;
                    return t._next = e,
                    t._prev = n,
                    e._prev = t,
                    n && (n._next = t),
                    e === this._mapHead && (this._mapHead = t),
                    this._appendAfter = e,
                    e
                }
                return this._appendAfter ? (this._appendAfter._next = t,
                t._prev = this._appendAfter) : this._mapHead = t,
                this._appendAfter = t,
                null
            }
            _getOrCreateRecordForKey(e, t) {
                if (this._records.has(e)) {
                    const n = this._records.get(e);
                    this._maybeAddToChanges(n, t);
                    const r = n._prev
                      , s = n._next;
                    return r && (r._next = s),
                    s && (s._prev = r),
                    n._next = null,
                    n._prev = null,
                    n
                }
                const n = new kr(e);
                return this._records.set(e, n),
                n.currentValue = t,
                this._addToAdditions(n),
                n
            }
            _reset() {
                if (this.isDirty) {
                    let e;
                    for (this._previousMapHead = this._mapHead,
                    e = this._previousMapHead; null !== e; e = e._next)
                        e._nextPrevious = e._next;
                    for (e = this._changesHead; null !== e; e = e._nextChanged)
                        e.previousValue = e.currentValue;
                    for (e = this._additionsHead; null != e; e = e._nextAdded)
                        e.previousValue = e.currentValue;
                    this._changesHead = this._changesTail = null,
                    this._additionsHead = this._additionsTail = null,
                    this._removalsHead = null
                }
            }
            _maybeAddToChanges(e, t) {
                Pn(t, e.currentValue) || (e.previousValue = e.currentValue,
                e.currentValue = t,
                this._addToChanges(e))
            }
            _addToAdditions(e) {
                null === this._additionsHead ? this._additionsHead = this._additionsTail = e : (this._additionsTail._nextAdded = e,
                this._additionsTail = e)
            }
            _addToChanges(e) {
                null === this._changesHead ? this._changesHead = this._changesTail = e : (this._changesTail._nextChanged = e,
                this._changesTail = e)
            }
            _forEach(e, t) {
                e instanceof Map ? e.forEach(t) : Object.keys(e).forEach(n => t(e[n], n))
            }
        }
        class kr {
            constructor(e) {
                this.key = e,
                this.previousValue = null,
                this.currentValue = null,
                this._nextPrevious = null,
                this._next = null,
                this._prev = null,
                this._nextAdded = null,
                this._nextRemoved = null,
                this._nextChanged = null
            }
        }
        let Or = ( () => {
            class e {
                constructor(e) {
                    this.factories = e
                }
                static create(t, n) {
                    if (null != n) {
                        const e = n.factories.slice();
                        t = t.concat(e)
                    }
                    return new e(t)
                }
                static extend(t) {
                    return {
                        provide: e,
                        useFactory: n => {
                            if (!n)
                                throw new Error("Cannot extend IterableDiffers without a parent injector");
                            return e.create(t, n)
                        }
                        ,
                        deps: [[e, new _, new y]]
                    }
                }
                find(e) {
                    const t = this.factories.find(t => t.supports(e));
                    if (null != t)
                        return t;
                    throw new Error(`Cannot find a differ supporting object '${e}' of type '${n = e,
                    n.name || typeof n}'`);
                    var n
                }
            }
            return e.ngInjectableDef = S({
                token: e,
                providedIn: "root",
                factory: () => new e([new yr])
            }),
            e
        }
        )()
          , Ir = ( () => {
            class e {
                constructor(e) {
                    this.factories = e
                }
                static create(t, n) {
                    if (n) {
                        const e = n.factories.slice();
                        t = t.concat(e)
                    }
                    return new e(t)
                }
                static extend(t) {
                    return {
                        provide: e,
                        useFactory: n => {
                            if (!n)
                                throw new Error("Cannot extend KeyValueDiffers without a parent injector");
                            return e.create(t, n)
                        }
                        ,
                        deps: [[e, new _, new y]]
                    }
                }
                find(e) {
                    const t = this.factories.find(t => t.supports(e));
                    if (t)
                        return t;
                    throw new Error(`Cannot find a differ supporting object '${e}'`)
                }
            }
            return e.ngInjectableDef = S({
                token: e,
                providedIn: "root",
                factory: () => new e([new Tr])
            }),
            e
        }
        )();
        const Ar = [new Tr]
          , Dr = new Or([new yr])
          , Rr = new Ir(Ar);
        let jr = ( () => {
            class e {
            }
            return e.__NG_ELEMENT_ID__ = () => Nr(e, lr),
            e
        }
        )();
        const Nr = cr;
        let Pr = ( () => {
            class e {
            }
            return e.__NG_ELEMENT_ID__ = () => Mr(e, lr),
            e
        }
        )();
        const Mr = cr;
        function Lr(e, t, n, r) {
            let s = `ExpressionChangedAfterItHasBeenCheckedError: Expression has changed after it was checked. Previous value: '${t}'. Current value: '${n}'.`;
            return r && (s += " It seems like the view has been created after its parent and its children have been dirty checked. Has it been created in a change detection hook ?"),
            function(e, t) {
                const n = new Error(e);
                return Fr(n, t),
                n
            }(s, e)
        }
        function Fr(e, t) {
            e[ht] = t,
            e[ft] = t.logError.bind(t)
        }
        function Ur(e) {
            return new Error(`ViewDestroyedError: Attempt to use a destroyed view: ${e}`)
        }
        function zr(e, t, n) {
            const r = e.state
              , s = 1792 & r;
            return s === t ? (e.state = -1793 & r | n,
            e.initIndex = -1,
            !0) : s === n
        }
        function Hr(e, t, n) {
            return (1792 & e.state) === t && e.initIndex <= n && (e.initIndex = n + 1,
            !0)
        }
        function Br(e, t) {
            return e.nodes[t]
        }
        function Vr(e, t) {
            return e.nodes[t]
        }
        function $r(e, t) {
            return e.nodes[t]
        }
        function qr(e, t) {
            return e.nodes[t]
        }
        function Qr(e, t) {
            return e.nodes[t]
        }
        const Gr = {
            setCurrentNode: void 0,
            createRootView: void 0,
            createEmbeddedView: void 0,
            createComponentView: void 0,
            createNgModuleRef: void 0,
            overrideProvider: void 0,
            overrideComponentView: void 0,
            clearOverrides: void 0,
            checkAndUpdateView: void 0,
            checkNoChangesView: void 0,
            destroyView: void 0,
            resolveDep: void 0,
            createDebugContext: void 0,
            handleEvent: void 0,
            updateDirectives: void 0,
            updateRenderer: void 0,
            dirtyParentQueries: void 0
        }
          , Kr = () => {}
          , Wr = new Map;
        function Zr(e) {
            let t = Wr.get(e);
            return t || (t = x(e) + "_" + Wr.size,
            Wr.set(e, t)),
            t
        }
        function Yr(e, t, n, r) {
            if (Ln.isWrapped(r)) {
                r = Ln.unwrap(r);
                const s = e.def.nodes[t].bindingIndex + n
                  , i = Ln.unwrap(e.oldValues[s]);
                e.oldValues[s] = new Ln(i)
            }
            return r
        }
        const Jr = "$$undefined"
          , Xr = "$$empty";
        function es(e) {
            return {
                id: Jr,
                styles: e.styles,
                encapsulation: e.encapsulation,
                data: e.data
            }
        }
        let ts = 0;
        function ns(e, t, n, r) {
            return !(!(2 & e.state) && Pn(e.oldValues[t.bindingIndex + n], r))
        }
        function rs(e, t, n, r) {
            return !!ns(e, t, n, r) && (e.oldValues[t.bindingIndex + n] = r,
            !0)
        }
        function ss(e, t, n, r) {
            const s = e.oldValues[t.bindingIndex + n];
            if (1 & e.state || !Mn(s, r)) {
                const i = t.bindings[n].name;
                throw Lr(Gr.createDebugContext(e, t.nodeIndex), `${i}: ${s}`, `${i}: ${r}`, 0 != (1 & e.state))
            }
        }
        function is(e) {
            let t = e;
            for (; t; )
                2 & t.def.flags && (t.state |= 8),
                t = t.viewContainerParent || t.parent
        }
        function os(e, t) {
            let n = e;
            for (; n && n !== t; )
                n.state |= 64,
                n = n.viewContainerParent || n.parent
        }
        function as(e, t, n, r) {
            try {
                return is(33554432 & e.def.nodes[t].flags ? Vr(e, t).componentView : e),
                Gr.handleEvent(e, t, n, r)
            } catch (s) {
                e.root.errorHandler.handleError(s)
            }
        }
        function cs(e) {
            return e.parent ? Vr(e.parent, e.parentNodeDef.nodeIndex) : null
        }
        function ls(e) {
            return e.parent ? e.parentNodeDef.parent : null
        }
        function us(e, t) {
            switch (201347067 & t.flags) {
            case 1:
                return Vr(e, t.nodeIndex).renderElement;
            case 2:
                return Br(e, t.nodeIndex).renderText
            }
        }
        function hs(e) {
            return !!e.parent && !!(32768 & e.parentNodeDef.flags)
        }
        function ds(e) {
            return !(!e.parent || 32768 & e.parentNodeDef.flags)
        }
        function fs(e) {
            return 1 << e % 32
        }
        function ps(e) {
            const t = {};
            let n = 0;
            const r = {};
            return e && e.forEach( ([e,s]) => {
                "number" == typeof e ? (t[e] = s,
                n |= fs(e)) : r[e] = s
            }
            ),
            {
                matchedQueries: t,
                references: r,
                matchedQueryIds: n
            }
        }
        function ms(e, t) {
            return e.map(e => {
                let n, r;
                return Array.isArray(e) ? [r,n] = e : (r = 0,
                n = e),
                n && ("function" == typeof n || "object" == typeof n) && t && Object.defineProperty(n, B, {
                    value: t,
                    configurable: !0
                }),
                {
                    flags: r,
                    token: n,
                    tokenKey: Zr(n)
                }
            }
            )
        }
        function gs(e, t, n) {
            let r = n.renderParent;
            return r ? 0 == (1 & r.flags) || 0 == (33554432 & r.flags) || r.element.componentRendererType && r.element.componentRendererType.encapsulation === ne.Native ? Vr(e, n.renderParent.nodeIndex).renderElement : void 0 : t
        }
        const bs = new WeakMap;
        function ys(e) {
            let t = bs.get(e);
            return t || ((t = e( () => Kr)).factory = e,
            bs.set(e, t)),
            t
        }
        function vs(e, t, n, r, s) {
            3 === t && (n = e.renderer.parentNode(us(e, e.def.lastRenderRootNode))),
            _s(e, t, 0, e.def.nodes.length - 1, n, r, s)
        }
        function _s(e, t, n, r, s, i, o) {
            for (let a = n; a <= r; a++) {
                const n = e.def.nodes[a];
                11 & n.flags && Es(e, n, t, s, i, o),
                a += n.childCount
            }
        }
        function ws(e, t, n, r, s, i) {
            let o = e;
            for (; o && !hs(o); )
                o = o.parent;
            const a = o.parent
              , c = ls(o)
              , l = c.nodeIndex + c.childCount;
            for (let u = c.nodeIndex + 1; u <= l; u++) {
                const e = a.def.nodes[u];
                e.ngContentIndex === t && Es(a, e, n, r, s, i),
                u += e.childCount
            }
            if (!a.parent) {
                const o = e.root.projectableNodes[t];
                if (o)
                    for (let t = 0; t < o.length; t++)
                        Ss(e, o[t], n, r, s, i)
            }
        }
        function Es(e, t, n, r, s, i) {
            if (8 & t.flags)
                ws(e, t.ngContent.index, n, r, s, i);
            else {
                const o = us(e, t);
                if (3 === n && 33554432 & t.flags && 48 & t.bindingFlags ? (16 & t.bindingFlags && Ss(e, o, n, r, s, i),
                32 & t.bindingFlags && Ss(Vr(e, t.nodeIndex).componentView, o, n, r, s, i)) : Ss(e, o, n, r, s, i),
                16777216 & t.flags) {
                    const o = Vr(e, t.nodeIndex).viewContainer._embeddedViews;
                    for (let e = 0; e < o.length; e++)
                        vs(o[e], n, r, s, i)
                }
                1 & t.flags && !t.element.name && _s(e, n, t.nodeIndex + 1, t.nodeIndex + t.childCount, r, s, i)
            }
        }
        function Ss(e, t, n, r, s, i) {
            const o = e.renderer;
            switch (n) {
            case 1:
                o.appendChild(r, t);
                break;
            case 2:
                o.insertBefore(r, t, s);
                break;
            case 3:
                o.removeChild(r, t);
                break;
            case 0:
                i.push(t)
            }
        }
        const Cs = /^:([^:]+):(.+)$/;
        function Ts(e) {
            if (":" === e[0]) {
                const t = e.match(Cs);
                return [t[1], t[2]]
            }
            return ["", e]
        }
        function xs(e) {
            let t = 0;
            for (let n = 0; n < e.length; n++)
                t |= e[n].flags;
            return t
        }
        const ks = new Object
          , Os = Zr(En)
          , Is = Zr(M)
          , As = Zr(Y);
        function Ds(e, t, n, r) {
            return n = I(n),
            {
                index: -1,
                deps: ms(r, x(t)),
                flags: e,
                token: t,
                value: n
            }
        }
        function Rs(e) {
            const t = {}
              , n = [];
            let r = !1;
            for (let s = 0; s < e.length; s++) {
                const i = e[s];
                i.token === _n && !0 === i.value && (r = !0),
                1073741824 & i.flags && n.push(i.token),
                i.index = s,
                t[Zr(i.token)] = i
            }
            return {
                factory: null,
                providersByKey: t,
                providers: e,
                modules: n,
                isRoot: r
            }
        }
        function js(e, t, n=En.THROW_IF_NOT_FOUND) {
            const r = Q(e);
            try {
                if (8 & t.flags)
                    return t.token;
                if (2 & t.flags && (n = null),
                1 & t.flags)
                    return e._parent.get(t.token, n);
                const o = t.tokenKey;
                switch (o) {
                case Os:
                case Is:
                case As:
                    return e
                }
                const a = e._def.providersByKey[o];
                let c;
                if (a) {
                    let t = e._providers[a.index];
                    return void 0 === t && (t = e._providers[a.index] = Ns(e, a)),
                    t === ks ? void 0 : t
                }
                if ((c = C(t.token)) && (s = e,
                null != (i = c).providedIn && (function(e, t) {
                    return e._def.modules.indexOf(i.providedIn) > -1
                }(s) || "root" === i.providedIn && s._def.isRoot))) {
                    const n = e._providers.length;
                    return e._def.providers[n] = e._def.providersByKey[t.tokenKey] = {
                        flags: 5120,
                        value: c.factory,
                        deps: [],
                        index: n,
                        token: t.token
                    },
                    e._providers[n] = ks,
                    e._providers[n] = Ns(e, e._def.providersByKey[t.tokenKey])
                }
                return 4 & t.flags ? n : e._parent.get(t.token, n)
            } finally {
                Q(r)
            }
            var s, i
        }
        function Ns(e, t) {
            let n;
            switch (201347067 & t.flags) {
            case 512:
                n = function(e, t, n) {
                    const r = n.length;
                    switch (r) {
                    case 0:
                        return new t;
                    case 1:
                        return new t(js(e, n[0]));
                    case 2:
                        return new t(js(e, n[0]),js(e, n[1]));
                    case 3:
                        return new t(js(e, n[0]),js(e, n[1]),js(e, n[2]));
                    default:
                        const s = new Array(r);
                        for (let t = 0; t < r; t++)
                            s[t] = js(e, n[t]);
                        return new t(...s)
                    }
                }(e, t.value, t.deps);
                break;
            case 1024:
                n = function(e, t, n) {
                    const r = n.length;
                    switch (r) {
                    case 0:
                        return t();
                    case 1:
                        return t(js(e, n[0]));
                    case 2:
                        return t(js(e, n[0]), js(e, n[1]));
                    case 3:
                        return t(js(e, n[0]), js(e, n[1]), js(e, n[2]));
                    default:
                        const s = Array(r);
                        for (let t = 0; t < r; t++)
                            s[t] = js(e, n[t]);
                        return t(...s)
                    }
                }(e, t.value, t.deps);
                break;
            case 2048:
                n = js(e, t.deps[0]);
                break;
            case 256:
                n = t.value
            }
            return n === ks || null === n || "object" != typeof n || 131072 & t.flags || "function" != typeof n.ngOnDestroy || (t.flags |= 131072),
            void 0 === n ? ks : n
        }
        function Ps(e, t) {
            const n = e.viewContainer._embeddedViews;
            if ((null == t || t >= n.length) && (t = n.length - 1),
            t < 0)
                return null;
            const r = n[t];
            return r.viewContainerParent = null,
            ee(n, t),
            Gr.dirtyParentQueries(r),
            Ls(r),
            r
        }
        function Ms(e, t, n) {
            const r = t ? us(t, t.def.lastRenderRootNode) : e.renderElement
              , s = n.renderer.parentNode(r)
              , i = n.renderer.nextSibling(r);
            vs(n, 2, s, i, void 0)
        }
        function Ls(e) {
            vs(e, 3, null, null, void 0)
        }
        const Fs = new Object;
        function Us(e, t, n, r, s, i) {
            return new zs(e,t,n,r,s,i)
        }
        class zs extends tr {
            constructor(e, t, n, r, s, i) {
                super(),
                this.selector = e,
                this.componentType = t,
                this._inputs = r,
                this._outputs = s,
                this.ngContentSelectors = i,
                this.viewDefFactory = n
            }
            get inputs() {
                const e = []
                  , t = this._inputs;
                for (let n in t)
                    e.push({
                        propName: n,
                        templateName: t[n]
                    });
                return e
            }
            get outputs() {
                const e = [];
                for (let t in this._outputs)
                    e.push({
                        propName: t,
                        templateName: this._outputs[t]
                    });
                return e
            }
            create(e, t, n, r) {
                if (!r)
                    throw new Error("ngModule should be provided");
                const s = ys(this.viewDefFactory)
                  , i = s.nodes[0].element.componentProvider.nodeIndex
                  , o = Gr.createRootView(e, t || [], n, s, r, Fs)
                  , a = $r(o, i).instance;
                return n && o.renderer.setAttribute(Vr(o, 0).renderElement, "ng-version", br.full),
                new Hs(o,new qs(o),a)
            }
        }
        class Hs extends er {
            constructor(e, t, n) {
                super(),
                this._view = e,
                this._viewRef = t,
                this._component = n,
                this._elDef = this._view.def.nodes[0],
                this.hostView = t,
                this.changeDetectorRef = t,
                this.instance = n
            }
            get location() {
                return new lr(Vr(this._view, this._elDef.nodeIndex).renderElement)
            }
            get injector() {
                return new Ws(this._view,this._elDef)
            }
            get componentType() {
                return this._component.constructor
            }
            destroy() {
                this._viewRef.destroy()
            }
            onDestroy(e) {
                this._viewRef.onDestroy(e)
            }
        }
        function Bs(e, t, n) {
            return new Vs(e,t,n)
        }
        class Vs {
            constructor(e, t, n) {
                this._view = e,
                this._elDef = t,
                this._data = n,
                this._embeddedViews = []
            }
            get element() {
                return new lr(this._data.renderElement)
            }
            get injector() {
                return new Ws(this._view,this._elDef)
            }
            get parentInjector() {
                let e = this._view
                  , t = this._elDef.parent;
                for (; !t && e; )
                    t = ls(e),
                    e = e.parent;
                return e ? new Ws(e,t) : new Ws(this._view,null)
            }
            clear() {
                for (let e = this._embeddedViews.length - 1; e >= 0; e--) {
                    const t = Ps(this._data, e);
                    Gr.destroyView(t)
                }
            }
            get(e) {
                const t = this._embeddedViews[e];
                if (t) {
                    const e = new qs(t);
                    return e.attachToViewContainerRef(this),
                    e
                }
                return null
            }
            get length() {
                return this._embeddedViews.length
            }
            createEmbeddedView(e, t, n) {
                const r = e.createEmbeddedView(t || {});
                return this.insert(r, n),
                r
            }
            createComponent(e, t, n, r, s) {
                const i = n || this.parentInjector;
                s || e instanceof ar || (s = i.get(Y));
                const o = e.create(i, r, void 0, s);
                return this.insert(o.hostView, t),
                o
            }
            insert(e, t) {
                if (e.destroyed)
                    throw new Error("Cannot insert a destroyed View in a ViewContainer!");
                const n = e;
                return function(e, t, n, r) {
                    let s = t.viewContainer._embeddedViews;
                    null == n && (n = s.length),
                    r.viewContainerParent = e,
                    X(s, n, r),
                    function(e, t) {
                        const n = cs(t);
                        if (!n || n === e || 16 & t.state)
                            return;
                        t.state |= 16;
                        let r = n.template._projectedViews;
                        r || (r = n.template._projectedViews = []),
                        r.push(t),
                        function(e, n) {
                            if (4 & n.flags)
                                return;
                            t.parent.def.nodeFlags |= 4,
                            n.flags |= 4;
                            let r = n.parent;
                            for (; r; )
                                r.childFlags |= 4,
                                r = r.parent
                        }(0, t.parentNodeDef)
                    }(t, r),
                    Gr.dirtyParentQueries(r),
                    Ms(t, n > 0 ? s[n - 1] : null, r)
                }(this._view, this._data, t, n._view),
                n.attachToViewContainerRef(this),
                e
            }
            move(e, t) {
                if (e.destroyed)
                    throw new Error("Cannot move a destroyed View in a ViewContainer!");
                const n = this._embeddedViews.indexOf(e._view);
                return function(e, t, r) {
                    const s = e.viewContainer._embeddedViews
                      , i = s[n];
                    ee(s, n),
                    null == r && (r = s.length),
                    X(s, r, i),
                    Gr.dirtyParentQueries(i),
                    Ls(i),
                    Ms(e, r > 0 ? s[r - 1] : null, i)
                }(this._data, 0, t),
                e
            }
            indexOf(e) {
                return this._embeddedViews.indexOf(e._view)
            }
            remove(e) {
                const t = Ps(this._data, e);
                t && Gr.destroyView(t)
            }
            detach(e) {
                const t = Ps(this._data, e);
                return t ? new qs(t) : null
            }
        }
        function $s(e) {
            return new qs(e)
        }
        class qs {
            constructor(e) {
                this._view = e,
                this._viewContainerRef = null,
                this._appRef = null
            }
            get rootNodes() {
                return function(e) {
                    const t = [];
                    return vs(e, 0, void 0, void 0, t),
                    t
                }(this._view)
            }
            get context() {
                return this._view.context
            }
            get destroyed() {
                return 0 != (128 & this._view.state)
            }
            markForCheck() {
                is(this._view)
            }
            detach() {
                this._view.state &= -5
            }
            detectChanges() {
                const e = this._view.root.rendererFactory;
                e.begin && e.begin();
                try {
                    Gr.checkAndUpdateView(this._view)
                } finally {
                    e.end && e.end()
                }
            }
            checkNoChanges() {
                Gr.checkNoChangesView(this._view)
            }
            reattach() {
                this._view.state |= 4
            }
            onDestroy(e) {
                this._view.disposables || (this._view.disposables = []),
                this._view.disposables.push(e)
            }
            destroy() {
                this._appRef ? this._appRef.detachView(this) : this._viewContainerRef && this._viewContainerRef.detach(this._viewContainerRef.indexOf(this)),
                Gr.destroyView(this._view)
            }
            detachFromAppRef() {
                this._appRef = null,
                Ls(this._view),
                Gr.dirtyParentQueries(this._view)
            }
            attachToAppRef(e) {
                if (this._viewContainerRef)
                    throw new Error("This view is already attached to a ViewContainer!");
                this._appRef = e
            }
            attachToViewContainerRef(e) {
                if (this._appRef)
                    throw new Error("This view is already attached directly to the ApplicationRef!");
                this._viewContainerRef = e
            }
        }
        function Qs(e, t) {
            return new Gs(e,t)
        }
        class Gs extends jr {
            constructor(e, t) {
                super(),
                this._parentView = e,
                this._def = t
            }
            createEmbeddedView(e) {
                return new qs(Gr.createEmbeddedView(this._parentView, this._def, this._def.element.template, e))
            }
            get elementRef() {
                return new lr(Vr(this._parentView, this._def.nodeIndex).renderElement)
            }
        }
        function Ks(e, t) {
            return new Ws(e,t)
        }
        class Ws {
            constructor(e, t) {
                this.view = e,
                this.elDef = t
            }
            get(e, t=En.THROW_IF_NOT_FOUND) {
                return Gr.resolveDep(this.view, this.elDef, !!this.elDef && 0 != (33554432 & this.elDef.flags), {
                    flags: 0,
                    token: e,
                    tokenKey: Zr(e)
                }, t)
            }
        }
        function Zs(e, t) {
            const n = e.def.nodes[t];
            if (1 & n.flags) {
                const t = Vr(e, n.nodeIndex);
                return n.element.template ? t.template : t.renderElement
            }
            if (2 & n.flags)
                return Br(e, n.nodeIndex).renderText;
            if (20240 & n.flags)
                return $r(e, n.nodeIndex).instance;
            throw new Error(`Illegal state: read nodeValue for node index ${t}`)
        }
        function Ys(e) {
            return new Js(e.renderer)
        }
        class Js {
            constructor(e) {
                this.delegate = e
            }
            selectRootElement(e) {
                return this.delegate.selectRootElement(e)
            }
            createElement(e, t) {
                const [n,r] = Ts(t)
                  , s = this.delegate.createElement(r, n);
                return e && this.delegate.appendChild(e, s),
                s
            }
            createViewRoot(e) {
                return e
            }
            createTemplateAnchor(e) {
                const t = this.delegate.createComment("");
                return e && this.delegate.appendChild(e, t),
                t
            }
            createText(e, t) {
                const n = this.delegate.createText(t);
                return e && this.delegate.appendChild(e, n),
                n
            }
            projectNodes(e, t) {
                for (let n = 0; n < t.length; n++)
                    this.delegate.appendChild(e, t[n])
            }
            attachViewAfter(e, t) {
                const n = this.delegate.parentNode(e)
                  , r = this.delegate.nextSibling(e);
                for (let s = 0; s < t.length; s++)
                    this.delegate.insertBefore(n, t[s], r)
            }
            detachView(e) {
                for (let t = 0; t < e.length; t++) {
                    const n = e[t]
                      , r = this.delegate.parentNode(n);
                    this.delegate.removeChild(r, n)
                }
            }
            destroyView(e, t) {
                for (let n = 0; n < t.length; n++)
                    this.delegate.destroyNode(t[n])
            }
            listen(e, t, n) {
                return this.delegate.listen(e, t, n)
            }
            listenGlobal(e, t, n) {
                return this.delegate.listen(e, t, n)
            }
            setElementProperty(e, t, n) {
                this.delegate.setProperty(e, t, n)
            }
            setElementAttribute(e, t, n) {
                const [r,s] = Ts(t);
                null != n ? this.delegate.setAttribute(e, s, n, r) : this.delegate.removeAttribute(e, s, r)
            }
            setBindingDebugInfo(e, t, n) {}
            setElementClass(e, t, n) {
                n ? this.delegate.addClass(e, t) : this.delegate.removeClass(e, t)
            }
            setElementStyle(e, t, n) {
                null != n ? this.delegate.setStyle(e, t, n) : this.delegate.removeStyle(e, t)
            }
            invokeElementMethod(e, t, n) {
                e[t].apply(e, n)
            }
            setText(e, t) {
                this.delegate.setValue(e, t)
            }
            animate() {
                throw new Error("Renderer.animate is no longer supported!")
            }
        }
        function Xs(e, t, n, r) {
            return new ei(e,t,n,r)
        }
        class ei {
            constructor(e, t, n, r) {
                this._moduleType = e,
                this._parent = t,
                this._bootstrapComponents = n,
                this._def = r,
                this._destroyListeners = [],
                this._destroyed = !1,
                this.injector = this,
                function(e) {
                    const t = e._def
                      , n = e._providers = new Array(t.providers.length);
                    for (let r = 0; r < t.providers.length; r++) {
                        const s = t.providers[r];
                        4096 & s.flags || void 0 === n[r] && (n[r] = Ns(e, s))
                    }
                }(this)
            }
            get(e, t=En.THROW_IF_NOT_FOUND, n=w.Default) {
                let r = 0;
                return n & w.SkipSelf ? r |= 1 : n & w.Self && (r |= 4),
                js(this, {
                    token: e,
                    tokenKey: Zr(e),
                    flags: r
                }, t)
            }
            get instance() {
                return this.get(this._moduleType)
            }
            get componentFactoryResolver() {
                return this.get(ir)
            }
            destroy() {
                if (this._destroyed)
                    throw new Error(`The ng module ${x(this.instance.constructor)} has already been destroyed.`);
                this._destroyed = !0,
                function(e, t) {
                    const n = e._def
                      , r = new Set;
                    for (let s = 0; s < n.providers.length; s++)
                        if (131072 & n.providers[s].flags) {
                            const t = e._providers[s];
                            if (t && t !== ks) {
                                const e = t.ngOnDestroy;
                                "function" != typeof e || r.has(t) || (e.apply(t),
                                r.add(t))
                            }
                        }
                }(this),
                this._destroyListeners.forEach(e => e())
            }
            onDestroy(e) {
                this._destroyListeners.push(e)
            }
        }
        const ti = Zr(hr)
          , ni = Zr(pr)
          , ri = Zr(lr)
          , si = Zr(Pr)
          , ii = Zr(jr)
          , oi = Zr(yn)
          , ai = Zr(En)
          , ci = Zr(M);
        function li(e, t, n, r, s, i, o, a) {
            const c = [];
            if (o)
                for (let u in o) {
                    const [e,t] = o[u];
                    c[e] = {
                        flags: 8,
                        name: u,
                        nonMinifiedName: t,
                        ns: null,
                        securityContext: null,
                        suffix: null
                    }
                }
            const l = [];
            if (a)
                for (let u in a)
                    l.push({
                        type: 1,
                        propName: u,
                        target: null,
                        eventName: a[u]
                    });
            return di(e, t |= 16384, n, r, s, s, i, c, l)
        }
        function ui(e, t, n) {
            return di(-1, e |= 16, null, 0, t, t, n)
        }
        function hi(e, t, n, r, s) {
            return di(-1, e, t, 0, n, r, s)
        }
        function di(e, t, n, r, s, i, o, a, c) {
            const {matchedQueries: l, references: u, matchedQueryIds: h} = ps(n);
            c || (c = []),
            a || (a = []),
            i = I(i);
            const d = ms(o, x(s));
            return {
                nodeIndex: -1,
                parent: null,
                renderParent: null,
                bindingIndex: -1,
                outputIndex: -1,
                checkIndex: e,
                flags: t,
                childFlags: 0,
                directChildFlags: 0,
                childMatchedQueries: 0,
                matchedQueries: l,
                matchedQueryIds: h,
                references: u,
                ngContentIndex: -1,
                childCount: r,
                bindings: a,
                bindingFlags: xs(a),
                outputs: c,
                element: null,
                provider: {
                    token: s,
                    value: i,
                    deps: d
                },
                text: null,
                query: null,
                ngContent: null
            }
        }
        function fi(e, t) {
            return bi(e, t)
        }
        function pi(e, t) {
            let n = e;
            for (; n.parent && !hs(n); )
                n = n.parent;
            return yi(n.parent, ls(n), !0, t.provider.value, t.provider.deps)
        }
        function mi(e, t) {
            const n = yi(e, t.parent, (32768 & t.flags) > 0, t.provider.value, t.provider.deps);
            if (t.outputs.length)
                for (let r = 0; r < t.outputs.length; r++) {
                    const s = t.outputs[r]
                      , i = n[s.propName];
                    if (!Jn(i))
                        throw new Error(`@Output ${s.propName} not initialized in '${n.constructor.name}'.`);
                    {
                        const n = i.subscribe(gi(e, t.parent.nodeIndex, s.eventName));
                        e.disposables[t.outputIndex + r] = n.unsubscribe.bind(n)
                    }
                }
            return n
        }
        function gi(e, t, n) {
            return r => as(e, t, n, r)
        }
        function bi(e, t) {
            const n = (8192 & t.flags) > 0
              , r = t.provider;
            switch (201347067 & t.flags) {
            case 512:
                return yi(e, t.parent, n, r.value, r.deps);
            case 1024:
                return function(e, t, n, r, s) {
                    const i = s.length;
                    switch (i) {
                    case 0:
                        return r();
                    case 1:
                        return r(_i(e, t, n, s[0]));
                    case 2:
                        return r(_i(e, t, n, s[0]), _i(e, t, n, s[1]));
                    case 3:
                        return r(_i(e, t, n, s[0]), _i(e, t, n, s[1]), _i(e, t, n, s[2]));
                    default:
                        const o = Array(i);
                        for (let r = 0; r < i; r++)
                            o[r] = _i(e, t, n, s[r]);
                        return r(...o)
                    }
                }(e, t.parent, n, r.value, r.deps);
            case 2048:
                return _i(e, t.parent, n, r.deps[0]);
            case 256:
                return r.value
            }
        }
        function yi(e, t, n, r, s) {
            const i = s.length;
            switch (i) {
            case 0:
                return new r;
            case 1:
                return new r(_i(e, t, n, s[0]));
            case 2:
                return new r(_i(e, t, n, s[0]),_i(e, t, n, s[1]));
            case 3:
                return new r(_i(e, t, n, s[0]),_i(e, t, n, s[1]),_i(e, t, n, s[2]));
            default:
                const o = new Array(i);
                for (let r = 0; r < i; r++)
                    o[r] = _i(e, t, n, s[r]);
                return new r(...o)
            }
        }
        const vi = {};
        function _i(e, t, n, r, s=En.THROW_IF_NOT_FOUND) {
            if (8 & r.flags)
                return r.token;
            const i = e;
            2 & r.flags && (s = null);
            const o = r.tokenKey;
            o === oi && (n = !(!t || !t.element.componentView)),
            t && 1 & r.flags && (n = !1,
            t = t.parent);
            let a = e;
            for (; a; ) {
                if (t)
                    switch (o) {
                    case ti:
                        return Ys(wi(a, t, n));
                    case ni:
                        return wi(a, t, n).renderer;
                    case ri:
                        return new lr(Vr(a, t.nodeIndex).renderElement);
                    case si:
                        return Vr(a, t.nodeIndex).viewContainer;
                    case ii:
                        if (t.element.template)
                            return Vr(a, t.nodeIndex).template;
                        break;
                    case oi:
                        return $s(wi(a, t, n));
                    case ai:
                    case ci:
                        return Ks(a, t);
                    default:
                        const e = (n ? t.element.allProviders : t.element.publicProviders)[o];
                        if (e) {
                            let t = $r(a, e.nodeIndex);
                            return t || (t = {
                                instance: bi(a, e)
                            },
                            a.nodes[e.nodeIndex] = t),
                            t.instance
                        }
                    }
                n = hs(a),
                t = ls(a),
                a = a.parent,
                4 & r.flags && (a = null)
            }
            const c = i.root.injector.get(r.token, vi);
            return c !== vi || s === vi ? c : i.root.ngModule.injector.get(r.token, s)
        }
        function wi(e, t, n) {
            let r;
            if (n)
                r = Vr(e, t.nodeIndex).componentView;
            else
                for (r = e; r.parent && !hs(r); )
                    r = r.parent;
            return r
        }
        function Ei(e, t, n, r, s, i) {
            if (32768 & n.flags) {
                const t = Vr(e, n.parent.nodeIndex).componentView;
                2 & t.def.flags && (t.state |= 8)
            }
            if (t.instance[n.bindings[r].name] = s,
            524288 & n.flags) {
                i = i || {};
                const t = Ln.unwrap(e.oldValues[n.bindingIndex + r]);
                i[n.bindings[r].nonMinifiedName] = new Xn(t,s,0 != (2 & e.state))
            }
            return e.oldValues[n.bindingIndex + r] = s,
            i
        }
        function Si(e, t) {
            if (!(e.def.nodeFlags & t))
                return;
            const n = e.def.nodes;
            let r = 0;
            for (let s = 0; s < n.length; s++) {
                const i = n[s];
                let o = i.parent;
                for (!o && i.flags & t && Ti(e, s, i.flags & t, r++),
                0 == (i.childFlags & t) && (s += i.childCount); o && 1 & o.flags && s === o.nodeIndex + o.childCount; )
                    o.directChildFlags & t && (r = Ci(e, o, t, r)),
                    o = o.parent
            }
        }
        function Ci(e, t, n, r) {
            for (let s = t.nodeIndex + 1; s <= t.nodeIndex + t.childCount; s++) {
                const t = e.def.nodes[s];
                t.flags & n && Ti(e, s, t.flags & n, r++),
                s += t.childCount
            }
            return r
        }
        function Ti(e, t, n, r) {
            const s = $r(e, t);
            if (!s)
                return;
            const i = s.instance;
            i && (Gr.setCurrentNode(e, t),
            1048576 & n && Hr(e, 512, r) && i.ngAfterContentInit(),
            2097152 & n && i.ngAfterContentChecked(),
            4194304 & n && Hr(e, 768, r) && i.ngAfterViewInit(),
            8388608 & n && i.ngAfterViewChecked(),
            131072 & n && i.ngOnDestroy())
        }
        const xi = new P("SCHEDULER_TOKEN",{
            providedIn: "root",
            factory: () => Le
        })
          , ki = {}
          , Oi = function() {
            var e = {
                LocaleId: 0,
                DayPeriodsFormat: 1,
                DayPeriodsStandalone: 2,
                DaysFormat: 3,
                DaysStandalone: 4,
                MonthsFormat: 5,
                MonthsStandalone: 6,
                Eras: 7,
                FirstDayOfWeek: 8,
                WeekendRange: 9,
                DateFormat: 10,
                TimeFormat: 11,
                DateTimeFormat: 12,
                NumberSymbols: 13,
                NumberFormats: 14,
                CurrencySymbol: 15,
                CurrencyName: 16,
                Currencies: 17,
                PluralCase: 18,
                ExtraData: 19
            };
            return e[e.LocaleId] = "LocaleId",
            e[e.DayPeriodsFormat] = "DayPeriodsFormat",
            e[e.DayPeriodsStandalone] = "DayPeriodsStandalone",
            e[e.DaysFormat] = "DaysFormat",
            e[e.DaysStandalone] = "DaysStandalone",
            e[e.MonthsFormat] = "MonthsFormat",
            e[e.MonthsStandalone] = "MonthsStandalone",
            e[e.Eras] = "Eras",
            e[e.FirstDayOfWeek] = "FirstDayOfWeek",
            e[e.WeekendRange] = "WeekendRange",
            e[e.DateFormat] = "DateFormat",
            e[e.TimeFormat] = "TimeFormat",
            e[e.DateTimeFormat] = "DateTimeFormat",
            e[e.NumberSymbols] = "NumberSymbols",
            e[e.NumberFormats] = "NumberFormats",
            e[e.CurrencySymbol] = "CurrencySymbol",
            e[e.CurrencyName] = "CurrencyName",
            e[e.Currencies] = "Currencies",
            e[e.PluralCase] = "PluralCase",
            e[e.ExtraData] = "ExtraData",
            e
        }()
          , Ii = void 0;
        var Ai = ["en", [["a", "p"], ["AM", "PM"], Ii], [["AM", "PM"], Ii, Ii], [["S", "M", "T", "W", "T", "F", "S"], ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]], Ii, [["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"], ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]], Ii, [["B", "A"], ["BC", "AD"], ["Before Christ", "Anno Domini"]], 0, [6, 0], ["M/d/yy", "MMM d, y", "MMMM d, y", "EEEE, MMMM d, y"], ["h:mm a", "h:mm:ss a", "h:mm:ss a z", "h:mm:ss a zzzz"], ["{1}, {0}", Ii, "{1} 'at' {0}", Ii], [".", ",", ";", "%", "+", "-", "E", "×", "‰", "∞", "NaN", ":"], ["#,##0.###", "#,##0%", "¤#,##0.00", "#E0"], "$", "US Dollar", {}, function(e) {
            let t = Math.floor(Math.abs(e))
              , n = e.toString().replace(/^[^.]*\.?/, "").length;
            return 1 === t && 0 === n ? 1 : 5
        }
        ];
        function Di(e) {
            return Ri(e)[Oi.PluralCase]
        }
        function Ri(e) {
            const t = e.toLowerCase().replace(/_/g, "-");
            let n = ki[t];
            if (n)
                return n;
            const r = t.split("-")[0];
            if (n = ki[r])
                return n;
            if ("en" === r)
                return Ai;
            throw new Error(`Missing locale data for the locale "${e}".`)
        }
        const ji = "en-US";
        let Ni = ji;
        function Pi(e) {
            var t;
            t = "Expected localeId to be defined",
            null == e && function(e) {
                throw new Error(`ASSERTION ERROR: ${e}`)
            }(t),
            "string" == typeof e && (Ni = e.toLowerCase().replace(/_/g, "-"))
        }
        class Mi extends r.a {
            constructor(e=!1) {
                super(),
                this.__isAsync = e
            }
            emit(e) {
                super.next(e)
            }
            subscribe(e, t, n) {
                let r, i = e => null, o = () => null;
                e && "object" == typeof e ? (r = this.__isAsync ? t => {
                    setTimeout( () => e.next(t))
                }
                : t => {
                    e.next(t)
                }
                ,
                e.error && (i = this.__isAsync ? t => {
                    setTimeout( () => e.error(t))
                }
                : t => {
                    e.error(t)
                }
                ),
                e.complete && (o = this.__isAsync ? () => {
                    setTimeout( () => e.complete())
                }
                : () => {
                    e.complete()
                }
                )) : (r = this.__isAsync ? t => {
                    setTimeout( () => e(t))
                }
                : t => {
                    e(t)
                }
                ,
                t && (i = this.__isAsync ? e => {
                    setTimeout( () => t(e))
                }
                : e => {
                    t(e)
                }
                ),
                n && (o = this.__isAsync ? () => {
                    setTimeout( () => n())
                }
                : () => {
                    n()
                }
                ));
                const a = super.subscribe(r, i, o);
                return e instanceof s.a && e.add(a),
                a
            }
        }
        function Li() {
            return this._results[Nn()]()
        }
        class Fi {
            constructor() {
                this.dirty = !0,
                this._results = [],
                this.changes = new Mi,
                this.length = 0;
                const e = Nn()
                  , t = Fi.prototype;
                t[e] || (t[e] = Li)
            }
            map(e) {
                return this._results.map(e)
            }
            filter(e) {
                return this._results.filter(e)
            }
            find(e) {
                return this._results.find(e)
            }
            reduce(e, t) {
                return this._results.reduce(e, t)
            }
            forEach(e) {
                this._results.forEach(e)
            }
            some(e) {
                return this._results.some(e)
            }
            toArray() {
                return this._results.slice()
            }
            toString() {
                return this._results.toString()
            }
            reset(e) {
                this._results = function e(t, n) {
                    void 0 === n && (n = t);
                    for (let r = 0; r < t.length; r++) {
                        let s = t[r];
                        Array.isArray(s) ? (n === t && (n = t.slice(0, r)),
                        e(s, n)) : n !== t && n.push(s)
                    }
                    return n
                }(e),
                this.dirty = !1,
                this.length = this._results.length,
                this.last = this._results[this.length - 1],
                this.first = this._results[0]
            }
            notifyOnChanges() {
                this.changes.emit(this)
            }
            setDirty() {
                this.dirty = !0
            }
            destroy() {
                this.changes.complete(),
                this.changes.unsubscribe()
            }
        }
        const Ui = new P("Application Initializer");
        class zi {
            constructor(e) {
                this.appInits = e,
                this.initialized = !1,
                this.done = !1,
                this.donePromise = new Promise( (e, t) => {
                    this.resolve = e,
                    this.reject = t
                }
                )
            }
            runInitializers() {
                if (this.initialized)
                    return;
                const e = []
                  , t = () => {
                    this.done = !0,
                    this.resolve()
                }
                ;
                if (this.appInits)
                    for (let n = 0; n < this.appInits.length; n++) {
                        const t = this.appInits[n]();
                        Yn(t) && e.push(t)
                    }
                Promise.all(e).then( () => {
                    t()
                }
                ).catch(e => {
                    this.reject(e)
                }
                ),
                0 === e.length && t(),
                this.initialized = !0
            }
        }
        const Hi = new P("AppId");
        function Bi() {
            return `${Vi()}${Vi()}${Vi()}`
        }
        function Vi() {
            return String.fromCharCode(97 + Math.floor(25 * Math.random()))
        }
        const $i = new P("Platform Initializer")
          , qi = new P("Platform ID")
          , Qi = new P("appBootstrapListener");
        class Gi {
            log(e) {
                console.log(e)
            }
            warn(e) {
                console.warn(e)
            }
        }
        const Ki = new P("LocaleId")
          , Wi = !1;
        function Zi() {
            throw new Error("Runtime compiler is not loaded")
        }
        const Yi = Zi
          , Ji = Zi
          , Xi = Zi
          , eo = Zi;
        class to {
            constructor() {
                this.compileModuleSync = Yi,
                this.compileModuleAsync = Ji,
                this.compileModuleAndAllComponentsSync = Xi,
                this.compileModuleAndAllComponentsAsync = eo
            }
            clearCache() {}
            clearCacheFor(e) {}
            getModuleId(e) {}
        }
        class no {
        }
        let ro, so;
        function io() {
            const e = N.wtf;
            return !(!e || !(ro = e.trace) || (so = ro.events,
            0))
        }
        const oo = io()
          , ao = oo ? function(e, t=null) {
            return so.createScope(e, t)
        }
        : (e, t) => (function(e, t) {
            return null
        }
        )
          , co = oo ? function(e, t) {
            return ro.leaveScope(e, t),
            t
        }
        : (e, t) => t
          , lo = ( () => Promise.resolve(0))();
        function uo(e) {
            "undefined" == typeof Zone ? lo.then( () => {
                e && e.apply(null, null)
            }
            ) : Zone.current.scheduleMicroTask("scheduleMicrotask", e)
        }
        class ho {
            constructor({enableLongStackTrace: e=!1}) {
                if (this.hasPendingMicrotasks = !1,
                this.hasPendingMacrotasks = !1,
                this.isStable = !0,
                this.onUnstable = new Mi(!1),
                this.onMicrotaskEmpty = new Mi(!1),
                this.onStable = new Mi(!1),
                this.onError = new Mi(!1),
                "undefined" == typeof Zone)
                    throw new Error("In this configuration Angular requires Zone.js");
                var t;
                Zone.assertZonePatched(),
                this._nesting = 0,
                this._outer = this._inner = Zone.current,
                Zone.wtfZoneSpec && (this._inner = this._inner.fork(Zone.wtfZoneSpec)),
                Zone.TaskTrackingZoneSpec && (this._inner = this._inner.fork(new Zone.TaskTrackingZoneSpec)),
                e && Zone.longStackTraceZoneSpec && (this._inner = this._inner.fork(Zone.longStackTraceZoneSpec)),
                (t = this)._inner = t._inner.fork({
                    name: "angular",
                    properties: {
                        isAngularZone: !0
                    },
                    onInvokeTask: (e, n, r, s, i, o) => {
                        try {
                            return go(t),
                            e.invokeTask(r, s, i, o)
                        } finally {
                            bo(t)
                        }
                    }
                    ,
                    onInvoke: (e, n, r, s, i, o, a) => {
                        try {
                            return go(t),
                            e.invoke(r, s, i, o, a)
                        } finally {
                            bo(t)
                        }
                    }
                    ,
                    onHasTask: (e, n, r, s) => {
                        e.hasTask(r, s),
                        n === r && ("microTask" == s.change ? (t.hasPendingMicrotasks = s.microTask,
                        mo(t)) : "macroTask" == s.change && (t.hasPendingMacrotasks = s.macroTask))
                    }
                    ,
                    onHandleError: (e, n, r, s) => (e.handleError(r, s),
                    t.runOutsideAngular( () => t.onError.emit(s)),
                    !1)
                })
            }
            static isInAngularZone() {
                return !0 === Zone.current.get("isAngularZone")
            }
            static assertInAngularZone() {
                if (!ho.isInAngularZone())
                    throw new Error("Expected to be in Angular Zone, but it is not!")
            }
            static assertNotInAngularZone() {
                if (ho.isInAngularZone())
                    throw new Error("Expected to not be in Angular Zone, but it is!")
            }
            run(e, t, n) {
                return this._inner.run(e, t, n)
            }
            runTask(e, t, n, r) {
                const s = this._inner
                  , i = s.scheduleEventTask("NgZoneEvent: " + r, e, po, fo, fo);
                try {
                    return s.runTask(i, t, n)
                } finally {
                    s.cancelTask(i)
                }
            }
            runGuarded(e, t, n) {
                return this._inner.runGuarded(e, t, n)
            }
            runOutsideAngular(e) {
                return this._outer.run(e)
            }
        }
        function fo() {}
        const po = {};
        function mo(e) {
            if (0 == e._nesting && !e.hasPendingMicrotasks && !e.isStable)
                try {
                    e._nesting++,
                    e.onMicrotaskEmpty.emit(null)
                } finally {
                    if (e._nesting--,
                    !e.hasPendingMicrotasks)
                        try {
                            e.runOutsideAngular( () => e.onStable.emit(null))
                        } finally {
                            e.isStable = !0
                        }
                }
        }
        function go(e) {
            e._nesting++,
            e.isStable && (e.isStable = !1,
            e.onUnstable.emit(null))
        }
        function bo(e) {
            e._nesting--,
            mo(e)
        }
        class yo {
            constructor() {
                this.hasPendingMicrotasks = !1,
                this.hasPendingMacrotasks = !1,
                this.isStable = !0,
                this.onUnstable = new Mi,
                this.onMicrotaskEmpty = new Mi,
                this.onStable = new Mi,
                this.onError = new Mi
            }
            run(e) {
                return e()
            }
            runGuarded(e) {
                return e()
            }
            runOutsideAngular(e) {
                return e()
            }
            runTask(e) {
                return e()
            }
        }
        class vo {
            constructor(e) {
                this._ngZone = e,
                this._pendingCount = 0,
                this._isZoneStable = !0,
                this._didWork = !1,
                this._callbacks = [],
                this.taskTrackingZone = null,
                this._watchAngularEvents(),
                e.run( () => {
                    this.taskTrackingZone = "undefined" == typeof Zone ? null : Zone.current.get("TaskTrackingZone")
                }
                )
            }
            _watchAngularEvents() {
                this._ngZone.onUnstable.subscribe({
                    next: () => {
                        this._didWork = !0,
                        this._isZoneStable = !1
                    }
                }),
                this._ngZone.runOutsideAngular( () => {
                    this._ngZone.onStable.subscribe({
                        next: () => {
                            ho.assertNotInAngularZone(),
                            uo( () => {
                                this._isZoneStable = !0,
                                this._runCallbacksIfReady()
                            }
                            )
                        }
                    })
                }
                )
            }
            increasePendingRequestCount() {
                return this._pendingCount += 1,
                this._didWork = !0,
                this._pendingCount
            }
            decreasePendingRequestCount() {
                if (this._pendingCount -= 1,
                this._pendingCount < 0)
                    throw new Error("pending async requests below zero");
                return this._runCallbacksIfReady(),
                this._pendingCount
            }
            isStable() {
                return this._isZoneStable && 0 === this._pendingCount && !this._ngZone.hasPendingMacrotasks
            }
            _runCallbacksIfReady() {
                if (this.isStable())
                    uo( () => {
                        for (; 0 !== this._callbacks.length; ) {
                            let e = this._callbacks.pop();
                            clearTimeout(e.timeoutId),
                            e.doneCb(this._didWork)
                        }
                        this._didWork = !1
                    }
                    );
                else {
                    let e = this.getPendingTasks();
                    this._callbacks = this._callbacks.filter(t => !t.updateCb || !t.updateCb(e) || (clearTimeout(t.timeoutId),
                    !1)),
                    this._didWork = !0
                }
            }
            getPendingTasks() {
                return this.taskTrackingZone ? this.taskTrackingZone.macroTasks.map(e => ({
                    source: e.source,
                    creationLocation: e.creationLocation,
                    data: e.data
                })) : []
            }
            addCallback(e, t, n) {
                let r = -1;
                t && t > 0 && (r = setTimeout( () => {
                    this._callbacks = this._callbacks.filter(e => e.timeoutId !== r),
                    e(this._didWork, this.getPendingTasks())
                }
                , t)),
                this._callbacks.push({
                    doneCb: e,
                    timeoutId: r,
                    updateCb: n
                })
            }
            whenStable(e, t, n) {
                if (n && !this.taskTrackingZone)
                    throw new Error('Task tracking zone is required when passing an update callback to whenStable(). Is "zone.js/dist/task-tracking.js" loaded?');
                this.addCallback(e, t, n),
                this._runCallbacksIfReady()
            }
            getPendingRequestCount() {
                return this._pendingCount
            }
            findProviders(e, t, n) {
                return []
            }
        }
        class _o {
            constructor() {
                this._applications = new Map,
                Co.addToWindow(this)
            }
            registerApplication(e, t) {
                this._applications.set(e, t)
            }
            unregisterApplication(e) {
                this._applications.delete(e)
            }
            unregisterAllApplications() {
                this._applications.clear()
            }
            getTestability(e) {
                return this._applications.get(e) || null
            }
            getAllTestabilities() {
                return Array.from(this._applications.values())
            }
            getAllRootElements() {
                return Array.from(this._applications.keys())
            }
            findTestabilityInTree(e, t=!0) {
                return Co.findTestabilityInTree(this, e, t)
            }
        }
        class wo {
            addToWindow(e) {}
            findTestabilityInTree(e, t, n) {
                return null
            }
        }
        function Eo(e) {
            Co = e
        }
        let So, Co = new wo, To = function(e, t, n) {
            return e.get(no).createCompiler([t]).compileModuleAsync(n)
        }, xo = function(e) {
            return e instanceof ar
        };
        const ko = new P("AllowMultipleToken");
        class Oo {
            constructor(e, t) {
                this.name = e,
                this.token = t
            }
        }
        function Io(e, t, n=[]) {
            const r = `Platform: ${t}`
              , s = new P(r);
            return (t=[]) => {
                let i = Ao();
                if (!i || i.injector.get(ko, !1))
                    if (e)
                        e(n.concat(t).concat({
                            provide: s,
                            useValue: !0
                        }));
                    else {
                        const e = n.concat(t).concat({
                            provide: s,
                            useValue: !0
                        });
                        !function(e) {
                            if (So && !So.destroyed && !So.injector.get(ko, !1))
                                throw new Error("There can be only one platform. Destroy the previous one to create a new one.");
                            So = e.get(Do);
                            const t = e.get($i, null);
                            t && t.forEach(e => e())
                        }(En.create({
                            providers: e,
                            name: r
                        }))
                    }
                return function(e) {
                    const t = Ao();
                    if (!t)
                        throw new Error("No platform exists!");
                    if (!t.injector.get(e, null))
                        throw new Error("A platform with a different configuration has been created. Please destroy it first.");
                    return t
                }(s)
            }
        }
        function Ao() {
            return So && !So.destroyed ? So : null
        }
        class Do {
            constructor(e) {
                this._injector = e,
                this._modules = [],
                this._destroyListeners = [],
                this._destroyed = !1
            }
            bootstrapModuleFactory(e, t) {
                const n = "noop" === (s = t ? t.ngZone : void 0) ? new yo : ("zone.js" === s ? void 0 : s) || new ho({
                    enableLongStackTrace: _t()
                })
                  , r = [{
                    provide: ho,
                    useValue: n
                }];
                var s;
                return n.run( () => {
                    const t = En.create({
                        providers: r,
                        parent: this.injector,
                        name: e.moduleType.name
                    })
                      , s = e.create(t)
                      , i = s.injector.get(bt, null);
                    if (!i)
                        throw new Error("No ErrorHandler. Is platform module (BrowserModule) included?");
                    return Wi && Pi(s.injector.get(Ki, ji) || ji),
                    s.onDestroy( () => No(this._modules, s)),
                    n.runOutsideAngular( () => n.onError.subscribe({
                        next: e => {
                            i.handleError(e)
                        }
                    })),
                    function(e, t, n) {
                        try {
                            const s = n();
                            return Yn(s) ? s.catch(n => {
                                throw t.runOutsideAngular( () => e.handleError(n)),
                                n
                            }
                            ) : s
                        } catch (r) {
                            throw t.runOutsideAngular( () => e.handleError(r)),
                            r
                        }
                    }(i, n, () => {
                        const e = s.injector.get(zi);
                        return e.runInitializers(),
                        e.donePromise.then( () => (this._moduleDoBootstrap(s),
                        s))
                    }
                    )
                }
                )
            }
            bootstrapModule(e, t=[]) {
                const n = Ro({}, t);
                return To(this.injector, n, e).then(e => this.bootstrapModuleFactory(e, n))
            }
            _moduleDoBootstrap(e) {
                const t = e.injector.get(jo);
                if (e._bootstrapComponents.length > 0)
                    e._bootstrapComponents.forEach(e => t.bootstrap(e));
                else {
                    if (!e.instance.ngDoBootstrap)
                        throw new Error(`The module ${x(e.instance.constructor)} was bootstrapped, but it does not declare "@NgModule.bootstrap" components nor a "ngDoBootstrap" method. ` + "Please define one of these.");
                    e.instance.ngDoBootstrap(t)
                }
                this._modules.push(e)
            }
            onDestroy(e) {
                this._destroyListeners.push(e)
            }
            get injector() {
                return this._injector
            }
            destroy() {
                if (this._destroyed)
                    throw new Error("The platform has already been destroyed!");
                this._modules.slice().forEach(e => e.destroy()),
                this._destroyListeners.forEach(e => e()),
                this._destroyed = !0
            }
            get destroyed() {
                return this._destroyed
            }
        }
        function Ro(e, t) {
            return Array.isArray(t) ? t.reduce(Ro, e) : Object.assign({}, e, t)
        }
        let jo = ( () => {
            class e {
                constructor(e, t, n, r, s, a) {
                    this._zone = e,
                    this._console = t,
                    this._injector = n,
                    this._exceptionHandler = r,
                    this._componentFactoryResolver = s,
                    this._initStatus = a,
                    this._bootstrapListeners = [],
                    this._views = [],
                    this._runningTick = !1,
                    this._enforceNoNewChanges = !1,
                    this._stable = !0,
                    this.componentTypes = [],
                    this.components = [],
                    this._enforceNoNewChanges = _t(),
                    this._zone.onMicrotaskEmpty.subscribe({
                        next: () => {
                            this._zone.run( () => {
                                this.tick()
                            }
                            )
                        }
                    });
                    const l = new i.a(e => {
                        this._stable = this._zone.isStable && !this._zone.hasPendingMacrotasks && !this._zone.hasPendingMicrotasks,
                        this._zone.runOutsideAngular( () => {
                            e.next(this._stable),
                            e.complete()
                        }
                        )
                    }
                    )
                      , u = new i.a(e => {
                        let t;
                        this._zone.runOutsideAngular( () => {
                            t = this._zone.onStable.subscribe( () => {
                                ho.assertNotInAngularZone(),
                                uo( () => {
                                    this._stable || this._zone.hasPendingMacrotasks || this._zone.hasPendingMicrotasks || (this._stable = !0,
                                    e.next(!0))
                                }
                                )
                            }
                            )
                        }
                        );
                        const n = this._zone.onUnstable.subscribe( () => {
                            ho.assertInAngularZone(),
                            this._stable && (this._stable = !1,
                            this._zone.runOutsideAngular( () => {
                                e.next(!1)
                            }
                            ))
                        }
                        );
                        return () => {
                            t.unsubscribe(),
                            n.unsubscribe()
                        }
                    }
                    );
                    this.isStable = Object(o.a)(l, u.pipe(e => c()(function(e, t) {
                        return function(t) {
                            let n;
                            n = "function" == typeof e ? e : function() {
                                return e
                            }
                            ;
                            const r = Object.create(t, d);
                            return r.source = t,
                            r.subjectFactory = n,
                            r
                        }
                    }(p)(e))))
                }
                bootstrap(e, t) {
                    if (!this._initStatus.done)
                        throw new Error("Cannot bootstrap as there are still asynchronous initializers running. Bootstrap components in the `ngDoBootstrap` method of the root module.");
                    let n;
                    n = e instanceof tr ? e : this._componentFactoryResolver.resolveComponentFactory(e),
                    this.componentTypes.push(n.componentType);
                    const r = xo(n) ? null : this._injector.get(Y)
                      , s = n.create(En.NULL, [], t || n.selector, r);
                    s.onDestroy( () => {
                        this._unloadComponent(s)
                    }
                    );
                    const i = s.injector.get(vo, null);
                    return i && s.injector.get(_o).registerApplication(s.location.nativeElement, i),
                    this._loadComponent(s),
                    _t() && this._console.log("Angular is running in the development mode. Call enableProdMode() to enable the production mode."),
                    s
                }
                tick() {
                    if (this._runningTick)
                        throw new Error("ApplicationRef.tick is called recursively");
                    const t = e._tickScope();
                    try {
                        this._runningTick = !0;
                        for (let e of this._views)
                            e.detectChanges();
                        if (this._enforceNoNewChanges)
                            for (let e of this._views)
                                e.checkNoChanges()
                    } catch (n) {
                        this._zone.runOutsideAngular( () => this._exceptionHandler.handleError(n))
                    } finally {
                        this._runningTick = !1,
                        co(t)
                    }
                }
                attachView(e) {
                    const t = e;
                    this._views.push(t),
                    t.attachToAppRef(this)
                }
                detachView(e) {
                    const t = e;
                    No(this._views, t),
                    t.detachFromAppRef()
                }
                _loadComponent(e) {
                    this.attachView(e.hostView),
                    this.tick(),
                    this.components.push(e),
                    this._injector.get(Qi, []).concat(this._bootstrapListeners).forEach(t => t(e))
                }
                _unloadComponent(e) {
                    this.detachView(e.hostView),
                    No(this.components, e)
                }
                ngOnDestroy() {
                    this._views.slice().forEach(e => e.destroy())
                }
                get viewCount() {
                    return this._views.length
                }
            }
            return e._tickScope = ao("ApplicationRef#tick()"),
            e
        }
        )();
        function No(e, t) {
            const n = e.indexOf(t);
            n > -1 && e.splice(n, 1)
        }
        class Po {
        }
        const Mo = "#"
          , Lo = "NgFactory";
        class Fo {
        }
        const Uo = {
            factoryPathPrefix: "",
            factoryPathSuffix: ".ngfactory"
        };
        class zo {
            constructor(e, t) {
                this._compiler = e,
                this._config = t || Uo
            }
            load(e) {
                return !Wi && this._compiler instanceof to ? this.loadFactory(e) : this.loadAndCompile(e)
            }
            loadAndCompile(e) {
                let[t,r] = e.split(Mo);
                return void 0 === r && (r = "default"),
                n("zn8P")(t).then(e => e[r]).then(e => Ho(e, t, r)).then(e => this._compiler.compileModuleAsync(e))
            }
            loadFactory(e) {
                let[t,r] = e.split(Mo)
                  , s = Lo;
                return void 0 === r && (r = "default",
                s = ""),
                n("zn8P")(this._config.factoryPathPrefix + t + this._config.factoryPathSuffix).then(e => e[r + s]).then(e => Ho(e, t, r))
            }
        }
        function Ho(e, t, n) {
            if (!e)
                throw new Error(`Cannot find '${n}' in '${t}'`);
            return e
        }
        class Bo {
            constructor(e, t) {
                this.name = e,
                this.callback = t
            }
        }
        class Vo {
            constructor(e, t, n) {
                this.listeners = [],
                this.parent = null,
                this._debugContext = n,
                this.nativeNode = e,
                t && t instanceof $o && t.addChild(this)
            }
            get injector() {
                return this._debugContext.injector
            }
            get componentInstance() {
                return this._debugContext.component
            }
            get context() {
                return this._debugContext.context
            }
            get references() {
                return this._debugContext.references
            }
            get providerTokens() {
                return this._debugContext.providerTokens
            }
        }
        class $o extends Vo {
            constructor(e, t, n) {
                super(e, t, n),
                this.properties = {},
                this.attributes = {},
                this.classes = {},
                this.styles = {},
                this.childNodes = [],
                this.nativeElement = e
            }
            addChild(e) {
                e && (this.childNodes.push(e),
                e.parent = this)
            }
            removeChild(e) {
                const t = this.childNodes.indexOf(e);
                -1 !== t && (e.parent = null,
                this.childNodes.splice(t, 1))
            }
            insertChildrenAfter(e, t) {
                const n = this.childNodes.indexOf(e);
                -1 !== n && (this.childNodes.splice(n + 1, 0, ...t),
                t.forEach(t => {
                    t.parent && t.parent.removeChild(t),
                    e.parent = this
                }
                ))
            }
            insertBefore(e, t) {
                const n = this.childNodes.indexOf(e);
                -1 === n ? this.addChild(t) : (t.parent && t.parent.removeChild(t),
                t.parent = this,
                this.childNodes.splice(n, 0, t))
            }
            query(e) {
                return this.queryAll(e)[0] || null
            }
            queryAll(e) {
                const t = [];
                return function e(t, n, r) {
                    t.childNodes.forEach(t => {
                        t instanceof $o && (n(t) && r.push(t),
                        e(t, n, r))
                    }
                    )
                }(this, e, t),
                t
            }
            queryAllNodes(e) {
                const t = [];
                return function e(t, n, r) {
                    t instanceof $o && t.childNodes.forEach(t => {
                        n(t) && r.push(t),
                        t instanceof $o && e(t, n, r)
                    }
                    )
                }(this, e, t),
                t
            }
            get children() {
                return this.childNodes.filter(e => e instanceof $o)
            }
            triggerEventHandler(e, t) {
                this.listeners.forEach(n => {
                    n.name == e && n.callback(t)
                }
                )
            }
        }
        const qo = new Map
          , Qo = function(e) {
            return qo.get(e) || null
        };
        function Go(e) {
            qo.set(e.nativeNode, e)
        }
        const Ko = Io(null, "core", [{
            provide: qi,
            useValue: "unknown"
        }, {
            provide: Do,
            deps: [En]
        }, {
            provide: _o,
            deps: []
        }, {
            provide: Gi,
            deps: []
        }]);
        function Wo() {
            return Dr
        }
        function Zo() {
            return Rr
        }
        function Yo(e) {
            return e ? (Wi && Pi(e),
            e) : ji
        }
        function Jo(e) {
            let t = [];
            return e.onStable.subscribe( () => {
                for (; t.length; )
                    t.pop()()
            }
            ),
            function(e) {
                t.push(e)
            }
        }
        class Xo {
            constructor(e) {}
        }
        function ea(e, t, n, r, s, i) {
            e |= 1;
            const {matchedQueries: o, references: a, matchedQueryIds: c} = ps(t);
            return {
                nodeIndex: -1,
                parent: null,
                renderParent: null,
                bindingIndex: -1,
                outputIndex: -1,
                flags: e,
                checkIndex: -1,
                childFlags: 0,
                directChildFlags: 0,
                childMatchedQueries: 0,
                matchedQueries: o,
                matchedQueryIds: c,
                references: a,
                ngContentIndex: n,
                childCount: r,
                bindings: [],
                bindingFlags: 0,
                outputs: [],
                element: {
                    ns: null,
                    name: null,
                    attrs: null,
                    template: i ? ys(i) : null,
                    componentProvider: null,
                    componentView: null,
                    componentRendererType: null,
                    publicProviders: null,
                    allProviders: null,
                    handleEvent: s || Kr
                },
                provider: null,
                text: null,
                query: null,
                ngContent: null
            }
        }
        function ta(e, t, n, r, s, i, o=[], a, c, l, u, h) {
            l || (l = Kr);
            const {matchedQueries: d, references: f, matchedQueryIds: p} = ps(n);
            let m = null
              , g = null;
            i && ([m,g] = Ts(i)),
            a = a || [];
            const b = new Array(a.length);
            for (let _ = 0; _ < a.length; _++) {
                const [e,t,n] = a[_]
                  , [r,s] = Ts(t);
                let i = void 0
                  , o = void 0;
                switch (15 & e) {
                case 4:
                    o = n;
                    break;
                case 1:
                case 8:
                    i = n
                }
                b[_] = {
                    flags: e,
                    ns: r,
                    name: s,
                    nonMinifiedName: s,
                    securityContext: i,
                    suffix: o
                }
            }
            c = c || [];
            const y = new Array(c.length);
            for (let _ = 0; _ < c.length; _++) {
                const [e,t] = c[_];
                y[_] = {
                    type: 0,
                    target: e,
                    eventName: t,
                    propName: null
                }
            }
            const v = (o = o || []).map( ([e,t]) => {
                const [n,r] = Ts(e);
                return [n, r, t]
            }
            );
            return h = function(e) {
                if (e && e.id === Jr) {
                    const t = null != e.encapsulation && e.encapsulation !== ne.None || e.styles.length || Object.keys(e.data).length;
                    e.id = t ? `c${ts++}` : Xr
                }
                return e && e.id === Xr && (e = null),
                e || null
            }(h),
            u && (t |= 33554432),
            {
                nodeIndex: -1,
                parent: null,
                renderParent: null,
                bindingIndex: -1,
                outputIndex: -1,
                checkIndex: e,
                flags: t |= 1,
                childFlags: 0,
                directChildFlags: 0,
                childMatchedQueries: 0,
                matchedQueries: d,
                matchedQueryIds: p,
                references: f,
                ngContentIndex: r,
                childCount: s,
                bindings: b,
                bindingFlags: xs(b),
                outputs: y,
                element: {
                    ns: m,
                    name: g,
                    attrs: v,
                    template: null,
                    componentProvider: null,
                    componentView: u || null,
                    componentRendererType: h,
                    publicProviders: null,
                    allProviders: null,
                    handleEvent: l || Kr
                },
                provider: null,
                text: null,
                query: null,
                ngContent: null
            }
        }
        function na(e, t, n) {
            const r = n.element
              , s = e.root.selectorOrNode
              , i = e.renderer;
            let o;
            if (e.parent || !s) {
                o = r.name ? i.createElement(r.name, r.ns) : i.createComment("");
                const s = gs(e, t, n);
                s && i.appendChild(s, o)
            } else
                o = i.selectRootElement(s, !!r.componentRendererType && r.componentRendererType.encapsulation === ne.ShadowDom);
            if (r.attrs)
                for (let a = 0; a < r.attrs.length; a++) {
                    const [e,t,n] = r.attrs[a];
                    i.setAttribute(o, t, n, e)
                }
            return o
        }
        function ra(e, t, n, r) {
            for (let o = 0; o < n.outputs.length; o++) {
                const a = n.outputs[o]
                  , c = sa(e, n.nodeIndex, (i = a.eventName,
                (s = a.target) ? `${s}:${i}` : i));
                let l = a.target
                  , u = e;
                "component" === a.target && (l = null,
                u = t);
                const h = u.renderer.listen(l || r, a.eventName, c);
                e.disposables[n.outputIndex + o] = h
            }
            var s, i
        }
        function sa(e, t, n) {
            return r => as(e, t, n, r)
        }
        function ia(e, t, n, r) {
            if (!rs(e, t, n, r))
                return !1;
            const s = t.bindings[n]
              , i = Vr(e, t.nodeIndex)
              , o = i.renderElement
              , a = s.name;
            switch (15 & s.flags) {
            case 1:
                !function(e, t, n, r, s, i) {
                    const o = t.securityContext;
                    let a = o ? e.root.sanitizer.sanitize(o, i) : i;
                    a = null != a ? a.toString() : null;
                    const c = e.renderer;
                    null != i ? c.setAttribute(n, s, a, r) : c.removeAttribute(n, s, r)
                }(e, s, o, s.ns, a, r);
                break;
            case 2:
                !function(e, t, n, r) {
                    const s = e.renderer;
                    r ? s.addClass(t, n) : s.removeClass(t, n)
                }(e, o, a, r);
                break;
            case 4:
                !function(e, t, n, r, s) {
                    let i = e.root.sanitizer.sanitize($t.STYLE, s);
                    if (null != i) {
                        i = i.toString();
                        const e = t.suffix;
                        null != e && (i += e)
                    } else
                        i = null;
                    const o = e.renderer;
                    null != i ? o.setStyle(n, r, i) : o.removeStyle(n, r)
                }(e, s, o, a, r);
                break;
            case 8:
                !function(e, t, n, r, s) {
                    const i = t.securityContext;
                    let o = i ? e.root.sanitizer.sanitize(i, s) : s;
                    e.renderer.setProperty(n, r, o)
                }(33554432 & t.flags && 32 & s.flags ? i.componentView : e, s, o, a, r)
            }
            return !0
        }
        function oa(e, t, n) {
            let r = [];
            for (let s in n)
                r.push({
                    propName: s,
                    bindingType: n[s]
                });
            return {
                nodeIndex: -1,
                parent: null,
                renderParent: null,
                bindingIndex: -1,
                outputIndex: -1,
                checkIndex: -1,
                flags: e,
                childFlags: 0,
                directChildFlags: 0,
                childMatchedQueries: 0,
                ngContentIndex: -1,
                matchedQueries: {},
                matchedQueryIds: 0,
                references: {},
                childCount: 0,
                bindings: [],
                bindingFlags: 0,
                outputs: [],
                element: null,
                provider: null,
                text: null,
                query: {
                    id: t,
                    filterId: fs(t),
                    bindings: r
                },
                ngContent: null
            }
        }
        function aa(e) {
            const t = e.def.nodeMatchedQueries;
            for (; e.parent && ds(e); ) {
                let n = e.parentNodeDef;
                e = e.parent;
                const r = n.nodeIndex + n.childCount;
                for (let s = 0; s <= r; s++) {
                    const r = e.def.nodes[s];
                    67108864 & r.flags && 536870912 & r.flags && (r.query.filterId & t) === r.query.filterId && Qr(e, s).setDirty(),
                    !(1 & r.flags && s + r.childCount < n.nodeIndex) && 67108864 & r.childFlags && 536870912 & r.childFlags || (s += r.childCount)
                }
            }
            if (134217728 & e.def.nodeFlags)
                for (let n = 0; n < e.def.nodes.length; n++) {
                    const t = e.def.nodes[n];
                    134217728 & t.flags && 536870912 & t.flags && Qr(e, n).setDirty(),
                    n += t.childCount
                }
        }
        function ca(e, t) {
            const n = Qr(e, t.nodeIndex);
            if (!n.dirty)
                return;
            let r, s = void 0;
            if (67108864 & t.flags) {
                const n = t.parent.parent;
                s = la(e, n.nodeIndex, n.nodeIndex + n.childCount, t.query, []),
                r = $r(e, t.parent.nodeIndex).instance
            } else
                134217728 & t.flags && (s = la(e, 0, e.def.nodes.length - 1, t.query, []),
                r = e.component);
            n.reset(s);
            const i = t.query.bindings;
            let o = !1;
            for (let a = 0; a < i.length; a++) {
                const e = i[a];
                let t;
                switch (e.bindingType) {
                case 0:
                    t = n.first;
                    break;
                case 1:
                    t = n,
                    o = !0
                }
                r[e.propName] = t
            }
            o && n.notifyOnChanges()
        }
        function la(e, t, n, r, s) {
            for (let i = t; i <= n; i++) {
                const t = e.def.nodes[i]
                  , n = t.matchedQueries[r.id];
                if (null != n && s.push(ua(e, t, n)),
                1 & t.flags && t.element.template && (t.element.template.nodeMatchedQueries & r.filterId) === r.filterId) {
                    const n = Vr(e, i);
                    if ((t.childMatchedQueries & r.filterId) === r.filterId && (la(e, i + 1, i + t.childCount, r, s),
                    i += t.childCount),
                    16777216 & t.flags) {
                        const e = n.viewContainer._embeddedViews;
                        for (let t = 0; t < e.length; t++) {
                            const i = e[t]
                              , o = cs(i);
                            o && o === n && la(i, 0, i.def.nodes.length - 1, r, s)
                        }
                    }
                    const o = n.template._projectedViews;
                    if (o)
                        for (let e = 0; e < o.length; e++) {
                            const t = o[e];
                            la(t, 0, t.def.nodes.length - 1, r, s)
                        }
                }
                (t.childMatchedQueries & r.filterId) !== r.filterId && (i += t.childCount)
            }
            return s
        }
        function ua(e, t, n) {
            if (null != n)
                switch (n) {
                case 1:
                    return Vr(e, t.nodeIndex).renderElement;
                case 0:
                    return new lr(Vr(e, t.nodeIndex).renderElement);
                case 2:
                    return Vr(e, t.nodeIndex).template;
                case 3:
                    return Vr(e, t.nodeIndex).viewContainer;
                case 4:
                    return $r(e, t.nodeIndex).instance
                }
        }
        function ha(e, t) {
            return {
                nodeIndex: -1,
                parent: null,
                renderParent: null,
                bindingIndex: -1,
                outputIndex: -1,
                checkIndex: -1,
                flags: 8,
                childFlags: 0,
                directChildFlags: 0,
                childMatchedQueries: 0,
                matchedQueries: {},
                matchedQueryIds: 0,
                references: {},
                ngContentIndex: e,
                childCount: 0,
                bindings: [],
                bindingFlags: 0,
                outputs: [],
                element: null,
                provider: null,
                text: null,
                query: null,
                ngContent: {
                    index: t
                }
            }
        }
        function da(e, t, n) {
            const r = gs(e, t, n);
            r && ws(e, n.ngContent.index, 1, r, null, void 0)
        }
        function fa(e, t) {
            return ma(128, e, new Array(t + 1))
        }
        function pa(e, t) {
            const n = Object.keys(t)
              , r = n.length
              , s = new Array(r);
            for (let i = 0; i < r; i++) {
                const e = n[i];
                s[t[e]] = e
            }
            return ma(64, e, s)
        }
        function ma(e, t, n) {
            const r = new Array(n.length);
            for (let s = 0; s < n.length; s++) {
                const e = n[s];
                r[s] = {
                    flags: 8,
                    name: e,
                    ns: null,
                    nonMinifiedName: e,
                    securityContext: null,
                    suffix: null
                }
            }
            return {
                nodeIndex: -1,
                parent: null,
                renderParent: null,
                bindingIndex: -1,
                outputIndex: -1,
                checkIndex: t,
                flags: e,
                childFlags: 0,
                directChildFlags: 0,
                childMatchedQueries: 0,
                matchedQueries: {},
                matchedQueryIds: 0,
                references: {},
                ngContentIndex: -1,
                childCount: 0,
                bindings: r,
                bindingFlags: xs(r),
                outputs: [],
                element: null,
                provider: null,
                text: null,
                query: null,
                ngContent: null
            }
        }
        function ga(e, t, n) {
            const r = new Array(n.length - 1);
            for (let s = 1; s < n.length; s++)
                r[s - 1] = {
                    flags: 8,
                    name: null,
                    ns: null,
                    nonMinifiedName: null,
                    securityContext: null,
                    suffix: n[s]
                };
            return {
                nodeIndex: -1,
                parent: null,
                renderParent: null,
                bindingIndex: -1,
                outputIndex: -1,
                checkIndex: e,
                flags: 2,
                childFlags: 0,
                directChildFlags: 0,
                childMatchedQueries: 0,
                matchedQueries: {},
                matchedQueryIds: 0,
                references: {},
                ngContentIndex: t,
                childCount: 0,
                bindings: r,
                bindingFlags: 8,
                outputs: [],
                element: null,
                provider: null,
                text: {
                    prefix: n[0]
                },
                query: null,
                ngContent: null
            }
        }
        function ba(e, t, n) {
            let r;
            const s = e.renderer;
            r = s.createText(n.text.prefix);
            const i = gs(e, t, n);
            return i && s.appendChild(i, r),
            {
                renderText: r
            }
        }
        function ya(e, t) {
            return (null != e ? e.toString() : "") + t.suffix
        }
        function va(e, t, n, r) {
            let s = 0
              , i = 0
              , o = 0
              , a = 0
              , c = 0
              , l = null
              , u = null
              , h = !1
              , d = !1
              , f = null;
            for (let p = 0; p < t.length; p++) {
                const e = t[p];
                if (e.nodeIndex = p,
                e.parent = l,
                e.bindingIndex = s,
                e.outputIndex = i,
                e.renderParent = u,
                o |= e.flags,
                c |= e.matchedQueryIds,
                e.element) {
                    const t = e.element;
                    t.publicProviders = l ? l.element.publicProviders : Object.create(null),
                    t.allProviders = t.publicProviders,
                    h = !1,
                    d = !1,
                    e.element.template && (c |= e.element.template.nodeMatchedQueries)
                }
                if (wa(l, e, t.length),
                s += e.bindings.length,
                i += e.outputs.length,
                !u && 3 & e.flags && (f = e),
                20224 & e.flags) {
                    h || (h = !0,
                    l.element.publicProviders = Object.create(l.element.publicProviders),
                    l.element.allProviders = l.element.publicProviders);
                    const t = 0 != (32768 & e.flags);
                    0 == (8192 & e.flags) || t ? l.element.publicProviders[Zr(e.provider.token)] = e : (d || (d = !0,
                    l.element.allProviders = Object.create(l.element.publicProviders)),
                    l.element.allProviders[Zr(e.provider.token)] = e),
                    t && (l.element.componentProvider = e)
                }
                if (l ? (l.childFlags |= e.flags,
                l.directChildFlags |= e.flags,
                l.childMatchedQueries |= e.matchedQueryIds,
                e.element && e.element.template && (l.childMatchedQueries |= e.element.template.nodeMatchedQueries)) : a |= e.flags,
                e.childCount > 0)
                    l = e,
                    _a(e) || (u = e);
                else
                    for (; l && p === l.nodeIndex + l.childCount; ) {
                        const e = l.parent;
                        e && (e.childFlags |= l.childFlags,
                        e.childMatchedQueries |= l.childMatchedQueries),
                        u = (l = e) && _a(l) ? l.renderParent : l
                    }
            }
            return {
                factory: null,
                nodeFlags: o,
                rootNodeFlags: a,
                nodeMatchedQueries: c,
                flags: e,
                nodes: t,
                updateDirectives: n || Kr,
                updateRenderer: r || Kr,
                handleEvent: (e, n, r, s) => t[n].element.handleEvent(e, r, s),
                bindingCount: s,
                outputCount: i,
                lastRenderRootNode: f
            }
        }
        function _a(e) {
            return 0 != (1 & e.flags) && null === e.element.name
        }
        function wa(e, t, n) {
            const r = t.element && t.element.template;
            if (r) {
                if (!r.lastRenderRootNode)
                    throw new Error("Illegal State: Embedded templates without nodes are not allowed!");
                if (r.lastRenderRootNode && 16777216 & r.lastRenderRootNode.flags)
                    throw new Error(`Illegal State: Last root node of a template can't have embedded views, at index ${t.nodeIndex}!`)
            }
            if (20224 & t.flags && 0 == (1 & (e ? e.flags : 0)))
                throw new Error(`Illegal State: StaticProvider/Directive nodes need to be children of elements or anchors, at index ${t.nodeIndex}!`);
            if (t.query) {
                if (67108864 & t.flags && (!e || 0 == (16384 & e.flags)))
                    throw new Error(`Illegal State: Content Query nodes need to be children of directives, at index ${t.nodeIndex}!`);
                if (134217728 & t.flags && e)
                    throw new Error(`Illegal State: View Query nodes have to be top level nodes, at index ${t.nodeIndex}!`)
            }
            if (t.childCount) {
                const r = e ? e.nodeIndex + e.childCount : n - 1;
                if (t.nodeIndex <= r && t.nodeIndex + t.childCount > r)
                    throw new Error(`Illegal State: childCount of node leads outside of parent, at index ${t.nodeIndex}!`)
            }
        }
        function Ea(e, t, n, r) {
            const s = Ta(e.root, e.renderer, e, t, n);
            return xa(s, e.component, r),
            ka(s),
            s
        }
        function Sa(e, t, n) {
            const r = Ta(e, e.renderer, null, null, t);
            return xa(r, n, n),
            ka(r),
            r
        }
        function Ca(e, t, n, r) {
            const s = t.element.componentRendererType;
            let i;
            return i = s ? e.root.rendererFactory.createRenderer(r, s) : e.root.renderer,
            Ta(e.root, i, e, t.element.componentProvider, n)
        }
        function Ta(e, t, n, r, s) {
            const i = new Array(s.nodes.length)
              , o = s.outputCount ? new Array(s.outputCount) : null;
            return {
                def: s,
                parent: n,
                viewContainerParent: null,
                parentNodeDef: r,
                context: null,
                component: null,
                nodes: i,
                state: 13,
                root: e,
                renderer: t,
                oldValues: new Array(s.bindingCount),
                disposables: o,
                initIndex: -1
            }
        }
        function xa(e, t, n) {
            e.component = t,
            e.context = n
        }
        function ka(e) {
            let t;
            hs(e) && (t = Vr(e.parent, e.parentNodeDef.parent.nodeIndex).renderElement);
            const n = e.def
              , r = e.nodes;
            for (let s = 0; s < n.nodes.length; s++) {
                const i = n.nodes[s];
                let o;
                switch (Gr.setCurrentNode(e, s),
                201347067 & i.flags) {
                case 1:
                    const n = na(e, t, i);
                    let a = void 0;
                    if (33554432 & i.flags) {
                        const t = ys(i.element.componentView);
                        a = Gr.createComponentView(e, i, t, n)
                    }
                    ra(e, a, i, n),
                    o = {
                        renderElement: n,
                        componentView: a,
                        viewContainer: null,
                        template: i.element.template ? Qs(e, i) : void 0
                    },
                    16777216 & i.flags && (o.viewContainer = Bs(e, i, o));
                    break;
                case 2:
                    o = ba(e, t, i);
                    break;
                case 512:
                case 1024:
                case 2048:
                case 256:
                    (o = r[s]) || 4096 & i.flags || (o = {
                        instance: fi(e, i)
                    });
                    break;
                case 16:
                    o = {
                        instance: pi(e, i)
                    };
                    break;
                case 16384:
                    (o = r[s]) || (o = {
                        instance: mi(e, i)
                    }),
                    32768 & i.flags && xa(Vr(e, i.parent.nodeIndex).componentView, o.instance, o.instance);
                    break;
                case 32:
                case 64:
                case 128:
                    o = {
                        value: void 0
                    };
                    break;
                case 67108864:
                case 134217728:
                    o = new Fi;
                    break;
                case 8:
                    da(e, t, i),
                    o = void 0
                }
                r[s] = o
            }
            Ma(e, Pa.CreateViewNodes),
            za(e, 201326592, 268435456, 0)
        }
        function Oa(e) {
            Da(e),
            Gr.updateDirectives(e, 1),
            La(e, Pa.CheckNoChanges),
            Gr.updateRenderer(e, 1),
            Ma(e, Pa.CheckNoChanges),
            e.state &= -97
        }
        function Ia(e) {
            1 & e.state ? (e.state &= -2,
            e.state |= 2) : e.state &= -3,
            zr(e, 0, 256),
            Da(e),
            Gr.updateDirectives(e, 0),
            La(e, Pa.CheckAndUpdate),
            za(e, 67108864, 536870912, 0);
            let t = zr(e, 256, 512);
            Si(e, 2097152 | (t ? 1048576 : 0)),
            Gr.updateRenderer(e, 0),
            Ma(e, Pa.CheckAndUpdate),
            za(e, 134217728, 536870912, 0),
            Si(e, 8388608 | ((t = zr(e, 512, 768)) ? 4194304 : 0)),
            2 & e.def.flags && (e.state &= -9),
            e.state &= -97,
            zr(e, 768, 1024)
        }
        function Aa(e, t, n, r, s, i, o, a, c, l, u, h, d) {
            return 0 === n ? function(e, t, n, r, s, i, o, a, c, l, u, h) {
                switch (201347067 & t.flags) {
                case 1:
                    return function(e, t, n, r, s, i, o, a, c, l, u, h) {
                        const d = t.bindings.length;
                        let f = !1;
                        return d > 0 && ia(e, t, 0, n) && (f = !0),
                        d > 1 && ia(e, t, 1, r) && (f = !0),
                        d > 2 && ia(e, t, 2, s) && (f = !0),
                        d > 3 && ia(e, t, 3, i) && (f = !0),
                        d > 4 && ia(e, t, 4, o) && (f = !0),
                        d > 5 && ia(e, t, 5, a) && (f = !0),
                        d > 6 && ia(e, t, 6, c) && (f = !0),
                        d > 7 && ia(e, t, 7, l) && (f = !0),
                        d > 8 && ia(e, t, 8, u) && (f = !0),
                        d > 9 && ia(e, t, 9, h) && (f = !0),
                        f
                    }(e, t, n, r, s, i, o, a, c, l, u, h);
                case 2:
                    return function(e, t, n, r, s, i, o, a, c, l, u, h) {
                        let d = !1;
                        const f = t.bindings
                          , p = f.length;
                        if (p > 0 && rs(e, t, 0, n) && (d = !0),
                        p > 1 && rs(e, t, 1, r) && (d = !0),
                        p > 2 && rs(e, t, 2, s) && (d = !0),
                        p > 3 && rs(e, t, 3, i) && (d = !0),
                        p > 4 && rs(e, t, 4, o) && (d = !0),
                        p > 5 && rs(e, t, 5, a) && (d = !0),
                        p > 6 && rs(e, t, 6, c) && (d = !0),
                        p > 7 && rs(e, t, 7, l) && (d = !0),
                        p > 8 && rs(e, t, 8, u) && (d = !0),
                        p > 9 && rs(e, t, 9, h) && (d = !0),
                        d) {
                            let d = t.text.prefix;
                            p > 0 && (d += ya(n, f[0])),
                            p > 1 && (d += ya(r, f[1])),
                            p > 2 && (d += ya(s, f[2])),
                            p > 3 && (d += ya(i, f[3])),
                            p > 4 && (d += ya(o, f[4])),
                            p > 5 && (d += ya(a, f[5])),
                            p > 6 && (d += ya(c, f[6])),
                            p > 7 && (d += ya(l, f[7])),
                            p > 8 && (d += ya(u, f[8])),
                            p > 9 && (d += ya(h, f[9]));
                            const m = Br(e, t.nodeIndex).renderText;
                            e.renderer.setValue(m, d)
                        }
                        return d
                    }(e, t, n, r, s, i, o, a, c, l, u, h);
                case 16384:
                    return function(e, t, n, r, s, i, o, a, c, l, u, h) {
                        const d = $r(e, t.nodeIndex)
                          , f = d.instance;
                        let p = !1
                          , m = void 0;
                        const g = t.bindings.length;
                        return g > 0 && ns(e, t, 0, n) && (p = !0,
                        m = Ei(e, d, t, 0, n, m)),
                        g > 1 && ns(e, t, 1, r) && (p = !0,
                        m = Ei(e, d, t, 1, r, m)),
                        g > 2 && ns(e, t, 2, s) && (p = !0,
                        m = Ei(e, d, t, 2, s, m)),
                        g > 3 && ns(e, t, 3, i) && (p = !0,
                        m = Ei(e, d, t, 3, i, m)),
                        g > 4 && ns(e, t, 4, o) && (p = !0,
                        m = Ei(e, d, t, 4, o, m)),
                        g > 5 && ns(e, t, 5, a) && (p = !0,
                        m = Ei(e, d, t, 5, a, m)),
                        g > 6 && ns(e, t, 6, c) && (p = !0,
                        m = Ei(e, d, t, 6, c, m)),
                        g > 7 && ns(e, t, 7, l) && (p = !0,
                        m = Ei(e, d, t, 7, l, m)),
                        g > 8 && ns(e, t, 8, u) && (p = !0,
                        m = Ei(e, d, t, 8, u, m)),
                        g > 9 && ns(e, t, 9, h) && (p = !0,
                        m = Ei(e, d, t, 9, h, m)),
                        m && f.ngOnChanges(m),
                        65536 & t.flags && Hr(e, 256, t.nodeIndex) && f.ngOnInit(),
                        262144 & t.flags && f.ngDoCheck(),
                        p
                    }(e, t, n, r, s, i, o, a, c, l, u, h);
                case 32:
                case 64:
                case 128:
                    return function(e, t, n, r, s, i, o, a, c, l, u, h) {
                        const d = t.bindings;
                        let f = !1;
                        const p = d.length;
                        if (p > 0 && rs(e, t, 0, n) && (f = !0),
                        p > 1 && rs(e, t, 1, r) && (f = !0),
                        p > 2 && rs(e, t, 2, s) && (f = !0),
                        p > 3 && rs(e, t, 3, i) && (f = !0),
                        p > 4 && rs(e, t, 4, o) && (f = !0),
                        p > 5 && rs(e, t, 5, a) && (f = !0),
                        p > 6 && rs(e, t, 6, c) && (f = !0),
                        p > 7 && rs(e, t, 7, l) && (f = !0),
                        p > 8 && rs(e, t, 8, u) && (f = !0),
                        p > 9 && rs(e, t, 9, h) && (f = !0),
                        f) {
                            const f = qr(e, t.nodeIndex);
                            let m;
                            switch (201347067 & t.flags) {
                            case 32:
                                m = new Array(d.length),
                                p > 0 && (m[0] = n),
                                p > 1 && (m[1] = r),
                                p > 2 && (m[2] = s),
                                p > 3 && (m[3] = i),
                                p > 4 && (m[4] = o),
                                p > 5 && (m[5] = a),
                                p > 6 && (m[6] = c),
                                p > 7 && (m[7] = l),
                                p > 8 && (m[8] = u),
                                p > 9 && (m[9] = h);
                                break;
                            case 64:
                                m = {},
                                p > 0 && (m[d[0].name] = n),
                                p > 1 && (m[d[1].name] = r),
                                p > 2 && (m[d[2].name] = s),
                                p > 3 && (m[d[3].name] = i),
                                p > 4 && (m[d[4].name] = o),
                                p > 5 && (m[d[5].name] = a),
                                p > 6 && (m[d[6].name] = c),
                                p > 7 && (m[d[7].name] = l),
                                p > 8 && (m[d[8].name] = u),
                                p > 9 && (m[d[9].name] = h);
                                break;
                            case 128:
                                const e = n;
                                switch (p) {
                                case 1:
                                    m = e.transform(n);
                                    break;
                                case 2:
                                    m = e.transform(r);
                                    break;
                                case 3:
                                    m = e.transform(r, s);
                                    break;
                                case 4:
                                    m = e.transform(r, s, i);
                                    break;
                                case 5:
                                    m = e.transform(r, s, i, o);
                                    break;
                                case 6:
                                    m = e.transform(r, s, i, o, a);
                                    break;
                                case 7:
                                    m = e.transform(r, s, i, o, a, c);
                                    break;
                                case 8:
                                    m = e.transform(r, s, i, o, a, c, l);
                                    break;
                                case 9:
                                    m = e.transform(r, s, i, o, a, c, l, u);
                                    break;
                                case 10:
                                    m = e.transform(r, s, i, o, a, c, l, u, h)
                                }
                            }
                            f.value = m
                        }
                        return f
                    }(e, t, n, r, s, i, o, a, c, l, u, h);
                default:
                    throw "unreachable"
                }
            }(e, t, r, s, i, o, a, c, l, u, h, d) : function(e, t, n) {
                switch (201347067 & t.flags) {
                case 1:
                    return function(e, t, n) {
                        let r = !1;
                        for (let s = 0; s < n.length; s++)
                            ia(e, t, s, n[s]) && (r = !0);
                        return r
                    }(e, t, n);
                case 2:
                    return function(e, t, n) {
                        const r = t.bindings;
                        let s = !1;
                        for (let i = 0; i < n.length; i++)
                            rs(e, t, i, n[i]) && (s = !0);
                        if (s) {
                            let s = "";
                            for (let e = 0; e < n.length; e++)
                                s += ya(n[e], r[e]);
                            s = t.text.prefix + s;
                            const i = Br(e, t.nodeIndex).renderText;
                            e.renderer.setValue(i, s)
                        }
                        return s
                    }(e, t, n);
                case 16384:
                    return function(e, t, n) {
                        const r = $r(e, t.nodeIndex)
                          , s = r.instance;
                        let i = !1
                          , o = void 0;
                        for (let a = 0; a < n.length; a++)
                            ns(e, t, a, n[a]) && (i = !0,
                            o = Ei(e, r, t, a, n[a], o));
                        return o && s.ngOnChanges(o),
                        65536 & t.flags && Hr(e, 256, t.nodeIndex) && s.ngOnInit(),
                        262144 & t.flags && s.ngDoCheck(),
                        i
                    }(e, t, n);
                case 32:
                case 64:
                case 128:
                    return function(e, t, n) {
                        const r = t.bindings;
                        let s = !1;
                        for (let i = 0; i < n.length; i++)
                            rs(e, t, i, n[i]) && (s = !0);
                        if (s) {
                            const s = qr(e, t.nodeIndex);
                            let i;
                            switch (201347067 & t.flags) {
                            case 32:
                                i = n;
                                break;
                            case 64:
                                i = {};
                                for (let t = 0; t < n.length; t++)
                                    i[r[t].name] = n[t];
                                break;
                            case 128:
                                const e = n[0]
                                  , s = n.slice(1);
                                i = e.transform(...s)
                            }
                            s.value = i
                        }
                        return s
                    }(e, t, n);
                default:
                    throw "unreachable"
                }
            }(e, t, r)
        }
        function Da(e) {
            const t = e.def;
            if (4 & t.nodeFlags)
                for (let n = 0; n < t.nodes.length; n++) {
                    const r = t.nodes[n];
                    if (4 & r.flags) {
                        const t = Vr(e, n).template._projectedViews;
                        if (t)
                            for (let n = 0; n < t.length; n++) {
                                const r = t[n];
                                r.state |= 32,
                                os(r, e)
                            }
                    } else
                        0 == (4 & r.childFlags) && (n += r.childCount)
                }
        }
        function Ra(e, t, n, r, s, i, o, a, c, l, u, h, d) {
            return 0 === n ? function(e, t, n, r, s, i, o, a, c, l, u, h) {
                const d = t.bindings.length;
                d > 0 && ss(e, t, 0, n),
                d > 1 && ss(e, t, 1, r),
                d > 2 && ss(e, t, 2, s),
                d > 3 && ss(e, t, 3, i),
                d > 4 && ss(e, t, 4, o),
                d > 5 && ss(e, t, 5, a),
                d > 6 && ss(e, t, 6, c),
                d > 7 && ss(e, t, 7, l),
                d > 8 && ss(e, t, 8, u),
                d > 9 && ss(e, t, 9, h)
            }(e, t, r, s, i, o, a, c, l, u, h, d) : function(e, t, n) {
                for (let r = 0; r < n.length; r++)
                    ss(e, t, r, n[r])
            }(e, t, r),
            !1
        }
        function ja(e, t) {
            if (Qr(e, t.nodeIndex).dirty)
                throw Lr(Gr.createDebugContext(e, t.nodeIndex), `Query ${t.query.id} not dirty`, `Query ${t.query.id} dirty`, 0 != (1 & e.state))
        }
        function Na(e) {
            if (!(128 & e.state)) {
                if (La(e, Pa.Destroy),
                Ma(e, Pa.Destroy),
                Si(e, 131072),
                e.disposables)
                    for (let t = 0; t < e.disposables.length; t++)
                        e.disposables[t]();
                !function(e) {
                    if (!(16 & e.state))
                        return;
                    const t = cs(e);
                    if (t) {
                        const n = t.template._projectedViews;
                        n && (ee(n, n.indexOf(e)),
                        Gr.dirtyParentQueries(e))
                    }
                }(e),
                e.renderer.destroyNode && function(e) {
                    const t = e.def.nodes.length;
                    for (let n = 0; n < t; n++) {
                        const t = e.def.nodes[n];
                        1 & t.flags ? e.renderer.destroyNode(Vr(e, n).renderElement) : 2 & t.flags ? e.renderer.destroyNode(Br(e, n).renderText) : (67108864 & t.flags || 134217728 & t.flags) && Qr(e, n).destroy()
                    }
                }(e),
                hs(e) && e.renderer.destroy(),
                e.state |= 128
            }
        }
        const Pa = function() {
            var e = {
                CreateViewNodes: 0,
                CheckNoChanges: 1,
                CheckNoChangesProjectedViews: 2,
                CheckAndUpdate: 3,
                CheckAndUpdateProjectedViews: 4,
                Destroy: 5
            };
            return e[e.CreateViewNodes] = "CreateViewNodes",
            e[e.CheckNoChanges] = "CheckNoChanges",
            e[e.CheckNoChangesProjectedViews] = "CheckNoChangesProjectedViews",
            e[e.CheckAndUpdate] = "CheckAndUpdate",
            e[e.CheckAndUpdateProjectedViews] = "CheckAndUpdateProjectedViews",
            e[e.Destroy] = "Destroy",
            e
        }();
        function Ma(e, t) {
            const n = e.def;
            if (33554432 & n.nodeFlags)
                for (let r = 0; r < n.nodes.length; r++) {
                    const s = n.nodes[r];
                    33554432 & s.flags ? Fa(Vr(e, r).componentView, t) : 0 == (33554432 & s.childFlags) && (r += s.childCount)
                }
        }
        function La(e, t) {
            const n = e.def;
            if (16777216 & n.nodeFlags)
                for (let r = 0; r < n.nodes.length; r++) {
                    const s = n.nodes[r];
                    if (16777216 & s.flags) {
                        const n = Vr(e, r).viewContainer._embeddedViews;
                        for (let e = 0; e < n.length; e++)
                            Fa(n[e], t)
                    } else
                        0 == (16777216 & s.childFlags) && (r += s.childCount)
                }
        }
        function Fa(e, t) {
            const n = e.state;
            switch (t) {
            case Pa.CheckNoChanges:
                0 == (128 & n) && (12 == (12 & n) ? Oa(e) : 64 & n && Ua(e, Pa.CheckNoChangesProjectedViews));
                break;
            case Pa.CheckNoChangesProjectedViews:
                0 == (128 & n) && (32 & n ? Oa(e) : 64 & n && Ua(e, t));
                break;
            case Pa.CheckAndUpdate:
                0 == (128 & n) && (12 == (12 & n) ? Ia(e) : 64 & n && Ua(e, Pa.CheckAndUpdateProjectedViews));
                break;
            case Pa.CheckAndUpdateProjectedViews:
                0 == (128 & n) && (32 & n ? Ia(e) : 64 & n && Ua(e, t));
                break;
            case Pa.Destroy:
                Na(e);
                break;
            case Pa.CreateViewNodes:
                ka(e)
            }
        }
        function Ua(e, t) {
            La(e, t),
            Ma(e, t)
        }
        function za(e, t, n, r) {
            if (!(e.def.nodeFlags & t && e.def.nodeFlags & n))
                return;
            const s = e.def.nodes.length;
            for (let i = 0; i < s; i++) {
                const s = e.def.nodes[i];
                if (s.flags & t && s.flags & n)
                    switch (Gr.setCurrentNode(e, s.nodeIndex),
                    r) {
                    case 0:
                        ca(e, s);
                        break;
                    case 1:
                        ja(e, s)
                    }
                s.childFlags & t && s.childFlags & n || (i += s.childCount)
            }
        }
        let Ha = !1;
        function Ba(e, t, n, r, s, i) {
            const o = s.injector.get(dr);
            return Sa($a(e, s, o, t, n), r, i)
        }
        function Va(e, t, n, r, s, i) {
            const o = s.injector.get(dr)
              , a = $a(e, s, new Ec(o), t, n)
              , c = ec(r);
            return _c(oc.create, Sa, null, [a, c, i])
        }
        function $a(e, t, n, r, s) {
            const i = t.injector.get(qt)
              , o = t.injector.get(bt)
              , a = n.createRenderer(null, null);
            return {
                ngModule: t,
                injector: e,
                projectableNodes: r,
                selectorOrNode: s,
                sanitizer: i,
                rendererFactory: n,
                renderer: a,
                errorHandler: o
            }
        }
        function qa(e, t, n, r) {
            const s = ec(n);
            return _c(oc.create, Ea, null, [e, t, s, r])
        }
        function Qa(e, t, n, r) {
            return n = Za.get(t.element.componentProvider.provider.token) || ec(n),
            _c(oc.create, Ca, null, [e, t, n, r])
        }
        function Ga(e, t, n, r) {
            return Xs(e, t, n, function(e) {
                const {hasOverrides: t, hasDeprecatedOverrides: n} = function(e) {
                    let t = !1
                      , n = !1;
                    return 0 === Ka.size ? {
                        hasOverrides: t,
                        hasDeprecatedOverrides: n
                    } : (e.providers.forEach(e => {
                        const r = Ka.get(e.token);
                        3840 & e.flags && r && (t = !0,
                        n = n || r.deprecatedBehavior)
                    }
                    ),
                    e.modules.forEach(e => {
                        Wa.forEach( (r, s) => {
                            C(s).providedIn === e && (t = !0,
                            n = n || r.deprecatedBehavior)
                        }
                        )
                    }
                    ),
                    {
                        hasOverrides: t,
                        hasDeprecatedOverrides: n
                    })
                }(e);
                return t ? (function(e) {
                    for (let t = 0; t < e.providers.length; t++) {
                        const r = e.providers[t];
                        n && (r.flags |= 4096);
                        const s = Ka.get(r.token);
                        s && (r.flags = -3841 & r.flags | s.flags,
                        r.deps = ms(s.deps),
                        r.value = s.value)
                    }
                    if (Wa.size > 0) {
                        let t = new Set(e.modules);
                        Wa.forEach( (r, s) => {
                            if (t.has(C(s).providedIn)) {
                                let t = {
                                    token: s,
                                    flags: r.flags | (n ? 4096 : 0),
                                    deps: ms(r.deps),
                                    value: r.value,
                                    index: e.providers.length
                                };
                                e.providers.push(t),
                                e.providersByKey[Zr(s)] = t
                            }
                        }
                        )
                    }
                }(e = e.factory( () => Kr)),
                e) : e
            }(r))
        }
        const Ka = new Map
          , Wa = new Map
          , Za = new Map;
        function Ya(e) {
            let t;
            Ka.set(e.token, e),
            "function" == typeof e.token && (t = C(e.token)) && "function" == typeof t.providedIn && Wa.set(e.token, e)
        }
        function Ja(e, t) {
            const n = ys(t.viewDefFactory)
              , r = ys(n.nodes[0].element.componentView);
            Za.set(e, r)
        }
        function Xa() {
            Ka.clear(),
            Wa.clear(),
            Za.clear()
        }
        function ec(e) {
            if (0 === Ka.size)
                return e;
            const t = function(e) {
                const t = [];
                let n = null;
                for (let r = 0; r < e.nodes.length; r++) {
                    const s = e.nodes[r];
                    1 & s.flags && (n = s),
                    n && 3840 & s.flags && Ka.has(s.provider.token) && (t.push(n.nodeIndex),
                    n = null)
                }
                return t
            }(e);
            if (0 === t.length)
                return e;
            e = e.factory( () => Kr);
            for (let r = 0; r < t.length; r++)
                n(e, t[r]);
            return e;
            function n(e, t) {
                for (let n = t + 1; n < e.nodes.length; n++) {
                    const t = e.nodes[n];
                    if (1 & t.flags)
                        return;
                    if (3840 & t.flags) {
                        const e = t.provider
                          , n = Ka.get(e.token);
                        n && (t.flags = -3841 & t.flags | n.flags,
                        e.deps = ms(n.deps),
                        e.value = n.value)
                    }
                }
            }
        }
        function tc(e, t, n, r, s, i, o, a, c, l, u, h, d) {
            const f = e.def.nodes[t];
            return Aa(e, f, n, r, s, i, o, a, c, l, u, h, d),
            224 & f.flags ? qr(e, t).value : void 0
        }
        function nc(e, t, n, r, s, i, o, a, c, l, u, h, d) {
            const f = e.def.nodes[t];
            return Ra(e, f, n, r, s, i, o, a, c, l, u, h, d),
            224 & f.flags ? qr(e, t).value : void 0
        }
        function rc(e) {
            return _c(oc.detectChanges, Ia, null, [e])
        }
        function sc(e) {
            return _c(oc.checkNoChanges, Oa, null, [e])
        }
        function ic(e) {
            return _c(oc.destroy, Na, null, [e])
        }
        const oc = function() {
            var e = {
                create: 0,
                detectChanges: 1,
                checkNoChanges: 2,
                destroy: 3,
                handleEvent: 4
            };
            return e[e.create] = "create",
            e[e.detectChanges] = "detectChanges",
            e[e.checkNoChanges] = "checkNoChanges",
            e[e.destroy] = "destroy",
            e[e.handleEvent] = "handleEvent",
            e
        }();
        let ac, cc, lc;
        function uc(e, t) {
            cc = e,
            lc = t
        }
        function hc(e, t, n, r) {
            return uc(e, t),
            _c(oc.handleEvent, e.def.handleEvent, null, [e, t, n, r])
        }
        function dc(e, t) {
            if (128 & e.state)
                throw Ur(oc[ac]);
            return uc(e, gc(e, 0)),
            e.def.updateDirectives(function(e, n, r, ...s) {
                const i = e.def.nodes[n];
                return 0 === t ? pc(e, i, r, s) : mc(e, i, r, s),
                16384 & i.flags && uc(e, gc(e, n)),
                224 & i.flags ? qr(e, i.nodeIndex).value : void 0
            }, e)
        }
        function fc(e, t) {
            if (128 & e.state)
                throw Ur(oc[ac]);
            return uc(e, bc(e, 0)),
            e.def.updateRenderer(function(e, n, r, ...s) {
                const i = e.def.nodes[n];
                return 0 === t ? pc(e, i, r, s) : mc(e, i, r, s),
                3 & i.flags && uc(e, bc(e, n)),
                224 & i.flags ? qr(e, i.nodeIndex).value : void 0
            }, e)
        }
        function pc(e, t, n, r) {
            if (Aa(e, t, n, ...r)) {
                const o = 1 === n ? r[0] : r;
                if (16384 & t.flags) {
                    const n = {};
                    for (let e = 0; e < t.bindings.length; e++) {
                        const r = t.bindings[e]
                          , a = o[e];
                        8 & r.flags && (n[(s = r.nonMinifiedName,
                        i = void 0,
                        i = s.replace(/[$@]/g, "_"),
                        `ng-reflect-${s = i.replace(Wt, (...e) => "-" + e[1].toLowerCase())}`)] = Zt(a))
                    }
                    const r = t.parent
                      , a = Vr(e, r.nodeIndex).renderElement;
                    if (r.element.name)
                        for (let t in n) {
                            const r = n[t];
                            null != r ? e.renderer.setAttribute(a, t, r) : e.renderer.removeAttribute(a, t)
                        }
                    else
                        e.renderer.setValue(a, `bindings=${JSON.stringify(n, null, 2)}`)
                }
            }
            var s, i
        }
        function mc(e, t, n, r) {
            Ra(e, t, n, ...r)
        }
        function gc(e, t) {
            for (let n = t; n < e.def.nodes.length; n++) {
                const t = e.def.nodes[n];
                if (16384 & t.flags && t.bindings && t.bindings.length)
                    return n
            }
            return null
        }
        function bc(e, t) {
            for (let n = t; n < e.def.nodes.length; n++) {
                const t = e.def.nodes[n];
                if (3 & t.flags && t.bindings && t.bindings.length)
                    return n
            }
            return null
        }
        class yc {
            constructor(e, t) {
                this.view = e,
                this.nodeIndex = t,
                null == t && (this.nodeIndex = t = 0),
                this.nodeDef = e.def.nodes[t];
                let n = this.nodeDef
                  , r = e;
                for (; n && 0 == (1 & n.flags); )
                    n = n.parent;
                if (!n)
                    for (; !n && r; )
                        n = ls(r),
                        r = r.parent;
                this.elDef = n,
                this.elView = r
            }
            get elOrCompView() {
                return Vr(this.elView, this.elDef.nodeIndex).componentView || this.view
            }
            get injector() {
                return Ks(this.elView, this.elDef)
            }
            get component() {
                return this.elOrCompView.component
            }
            get context() {
                return this.elOrCompView.context
            }
            get providerTokens() {
                const e = [];
                if (this.elDef)
                    for (let t = this.elDef.nodeIndex + 1; t <= this.elDef.nodeIndex + this.elDef.childCount; t++) {
                        const n = this.elView.def.nodes[t];
                        20224 & n.flags && e.push(n.provider.token),
                        t += n.childCount
                    }
                return e
            }
            get references() {
                const e = {};
                if (this.elDef) {
                    vc(this.elView, this.elDef, e);
                    for (let t = this.elDef.nodeIndex + 1; t <= this.elDef.nodeIndex + this.elDef.childCount; t++) {
                        const n = this.elView.def.nodes[t];
                        20224 & n.flags && vc(this.elView, n, e),
                        t += n.childCount
                    }
                }
                return e
            }
            get componentRenderElement() {
                const e = function(e) {
                    for (; e && !hs(e); )
                        e = e.parent;
                    return e.parent ? Vr(e.parent, ls(e).nodeIndex) : null
                }(this.elOrCompView);
                return e ? e.renderElement : void 0
            }
            get renderNode() {
                return 2 & this.nodeDef.flags ? us(this.view, this.nodeDef) : us(this.elView, this.elDef)
            }
            logError(e, ...t) {
                let n, r;
                2 & this.nodeDef.flags ? (n = this.view.def,
                r = this.nodeDef.nodeIndex) : (n = this.elView.def,
                r = this.elDef.nodeIndex);
                const s = function(e, t) {
                    let n = -1;
                    for (let r = 0; r <= t; r++)
                        3 & e.nodes[r].flags && n++;
                    return n
                }(n, r);
                let i = -1;
                n.factory( () => ++i === s ? e.error.bind(e, ...t) : Kr),
                i < s && (e.error("Illegal state: the ViewDefinitionFactory did not call the logger!"),
                e.error(...t))
            }
        }
        function vc(e, t, n) {
            for (let r in t.references)
                n[r] = ua(e, t, t.references[r])
        }
        function _c(e, t, n, r) {
            const s = ac
              , i = cc
              , o = lc;
            try {
                ac = e;
                const c = t.apply(n, r);
                return cc = i,
                lc = o,
                ac = s,
                c
            } catch (a) {
                if (pt(a) || !cc)
                    throw a;
                throw function(e, t) {
                    return e instanceof Error || (e = new Error(e.toString())),
                    Fr(e, t),
                    e
                }(a, wc())
            }
        }
        function wc() {
            return cc ? new yc(cc,lc) : null
        }
        class Ec {
            constructor(e) {
                this.delegate = e
            }
            createRenderer(e, t) {
                return new Sc(this.delegate.createRenderer(e, t))
            }
            begin() {
                this.delegate.begin && this.delegate.begin()
            }
            end() {
                this.delegate.end && this.delegate.end()
            }
            whenRenderingDone() {
                return this.delegate.whenRenderingDone ? this.delegate.whenRenderingDone() : Promise.resolve(null)
            }
        }
        class Sc {
            constructor(e) {
                this.delegate = e,
                this.debugContextFactory = wc,
                this.data = this.delegate.data
            }
            createDebugContext(e) {
                return this.debugContextFactory(e)
            }
            destroyNode(e) {
                const t = Qo(e);
                qo.delete(t.nativeNode),
                t instanceof Vo && (t.listeners.length = 0),
                this.delegate.destroyNode && this.delegate.destroyNode(e)
            }
            destroy() {
                this.delegate.destroy()
            }
            createElement(e, t) {
                const n = this.delegate.createElement(e, t)
                  , r = this.createDebugContext(n);
                if (r) {
                    const t = new $o(n,null,r);
                    t.name = e,
                    Go(t)
                }
                return n
            }
            createComment(e) {
                const t = this.delegate.createComment(e)
                  , n = this.createDebugContext(t);
                return n && Go(new Vo(t,null,n)),
                t
            }
            createText(e) {
                const t = this.delegate.createText(e)
                  , n = this.createDebugContext(t);
                return n && Go(new Vo(t,null,n)),
                t
            }
            appendChild(e, t) {
                const n = Qo(e)
                  , r = Qo(t);
                n && r && n instanceof $o && n.addChild(r),
                this.delegate.appendChild(e, t)
            }
            insertBefore(e, t, n) {
                const r = Qo(e)
                  , s = Qo(t)
                  , i = Qo(n);
                r && s && r instanceof $o && r.insertBefore(i, s),
                this.delegate.insertBefore(e, t, n)
            }
            removeChild(e, t) {
                const n = Qo(e)
                  , r = Qo(t);
                n && r && n instanceof $o && n.removeChild(r),
                this.delegate.removeChild(e, t)
            }
            selectRootElement(e, t) {
                const n = this.delegate.selectRootElement(e, t)
                  , r = wc();
                return r && Go(new $o(n,null,r)),
                n
            }
            setAttribute(e, t, n, r) {
                const s = Qo(e);
                s && s instanceof $o && (s.attributes[r ? r + ":" + t : t] = n),
                this.delegate.setAttribute(e, t, n, r)
            }
            removeAttribute(e, t, n) {
                const r = Qo(e);
                r && r instanceof $o && (r.attributes[n ? n + ":" + t : t] = null),
                this.delegate.removeAttribute(e, t, n)
            }
            addClass(e, t) {
                const n = Qo(e);
                n && n instanceof $o && (n.classes[t] = !0),
                this.delegate.addClass(e, t)
            }
            removeClass(e, t) {
                const n = Qo(e);
                n && n instanceof $o && (n.classes[t] = !1),
                this.delegate.removeClass(e, t)
            }
            setStyle(e, t, n, r) {
                const s = Qo(e);
                s && s instanceof $o && (s.styles[t] = n),
                this.delegate.setStyle(e, t, n, r)
            }
            removeStyle(e, t, n) {
                const r = Qo(e);
                r && r instanceof $o && (r.styles[t] = null),
                this.delegate.removeStyle(e, t, n)
            }
            setProperty(e, t, n) {
                const r = Qo(e);
                r && r instanceof $o && (r.properties[t] = n),
                this.delegate.setProperty(e, t, n)
            }
            listen(e, t, n) {
                if ("string" != typeof e) {
                    const r = Qo(e);
                    r && r.listeners.push(new Bo(t,n))
                }
                return this.delegate.listen(e, t, n)
            }
            parentNode(e) {
                return this.delegate.parentNode(e)
            }
            nextSibling(e) {
                return this.delegate.nextSibling(e)
            }
            setValue(e, t) {
                return this.delegate.setValue(e, t)
            }
        }
        function Cc(e, t, n) {
            return new Tc(e,t,n)
        }
        class Tc extends J {
            constructor(e, t, n) {
                super(),
                this.moduleType = e,
                this._bootstrapComponents = t,
                this._ngModuleDefFactory = n
            }
            create(e) {
                !function() {
                    if (Ha)
                        return;
                    Ha = !0;
                    const e = _t() ? {
                        setCurrentNode: uc,
                        createRootView: Va,
                        createEmbeddedView: qa,
                        createComponentView: Qa,
                        createNgModuleRef: Ga,
                        overrideProvider: Ya,
                        overrideComponentView: Ja,
                        clearOverrides: Xa,
                        checkAndUpdateView: rc,
                        checkNoChangesView: sc,
                        destroyView: ic,
                        createDebugContext: (e, t) => new yc(e,t),
                        handleEvent: hc,
                        updateDirectives: dc,
                        updateRenderer: fc
                    } : {
                        setCurrentNode: () => {}
                        ,
                        createRootView: Ba,
                        createEmbeddedView: Ea,
                        createComponentView: Ca,
                        createNgModuleRef: Xs,
                        overrideProvider: Kr,
                        overrideComponentView: Kr,
                        clearOverrides: Kr,
                        checkAndUpdateView: Ia,
                        checkNoChangesView: Oa,
                        destroyView: Na,
                        createDebugContext: (e, t) => new yc(e,t),
                        handleEvent: (e, t, n, r) => e.def.handleEvent(e, t, n, r),
                        updateDirectives: (e, t) => e.def.updateDirectives(0 === t ? tc : nc, e),
                        updateRenderer: (e, t) => e.def.updateRenderer(0 === t ? tc : nc, e)
                    };
                    Gr.setCurrentNode = e.setCurrentNode,
                    Gr.createRootView = e.createRootView,
                    Gr.createEmbeddedView = e.createEmbeddedView,
                    Gr.createComponentView = e.createComponentView,
                    Gr.createNgModuleRef = e.createNgModuleRef,
                    Gr.overrideProvider = e.overrideProvider,
                    Gr.overrideComponentView = e.overrideComponentView,
                    Gr.clearOverrides = e.clearOverrides,
                    Gr.checkAndUpdateView = e.checkAndUpdateView,
                    Gr.checkNoChangesView = e.checkNoChangesView,
                    Gr.destroyView = e.destroyView,
                    Gr.resolveDep = _i,
                    Gr.createDebugContext = e.createDebugContext,
                    Gr.handleEvent = e.handleEvent,
                    Gr.updateDirectives = e.updateDirectives,
                    Gr.updateRenderer = e.updateRenderer,
                    Gr.dirtyParentQueries = aa
                }();
                const t = function(e) {
                    const t = Array.from(e.providers)
                      , n = Array.from(e.modules)
                      , r = {};
                    for (const s in e.providersByKey)
                        r[s] = e.providersByKey[s];
                    return {
                        factory: e.factory,
                        isRoot: e.isRoot,
                        providers: t,
                        modules: n,
                        providersByKey: r
                    }
                }(ys(this._ngModuleDefFactory));
                return Gr.createNgModuleRef(this.moduleType, e || En.NULL, this._bootstrapComponents, t)
            }
        }
    },
    "9ppp": function(e, t, n) {
        "use strict";
        function r() {
            return Error.call(this),
            this.message = "object unsubscribed",
            this.name = "ObjectUnsubscribedError",
            this
        }
        n.d(t, "a", function() {
            return s
        }),
        r.prototype = Object.create(Error.prototype);
        const s = r
    },
    AytR: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        const r = {
            production: !0,
            mock: !1,
            api: "./i"
        }
    },
    BJVr: function(e, t, n) {
        "use strict";
        var r = n("8Y7J")
          , s = n("wUVa")
          , i = n("5GAg");
        n.d(t, "a", function() {
            return l
        });
        var o = r.qb({
            encapsulation: 2,
            styles: [['@charset "UTF-8";app-dialog,app-dialog::after{position:absolute;top:0;right:0;bottom:0;left:0;opacity:0;transition:opacity .3s ease 0s}app-dialog{display:flex;justify-content:center;align-items:center;padding:1.5rem;z-index:1102}app-dialog::after{content:"";background:rgba(0,0,0,.5);z-index:1100}app-dialog.show,app-dialog.show::after{opacity:1}app-dialog>*{display:flex;flex-direction:column;max-width:100%;max-height:100%;background:#f4f4f4;color:#333;border:thin solid #ddd;border-radius:.25rem;box-shadow:0 2px 1px 0 rgba(0,0,0,.15);overflow:hidden;z-index:1103;transform:scale(0);transition:transform .3s ease 0s}app-dialog.show>*{transform:scale(1)}@media screen and (max-device-width:450px),screen and (max-device-height:450px){app-dialog{padding:.5rem}}']],
            data: {}
        });
        function a(e) {
            return r.Mb(0, [r.Ib(402653184, 1, {
                container: 0
            }), (e()(),
            r.sb(1, 16777216, [[1, 3], ["inner", 1]], null, 0, null, null, null, null, null, null, null))], null, null)
        }
        function c(e) {
            return r.Mb(0, [(e()(),
            r.sb(0, 0, null, null, 1, "app-dialog", [], null, null, null, a, o)), r.rb(1, 4440064, null, 0, s.a, [r.k, r.D, r.y, i.e], null, null)], function(e, t) {
                e(t, 1, 0)
            }, null)
        }
        var l = r.ob("app-dialog", s.a, c, {}, {}, [])
    },
    CRDf: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("kJWO");
        const s = e => t => {
            const n = e[r.a]();
            if ("function" != typeof n.subscribe)
                throw new TypeError("Provided object does not correctly implement Symbol.observable");
            return n.subscribe(t)
        }
    },
    Cfvw: function(e, t, n) {
        "use strict";
        var r = n("HDdC")
          , s = n("c2HN")
          , i = n("I55L")
          , o = n("kJWO")
          , a = n("Lhse")
          , c = n("yCtX")
          , l = n("quSY")
          , u = n("a7t3")
          , h = n("pLzU")
          , d = n("CRDf")
          , f = n("SeVD");
        function p(e, t) {
            if (!t)
                return e instanceof r.a ? e : new r.a(Object(f.a)(e));
            if (null != e) {
                if (function(e) {
                    return e && "function" == typeof e[o.a]
                }(e))
                    return function(e, t) {
                        return new r.a(t ? n => {
                            const r = new l.a;
                            return r.add(t.schedule( () => {
                                const s = e[o.a]();
                                r.add(s.subscribe({
                                    next(e) {
                                        r.add(t.schedule( () => n.next(e)))
                                    },
                                    error(e) {
                                        r.add(t.schedule( () => n.error(e)))
                                    },
                                    complete() {
                                        r.add(t.schedule( () => n.complete()))
                                    }
                                }))
                            }
                            )),
                            r
                        }
                        : Object(d.a)(e))
                    }(e, t);
                if (Object(s.a)(e))
                    return function(e, t) {
                        return new r.a(t ? n => {
                            const r = new l.a;
                            return r.add(t.schedule( () => e.then(e => {
                                r.add(t.schedule( () => {
                                    n.next(e),
                                    r.add(t.schedule( () => n.complete()))
                                }
                                ))
                            }
                            , e => {
                                r.add(t.schedule( () => n.error(e)))
                            }
                            ))),
                            r
                        }
                        : Object(u.a)(e))
                    }(e, t);
                if (Object(i.a)(e))
                    return Object(c.a)(e, t);
                if (function(e) {
                    return e && "function" == typeof e[a.a]
                }(e) || "string" == typeof e)
                    return function(e, t) {
                        if (!e)
                            throw new Error("Iterable cannot be null");
                        return new r.a(t ? n => {
                            const r = new l.a;
                            let s;
                            return r.add( () => {
                                s && "function" == typeof s.return && s.return()
                            }
                            ),
                            r.add(t.schedule( () => {
                                s = e[a.a](),
                                r.add(t.schedule(function() {
                                    if (n.closed)
                                        return;
                                    let e, t;
                                    try {
                                        const i = s.next();
                                        e = i.value,
                                        t = i.done
                                    } catch (r) {
                                        return void n.error(r)
                                    }
                                    t ? n.complete() : (n.next(e),
                                    this.schedule())
                                }))
                            }
                            )),
                            r
                        }
                        : Object(h.a)(e))
                    }(e, t)
            }
            throw new TypeError((null !== e && typeof e || e) + " is not observable")
        }
        n.d(t, "a", function() {
            return p
        })
    },
    D0XW: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("3N8a");
        const s = new (n("IjjT").a)(r.a)
    },
    DH7j: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        const r = Array.isArray || (e => e && "number" == typeof e.length)
    },
    DQLy: function(e, t, n) {
        "use strict";
        var r = n("8Y7J")
          , s = n("2Vo4")
          , i = n("HDdC")
          , o = n("XNiG")
          , a = n("qgXg")
          , c = n("pxpQ")
          , l = n("l7GE")
          , u = n("ZUHj");
        class h {
            constructor(e, t) {
                this.observables = e,
                this.project = t
            }
            call(e, t) {
                return t.subscribe(new d(e,this.observables,this.project))
            }
        }
        class d extends l.a {
            constructor(e, t, n) {
                super(e),
                this.observables = t,
                this.project = n,
                this.toRespond = [];
                const r = t.length;
                this.values = new Array(r);
                for (let s = 0; s < r; s++)
                    this.toRespond.push(s);
                for (let s = 0; s < r; s++) {
                    let e = t[s];
                    this.add(Object(u.a)(this, e, e, s))
                }
            }
            notifyNext(e, t, n, r, s) {
                this.values[n] = t;
                const i = this.toRespond;
                if (i.length > 0) {
                    const e = i.indexOf(n);
                    -1 !== e && i.splice(e, 1)
                }
            }
            notifyComplete() {}
            _next(e) {
                if (0 === this.toRespond.length) {
                    const t = [e, ...this.values];
                    this.project ? this._tryProject(t) : this.destination.next(t)
                }
            }
            _tryProject(e) {
                let t;
                try {
                    t = this.project.apply(this, e)
                } catch (n) {
                    return void this.destination.error(n)
                }
                this.destination.next(t)
            }
        }
        var f = n("Kqap")
          , p = n("lJxs")
          , m = n("/uUt");
        function g(e, t) {
            if ("function" == typeof t)
                return b(e, (...n) => Object.assign({}, t(...n), {
                    type: e
                }));
            switch (t ? t._as : "empty") {
            case "empty":
                return b(e, () => ({
                    type: e
                }));
            case "props":
                return b(e, t => Object.assign({}, t, {
                    type: e
                }));
            default:
                throw new Error("Unexpected config.")
            }
        }
        function b(e, t) {
            return Object.defineProperty(t, "type", {
                value: e,
                writable: !1
            })
        }
        n.d(t, "A", function() {
            return fe
        }),
        n.d(t, "R", function() {
            return ue
        }),
        n.d(t, "T", function() {
            return de
        }),
        n.d(t, "S", function() {
            return he
        }),
        n.d(t, "Q", function() {
            return _e
        }),
        n.d(t, "O", function() {
            return ye
        }),
        n.d(t, "N", function() {
            return be
        }),
        n.d(t, "M", function() {
            return ge
        }),
        n.d(t, "P", function() {
            return ve
        }),
        n.d(t, "L", function() {
            return F
        }),
        n.d(t, "G", function() {
            return I
        }),
        n.d(t, "F", function() {
            return O
        }),
        n.d(t, "I", function() {
            return D
        }),
        n.d(t, "D", function() {
            return T
        }),
        n.d(t, "B", function() {
            return _
        }),
        n.d(t, "C", function() {
            return S
        }),
        n.d(t, "J", function() {
            return P
        }),
        n.d(t, "H", function() {
            return A
        }),
        n.d(t, "E", function() {
            return k
        }),
        n.d(t, "K", function() {
            return L
        }),
        n.d(t, "u", function() {
            return g
        }),
        n.d(t, "n", function() {
            return Z
        }),
        n.d(t, "s", function() {
            return U
        }),
        n.d(t, "t", function() {
            return z
        }),
        n.d(t, "x", function() {
            return H
        }),
        n.d(t, "a", function() {
            return v
        }),
        n.d(t, "g", function() {
            return q
        }),
        n.d(t, "i", function() {
            return B
        }),
        n.d(t, "h", function() {
            return V
        }),
        n.d(t, "k", function() {
            return Q
        }),
        n.d(t, "y", function() {
            return X
        }),
        n.d(t, "v", function() {
            return te
        }),
        n.d(t, "l", function() {
            return K
        }),
        n.d(t, "m", function() {
            return G
        }),
        n.d(t, "d", function() {
            return w
        }),
        n.d(t, "f", function() {
            return E
        }),
        n.d(t, "c", function() {
            return C
        }),
        n.d(t, "j", function() {
            return x
        }),
        n.d(t, "e", function() {
            return N
        }),
        n.d(t, "b", function() {
            return R
        }),
        n.d(t, "q", function() {
            return j
        }),
        n.d(t, "r", function() {
            return M
        }),
        n.d(t, "p", function() {
            return pe
        }),
        n.d(t, "o", function() {
            return me
        }),
        n.d(t, "z", function() {
            return we
        }),
        n.d(t, "w", function() {
            return Ee
        });
        const y = "@ngrx/store/init";
        class v extends s.a {
            constructor() {
                super({
                    type: y
                })
            }
            next(e) {
                if ("function" == typeof e)
                    throw new TypeError("\n        Dispatch expected an object, instead it received a function.\n        If you're using the createAction function, make sure to invoke the function\n        before dispatching the action. For example, someAction should be someAction().");
                if (void 0 === e)
                    throw new TypeError("Actions must be objects");
                if (void 0 === e.type)
                    throw new TypeError("Actions must have a type property");
                super.next(e)
            }
            complete() {}
            ngOnDestroy() {
                super.complete()
            }
        }
        const _ = new r.p("@ngrx/store Internal Initial State")
          , w = new r.p("@ngrx/store Initial State")
          , E = new r.p("@ngrx/store Reducer Factory")
          , S = new r.p("@ngrx/store Internal Reducer Factory Provider")
          , C = new r.p("@ngrx/store Initial Reducers")
          , T = new r.p("@ngrx/store Internal Initial Reducers")
          , x = new r.p("@ngrx/store Store Features")
          , k = new r.p("@ngrx/store Internal Store Reducers")
          , O = new r.p("@ngrx/store Internal Feature Reducers")
          , I = new r.p("@ngrx/store Internal Feature Configs")
          , A = new r.p("@ngrx/store Internal Store Features")
          , D = new r.p("@ngrx/store Internal Feature Reducers Token")
          , R = new r.p("@ngrx/store Feature Reducers")
          , j = new r.p("@ngrx/store User Provided Meta Reducers")
          , N = new r.p("@ngrx/store Meta Reducers")
          , P = new r.p("@ngrx/store Internal Resolved Meta Reducers")
          , M = new r.p("@ngrx/store User Runtime Checks Config")
          , L = new r.p("@ngrx/store Internal User Runtime Checks Config")
          , F = new r.p("@ngrx/store Internal Runtime Checks");
        function U(e, t={}) {
            const n = Object.keys(e)
              , r = {};
            for (let i = 0; i < n.length; i++) {
                const t = n[i];
                "function" == typeof e[t] && (r[t] = e[t])
            }
            const s = Object.keys(r);
            return function(e, n) {
                e = void 0 === e ? t : e;
                let i = !1;
                const o = {};
                for (let t = 0; t < s.length; t++) {
                    const a = s[t]
                      , c = e[a]
                      , l = (0,
                    r[a])(c, n);
                    o[a] = l,
                    i = i || l !== c
                }
                return i ? o : e
            }
        }
        function z(...e) {
            return function(t) {
                if (0 === e.length)
                    return t;
                const n = e[e.length - 1];
                return e.slice(0, -1).reduceRight( (e, t) => t(e), n(t))
            }
        }
        function H(e, t) {
            return Array.isArray(t) && t.length > 0 && (e = z.apply(null, [...t, e])),
            (t, n) => {
                const r = e(t);
                return (e, t) => r(e = void 0 === e ? n : e, t)
            }
        }
        class B extends i.a {
        }
        class V extends v {
        }
        const $ = "@ngrx/store/update-reducers";
        class q extends s.a {
            constructor(e, t, n, r) {
                super(r(n, t)),
                this.dispatcher = e,
                this.initialState = t,
                this.reducers = n,
                this.reducerFactory = r
            }
            addFeature(e) {
                this.addFeatures([e])
            }
            addFeatures(e) {
                const t = e.reduce( (e, {reducers: t, reducerFactory: n, metaReducers: r, initialState: s, key: i}) => {
                    const o = "function" == typeof t ? function(e) {
                        const t = Array.isArray(e) && e.length > 0 ? z(...e) : e => e;
                        return (e, n) => (e = t(e),
                        (t, r) => e(t = void 0 === t ? n : t, r))
                    }(r)(t, s) : H(n, r)(t, s);
                    return e[i] = o,
                    e
                }
                , {});
                this.addReducers(t)
            }
            removeFeature(e) {
                this.removeFeatures([e])
            }
            removeFeatures(e) {
                this.removeReducers(e.map(e => e.key))
            }
            addReducer(e, t) {
                this.addReducers({
                    [e]: t
                })
            }
            addReducers(e) {
                this.reducers = Object.assign({}, this.reducers, e),
                this.updateReducers(Object.keys(e))
            }
            removeReducer(e) {
                this.removeReducers([e])
            }
            removeReducers(e) {
                e.forEach(e => {
                    this.reducers = function(e, t) {
                        return Object.keys(e).filter(e => e !== t).reduce( (t, n) => Object.assign(t, {
                            [n]: e[n]
                        }), {})
                    }(this.reducers, e)
                }
                ),
                this.updateReducers(e)
            }
            updateReducers(e) {
                this.next(this.reducerFactory(this.reducers, this.initialState)),
                this.dispatcher.next({
                    type: $,
                    features: e
                })
            }
            ngOnDestroy() {
                this.complete()
            }
        }
        class Q extends o.a {
            ngOnDestroy() {
                this.complete()
            }
        }
        class G extends i.a {
        }
        let K = ( () => {
            class e extends s.a {
                constructor(e, t, n, r) {
                    super(r);
                    const s = {
                        state: r
                    }
                      , i = e.pipe(Object(c.b)(a.a)).pipe(function(...e) {
                        return t => {
                            let n;
                            return "function" == typeof e[e.length - 1] && (n = e.pop()),
                            t.lift(new h(e,n))
                        }
                    }(t)).pipe(Object(f.a)(W, s));
                    this.stateSubscription = i.subscribe( ({state: e, action: t}) => {
                        this.next(e),
                        n.next(t)
                    }
                    )
                }
                ngOnDestroy() {
                    this.stateSubscription.unsubscribe(),
                    this.complete()
                }
            }
            return e.INIT = y,
            e
        }
        )();
        function W(e={
            state: void 0
        }, [t,n]) {
            const {state: r} = e;
            return {
                state: n(r, t),
                action: t
            }
        }
        class Z extends i.a {
            constructor(e, t, n) {
                super(),
                this.actionsObserver = t,
                this.reducerManager = n,
                this.source = e
            }
            select(e, ...t) {
                return (function(e, t, ...n) {
                    return function(r) {
                        let s;
                        if ("string" == typeof e) {
                            const i = [t, ...n].filter(Boolean);
                            s = r.pipe(function(...e) {
                                const t = e.length;
                                if (0 === t)
                                    throw new Error("list of properties cannot be empty.");
                                return n => Object(p.a)(function(e, t) {
                                    return n => {
                                        let r = n;
                                        for (let s = 0; s < t; s++) {
                                            const t = r[e[s]];
                                            if (void 0 === t)
                                                return;
                                            r = t
                                        }
                                        return r
                                    }
                                }(e, t))(n)
                            }(e, ...i))
                        } else {
                            if ("function" != typeof e)
                                throw new TypeError(`Unexpected type '${typeof e}' in select operator,` + " expected 'string' or 'function'");
                            s = r.pipe(Object(p.a)(n => e(n, t)))
                        }
                        return s.pipe(Object(m.a)())
                    }
                }
                ).call(null, e, ...t)(this)
            }
            lift(e) {
                const t = new Z(this,this.actionsObserver,this.reducerManager);
                return t.operator = e,
                t
            }
            dispatch(e) {
                this.actionsObserver.next(e)
            }
            next(e) {
                this.actionsObserver.next(e)
            }
            error(e) {
                this.actionsObserver.error(e)
            }
            complete() {
                this.actionsObserver.complete()
            }
            addReducer(e, t) {
                this.reducerManager.addReducer(e, t)
            }
            removeReducer(e) {
                this.reducerManager.removeReducer(e)
            }
        }
        function Y(e, t) {
            return e === t
        }
        function J(e, t=Y, n=Y) {
            let r, s = null, i = null;
            return {
                memoized: function() {
                    if (void 0 !== r)
                        return r;
                    if (!s)
                        return i = e.apply(null, arguments),
                        s = arguments,
                        i;
                    if (!function(e, t, n) {
                        for (let r = 0; r < e.length; r++)
                            if (!n(e[r], t[r]))
                                return !0;
                        return !1
                    }(arguments, s, t))
                        return i;
                    s = arguments;
                    const o = e.apply(null, arguments);
                    return n(i, o) ? i : (i = o,
                    o)
                },
                reset: function() {
                    s = null,
                    i = null
                },
                setResult: function(e) {
                    r = e
                }
            }
        }
        function X(...e) {
            return function(e, t={
                stateFn: ee
            }) {
                return function(...n) {
                    let r = n;
                    if (Array.isArray(r[0])) {
                        const [e,...t] = r;
                        r = [...e, ...t]
                    }
                    const s = r.slice(0, r.length - 1)
                      , i = r[r.length - 1]
                      , o = s.filter(e => e.release && "function" == typeof e.release)
                      , a = e(function(...e) {
                        return i.apply(null, e)
                    })
                      , c = J(function(e, n) {
                        return t.stateFn.apply(null, [e, s, n, a])
                    });
                    return Object.assign(c.memoized, {
                        release: function() {
                            c.reset(),
                            a.reset(),
                            o.forEach(e => e.release())
                        },
                        projector: a.memoized,
                        setResult: c.setResult
                    })
                }
            }(J)(...e)
        }
        function ee(e, t, n, r) {
            if (void 0 === n) {
                const n = t.map(t => t(e));
                return r.memoized.apply(null, n)
            }
            const s = t.map(t => t(e, n));
            return r.memoized.apply(null, [...s, n])
        }
        function te(e) {
            return X(t => {
                const n = t[e];
                return Object(r.W)() && void 0 === n && console.warn(`The feature name "${e}" does ` + "not exist in the state, therefore createFeatureSelector cannot access it.  Be sure it is imported in a loaded module " + `using StoreModule.forRoot('${e}', ...) or ` + `StoreModule.forFeature('${e}', ...).  If the default ` + "state is intended to be undefined, as is the case with router state, this development-only warning message can be ignored."),
                n
            }
            , e => e)
        }
        function ne(e) {
            return void 0 === e
        }
        function re(e) {
            return null === e
        }
        function se(e) {
            return Array.isArray(e)
        }
        function ie(e) {
            return "object" == typeof e && null !== e
        }
        function oe(e) {
            return "function" == typeof e
        }
        function ae(e) {
            Object.freeze(e);
            const t = oe(e);
            return Object.getOwnPropertyNames(e).forEach(n => {
                if (function(e, t) {
                    return Object.prototype.hasOwnProperty.call(e, n)
                }(e) && (!t || "caller" !== n && "callee" !== n && "arguments" !== n)) {
                    const t = e[n];
                    !ie(t) && !oe(t) || Object.isFrozen(t) || ae(t)
                }
            }
            ),
            e
        }
        function ce(e, t=[]) {
            return (ne(e) || re(e)) && 0 === t.length ? {
                path: ["root"],
                value: e
            } : Object.keys(e).reduce( (n, r) => {
                if (n)
                    return n;
                const s = e[r];
                return !(ne(s) || re(s) || function(e) {
                    return "number" == typeof s
                }() || function(e) {
                    return "boolean" == typeof s
                }() || function(e) {
                    return "string" == typeof s
                }() || se(s)) && (function(e) {
                    if (!function(e) {
                        return ie(e) && !se(e)
                    }(e))
                        return !1;
                    const t = Object.getPrototypeOf(e);
                    return t === Object.prototype || null === t
                }(s) ? ce(s, [...t, r]) : {
                    path: [...t, r],
                    value: s
                })
            }
            , !1)
        }
        function le(e, t) {
            if (!1 === e)
                return;
            const n = e.path.join(".")
              , r = new Error(`Detected unserializable ${t} at "${n}"`);
            throw r.value = e.value,
            r.unserializablePath = n,
            r
        }
        function ue(e) {
            return Object(r.W)() ? (void 0 === e && console.warn("@ngrx/store: runtime checks are currently opt-in but will be the default in the next major version with the possibility to opt-out, see https://ngrx.io/guide/migration/v8 for more information."),
            Object.assign({
                strictStateSerializability: !1,
                strictActionSerializability: !1,
                strictStateImmutability: !1,
                strictActionImmutability: !1
            }, e)) : {
                strictStateSerializability: !1,
                strictActionSerializability: !1,
                strictStateImmutability: !1,
                strictActionImmutability: !1
            }
        }
        function he({strictActionSerializability: e, strictStateSerializability: t}) {
            return n => e || t ? function(e, t) {
                return function(n, r) {
                    t.action && le(ce(r), "action");
                    const s = e(n, r);
                    return t.state && le(ce(s), "state"),
                    s
                }
            }(n, {
                action: e,
                state: t
            }) : n
        }
        function de({strictActionImmutability: e, strictStateImmutability: t}) {
            return n => e || t ? function(e, t) {
                return function(n, r) {
                    const s = t.action ? ae(r) : r
                      , i = e(n, s);
                    return t.state ? ae(i) : i
                }
            }(n, {
                action: e,
                state: t
            }) : n
        }
        function fe(e) {
            return e
        }
        class pe {
            constructor(e, t, n, r) {}
        }
        class me {
            constructor(e, t, n, r) {
                this.features = e,
                this.featureReducers = t,
                this.reducerManager = n;
                const s = e.map( (e, n) => {
                    const r = t.shift();
                    return Object.assign({}, e, {
                        reducers: r[n],
                        initialState: ve(e.initialState)
                    })
                }
                );
                n.addFeatures(s)
            }
            ngOnDestroy() {
                this.reducerManager.removeFeatures(this.features)
            }
        }
        function ge(e, t) {
            return t instanceof r.p ? e.get(t) : t
        }
        function be(e, t, n) {
            return n.map( (n, s) => {
                if (t[s]instanceof r.p) {
                    const r = e.get(t[s]);
                    return {
                        key: n.key,
                        reducerFactory: r.reducerFactory ? r.reducerFactory : U,
                        metaReducers: r.metaReducers ? r.metaReducers : [],
                        initialState: r.initialState
                    }
                }
                return n
            }
            )
        }
        function ye(e, t) {
            return t.map(t => t instanceof r.p ? e.get(t) : t)
        }
        function ve(e) {
            return "function" == typeof e ? e() : e
        }
        function _e(e, t) {
            return e.concat(t)
        }
        function we(...e) {
            return {
                reducer: e.pop(),
                types: e.reduce( (e, t) => [...e, t.type], [])
            }
        }
        function Ee(e, ...t) {
            const n = new Map;
            for (let r of t)
                for (let e of r.types)
                    n.set(e, r.reducer);
            return function(t=e, r) {
                const s = n.get(r.type);
                return s ? s(t, r) : t
            }
        }
    },
    EY2u: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        }),
        n.d(t, "b", function() {
            return i
        });
        var r = n("HDdC");
        const s = new r.a(e => e.complete());
        function i(e) {
            return e ? function(e) {
                return new r.a(t => e.schedule( () => t.complete()))
            }(e) : s
        }
    },
    FBHR: function(e, t, n) {
        "use strict";
        var r = n("8Y7J")
          , s = n("SVse")
          , i = n("Jq3a")
          , o = n("cUpR")
          , a = n("Toje")
          , c = n("/GRb")
          , l = n("bujt")
          , u = n("Fwaw")
          , h = n("5GAg")
          , d = n("omvX")
          , f = n("mHMc");
        n.d(t, "a", function() {
            return v
        });
        var p = r.qb({
            encapsulation: 0,
            styles: [['@charset "UTF-8";[_nghost-%COMP%]{min-width:25rem;max-width:37.5rem}.dialog-body[_ngcontent-%COMP%]{display:flex;flex-direction:column;min-height:6.875rem;max-height:31.25rem}.nowDate-area[_ngcontent-%COMP%]{text-align:right}.messageId-area[_ngcontent-%COMP%]{font-weight:700}.message-area[_ngcontent-%COMP%]{padding:.5rem 0;word-break:break-all}.errorCode-area[_ngcontent-%COMP%]{text-align:right}.messageDetail-area[_ngcontent-%COMP%]{margin-top:1rem;word-break:break-all;height:5rem;overflow:auto}']],
            data: {}
        });
        function m(e) {
            return r.Mb(0, [(e()(),
            r.sb(0, 0, null, null, 2, "div", [["class", "errorCode-area"]], null, null, null, null, null)), (e()(),
            r.sb(1, 0, null, null, 1, "p", [], null, null, null, null, null)), (e()(),
            r.Kb(2, null, ["", ""]))], null, function(e, t) {
                e(t, 2, 0, t.component.errorCode)
            })
        }
        function g(e) {
            return r.Mb(0, [(e()(),
            r.sb(0, 0, null, null, 2, "div", [["class", "messageDetail-area"]], null, null, null, null, null)), (e()(),
            r.sb(1, 0, null, null, 1, "p", [], [[8, "innerHTML", 1]], null, null, null, null)), r.Gb(2, 1)], null, function(e, t) {
                var n = t.component
                  , s = r.Lb(t, 1, 0, e(t, 2, 0, r.Db(t.parent, 1), n.messageDetail));
                e(t, 1, 0, s)
            })
        }
        function b(e) {
            return r.Mb(0, [r.Eb(0, s.e, [r.t]), r.Eb(0, i.a, [o.b]), r.Eb(0, a.a, [c.a]), (e()(),
            r.sb(3, 0, null, null, 2, "div", [["class", "dialog-header"]], null, null, null, null, null)), (e()(),
            r.sb(4, 0, null, null, 1, "label", [], null, null, null, null, null)), (e()(),
            r.Kb(5, null, ["", ""])), (e()(),
            r.sb(6, 0, null, null, 14, "div", [["class", "dialog-body"]], null, null, null, null, null)), (e()(),
            r.sb(7, 0, null, null, 3, "div", [["class", "nowDate-area"]], null, null, null, null, null)), (e()(),
            r.sb(8, 0, null, null, 2, "p", [], null, null, null, null, null)), (e()(),
            r.Kb(9, null, ["", ""])), r.Gb(10, 2), (e()(),
            r.sb(11, 0, null, null, 2, "div", [["class", "messageId-area"]], null, null, null, null, null)), (e()(),
            r.sb(12, 0, null, null, 1, "p", [], null, null, null, null, null)), (e()(),
            r.Kb(13, null, ["", ""])), (e()(),
            r.sb(14, 0, null, null, 2, "div", [["class", "message-area"]], null, null, null, null, null)), (e()(),
            r.sb(15, 0, null, null, 1, "p", [], null, null, null, null, null)), (e()(),
            r.Kb(16, null, ["", ""])), (e()(),
            r.hb(16777216, null, null, 1, null, m)), r.rb(18, 16384, null, 0, s.l, [r.O, r.L], {
                ngIf: [0, "ngIf"]
            }, null), (e()(),
            r.hb(16777216, null, null, 1, null, g)), r.rb(20, 16384, null, 0, s.l, [r.O, r.L], {
                ngIf: [0, "ngIf"]
            }, null), (e()(),
            r.sb(21, 0, null, null, 4, "div", [["class", "dialog-footer"]], null, null, null, null, null)), (e()(),
            r.sb(22, 0, null, null, 3, "button", [["class", "tm-button"], ["mat-button", ""], ["type", "button"]], [[1, "disabled", 0], [2, "_mat-animation-noopable", null]], [[null, "click"]], function(e, t, n) {
                var r = !0;
                return "click" === t && (r = !1 !== e.component.$close() && r),
                r
            }, l.d, l.b)), r.rb(23, 180224, null, 0, u.b, [r.k, h.d, [2, d.a]], null, null), (e()(),
            r.Kb(24, 0, ["", ""])), r.Gb(25, 1)], function(e, t) {
                var n = t.component;
                e(t, 18, 0, n.errorCode),
                e(t, 20, 0, n.messageDetail)
            }, function(e, t) {
                var n = t.component;
                e(t, 5, 0, n.title);
                var s = r.Lb(t, 9, 0, e(t, 10, 0, r.Db(t, 0), n.errorTime, "yy/MM/dd HH:mm"));
                e(t, 9, 0, s),
                e(t, 13, 0, n.messageId),
                e(t, 16, 0, n.message),
                e(t, 22, 0, r.Db(t, 23).disabled || null, "NoopAnimations" === r.Db(t, 23)._animationMode);
                var i = r.Lb(t, 24, 0, e(t, 25, 0, r.Db(t, 2), "Common_Close"));
                e(t, 24, 0, i)
            })
        }
        function y(e) {
            return r.Mb(0, [(e()(),
            r.sb(0, 0, null, null, 1, "app-notice", [], null, null, null, b, p)), r.rb(1, 4440064, null, 0, f.a, [], null, null)], function(e, t) {
                e(t, 1, 0)
            }, null)
        }
        var v = r.ob("app-notice", f.a, y, {}, {}, [])
    },
    Fwaw: function(e, t, n) {
        "use strict";
        n.d(t, "c", function() {
            return u
        }),
        n.d(t, "b", function() {
            return c
        }),
        n.d(t, "a", function() {
            return l
        });
        var r = n("Xd0L");
        const s = "accent"
          , i = ["mat-button", "mat-flat-button", "mat-icon-button", "mat-raised-button", "mat-stroked-button", "mat-mini-fab", "mat-fab"];
        class o {
            constructor(e) {
                this._elementRef = e
            }
        }
        const a = Object(r.i)(Object(r.k)(Object(r.j)(o)));
        class c extends a {
            constructor(e, t, n) {
                super(e),
                this._focusMonitor = t,
                this._animationMode = n,
                this.isRoundButton = this._hasHostAttributes("mat-fab", "mat-mini-fab"),
                this.isIconButton = this._hasHostAttributes("mat-icon-button");
                for (const r of i)
                    this._hasHostAttributes(r) && this._getHostElement().classList.add(r);
                e.nativeElement.classList.add("mat-button-base"),
                this._focusMonitor.monitor(this._elementRef, !0),
                this.isRoundButton && (this.color = s)
            }
            ngOnDestroy() {
                this._focusMonitor.stopMonitoring(this._elementRef)
            }
            focus(e, t) {
                this._getHostElement().focus(t)
            }
            _getHostElement() {
                return this._elementRef.nativeElement
            }
            _isRippleDisabled() {
                return this.disableRipple || this.disabled
            }
            _hasHostAttributes(...e) {
                return e.some(e => this._getHostElement().hasAttribute(e))
            }
        }
        class l extends c {
            constructor(e, t, n) {
                super(t, e, n)
            }
            _haltDisabledEvents(e) {
                this.disabled && (e.preventDefault(),
                e.stopImmediatePropagation())
            }
        }
        class u {
        }
    },
    G4Cx: function(e, t, n) {
        "use strict";
        n.d(t, "d", function() {
            return i
        }),
        n.d(t, "e", function() {
            return o
        }),
        n.d(t, "c", function() {
            return a
        }),
        n.d(t, "a", function() {
            return c
        }),
        n.d(t, "b", function() {
            return l
        });
        var r = n("DQLy")
          , s = function(e) {
            return e.NotifyError = "[Notice] Notify Error",
            e.SetError = "[Notice] Set Error",
            e.ClearError = "[Notice] Clear Error",
            e.ShowErrorDialog = "[Notice] Show Error Dialog",
            e.ShowErrorPage = "[Notice] Show Error Page",
            e
        }({});
        const i = Object(r.u)(s.NotifyError, e => ({
            payload: {
                error: e
            }
        }))
          , o = Object(r.u)(s.SetError, e => ({
            payload: {
                notice: e
            }
        }))
          , a = Object(r.u)(s.ClearError)
          , c = Object(r.u)(s.ShowErrorDialog)
          , l = Object(r.u)(s.ShowErrorPage, e => ({
            payload: {
                errorPage: e
            }
        }))
    },
    GS7A: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r
        }),
        n.d(t, "c", function() {
            return s
        }),
        n.d(t, "a", function() {
            return i
        }),
        n.d(t, "e", function() {
            return a
        }),
        n.d(t, "f", function() {
            return c
        }),
        n.d(t, "g", function() {
            return u
        }),
        n.d(t, "h", function() {
            return l
        }),
        n.d(t, "i", function() {
            return h
        }),
        n.d(t, "j", function() {
            return o
        }),
        n.d(t, "d", function() {
            return f
        }),
        n.d(t, "k", function() {
            return p
        }),
        n.d(t, "l", function() {
            return m
        });
        class r {
        }
        class s {
        }
        const i = "*";
        function o(e, t) {
            return {
                type: 7,
                name: e,
                definitions: t,
                options: {}
            }
        }
        function a(e, t=null) {
            return {
                type: 4,
                styles: t,
                timings: e
            }
        }
        function c(e, t=null) {
            return {
                type: 2,
                steps: e,
                options: t
            }
        }
        function l(e) {
            return {
                type: 6,
                styles: e,
                offset: null
            }
        }
        function u(e, t, n) {
            return {
                type: 0,
                name: e,
                styles: t,
                options: n
            }
        }
        function h(e, t, n=null) {
            return {
                type: 1,
                expr: e,
                animation: t,
                options: n
            }
        }
        function d(e) {
            Promise.resolve(null).then(e)
        }
        class f {
            constructor(e=0, t=0) {
                this._onDoneFns = [],
                this._onStartFns = [],
                this._onDestroyFns = [],
                this._started = !1,
                this._destroyed = !1,
                this._finished = !1,
                this.parentPlayer = null,
                this.totalTime = e + t
            }
            _onFinish() {
                this._finished || (this._finished = !0,
                this._onDoneFns.forEach(e => e()),
                this._onDoneFns = [])
            }
            onStart(e) {
                this._onStartFns.push(e)
            }
            onDone(e) {
                this._onDoneFns.push(e)
            }
            onDestroy(e) {
                this._onDestroyFns.push(e)
            }
            hasStarted() {
                return this._started
            }
            init() {}
            play() {
                this.hasStarted() || (this._onStart(),
                this.triggerMicrotask()),
                this._started = !0
            }
            triggerMicrotask() {
                d( () => this._onFinish())
            }
            _onStart() {
                this._onStartFns.forEach(e => e()),
                this._onStartFns = []
            }
            pause() {}
            restart() {}
            finish() {
                this._onFinish()
            }
            destroy() {
                this._destroyed || (this._destroyed = !0,
                this.hasStarted() || this._onStart(),
                this.finish(),
                this._onDestroyFns.forEach(e => e()),
                this._onDestroyFns = [])
            }
            reset() {}
            setPosition(e) {}
            getPosition() {
                return 0
            }
            triggerCallback(e) {
                const t = "start" == e ? this._onStartFns : this._onDoneFns;
                t.forEach(e => e()),
                t.length = 0
            }
        }
        class p {
            constructor(e) {
                this._onDoneFns = [],
                this._onStartFns = [],
                this._finished = !1,
                this._started = !1,
                this._destroyed = !1,
                this._onDestroyFns = [],
                this.parentPlayer = null,
                this.totalTime = 0,
                this.players = e;
                let t = 0
                  , n = 0
                  , r = 0;
                const s = this.players.length;
                0 == s ? d( () => this._onFinish()) : this.players.forEach(e => {
                    e.onDone( () => {
                        ++t == s && this._onFinish()
                    }
                    ),
                    e.onDestroy( () => {
                        ++n == s && this._onDestroy()
                    }
                    ),
                    e.onStart( () => {
                        ++r == s && this._onStart()
                    }
                    )
                }
                ),
                this.totalTime = this.players.reduce( (e, t) => Math.max(e, t.totalTime), 0)
            }
            _onFinish() {
                this._finished || (this._finished = !0,
                this._onDoneFns.forEach(e => e()),
                this._onDoneFns = [])
            }
            init() {
                this.players.forEach(e => e.init())
            }
            onStart(e) {
                this._onStartFns.push(e)
            }
            _onStart() {
                this.hasStarted() || (this._started = !0,
                this._onStartFns.forEach(e => e()),
                this._onStartFns = [])
            }
            onDone(e) {
                this._onDoneFns.push(e)
            }
            onDestroy(e) {
                this._onDestroyFns.push(e)
            }
            hasStarted() {
                return this._started
            }
            play() {
                this.parentPlayer || this.init(),
                this._onStart(),
                this.players.forEach(e => e.play())
            }
            pause() {
                this.players.forEach(e => e.pause())
            }
            restart() {
                this.players.forEach(e => e.restart())
            }
            finish() {
                this._onFinish(),
                this.players.forEach(e => e.finish())
            }
            destroy() {
                this._onDestroy()
            }
            _onDestroy() {
                this._destroyed || (this._destroyed = !0,
                this._onFinish(),
                this.players.forEach(e => e.destroy()),
                this._onDestroyFns.forEach(e => e()),
                this._onDestroyFns = [])
            }
            reset() {
                this.players.forEach(e => e.reset()),
                this._destroyed = !1,
                this._finished = !1,
                this._started = !1
            }
            setPosition(e) {
                const t = e * this.totalTime;
                this.players.forEach(e => {
                    const n = e.totalTime ? Math.min(1, t / e.totalTime) : 1;
                    e.setPosition(n)
                }
                )
            }
            getPosition() {
                let e = 0;
                return this.players.forEach(t => {
                    const n = t.getPosition();
                    e = Math.min(n, e)
                }
                ),
                e
            }
            beforeDestroy() {
                this.players.forEach(e => {
                    e.beforeDestroy && e.beforeDestroy()
                }
                )
            }
            triggerCallback(e) {
                const t = "start" == e ? this._onStartFns : this._onDoneFns;
                t.forEach(e => e()),
                t.length = 0
            }
        }
        const m = "!"
    },
    GyhO: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        var r = n("LRne")
          , s = n("0EUg");
        function i(...e) {
            return Object(s.a)()(Object(r.a)(...e))
        }
    },
    HDdC: function(e, t, n) {
        "use strict";
        var r = n("7o/Q")
          , s = n("2QA8")
          , i = n("gRHU")
          , o = n("kJWO")
          , a = n("mCNh")
          , c = n("2fFW");
        n.d(t, "a", function() {
            return l
        });
        let l = ( () => {
            class e {
                constructor(e) {
                    this._isScalar = !1,
                    e && (this._subscribe = e)
                }
                lift(t) {
                    const n = new e;
                    return n.source = this,
                    n.operator = t,
                    n
                }
                subscribe(e, t, n) {
                    const {operator: o} = this
                      , a = function(e, t, n) {
                        if (e) {
                            if (e instanceof r.a)
                                return e;
                            if (e[s.a])
                                return e[s.a]()
                        }
                        return e || t || n ? new r.a(e,t,n) : new r.a(i.a)
                    }(e, t, n);
                    if (a.add(o ? o.call(a, this.source) : this.source || c.a.useDeprecatedSynchronousErrorHandling && !a.syncErrorThrowable ? this._subscribe(a) : this._trySubscribe(a)),
                    c.a.useDeprecatedSynchronousErrorHandling && a.syncErrorThrowable && (a.syncErrorThrowable = !1,
                    a.syncErrorThrown))
                        throw a.syncErrorValue;
                    return a
                }
                _trySubscribe(e) {
                    try {
                        return this._subscribe(e)
                    } catch (t) {
                        c.a.useDeprecatedSynchronousErrorHandling && (e.syncErrorThrown = !0,
                        e.syncErrorValue = t),
                        function(e) {
                            for (; e; ) {
                                const {closed: t, destination: n, isStopped: s} = e;
                                if (t || s)
                                    return !1;
                                e = n && n instanceof r.a ? n : null
                            }
                            return !0
                        }(e) ? e.error(t) : console.warn(t)
                    }
                }
                forEach(e, t) {
                    return new (t = u(t))( (t, n) => {
                        let r;
                        r = this.subscribe(t => {
                            try {
                                e(t)
                            } catch (s) {
                                n(s),
                                r && r.unsubscribe()
                            }
                        }
                        , n, t)
                    }
                    )
                }
                _subscribe(e) {
                    const {source: t} = this;
                    return t && t.subscribe(e)
                }
                [o.a]() {
                    return this
                }
                pipe(...e) {
                    return 0 === e.length ? this : Object(a.b)(e)(this)
                }
                toPromise(e) {
                    return new (e = u(e))( (e, t) => {
                        let n;
                        this.subscribe(e => n = e, e => t(e), () => e(n))
                    }
                    )
                }
            }
            return e.create = t => new e(t),
            e
        }
        )();
        function u(e) {
            if (e || (e = c.a.Promise || Promise),
            !e)
                throw new Error("no Promise impl found");
            return e
        }
    },
    "HIK+": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("8Y7J");
        let s = ( () => {
            class e {
                constructor() {
                    this._root = "",
                    this._resourceMap = new Map,
                    this._apiToken = ""
                }
                get root() {
                    return this._root
                }
                set root(e) {
                    this._root = e
                }
                get resourceMap() {
                    return this._resourceMap
                }
                set resourceMap(e) {
                    this._resourceMap = e
                }
                get apiToken() {
                    return this._apiToken
                }
                set apiToken(e) {
                    this._apiToken = e
                }
            }
            return e.ngInjectableDef = r.Qb({
                factory: function() {
                    return new e
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )()
    },
    I55L: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        const r = e => e && "number" == typeof e.length && "function" != typeof e
    },
    IP0z: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return o
        }),
        n.d(t, "a", function() {
            return a
        });
        var r = n("SVse")
          , s = n("8Y7J");
        const i = new s.p("cdk-dir-doc",{
            providedIn: "root",
            factory: function() {
                return Object(s.V)(r.d)
            }
        });
        let o = ( () => {
            class e {
                constructor(e) {
                    if (this.value = "ltr",
                    this.change = new s.m,
                    e) {
                        const t = e.documentElement ? e.documentElement.dir : null
                          , n = (e.body ? e.body.dir : null) || t;
                        this.value = "ltr" === n || "rtl" === n ? n : "ltr"
                    }
                }
                ngOnDestroy() {
                    this.change.complete()
                }
            }
            return e.ngInjectableDef = Object(s.Qb)({
                factory: function() {
                    return new e(Object(s.Rb)(i, 8))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        class a {
        }
    },
    IheW: function(e, t, n) {
        "use strict";
        n.d(t, "p", function() {
            return R
        }),
        n.d(t, "s", function() {
            return L
        }),
        n.d(t, "t", function() {
            return F
        }),
        n.d(t, "q", function() {
            return N
        }),
        n.d(t, "r", function() {
            return P
        }),
        n.d(t, "b", function() {
            return h
        }),
        n.d(t, "g", function() {
            return u
        }),
        n.d(t, "c", function() {
            return x
        }),
        n.d(t, "h", function() {
            return d
        }),
        n.d(t, "a", function() {
            return O
        }),
        n.d(t, "d", function() {
            return H
        }),
        n.d(t, "e", function() {
            return z
        }),
        n.d(t, "o", function() {
            return U
        }),
        n.d(t, "i", function() {
            return m
        }),
        n.d(t, "j", function() {
            return v
        }),
        n.d(t, "f", function() {
            return C
        }),
        n.d(t, "k", function() {
            return S
        }),
        n.d(t, "l", function() {
            return j
        }),
        n.d(t, "n", function() {
            return D
        }),
        n.d(t, "m", function() {
            return M
        });
        var r = n("8Y7J")
          , s = n("LRne")
          , i = n("HDdC")
          , o = n("bOdf")
          , a = n("pLZG")
          , c = n("lJxs")
          , l = n("SVse");
        class u {
        }
        class h {
        }
        class d {
            constructor(e) {
                this.normalizedNames = new Map,
                this.lazyUpdate = null,
                e ? this.lazyInit = "string" == typeof e ? () => {
                    this.headers = new Map,
                    e.split("\n").forEach(e => {
                        const t = e.indexOf(":");
                        if (t > 0) {
                            const n = e.slice(0, t)
                              , r = n.toLowerCase()
                              , s = e.slice(t + 1).trim();
                            this.maybeSetNormalizedName(n, r),
                            this.headers.has(r) ? this.headers.get(r).push(s) : this.headers.set(r, [s])
                        }
                    }
                    )
                }
                : () => {
                    this.headers = new Map,
                    Object.keys(e).forEach(t => {
                        let n = e[t];
                        const r = t.toLowerCase();
                        "string" == typeof n && (n = [n]),
                        n.length > 0 && (this.headers.set(r, n),
                        this.maybeSetNormalizedName(t, r))
                    }
                    )
                }
                : this.headers = new Map
            }
            has(e) {
                return this.init(),
                this.headers.has(e.toLowerCase())
            }
            get(e) {
                this.init();
                const t = this.headers.get(e.toLowerCase());
                return t && t.length > 0 ? t[0] : null
            }
            keys() {
                return this.init(),
                Array.from(this.normalizedNames.values())
            }
            getAll(e) {
                return this.init(),
                this.headers.get(e.toLowerCase()) || null
            }
            append(e, t) {
                return this.clone({
                    name: e,
                    value: t,
                    op: "a"
                })
            }
            set(e, t) {
                return this.clone({
                    name: e,
                    value: t,
                    op: "s"
                })
            }
            delete(e, t) {
                return this.clone({
                    name: e,
                    value: t,
                    op: "d"
                })
            }
            maybeSetNormalizedName(e, t) {
                this.normalizedNames.has(t) || this.normalizedNames.set(t, e)
            }
            init() {
                this.lazyInit && (this.lazyInit instanceof d ? this.copyFrom(this.lazyInit) : this.lazyInit(),
                this.lazyInit = null,
                this.lazyUpdate && (this.lazyUpdate.forEach(e => this.applyUpdate(e)),
                this.lazyUpdate = null))
            }
            copyFrom(e) {
                e.init(),
                Array.from(e.headers.keys()).forEach(t => {
                    this.headers.set(t, e.headers.get(t)),
                    this.normalizedNames.set(t, e.normalizedNames.get(t))
                }
                )
            }
            clone(e) {
                const t = new d;
                return t.lazyInit = this.lazyInit && this.lazyInit instanceof d ? this.lazyInit : this,
                t.lazyUpdate = (this.lazyUpdate || []).concat([e]),
                t
            }
            applyUpdate(e) {
                const t = e.name.toLowerCase();
                switch (e.op) {
                case "a":
                case "s":
                    let n = e.value;
                    if ("string" == typeof n && (n = [n]),
                    0 === n.length)
                        return;
                    this.maybeSetNormalizedName(e.name, t);
                    const r = ("a" === e.op ? this.headers.get(t) : void 0) || [];
                    r.push(...n),
                    this.headers.set(t, r);
                    break;
                case "d":
                    const s = e.value;
                    if (s) {
                        let e = this.headers.get(t);
                        if (!e)
                            return;
                        0 === (e = e.filter(e => -1 === s.indexOf(e))).length ? (this.headers.delete(t),
                        this.normalizedNames.delete(t)) : this.headers.set(t, e)
                    } else
                        this.headers.delete(t),
                        this.normalizedNames.delete(t)
                }
            }
            forEach(e) {
                this.init(),
                Array.from(this.normalizedNames.keys()).forEach(t => e(this.normalizedNames.get(t), this.headers.get(t)))
            }
        }
        class f {
            encodeKey(e) {
                return p(e)
            }
            encodeValue(e) {
                return p(e)
            }
            decodeKey(e) {
                return decodeURIComponent(e)
            }
            decodeValue(e) {
                return decodeURIComponent(e)
            }
        }
        function p(e) {
            return encodeURIComponent(e).replace(/%40/gi, "@").replace(/%3A/gi, ":").replace(/%24/gi, "$").replace(/%2C/gi, ",").replace(/%3B/gi, ";").replace(/%2B/gi, "+").replace(/%3D/gi, "=").replace(/%3F/gi, "?").replace(/%2F/gi, "/")
        }
        class m {
            constructor(e={}) {
                if (this.updates = null,
                this.cloneFrom = null,
                this.encoder = e.encoder || new f,
                e.fromString) {
                    if (e.fromObject)
                        throw new Error("Cannot specify both fromString and fromObject.");
                    this.map = function(e, t) {
                        const n = new Map;
                        return e.length > 0 && e.split("&").forEach(e => {
                            const r = e.indexOf("=")
                              , [s,i] = -1 == r ? [t.decodeKey(e), ""] : [t.decodeKey(e.slice(0, r)), t.decodeValue(e.slice(r + 1))]
                              , o = n.get(s) || [];
                            o.push(i),
                            n.set(s, o)
                        }
                        ),
                        n
                    }(e.fromString, this.encoder)
                } else
                    e.fromObject ? (this.map = new Map,
                    Object.keys(e.fromObject).forEach(t => {
                        const n = e.fromObject[t];
                        this.map.set(t, Array.isArray(n) ? n : [n])
                    }
                    )) : this.map = null
            }
            has(e) {
                return this.init(),
                this.map.has(e)
            }
            get(e) {
                this.init();
                const t = this.map.get(e);
                return t ? t[0] : null
            }
            getAll(e) {
                return this.init(),
                this.map.get(e) || null
            }
            keys() {
                return this.init(),
                Array.from(this.map.keys())
            }
            append(e, t) {
                return this.clone({
                    param: e,
                    value: t,
                    op: "a"
                })
            }
            set(e, t) {
                return this.clone({
                    param: e,
                    value: t,
                    op: "s"
                })
            }
            delete(e, t) {
                return this.clone({
                    param: e,
                    value: t,
                    op: "d"
                })
            }
            toString() {
                return this.init(),
                this.keys().map(e => {
                    const t = this.encoder.encodeKey(e);
                    return this.map.get(e).map(e => t + "=" + this.encoder.encodeValue(e)).join("&")
                }
                ).join("&")
            }
            clone(e) {
                const t = new m({
                    encoder: this.encoder
                });
                return t.cloneFrom = this.cloneFrom || this,
                t.updates = (this.updates || []).concat([e]),
                t
            }
            init() {
                null === this.map && (this.map = new Map),
                null !== this.cloneFrom && (this.cloneFrom.init(),
                this.cloneFrom.keys().forEach(e => this.map.set(e, this.cloneFrom.map.get(e))),
                this.updates.forEach(e => {
                    switch (e.op) {
                    case "a":
                    case "s":
                        const t = ("a" === e.op ? this.map.get(e.param) : void 0) || [];
                        t.push(e.value),
                        this.map.set(e.param, t);
                        break;
                    case "d":
                        if (void 0 === e.value) {
                            this.map.delete(e.param);
                            break
                        }
                        {
                            let t = this.map.get(e.param) || [];
                            const n = t.indexOf(e.value);
                            -1 !== n && t.splice(n, 1),
                            t.length > 0 ? this.map.set(e.param, t) : this.map.delete(e.param)
                        }
                    }
                }
                ),
                this.cloneFrom = this.updates = null)
            }
        }
        function g(e) {
            return "undefined" != typeof ArrayBuffer && e instanceof ArrayBuffer
        }
        function b(e) {
            return "undefined" != typeof Blob && e instanceof Blob
        }
        function y(e) {
            return "undefined" != typeof FormData && e instanceof FormData
        }
        class v {
            constructor(e, t, n, r) {
                let s;
                if (this.url = t,
                this.body = null,
                this.reportProgress = !1,
                this.withCredentials = !1,
                this.responseType = "json",
                this.method = e.toUpperCase(),
                function(e) {
                    switch (e) {
                    case "DELETE":
                    case "GET":
                    case "HEAD":
                    case "OPTIONS":
                    case "JSONP":
                        return !1;
                    default:
                        return !0
                    }
                }(this.method) || r ? (this.body = void 0 !== n ? n : null,
                s = r) : s = n,
                s && (this.reportProgress = !!s.reportProgress,
                this.withCredentials = !!s.withCredentials,
                s.responseType && (this.responseType = s.responseType),
                s.headers && (this.headers = s.headers),
                s.params && (this.params = s.params)),
                this.headers || (this.headers = new d),
                this.params) {
                    const e = this.params.toString();
                    if (0 === e.length)
                        this.urlWithParams = t;
                    else {
                        const n = t.indexOf("?");
                        this.urlWithParams = t + (-1 === n ? "?" : n < t.length - 1 ? "&" : "") + e
                    }
                } else
                    this.params = new m,
                    this.urlWithParams = t
            }
            serializeBody() {
                return null === this.body ? null : g(this.body) || b(this.body) || y(this.body) || "string" == typeof this.body ? this.body : this.body instanceof m ? this.body.toString() : "object" == typeof this.body || "boolean" == typeof this.body || Array.isArray(this.body) ? JSON.stringify(this.body) : this.body.toString()
            }
            detectContentTypeHeader() {
                return null === this.body ? null : y(this.body) ? null : b(this.body) ? this.body.type || null : g(this.body) ? null : "string" == typeof this.body ? "text/plain" : this.body instanceof m ? "application/x-www-form-urlencoded;charset=UTF-8" : "object" == typeof this.body || "number" == typeof this.body || Array.isArray(this.body) ? "application/json" : null
            }
            clone(e={}) {
                const t = e.method || this.method
                  , n = e.url || this.url
                  , r = e.responseType || this.responseType
                  , s = void 0 !== e.body ? e.body : this.body
                  , i = void 0 !== e.withCredentials ? e.withCredentials : this.withCredentials
                  , o = void 0 !== e.reportProgress ? e.reportProgress : this.reportProgress;
                let a = e.headers || this.headers
                  , c = e.params || this.params;
                return void 0 !== e.setHeaders && (a = Object.keys(e.setHeaders).reduce( (t, n) => t.set(n, e.setHeaders[n]), a)),
                e.setParams && (c = Object.keys(e.setParams).reduce( (t, n) => t.set(n, e.setParams[n]), c)),
                new v(t,n,s,{
                    params: c,
                    headers: a,
                    reportProgress: o,
                    responseType: r,
                    withCredentials: i
                })
            }
        }
        const _ = function() {
            var e = {
                Sent: 0,
                UploadProgress: 1,
                ResponseHeader: 2,
                DownloadProgress: 3,
                Response: 4,
                User: 5
            };
            return e[e.Sent] = "Sent",
            e[e.UploadProgress] = "UploadProgress",
            e[e.ResponseHeader] = "ResponseHeader",
            e[e.DownloadProgress] = "DownloadProgress",
            e[e.Response] = "Response",
            e[e.User] = "User",
            e
        }();
        class w {
            constructor(e, t=200, n="OK") {
                this.headers = e.headers || new d,
                this.status = void 0 !== e.status ? e.status : t,
                this.statusText = e.statusText || n,
                this.url = e.url || null,
                this.ok = this.status >= 200 && this.status < 300
            }
        }
        class E extends w {
            constructor(e={}) {
                super(e),
                this.type = _.ResponseHeader
            }
            clone(e={}) {
                return new E({
                    headers: e.headers || this.headers,
                    status: void 0 !== e.status ? e.status : this.status,
                    statusText: e.statusText || this.statusText,
                    url: e.url || this.url || void 0
                })
            }
        }
        class S extends w {
            constructor(e={}) {
                super(e),
                this.type = _.Response,
                this.body = void 0 !== e.body ? e.body : null
            }
            clone(e={}) {
                return new S({
                    body: void 0 !== e.body ? e.body : this.body,
                    headers: e.headers || this.headers,
                    status: void 0 !== e.status ? e.status : this.status,
                    statusText: e.statusText || this.statusText,
                    url: e.url || this.url || void 0
                })
            }
        }
        class C extends w {
            constructor(e) {
                super(e, 0, "Unknown Error"),
                this.name = "HttpErrorResponse",
                this.ok = !1,
                this.message = this.status >= 200 && this.status < 300 ? `Http failure during parsing for ${e.url || "(unknown url)"}` : `Http failure response for ${e.url || "(unknown url)"}: ${e.status} ${e.statusText}`,
                this.error = e.error || null
            }
        }
        function T(e, t) {
            return {
                body: t,
                headers: e.headers,
                observe: e.observe,
                params: e.params,
                reportProgress: e.reportProgress,
                responseType: e.responseType,
                withCredentials: e.withCredentials
            }
        }
        class x {
            constructor(e) {
                this.handler = e
            }
            request(e, t, n={}) {
                let r;
                if (e instanceof v)
                    r = e;
                else {
                    let s = void 0;
                    s = n.headers instanceof d ? n.headers : new d(n.headers);
                    let i = void 0;
                    n.params && (i = n.params instanceof m ? n.params : new m({
                        fromObject: n.params
                    })),
                    r = new v(e,t,void 0 !== n.body ? n.body : null,{
                        headers: s,
                        params: i,
                        reportProgress: n.reportProgress,
                        responseType: n.responseType || "json",
                        withCredentials: n.withCredentials
                    })
                }
                const i = Object(s.a)(r).pipe(Object(o.a)(e => this.handler.handle(e)));
                if (e instanceof v || "events" === n.observe)
                    return i;
                const l = i.pipe(Object(a.a)(e => e instanceof S));
                switch (n.observe || "body") {
                case "body":
                    switch (r.responseType) {
                    case "arraybuffer":
                        return l.pipe(Object(c.a)(e => {
                            if (null !== e.body && !(e.body instanceof ArrayBuffer))
                                throw new Error("Response is not an ArrayBuffer.");
                            return e.body
                        }
                        ));
                    case "blob":
                        return l.pipe(Object(c.a)(e => {
                            if (null !== e.body && !(e.body instanceof Blob))
                                throw new Error("Response is not a Blob.");
                            return e.body
                        }
                        ));
                    case "text":
                        return l.pipe(Object(c.a)(e => {
                            if (null !== e.body && "string" != typeof e.body)
                                throw new Error("Response is not a string.");
                            return e.body
                        }
                        ));
                    case "json":
                    default:
                        return l.pipe(Object(c.a)(e => e.body))
                    }
                case "response":
                    return l;
                default:
                    throw new Error(`Unreachable: unhandled observe type ${n.observe}}`)
                }
            }
            delete(e, t={}) {
                return this.request("DELETE", e, t)
            }
            get(e, t={}) {
                return this.request("GET", e, t)
            }
            head(e, t={}) {
                return this.request("HEAD", e, t)
            }
            jsonp(e, t) {
                return this.request("JSONP", e, {
                    params: (new m).append(t, "JSONP_CALLBACK"),
                    observe: "body",
                    responseType: "json"
                })
            }
            options(e, t={}) {
                return this.request("OPTIONS", e, t)
            }
            patch(e, t, n={}) {
                return this.request("PATCH", e, T(n, t))
            }
            post(e, t, n={}) {
                return this.request("POST", e, T(n, t))
            }
            put(e, t, n={}) {
                return this.request("PUT", e, T(n, t))
            }
        }
        class k {
            constructor(e, t) {
                this.next = e,
                this.interceptor = t
            }
            handle(e) {
                return this.interceptor.intercept(e, this.next)
            }
        }
        const O = new r.p("HTTP_INTERCEPTORS");
        class I {
            intercept(e, t) {
                return t.handle(e)
            }
        }
        const A = /^\)\]\}',?\n/;
        class D {
        }
        class R {
            constructor() {}
            build() {
                return new XMLHttpRequest
            }
        }
        class j {
            constructor(e) {
                this.xhrFactory = e
            }
            handle(e) {
                if ("JSONP" === e.method)
                    throw new Error("Attempted to construct Jsonp request without JsonpClientModule installed.");
                return new i.a(t => {
                    const n = this.xhrFactory.build();
                    if (n.open(e.method, e.urlWithParams),
                    e.withCredentials && (n.withCredentials = !0),
                    e.headers.forEach( (e, t) => n.setRequestHeader(e, t.join(","))),
                    e.headers.has("Accept") || n.setRequestHeader("Accept", "application/json, text/plain, */*"),
                    !e.headers.has("Content-Type")) {
                        const t = e.detectContentTypeHeader();
                        null !== t && n.setRequestHeader("Content-Type", t)
                    }
                    if (e.responseType) {
                        const t = e.responseType.toLowerCase();
                        n.responseType = "json" !== t ? t : "text"
                    }
                    const r = e.serializeBody();
                    let s = null;
                    const i = () => {
                        if (null !== s)
                            return s;
                        const t = 1223 === n.status ? 204 : n.status
                          , r = n.statusText || "OK"
                          , i = new d(n.getAllResponseHeaders())
                          , o = function(e) {
                            return "responseURL"in e && e.responseURL ? e.responseURL : /^X-Request-URL:/m.test(e.getAllResponseHeaders()) ? e.getResponseHeader("X-Request-URL") : null
                        }(n) || e.url;
                        return s = new E({
                            headers: i,
                            status: t,
                            statusText: r,
                            url: o
                        })
                    }
                      , o = () => {
                        let {headers: r, status: s, statusText: o, url: a} = i()
                          , c = null;
                        204 !== s && (c = void 0 === n.response ? n.responseText : n.response),
                        0 === s && (s = c ? 200 : 0);
                        let l = s >= 200 && s < 300;
                        if ("json" === e.responseType && "string" == typeof c) {
                            const e = c;
                            c = c.replace(A, "");
                            try {
                                c = "" !== c ? JSON.parse(c) : null
                            } catch (u) {
                                c = e,
                                l && (l = !1,
                                c = {
                                    error: u,
                                    text: c
                                })
                            }
                        }
                        l ? (t.next(new S({
                            body: c,
                            headers: r,
                            status: s,
                            statusText: o,
                            url: a || void 0
                        })),
                        t.complete()) : t.error(new C({
                            error: c,
                            headers: r,
                            status: s,
                            statusText: o,
                            url: a || void 0
                        }))
                    }
                      , a = e => {
                        const {url: r} = i()
                          , s = new C({
                            error: e,
                            status: n.status || 0,
                            statusText: n.statusText || "Unknown Error",
                            url: r || void 0
                        });
                        t.error(s)
                    }
                    ;
                    let c = !1;
                    const l = r => {
                        c || (t.next(i()),
                        c = !0);
                        let s = {
                            type: _.DownloadProgress,
                            loaded: r.loaded
                        };
                        r.lengthComputable && (s.total = r.total),
                        "text" === e.responseType && n.responseText && (s.partialText = n.responseText),
                        t.next(s)
                    }
                      , u = e => {
                        let n = {
                            type: _.UploadProgress,
                            loaded: e.loaded
                        };
                        e.lengthComputable && (n.total = e.total),
                        t.next(n)
                    }
                    ;
                    return n.addEventListener("load", o),
                    n.addEventListener("error", a),
                    e.reportProgress && (n.addEventListener("progress", l),
                    null !== r && n.upload && n.upload.addEventListener("progress", u)),
                    n.send(r),
                    t.next({
                        type: _.Sent
                    }),
                    () => {
                        n.removeEventListener("error", a),
                        n.removeEventListener("load", o),
                        e.reportProgress && (n.removeEventListener("progress", l),
                        null !== r && n.upload && n.upload.removeEventListener("progress", u)),
                        n.abort()
                    }
                }
                )
            }
        }
        const N = new r.p("XSRF_COOKIE_NAME")
          , P = new r.p("XSRF_HEADER_NAME");
        class M {
        }
        class L {
            constructor(e, t, n) {
                this.doc = e,
                this.platform = t,
                this.cookieName = n,
                this.lastCookieString = "",
                this.lastToken = null,
                this.parseCount = 0
            }
            getToken() {
                if ("server" === this.platform)
                    return null;
                const e = this.doc.cookie || "";
                return e !== this.lastCookieString && (this.parseCount++,
                this.lastToken = Object(l.y)(e, this.cookieName),
                this.lastCookieString = e),
                this.lastToken
            }
        }
        class F {
            constructor(e, t) {
                this.tokenService = e,
                this.headerName = t
            }
            intercept(e, t) {
                const n = e.url.toLowerCase();
                if ("GET" === e.method || "HEAD" === e.method || n.startsWith("http://") || n.startsWith("https://"))
                    return t.handle(e);
                const r = this.tokenService.getToken();
                return null === r || e.headers.has(this.headerName) || (e = e.clone({
                    headers: e.headers.set(this.headerName, r)
                })),
                t.handle(e)
            }
        }
        class U {
            constructor(e, t) {
                this.backend = e,
                this.injector = t,
                this.chain = null
            }
            handle(e) {
                if (null === this.chain) {
                    const e = this.injector.get(O, []);
                    this.chain = e.reduceRight( (e, t) => new k(e,t), this.backend)
                }
                return this.chain.handle(e)
            }
        }
        class z {
            static disable() {
                return {
                    ngModule: z,
                    providers: [{
                        provide: F,
                        useClass: I
                    }]
                }
            }
            static withOptions(e={}) {
                return {
                    ngModule: z,
                    providers: [e.cookieName ? {
                        provide: N,
                        useValue: e.cookieName
                    } : [], e.headerName ? {
                        provide: P,
                        useValue: e.headerName
                    } : []]
                }
            }
        }
        class H {
        }
    },
    IjjT: function(e, t, n) {
        "use strict";
        let r = ( () => {
            class e {
                constructor(t, n=e.now) {
                    this.SchedulerAction = t,
                    this.now = n
                }
                schedule(e, t=0, n) {
                    return new this.SchedulerAction(this,e).schedule(n, t)
                }
            }
            return e.now = () => Date.now(),
            e
        }
        )();
        n.d(t, "a", function() {
            return s
        });
        class s extends r {
            constructor(e, t=r.now) {
                super(e, () => s.delegate && s.delegate !== this ? s.delegate.now() : t()),
                this.actions = [],
                this.active = !1,
                this.scheduled = void 0
            }
            schedule(e, t=0, n) {
                return s.delegate && s.delegate !== this ? s.delegate.schedule(e, t, n) : super.schedule(e, t, n)
            }
            flush(e) {
                const {actions: t} = this;
                if (this.active)
                    return void t.push(e);
                let n;
                this.active = !0;
                do {
                    if (n = e.execute(e.state, e.delay))
                        break
                } while (e = t.shift());
                if (this.active = !1,
                n) {
                    for (; e = t.shift(); )
                        e.unsubscribe();
                    throw n
                }
            }
        }
    },
    IzEk: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o
        });
        var r = n("7o/Q")
          , s = n("4I5i")
          , i = n("EY2u");
        function o(e) {
            return t => 0 === e ? Object(i.b)() : t.lift(new a(e))
        }
        class a {
            constructor(e) {
                if (this.total = e,
                this.total < 0)
                    throw new s.a
            }
            call(e, t) {
                return t.subscribe(new c(e,this.total))
            }
        }
        class c extends r.a {
            constructor(e, t) {
                super(e),
                this.total = t,
                this.count = 0
            }
            _next(e) {
                const t = this.total
                  , n = ++this.count;
                n <= t && (this.destination.next(e),
                n === t && (this.destination.complete(),
                this.unsubscribe()))
            }
        }
    },
    JIr8: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o
        });
        var r = n("l7GE")
          , s = n("51Dv")
          , i = n("ZUHj");
        function o(e) {
            return function(t) {
                const n = new a(e)
                  , r = t.lift(n);
                return n.caught = r
            }
        }
        class a {
            constructor(e) {
                this.selector = e
            }
            call(e, t) {
                return t.subscribe(new c(e,this.selector,this.caught))
            }
        }
        class c extends r.a {
            constructor(e, t, n) {
                super(e),
                this.selector = t,
                this.caught = n
            }
            error(e) {
                if (!this.isStopped) {
                    let n;
                    try {
                        n = this.selector(e, this.caught)
                    } catch (t) {
                        return void super.error(t)
                    }
                    this._unsubscribeAndRecycle();
                    const r = new s.a(this,void 0,void 0);
                    this.add(r),
                    Object(i.a)(this, n, void 0, void 0, r)
                }
            }
        }
    },
    JX91: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return c
        });
        var r = n("yCtX")
          , s = n("XUOw")
          , i = n("EY2u")
          , o = n("GyhO")
          , a = n("z+Ro");
        function c(...e) {
            return t => {
                let n = e[e.length - 1];
                Object(a.a)(n) ? e.pop() : n = null;
                const c = e.length;
                return 1 !== c || n ? c > 0 ? Object(o.a)(Object(r.a)(e, n), t) : Object(o.a)(Object(i.b)(n), t) : Object(o.a)(Object(s.a)(e[0]), t)
            }
        }
    },
    Jq3a: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("PJcQ");
        class s {
            constructor(e) {
                this.sanitizer = e
            }
            transform(e, ...t) {
                return e ? this.sanitizer.bypassSecurityTrustHtml(r.a.convertNewLineHtml(e)) : ""
            }
        }
    },
    KCVW: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return s
        }),
        n.d(t, "e", function() {
            return i
        }),
        n.d(t, "a", function() {
            return o
        }),
        n.d(t, "c", function() {
            return a
        }),
        n.d(t, "d", function() {
            return c
        });
        var r = n("8Y7J");
        function s(e) {
            return null != e && "false" !== `${e}`
        }
        function i(e, t=0) {
            return function(e) {
                return !isNaN(parseFloat(e)) && !isNaN(Number(e))
            }(e) ? Number(e) : t
        }
        function o(e) {
            return Array.isArray(e) ? e : [e]
        }
        function a(e) {
            return null == e ? "" : "string" == typeof e ? e : `${e}px`
        }
        function c(e) {
            return e instanceof r.k ? e.nativeElement : e
        }
    },
    Kj3r: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        var r = n("7o/Q")
          , s = n("D0XW");
        function i(e, t=s.a) {
            return n => n.lift(new o(e,t))
        }
        class o {
            constructor(e, t) {
                this.dueTime = e,
                this.scheduler = t
            }
            call(e, t) {
                return t.subscribe(new a(e,this.dueTime,this.scheduler))
            }
        }
        class a extends r.a {
            constructor(e, t, n) {
                super(e),
                this.dueTime = t,
                this.scheduler = n,
                this.debouncedSubscription = null,
                this.lastValue = null,
                this.hasValue = !1
            }
            _next(e) {
                this.clearDebounce(),
                this.lastValue = e,
                this.hasValue = !0,
                this.add(this.debouncedSubscription = this.scheduler.schedule(c, this.dueTime, this))
            }
            _complete() {
                this.debouncedNext(),
                this.destination.complete()
            }
            debouncedNext() {
                if (this.clearDebounce(),
                this.hasValue) {
                    const {lastValue: e} = this;
                    this.lastValue = null,
                    this.hasValue = !1,
                    this.destination.next(e)
                }
            }
            clearDebounce() {
                const e = this.debouncedSubscription;
                null !== e && (this.remove(e),
                e.unsubscribe(),
                this.debouncedSubscription = null)
            }
        }
        function c(e) {
            e.debouncedNext()
        }
    },
    Kqap: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("7o/Q");
        function s(e, t) {
            let n = !1;
            return arguments.length >= 2 && (n = !0),
            function(r) {
                return r.lift(new i(e,t,n))
            }
        }
        class i {
            constructor(e, t, n=!1) {
                this.accumulator = e,
                this.seed = t,
                this.hasSeed = n
            }
            call(e, t) {
                return t.subscribe(new o(e,this.accumulator,this.seed,this.hasSeed))
            }
        }
        class o extends r.a {
            constructor(e, t, n, r) {
                super(e),
                this.accumulator = t,
                this._seed = n,
                this.hasSeed = r,
                this.index = 0
            }
            get seed() {
                return this._seed
            }
            set seed(e) {
                this.hasSeed = !0,
                this._seed = e
            }
            _next(e) {
                if (this.hasSeed)
                    return this._tryNext(e);
                this.seed = e,
                this.destination.next(e)
            }
            _tryNext(e) {
                const t = this.index++;
                let n;
                try {
                    n = this.accumulator(this.seed, e, t)
                } catch (r) {
                    this.destination.error(r)
                }
                this.seed = n,
                this.destination.next(n)
            }
        }
    },
    KqfI: function(e, t, n) {
        "use strict";
        function r() {}
        n.d(t, "a", function() {
            return r
        })
    },
    LPws: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i
        }),
        n.d(t, "c", function() {
            return o
        }),
        n.d(t, "d", function() {
            return a
        }),
        n.d(t, "a", function() {
            return c
        });
        var r = n("DQLy")
          , s = function(e) {
            return e.InitEffects = "[View] InitEffects",
            e.SetPrevState = "[View] SetPrevState",
            e.UpdateNow = "[View] UpdateNow",
            e.ChangeUpdateSpan = "[View] ChangeUpdateSpan",
            e
        }({});
        const i = Object(r.u)(s.InitEffects)
          , o = Object(r.u)(s.SetPrevState, e => ({
            payload: e
        }))
          , a = Object(r.u)(s.UpdateNow, e => ({
            payload: {
                now: e
            }
        }))
          , c = Object(r.u)(s.ChangeUpdateSpan)
    },
    LRne: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return a
        });
        var r = n("z+Ro")
          , s = n("yCtX")
          , i = n("EY2u")
          , o = n("XUOw");
        function a(...e) {
            let t = e[e.length - 1];
            switch (Object(r.a)(t) ? e.pop() : t = void 0,
            e.length) {
            case 0:
                return Object(i.b)(t);
            case 1:
                return t ? Object(s.a)(e, t) : Object(o.a)(e[0]);
            default:
                return Object(s.a)(e, t)
            }
        }
    },
    Lhse: function(e, t, n) {
        "use strict";
        function r() {
            return "function" == typeof Symbol && Symbol.iterator ? Symbol.iterator : "@@iterator"
        }
        n.d(t, "a", function() {
            return s
        });
        const s = r()
    },
    NJ4a: function(e, t, n) {
        "use strict";
        function r(e) {
            setTimeout( () => {
                throw e
            }
            )
        }
        n.d(t, "a", function() {
            return r
        })
    },
    NXyV: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o
        });
        var r = n("HDdC")
          , s = n("Cfvw")
          , i = n("EY2u");
        function o(e) {
            return new r.a(t => {
                let n;
                try {
                    n = e()
                } catch (r) {
                    return void t.error(r)
                }
                return (n ? Object(s.a)(n) : Object(i.b)()).subscribe(t)
            }
            )
        }
    },
    PJcQ: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        class r {
            static isDefined(e) {
                return void 0 !== e
            }
            static isString(e) {
                return "string" == typeof e
            }
            static formatString(e, ...t) {
                let n = e;
                if (t) {
                    const e = t.length;
                    for (let r = 0; r < e; r++)
                        n = n.replace(new RegExp(`\\{${r}\\}`,"g"), t[r])
                }
                return n
            }
            static escapeRegExp(e) {
                return e ? e.replace(/([.*+?^=!:${}()|[\]\/\\])/g, "\\$1") : e
            }
            static escapeHtml(e) {
                return e ? e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/'/g, "&#039;") : ""
            }
            static convertNewLineHtml(e) {
                return e ? r.escapeHtml(e).replace(/\r\n|\r|\n/g, "<br>") : ""
            }
            static addHandler(e, t, n) {
                return e.addEventListener(t, n, {
                    passive: !1
                }),
                () => {
                    e.removeEventListener(t, n)
                }
            }
            static dispachResizeEvent() {
                const e = new UIEvent("resize",{
                    bubbles: !0,
                    cancelable: !0,
                    view: window,
                    detail: 1
                });
                window.dispatchEvent(e)
            }
            static disableDefaultTouchEvent(e, t) {
                if (e.addEventListener("touchmove", e => {
                    e.touches.length > 1 && e.preventDefault()
                }
                , {
                    passive: !1
                }),
                t) {
                    let t = 0;
                    e.addEventListener("touchend", e => {
                        const n = Date.now();
                        n - t < 350 && e.preventDefault(),
                        t = n
                    }
                    , {
                        passive: !1
                    })
                }
            }
            static getQueryParams() {
                const e = Object.create(null);
                let t = location.href;
                const n = t.indexOf("?");
                return n >= 0 && (t = t.substr(n + 1)) && t.split("&").forEach(t => {
                    const n = t.split("=");
                    e[n[0]] = n[1] ? decodeURIComponent(n[1]) : ""
                }
                ),
                e
            }
            static convertServerTime(e) {
                const t = new Date(e);
                return "Invalid Date" !== t.toString() ? t : new Date
            }
            static convertDelayMinute(e) {
                const t = Math.floor(e / 60);
                return t > 99 ? 99 : t
            }
            static convertHankakuKana(e) {
                const t = ["ア", "イ", "ウ", "エ", "オ", "カ", "キ", "ク", "ケ", "コ", "サ", "シ", "ス", "セ", "ソ", "タ", "チ", "ツ", "テ", "ト", "ナ", "ニ", "ヌ", "ネ", "ノ", "ハ", "ヒ", "フ", "ヘ", "ホ", "マ", "ミ", "ム", "メ", "モ", "ヤ", "ヰ", "ユ", "ヱ", "ヨ", "ラ", "リ", "ル", "レ", "ロ", "ワ", "ヲ", "ン", "？"]
                  , n = ["ｱ", "ｲ", "ｳ", "ｴ", "ｵ", "ｶ", "ｷ", "ｸ", "ｹ", "ｺ", "ｻ", "ｼ", "ｽ", "ｾ", "ｿ", "ﾀ", "ﾁ", "ﾂ", "ﾃ", "ﾄ", "ﾅ", "ﾆ", "ﾇ", "ﾈ", "ﾉ", "ﾊ", "ﾋ", "ﾌ", "ﾍ", "ﾎ", "ﾏ", "ﾐ", "ﾑ", "ﾒ", "ﾓ", "ﾔ", "ｲ", "ﾕ", "ｴ", "ﾖ", "ﾗ", "ﾘ", "ﾙ", "ﾚ", "ﾛ", "ﾜ", "ｦ", "ﾝ", "?"];
                let r = "";
                const s = e ? e.length : 0;
                for (let i = 0; i < s; i++) {
                    const s = t.indexOf(e.charAt(i));
                    r += s >= 0 ? n[s] : " "
                }
                return r
            }
        }
    },
    POq0: function(e, t, n) {
        "use strict";
        n.d(t, "c", function() {
            return c
        }),
        n.d(t, "b", function() {
            return l
        }),
        n.d(t, "a", function() {
            return u
        }),
        n.d(t, "d", function() {
            return h
        });
        var r = n("KCVW")
          , s = n("8Y7J")
          , i = n("HDdC")
          , o = n("XNiG")
          , a = n("Kj3r");
        let c = ( () => {
            class e {
                create(e) {
                    return "undefined" == typeof MutationObserver ? null : new MutationObserver(e)
                }
            }
            return e.ngInjectableDef = Object(s.Qb)({
                factory: function() {
                    return new e
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )()
          , l = ( () => {
            class e {
                constructor(e) {
                    this._mutationObserverFactory = e,
                    this._observedElements = new Map
                }
                ngOnDestroy() {
                    this._observedElements.forEach( (e, t) => this._cleanupObserver(t))
                }
                observe(e) {
                    const t = Object(r.d)(e);
                    return new i.a(e => {
                        const n = this._observeElement(t).subscribe(e);
                        return () => {
                            n.unsubscribe(),
                            this._unobserveElement(t)
                        }
                    }
                    )
                }
                _observeElement(e) {
                    if (this._observedElements.has(e))
                        this._observedElements.get(e).count++;
                    else {
                        const t = new o.a
                          , n = this._mutationObserverFactory.create(e => t.next(e));
                        n && n.observe(e, {
                            characterData: !0,
                            childList: !0,
                            subtree: !0
                        }),
                        this._observedElements.set(e, {
                            observer: n,
                            stream: t,
                            count: 1
                        })
                    }
                    return this._observedElements.get(e).stream
                }
                _unobserveElement(e) {
                    this._observedElements.has(e) && (this._observedElements.get(e).count--,
                    this._observedElements.get(e).count || this._cleanupObserver(e))
                }
                _cleanupObserver(e) {
                    if (this._observedElements.has(e)) {
                        const {observer: t, stream: n} = this._observedElements.get(e);
                        t && t.disconnect(),
                        n.complete(),
                        this._observedElements.delete(e)
                    }
                }
            }
            return e.ngInjectableDef = Object(s.Qb)({
                factory: function() {
                    return new e(Object(s.Rb)(c))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        class u {
            constructor(e, t, n) {
                this._contentObserver = e,
                this._elementRef = t,
                this._ngZone = n,
                this.event = new s.m,
                this._disabled = !1,
                this._currentSubscription = null
            }
            get disabled() {
                return this._disabled
            }
            set disabled(e) {
                this._disabled = Object(r.b)(e),
                this._disabled ? this._unsubscribe() : this._subscribe()
            }
            get debounce() {
                return this._debounce
            }
            set debounce(e) {
                this._debounce = Object(r.e)(e),
                this._subscribe()
            }
            ngAfterContentInit() {
                this._currentSubscription || this.disabled || this._subscribe()
            }
            ngOnDestroy() {
                this._unsubscribe()
            }
            _subscribe() {
                this._unsubscribe();
                const e = this._contentObserver.observe(this._elementRef);
                this._ngZone.runOutsideAngular( () => {
                    this._currentSubscription = (this.debounce ? e.pipe(Object(a.a)(this.debounce)) : e).subscribe(this.event)
                }
                )
            }
            _unsubscribe() {
                this._currentSubscription && this._currentSubscription.unsubscribe()
            }
        }
        class h {
        }
    },
    PcjG: function(e, t, n) {
        "use strict";
        n.d(t, "c", function() {
            return a
        }),
        n.d(t, "d", function() {
            return c
        }),
        n.d(t, "a", function() {
            return u
        }),
        n.d(t, "b", function() {
            return h
        });
        var r = n("DQLy")
          , s = (n("2mKN"),
        n("oTXU"),
        n("TOZH"));
        n("AytR");
        const i = Object(r.v)(s.a.Core)
          , o = Object(r.y)(i, e => e.view)
          , a = Object(r.y)(o, e => e.now)
          , c = Object(r.y)(o, e => e.updateSpan)
          , l = Object(r.y)(i, e => e.notice)
          , u = Object(r.y)(l, e => e.notice)
          , h = Object(r.y)(u, e => e.type)
    },
    Qrwk: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        class r {
        }
    },
    SVse: function(e, t, n) {
        "use strict";
        n.d(t, "x", function() {
            return V
        }),
        n.d(t, "r", function() {
            return D
        }),
        n.d(t, "m", function() {
            return q
        }),
        n.d(t, "n", function() {
            return $
        }),
        n.d(t, "y", function() {
            return Q
        }),
        n.d(t, "c", function() {
            return ue
        }),
        n.d(t, "j", function() {
            return Z
        }),
        n.d(t, "k", function() {
            return J
        }),
        n.d(t, "l", function() {
            return ee
        }),
        n.d(t, "d", function() {
            return he
        }),
        n.d(t, "b", function() {
            return ce
        }),
        n.d(t, "e", function() {
            return le
        }),
        n.d(t, "w", function() {
            return de
        }),
        n.d(t, "s", function() {
            return pe
        }),
        n.d(t, "t", function() {
            return me
        }),
        n.d(t, "q", function() {
            return ge
        }),
        n.d(t, "v", function() {
            return K
        }),
        n.d(t, "u", function() {
            return G
        }),
        n.d(t, "p", function() {
            return s
        }),
        n.d(t, "g", function() {
            return i
        }),
        n.d(t, "i", function() {
            return o
        }),
        n.d(t, "a", function() {
            return a
        }),
        n.d(t, "f", function() {
            return u
        }),
        n.d(t, "o", function() {
            return h
        }),
        n.d(t, "h", function() {
            return c
        });
        var r = n("8Y7J");
        class s {
        }
        const i = new r.p("Location Initialized");
        class o {
        }
        const a = new r.p("appBaseHref");
        class c {
            constructor(e, t) {
                this._subject = new r.m,
                this._urlChangeListeners = [],
                this._platformStrategy = e;
                const n = this._platformStrategy.getBaseHref();
                this._platformLocation = t,
                this._baseHref = c.stripTrailingSlash(l(n)),
                this._platformStrategy.onPopState(e => {
                    this._subject.emit({
                        url: this.path(!0),
                        pop: !0,
                        state: e.state,
                        type: e.type
                    })
                }
                )
            }
            path(e=!1) {
                return this.normalize(this._platformStrategy.path(e))
            }
            getState() {
                return this._platformLocation.getState()
            }
            isCurrentPathEqualTo(e, t="") {
                return this.path() == this.normalize(e + c.normalizeQueryParams(t))
            }
            normalize(e) {
                return c.stripTrailingSlash(function(e, t) {
                    return e && t.startsWith(e) ? t.substring(e.length) : t
                }(this._baseHref, l(e)))
            }
            prepareExternalUrl(e) {
                return e && "/" !== e[0] && (e = "/" + e),
                this._platformStrategy.prepareExternalUrl(e)
            }
            go(e, t="", n=null) {
                this._platformStrategy.pushState(n, "", e, t),
                this._notifyUrlChangeListeners(this.prepareExternalUrl(e + c.normalizeQueryParams(t)), n)
            }
            replaceState(e, t="", n=null) {
                this._platformStrategy.replaceState(n, "", e, t),
                this._notifyUrlChangeListeners(this.prepareExternalUrl(e + c.normalizeQueryParams(t)), n)
            }
            forward() {
                this._platformStrategy.forward()
            }
            back() {
                this._platformStrategy.back()
            }
            onUrlChange(e) {
                this._urlChangeListeners.push(e),
                this.subscribe(e => {
                    this._notifyUrlChangeListeners(e.url, e.state)
                }
                )
            }
            _notifyUrlChangeListeners(e="", t) {
                this._urlChangeListeners.forEach(n => n(e, t))
            }
            subscribe(e, t, n) {
                return this._subject.subscribe({
                    next: e,
                    error: t,
                    complete: n
                })
            }
            static normalizeQueryParams(e) {
                return e && "?" !== e[0] ? "?" + e : e
            }
            static joinWithSlash(e, t) {
                if (0 == e.length)
                    return t;
                if (0 == t.length)
                    return e;
                let n = 0;
                return e.endsWith("/") && n++,
                t.startsWith("/") && n++,
                2 == n ? e + t.substring(1) : 1 == n ? e + t : e + "/" + t
            }
            static stripTrailingSlash(e) {
                const t = e.match(/#|\?|$/)
                  , n = t && t.index || e.length;
                return e.slice(0, n - ("/" === e[n - 1] ? 1 : 0)) + e.slice(n)
            }
        }
        function l(e) {
            return e.replace(/\/index.html$/, "")
        }
        class u extends o {
            constructor(e, t) {
                super(),
                this._platformLocation = e,
                this._baseHref = "",
                null != t && (this._baseHref = t)
            }
            onPopState(e) {
                this._platformLocation.onPopState(e),
                this._platformLocation.onHashChange(e)
            }
            getBaseHref() {
                return this._baseHref
            }
            path(e=!1) {
                let t = this._platformLocation.hash;
                return null == t && (t = "#"),
                t.length > 0 ? t.substring(1) : t
            }
            prepareExternalUrl(e) {
                const t = c.joinWithSlash(this._baseHref, e);
                return t.length > 0 ? "#" + t : t
            }
            pushState(e, t, n, r) {
                let s = this.prepareExternalUrl(n + c.normalizeQueryParams(r));
                0 == s.length && (s = this._platformLocation.pathname),
                this._platformLocation.pushState(e, t, s)
            }
            replaceState(e, t, n, r) {
                let s = this.prepareExternalUrl(n + c.normalizeQueryParams(r));
                0 == s.length && (s = this._platformLocation.pathname),
                this._platformLocation.replaceState(e, t, s)
            }
            forward() {
                this._platformLocation.forward()
            }
            back() {
                this._platformLocation.back()
            }
        }
        class h extends o {
            constructor(e, t) {
                if (super(),
                this._platformLocation = e,
                null == t && (t = this._platformLocation.getBaseHrefFromDOM()),
                null == t)
                    throw new Error("No base href set. Please provide a value for the APP_BASE_HREF token or add a base element to the document.");
                this._baseHref = t
            }
            onPopState(e) {
                this._platformLocation.onPopState(e),
                this._platformLocation.onHashChange(e)
            }
            getBaseHref() {
                return this._baseHref
            }
            prepareExternalUrl(e) {
                return c.joinWithSlash(this._baseHref, e)
            }
            path(e=!1) {
                const t = this._platformLocation.pathname + c.normalizeQueryParams(this._platformLocation.search)
                  , n = this._platformLocation.hash;
                return n && e ? `${t}${n}` : t
            }
            pushState(e, t, n, r) {
                const s = this.prepareExternalUrl(n + c.normalizeQueryParams(r));
                this._platformLocation.pushState(e, t, s)
            }
            replaceState(e, t, n, r) {
                const s = this.prepareExternalUrl(n + c.normalizeQueryParams(r));
                this._platformLocation.replaceState(e, t, s)
            }
            forward() {
                this._platformLocation.forward()
            }
            back() {
                this._platformLocation.back()
            }
        }
        const d = function() {
            var e = {
                Zero: 0,
                One: 1,
                Two: 2,
                Few: 3,
                Many: 4,
                Other: 5
            };
            return e[e.Zero] = "Zero",
            e[e.One] = "One",
            e[e.Two] = "Two",
            e[e.Few] = "Few",
            e[e.Many] = "Many",
            e[e.Other] = "Other",
            e
        }()
          , f = function() {
            var e = {
                Format: 0,
                Standalone: 1
            };
            return e[e.Format] = "Format",
            e[e.Standalone] = "Standalone",
            e
        }()
          , p = function() {
            var e = {
                Narrow: 0,
                Abbreviated: 1,
                Wide: 2,
                Short: 3
            };
            return e[e.Narrow] = "Narrow",
            e[e.Abbreviated] = "Abbreviated",
            e[e.Wide] = "Wide",
            e[e.Short] = "Short",
            e
        }()
          , m = function() {
            var e = {
                Short: 0,
                Medium: 1,
                Long: 2,
                Full: 3
            };
            return e[e.Short] = "Short",
            e[e.Medium] = "Medium",
            e[e.Long] = "Long",
            e[e.Full] = "Full",
            e
        }()
          , g = function() {
            var e = {
                Decimal: 0,
                Group: 1,
                List: 2,
                PercentSign: 3,
                PlusSign: 4,
                MinusSign: 5,
                Exponential: 6,
                SuperscriptingExponent: 7,
                PerMille: 8,
                Infinity: 9,
                NaN: 10,
                TimeSeparator: 11,
                CurrencyDecimal: 12,
                CurrencyGroup: 13
            };
            return e[e.Decimal] = "Decimal",
            e[e.Group] = "Group",
            e[e.List] = "List",
            e[e.PercentSign] = "PercentSign",
            e[e.PlusSign] = "PlusSign",
            e[e.MinusSign] = "MinusSign",
            e[e.Exponential] = "Exponential",
            e[e.SuperscriptingExponent] = "SuperscriptingExponent",
            e[e.PerMille] = "PerMille",
            e[e.Infinity] = "Infinity",
            e[e.NaN] = "NaN",
            e[e.TimeSeparator] = "TimeSeparator",
            e[e.CurrencyDecimal] = "CurrencyDecimal",
            e[e.CurrencyGroup] = "CurrencyGroup",
            e
        }();
        function b(e, t) {
            return S(Object(r.tb)(e)[r.db.DateFormat], t)
        }
        function y(e, t) {
            return S(Object(r.tb)(e)[r.db.TimeFormat], t)
        }
        function v(e, t) {
            return S(Object(r.tb)(e)[r.db.DateTimeFormat], t)
        }
        function _(e, t) {
            const n = Object(r.tb)(e)
              , s = n[r.db.NumberSymbols][t];
            if (void 0 === s) {
                if (t === g.CurrencyDecimal)
                    return n[r.db.NumberSymbols][g.Decimal];
                if (t === g.CurrencyGroup)
                    return n[r.db.NumberSymbols][g.Group]
            }
            return s
        }
        const w = r.ub;
        function E(e) {
            if (!e[r.db.ExtraData])
                throw new Error(`Missing extra locale data for the locale "${e[r.db.LocaleId]}". Use "registerLocaleData" to load new data. See the "I18n guide" on angular.io to know more.`)
        }
        function S(e, t) {
            for (let n = t; n > -1; n--)
                if (void 0 !== e[n])
                    return e[n];
            throw new Error("Locale data API: locale data undefined")
        }
        function C(e) {
            const [t,n] = e.split(":");
            return {
                hours: +t,
                minutes: +n
            }
        }
        const T = /^(\d{4})-?(\d\d)-?(\d\d)(?:T(\d\d)(?::?(\d\d)(?::?(\d\d)(?:\.(\d+))?)?)?(Z|([+-])(\d\d):?(\d\d))?)?$/
          , x = {}
          , k = /((?:[^GyMLwWdEabBhHmsSzZO']+)|(?:'(?:[^']|'')*')|(?:G{1,5}|y{1,4}|M{1,5}|L{1,5}|w{1,2}|W{1}|d{1,2}|E{1,6}|a{1,5}|b{1,5}|B{1,5}|h{1,2}|H{1,2}|m{1,2}|s{1,2}|S{1,3}|z{1,4}|Z{1,5}|O{1,4}))([\s\S]*)/
          , O = function() {
            var e = {
                Short: 0,
                ShortGMT: 1,
                Long: 2,
                Extended: 3
            };
            return e[e.Short] = "Short",
            e[e.ShortGMT] = "ShortGMT",
            e[e.Long] = "Long",
            e[e.Extended] = "Extended",
            e
        }()
          , I = function() {
            var e = {
                FullYear: 0,
                Month: 1,
                Date: 2,
                Hours: 3,
                Minutes: 4,
                Seconds: 5,
                FractionalSeconds: 6,
                Day: 7
            };
            return e[e.FullYear] = "FullYear",
            e[e.Month] = "Month",
            e[e.Date] = "Date",
            e[e.Hours] = "Hours",
            e[e.Minutes] = "Minutes",
            e[e.Seconds] = "Seconds",
            e[e.FractionalSeconds] = "FractionalSeconds",
            e[e.Day] = "Day",
            e
        }()
          , A = function() {
            var e = {
                DayPeriods: 0,
                Days: 1,
                Months: 2,
                Eras: 3
            };
            return e[e.DayPeriods] = "DayPeriods",
            e[e.Days] = "Days",
            e[e.Months] = "Months",
            e[e.Eras] = "Eras",
            e
        }();
        function D(e, t, n, s) {
            let i = function(e) {
                if (B(e))
                    return e;
                if ("number" == typeof e && !isNaN(e))
                    return new Date(e);
                if ("string" == typeof e) {
                    e = e.trim();
                    const t = parseFloat(e);
                    if (!isNaN(e - t))
                        return new Date(t);
                    if (/^(\d{4}-\d{1,2}-\d{1,2})$/.test(e)) {
                        const [t,n,r] = e.split("-").map(e => +e);
                        return new Date(t,n - 1,r)
                    }
                    let n;
                    if (n = e.match(T))
                        return function(e) {
                            const t = new Date(0);
                            let n = 0
                              , r = 0;
                            const s = e[8] ? t.setUTCFullYear : t.setFullYear
                              , i = e[8] ? t.setUTCHours : t.setHours;
                            e[9] && (n = Number(e[9] + e[10]),
                            r = Number(e[9] + e[11])),
                            s.call(t, Number(e[1]), Number(e[2]) - 1, Number(e[3]));
                            const o = Number(e[4] || 0) - n
                              , a = Number(e[5] || 0) - r
                              , c = Number(e[6] || 0)
                              , l = Math.round(1e3 * parseFloat("0." + (e[7] || 0)));
                            return i.call(t, o, a, c, l),
                            t
                        }(n)
                }
                const t = new Date(e);
                if (!B(t))
                    throw new Error(`Unable to convert "${e}" into a date`);
                return t
            }(e);
            t = function e(t, n) {
                const s = function(e) {
                    return Object(r.tb)(e)[r.db.LocaleId]
                }(t);
                if (x[s] = x[s] || {},
                x[s][n])
                    return x[s][n];
                let i = "";
                switch (n) {
                case "shortDate":
                    i = b(t, m.Short);
                    break;
                case "mediumDate":
                    i = b(t, m.Medium);
                    break;
                case "longDate":
                    i = b(t, m.Long);
                    break;
                case "fullDate":
                    i = b(t, m.Full);
                    break;
                case "shortTime":
                    i = y(t, m.Short);
                    break;
                case "mediumTime":
                    i = y(t, m.Medium);
                    break;
                case "longTime":
                    i = y(t, m.Long);
                    break;
                case "fullTime":
                    i = y(t, m.Full);
                    break;
                case "short":
                    const r = e(t, "shortTime")
                      , s = e(t, "shortDate");
                    i = R(v(t, m.Short), [r, s]);
                    break;
                case "medium":
                    const o = e(t, "mediumTime")
                      , a = e(t, "mediumDate");
                    i = R(v(t, m.Medium), [o, a]);
                    break;
                case "long":
                    const c = e(t, "longTime")
                      , l = e(t, "longDate");
                    i = R(v(t, m.Long), [c, l]);
                    break;
                case "full":
                    const u = e(t, "fullTime")
                      , h = e(t, "fullDate");
                    i = R(v(t, m.Full), [u, h])
                }
                return i && (x[s][n] = i),
                i
            }(n, t) || t;
            let o, a = [];
            for (; t; ) {
                if (!(o = k.exec(t))) {
                    a.push(t);
                    break
                }
                {
                    const e = (a = a.concat(o.slice(1))).pop();
                    if (!e)
                        break;
                    t = e
                }
            }
            let c = i.getTimezoneOffset();
            s && (c = H(s, c),
            i = function(e, t, n) {
                const r = e.getTimezoneOffset();
                return function(e, t) {
                    return (e = new Date(e.getTime())).setMinutes(e.getMinutes() + t),
                    e
                }(e, -1 * (H(t, r) - r))
            }(i, s));
            let l = "";
            return a.forEach(e => {
                const t = function(e) {
                    if (z[e])
                        return z[e];
                    let t;
                    switch (e) {
                    case "G":
                    case "GG":
                    case "GGG":
                        t = P(A.Eras, p.Abbreviated);
                        break;
                    case "GGGG":
                        t = P(A.Eras, p.Wide);
                        break;
                    case "GGGGG":
                        t = P(A.Eras, p.Narrow);
                        break;
                    case "y":
                        t = N(I.FullYear, 1, 0, !1, !0);
                        break;
                    case "yy":
                        t = N(I.FullYear, 2, 0, !0, !0);
                        break;
                    case "yyy":
                        t = N(I.FullYear, 3, 0, !1, !0);
                        break;
                    case "yyyy":
                        t = N(I.FullYear, 4, 0, !1, !0);
                        break;
                    case "M":
                    case "L":
                        t = N(I.Month, 1, 1);
                        break;
                    case "MM":
                    case "LL":
                        t = N(I.Month, 2, 1);
                        break;
                    case "MMM":
                        t = P(A.Months, p.Abbreviated);
                        break;
                    case "MMMM":
                        t = P(A.Months, p.Wide);
                        break;
                    case "MMMMM":
                        t = P(A.Months, p.Narrow);
                        break;
                    case "LLL":
                        t = P(A.Months, p.Abbreviated, f.Standalone);
                        break;
                    case "LLLL":
                        t = P(A.Months, p.Wide, f.Standalone);
                        break;
                    case "LLLLL":
                        t = P(A.Months, p.Narrow, f.Standalone);
                        break;
                    case "w":
                        t = U(1);
                        break;
                    case "ww":
                        t = U(2);
                        break;
                    case "W":
                        t = U(1, !0);
                        break;
                    case "d":
                        t = N(I.Date, 1);
                        break;
                    case "dd":
                        t = N(I.Date, 2);
                        break;
                    case "E":
                    case "EE":
                    case "EEE":
                        t = P(A.Days, p.Abbreviated);
                        break;
                    case "EEEE":
                        t = P(A.Days, p.Wide);
                        break;
                    case "EEEEE":
                        t = P(A.Days, p.Narrow);
                        break;
                    case "EEEEEE":
                        t = P(A.Days, p.Short);
                        break;
                    case "a":
                    case "aa":
                    case "aaa":
                        t = P(A.DayPeriods, p.Abbreviated);
                        break;
                    case "aaaa":
                        t = P(A.DayPeriods, p.Wide);
                        break;
                    case "aaaaa":
                        t = P(A.DayPeriods, p.Narrow);
                        break;
                    case "b":
                    case "bb":
                    case "bbb":
                        t = P(A.DayPeriods, p.Abbreviated, f.Standalone, !0);
                        break;
                    case "bbbb":
                        t = P(A.DayPeriods, p.Wide, f.Standalone, !0);
                        break;
                    case "bbbbb":
                        t = P(A.DayPeriods, p.Narrow, f.Standalone, !0);
                        break;
                    case "B":
                    case "BB":
                    case "BBB":
                        t = P(A.DayPeriods, p.Abbreviated, f.Format, !0);
                        break;
                    case "BBBB":
                        t = P(A.DayPeriods, p.Wide, f.Format, !0);
                        break;
                    case "BBBBB":
                        t = P(A.DayPeriods, p.Narrow, f.Format, !0);
                        break;
                    case "h":
                        t = N(I.Hours, 1, -12);
                        break;
                    case "hh":
                        t = N(I.Hours, 2, -12);
                        break;
                    case "H":
                        t = N(I.Hours, 1);
                        break;
                    case "HH":
                        t = N(I.Hours, 2);
                        break;
                    case "m":
                        t = N(I.Minutes, 1);
                        break;
                    case "mm":
                        t = N(I.Minutes, 2);
                        break;
                    case "s":
                        t = N(I.Seconds, 1);
                        break;
                    case "ss":
                        t = N(I.Seconds, 2);
                        break;
                    case "S":
                        t = N(I.FractionalSeconds, 1);
                        break;
                    case "SS":
                        t = N(I.FractionalSeconds, 2);
                        break;
                    case "SSS":
                        t = N(I.FractionalSeconds, 3);
                        break;
                    case "Z":
                    case "ZZ":
                    case "ZZZ":
                        t = M(O.Short);
                        break;
                    case "ZZZZZ":
                        t = M(O.Extended);
                        break;
                    case "O":
                    case "OO":
                    case "OOO":
                    case "z":
                    case "zz":
                    case "zzz":
                        t = M(O.ShortGMT);
                        break;
                    case "OOOO":
                    case "ZZZZ":
                    case "zzzz":
                        t = M(O.Long);
                        break;
                    default:
                        return null
                    }
                    return z[e] = t,
                    t
                }(e);
                l += t ? t(i, n, c) : "''" === e ? "'" : e.replace(/(^'|'$)/g, "").replace(/''/g, "'")
            }
            ),
            l
        }
        function R(e, t) {
            return t && (e = e.replace(/\{([^}]+)}/g, function(e, n) {
                return null != t && n in t ? t[n] : e
            })),
            e
        }
        function j(e, t, n="-", r, s) {
            let i = "";
            (e < 0 || s && e <= 0) && (s ? e = 1 - e : (e = -e,
            i = n));
            let o = String(e);
            for (; o.length < t; )
                o = "0" + o;
            return r && (o = o.substr(o.length - t)),
            i + o
        }
        function N(e, t, n=0, r=!1, s=!1) {
            return function(i, o) {
                let a = function(e, t) {
                    switch (e) {
                    case I.FullYear:
                        return t.getFullYear();
                    case I.Month:
                        return t.getMonth();
                    case I.Date:
                        return t.getDate();
                    case I.Hours:
                        return t.getHours();
                    case I.Minutes:
                        return t.getMinutes();
                    case I.Seconds:
                        return t.getSeconds();
                    case I.FractionalSeconds:
                        return t.getMilliseconds();
                    case I.Day:
                        return t.getDay();
                    default:
                        throw new Error(`Unknown DateType value "${e}".`)
                    }
                }(e, i);
                if ((n > 0 || a > -n) && (a += n),
                e === I.Hours)
                    0 === a && -12 === n && (a = 12);
                else if (e === I.FractionalSeconds)
                    return c = t,
                    j(a, 3).substr(0, c);
                var c;
                const l = _(o, g.MinusSign);
                return j(a, t, l, r, s)
            }
        }
        function P(e, t, n=f.Format, s=!1) {
            return function(i, o) {
                return function(e, t, n, s, i, o) {
                    switch (n) {
                    case A.Months:
                        return function(e, t, n) {
                            const s = Object(r.tb)(e)
                              , i = S([s[r.db.MonthsFormat], s[r.db.MonthsStandalone]], t);
                            return S(i, n)
                        }(t, i, s)[e.getMonth()];
                    case A.Days:
                        return function(e, t, n) {
                            const s = Object(r.tb)(e)
                              , i = S([s[r.db.DaysFormat], s[r.db.DaysStandalone]], t);
                            return S(i, n)
                        }(t, i, s)[e.getDay()];
                    case A.DayPeriods:
                        const a = e.getHours()
                          , c = e.getMinutes();
                        if (o) {
                            const e = function(e) {
                                const t = Object(r.tb)(e);
                                return E(t),
                                (t[r.db.ExtraData][2] || []).map(e => "string" == typeof e ? C(e) : [C(e[0]), C(e[1])])
                            }(t)
                              , n = function(e, t, n) {
                                const s = Object(r.tb)(e);
                                E(s);
                                const i = S([s[r.db.ExtraData][0], s[r.db.ExtraData][1]], t) || [];
                                return S(i, n) || []
                            }(t, i, s);
                            let o;
                            if (e.forEach( (e, t) => {
                                if (Array.isArray(e)) {
                                    const {hours: r, minutes: s} = e[0]
                                      , {hours: i, minutes: l} = e[1];
                                    a >= r && c >= s && (a < i || a === i && c < l) && (o = n[t])
                                } else {
                                    const {hours: r, minutes: s} = e;
                                    r === a && s === c && (o = n[t])
                                }
                            }
                            ),
                            o)
                                return o
                        }
                        return function(e, t, n) {
                            const s = Object(r.tb)(e)
                              , i = S([s[r.db.DayPeriodsFormat], s[r.db.DayPeriodsStandalone]], t);
                            return S(i, n)
                        }(t, i, s)[a < 12 ? 0 : 1];
                    case A.Eras:
                        return function(e, t) {
                            return S(Object(r.tb)(e)[r.db.Eras], t)
                        }(t, s)[e.getFullYear() <= 0 ? 0 : 1];
                    default:
                        throw new Error(`unexpected translation type ${n}`)
                    }
                }(i, o, e, t, n, s)
            }
        }
        function M(e) {
            return function(t, n, r) {
                const s = -1 * r
                  , i = _(n, g.MinusSign)
                  , o = s > 0 ? Math.floor(s / 60) : Math.ceil(s / 60);
                switch (e) {
                case O.Short:
                    return (s >= 0 ? "+" : "") + j(o, 2, i) + j(Math.abs(s % 60), 2, i);
                case O.ShortGMT:
                    return "GMT" + (s >= 0 ? "+" : "") + j(o, 1, i);
                case O.Long:
                    return "GMT" + (s >= 0 ? "+" : "") + j(o, 2, i) + ":" + j(Math.abs(s % 60), 2, i);
                case O.Extended:
                    return 0 === r ? "Z" : (s >= 0 ? "+" : "") + j(o, 2, i) + ":" + j(Math.abs(s % 60), 2, i);
                default:
                    throw new Error(`Unknown zone width "${e}"`)
                }
            }
        }
        const L = 0
          , F = 4;
        function U(e, t=!1) {
            return function(n, r) {
                let s;
                if (t) {
                    const e = new Date(n.getFullYear(),n.getMonth(),1).getDay() - 1
                      , t = n.getDate();
                    s = 1 + Math.floor((t + e) / 7)
                } else {
                    const e = function(e) {
                        const t = new Date(e,L,1).getDay();
                        return new Date(e,0,1 + (t <= F ? F : F + 7) - t)
                    }(n.getFullYear())
                      , t = (i = n,
                    new Date(i.getFullYear(),i.getMonth(),i.getDate() + (F - i.getDay()))).getTime() - e.getTime();
                    s = 1 + Math.round(t / 6048e5)
                }
                var i;
                return j(s, e, _(r, g.MinusSign))
            }
        }
        const z = {};
        function H(e, t) {
            e = e.replace(/:/g, "");
            const n = Date.parse("Jan 01, 1970 00:00:00 " + e) / 6e4;
            return isNaN(n) ? t : n
        }
        function B(e) {
            return e instanceof Date && !isNaN(e.valueOf())
        }
        const V = new r.p("UseV4Plurals");
        class $ {
        }
        class q extends $ {
            constructor(e, t) {
                super(),
                this.locale = e,
                this.deprecatedPluralFn = t
            }
            getPluralCategory(e, t) {
                switch (this.deprecatedPluralFn ? this.deprecatedPluralFn(t || this.locale, e) : w(t || this.locale)(e)) {
                case d.Zero:
                    return "zero";
                case d.One:
                    return "one";
                case d.Two:
                    return "two";
                case d.Few:
                    return "few";
                case d.Many:
                    return "many";
                default:
                    return "other"
                }
            }
        }
        function Q(e, t) {
            t = encodeURIComponent(t);
            for (const n of e.split(";")) {
                const e = n.indexOf("=")
                  , [r,s] = -1 == e ? [n, ""] : [n.slice(0, e), n.slice(e + 1)];
                if (r.trim() === t)
                    return decodeURIComponent(s)
            }
            return null
        }
        class G {
        }
        class K {
            constructor(e, t, n, r) {
                this._iterableDiffers = e,
                this._keyValueDiffers = t,
                this._ngEl = n,
                this._renderer = r,
                this._initialClasses = []
            }
            getValue() {
                return null
            }
            setClass(e) {
                this._removeClasses(this._initialClasses),
                this._initialClasses = "string" == typeof e ? e.split(/\s+/) : [],
                this._applyClasses(this._initialClasses),
                this._applyClasses(this._rawClass)
            }
            setNgClass(e) {
                this._removeClasses(this._rawClass),
                this._applyClasses(this._initialClasses),
                this._iterableDiffer = null,
                this._keyValueDiffer = null,
                this._rawClass = "string" == typeof e ? e.split(/\s+/) : e,
                this._rawClass && (Object(r.wb)(this._rawClass) ? this._iterableDiffer = this._iterableDiffers.find(this._rawClass).create() : this._keyValueDiffer = this._keyValueDiffers.find(this._rawClass).create())
            }
            applyChanges() {
                if (this._iterableDiffer) {
                    const e = this._iterableDiffer.diff(this._rawClass);
                    e && this._applyIterableChanges(e)
                } else if (this._keyValueDiffer) {
                    const e = this._keyValueDiffer.diff(this._rawClass);
                    e && this._applyKeyValueChanges(e)
                }
            }
            _applyKeyValueChanges(e) {
                e.forEachAddedItem(e => this._toggleClass(e.key, e.currentValue)),
                e.forEachChangedItem(e => this._toggleClass(e.key, e.currentValue)),
                e.forEachRemovedItem(e => {
                    e.previousValue && this._toggleClass(e.key, !1)
                }
                )
            }
            _applyIterableChanges(e) {
                e.forEachAddedItem(e => {
                    if ("string" != typeof e.item)
                        throw new Error(`NgClass can only toggle CSS classes expressed as strings, got ${Object(r.Jb)(e.item)}`);
                    this._toggleClass(e.item, !0)
                }
                ),
                e.forEachRemovedItem(e => this._toggleClass(e.item, !1))
            }
            _applyClasses(e) {
                e && (Array.isArray(e) || e instanceof Set ? e.forEach(e => this._toggleClass(e, !0)) : Object.keys(e).forEach(t => this._toggleClass(t, !!e[t])))
            }
            _removeClasses(e) {
                e && (Array.isArray(e) || e instanceof Set ? e.forEach(e => this._toggleClass(e, !1)) : Object.keys(e).forEach(e => this._toggleClass(e, !1)))
            }
            _toggleClass(e, t) {
                (e = e.trim()) && e.split(/\s+/g).forEach(e => {
                    t ? this._renderer.addClass(this._ngEl.nativeElement, e) : this._renderer.removeClass(this._ngEl.nativeElement, e)
                }
                )
            }
        }
        let W = ( () => {
            class e {
                constructor(e) {
                    this._delegate = e
                }
                getValue() {
                    return this._delegate.getValue()
                }
            }
            return e.ngDirectiveDef = void 0,
            e
        }
        )();
        class Z extends W {
            constructor(e) {
                super(e)
            }
            set klass(e) {
                this._delegate.setClass(e)
            }
            set ngClass(e) {
                this._delegate.setNgClass(e)
            }
            ngDoCheck() {
                this._delegate.applyChanges()
            }
        }
        class Y {
            constructor(e, t, n, r) {
                this.$implicit = e,
                this.ngForOf = t,
                this.index = n,
                this.count = r
            }
            get first() {
                return 0 === this.index
            }
            get last() {
                return this.index === this.count - 1
            }
            get even() {
                return this.index % 2 == 0
            }
            get odd() {
                return !this.even
            }
        }
        class J {
            constructor(e, t, n) {
                this._viewContainer = e,
                this._template = t,
                this._differs = n,
                this._ngForOfDirty = !0,
                this._differ = null
            }
            set ngForOf(e) {
                this._ngForOf = e,
                this._ngForOfDirty = !0
            }
            set ngForTrackBy(e) {
                Object(r.W)() && null != e && "function" != typeof e && console && console.warn && console.warn(`trackBy must be a function, but received ${JSON.stringify(e)}. ` + "See https://angular.io/docs/ts/latest/api/common/index/NgFor-directive.html#!#change-propagation for more information."),
                this._trackByFn = e
            }
            get ngForTrackBy() {
                return this._trackByFn
            }
            set ngForTemplate(e) {
                e && (this._template = e)
            }
            ngDoCheck() {
                if (this._ngForOfDirty) {
                    this._ngForOfDirty = !1;
                    const n = this._ngForOf;
                    if (!this._differ && n)
                        try {
                            this._differ = this._differs.find(n).create(this.ngForTrackBy)
                        } catch (t) {
                            throw new Error(`Cannot find a differ supporting object '${n}' of type '${e = n,
                            e.name || typeof e}'. NgFor only supports binding to Iterables such as Arrays.`)
                        }
                }
                var e;
                if (this._differ) {
                    const e = this._differ.diff(this._ngForOf);
                    e && this._applyChanges(e)
                }
            }
            _applyChanges(e) {
                const t = [];
                e.forEachOperation( (e, n, r) => {
                    if (null == e.previousIndex) {
                        const n = this._viewContainer.createEmbeddedView(this._template, new Y(null,this._ngForOf,-1,-1), null === r ? void 0 : r)
                          , s = new X(e,n);
                        t.push(s)
                    } else if (null == r)
                        this._viewContainer.remove(null === n ? void 0 : n);
                    else if (null !== n) {
                        const s = this._viewContainer.get(n);
                        this._viewContainer.move(s, r);
                        const i = new X(e,s);
                        t.push(i)
                    }
                }
                );
                for (let n = 0; n < t.length; n++)
                    this._perViewChange(t[n].view, t[n].record);
                for (let n = 0, r = this._viewContainer.length; n < r; n++) {
                    const e = this._viewContainer.get(n);
                    e.context.index = n,
                    e.context.count = r,
                    e.context.ngForOf = this._ngForOf
                }
                e.forEachIdentityChange(e => {
                    this._viewContainer.get(e.currentIndex).context.$implicit = e.item
                }
                )
            }
            _perViewChange(e, t) {
                e.context.$implicit = t.item
            }
            static ngTemplateContextGuard(e, t) {
                return !0
            }
        }
        class X {
            constructor(e, t) {
                this.record = e,
                this.view = t
            }
        }
        class ee {
            constructor(e, t) {
                this._viewContainer = e,
                this._context = new te,
                this._thenTemplateRef = null,
                this._elseTemplateRef = null,
                this._thenViewRef = null,
                this._elseViewRef = null,
                this._thenTemplateRef = t
            }
            set ngIf(e) {
                this._context.$implicit = this._context.ngIf = e,
                this._updateView()
            }
            set ngIfThen(e) {
                ne("ngIfThen", e),
                this._thenTemplateRef = e,
                this._thenViewRef = null,
                this._updateView()
            }
            set ngIfElse(e) {
                ne("ngIfElse", e),
                this._elseTemplateRef = e,
                this._elseViewRef = null,
                this._updateView()
            }
            _updateView() {
                this._context.$implicit ? this._thenViewRef || (this._viewContainer.clear(),
                this._elseViewRef = null,
                this._thenTemplateRef && (this._thenViewRef = this._viewContainer.createEmbeddedView(this._thenTemplateRef, this._context))) : this._elseViewRef || (this._viewContainer.clear(),
                this._thenViewRef = null,
                this._elseTemplateRef && (this._elseViewRef = this._viewContainer.createEmbeddedView(this._elseTemplateRef, this._context)))
            }
        }
        class te {
            constructor() {
                this.$implicit = null,
                this.ngIf = null
            }
        }
        function ne(e, t) {
            if (t && !t.createEmbeddedView)
                throw new Error(`${e} must be a TemplateRef, but received '${Object(r.Jb)(t)}'.`)
        }
        function re(e, t) {
            return Error(`InvalidPipeArgument: '${t}' for pipe '${Object(r.Jb)(e)}'`)
        }
        class se {
            createSubscription(e, t) {
                return e.subscribe({
                    next: t,
                    error: e => {
                        throw e
                    }
                })
            }
            dispose(e) {
                e.unsubscribe()
            }
            onDestroy(e) {
                e.unsubscribe()
            }
        }
        class ie {
            createSubscription(e, t) {
                return e.then(t, e => {
                    throw e
                }
                )
            }
            dispose(e) {}
            onDestroy(e) {}
        }
        const oe = new ie
          , ae = new se;
        class ce {
            constructor(e) {
                this._ref = e,
                this._latestValue = null,
                this._latestReturnedValue = null,
                this._subscription = null,
                this._obj = null,
                this._strategy = null
            }
            ngOnDestroy() {
                this._subscription && this._dispose()
            }
            transform(e) {
                return this._obj ? e !== this._obj ? (this._dispose(),
                this.transform(e)) : Object(r.zb)(this._latestValue, this._latestReturnedValue) ? this._latestReturnedValue : (this._latestReturnedValue = this._latestValue,
                r.Q.wrap(this._latestValue)) : (e && this._subscribe(e),
                this._latestReturnedValue = this._latestValue,
                this._latestValue)
            }
            _subscribe(e) {
                this._obj = e,
                this._strategy = this._selectStrategy(e),
                this._subscription = this._strategy.createSubscription(e, t => this._updateLatestValue(e, t))
            }
            _selectStrategy(e) {
                if (Object(r.yb)(e))
                    return oe;
                if (Object(r.xb)(e))
                    return ae;
                throw re(ce, e)
            }
            _dispose() {
                this._strategy.dispose(this._subscription),
                this._latestValue = null,
                this._latestReturnedValue = null,
                this._subscription = null,
                this._obj = null
            }
            _updateLatestValue(e, t) {
                e === this._obj && (this._latestValue = t,
                this._ref.markForCheck())
            }
        }
        class le {
            constructor(e) {
                this.locale = e
            }
            transform(e, t="mediumDate", n, r) {
                if (null == e || "" === e || e != e)
                    return null;
                try {
                    return D(e, t, r || this.locale, n)
                } catch (s) {
                    throw re(le, s.message)
                }
            }
        }
        class ue {
        }
        const he = new r.p("DocumentToken")
          , de = "browser"
          , fe = "server";
        function pe(e) {
            return e === de
        }
        function me(e) {
            return e === fe
        }
        let ge = ( () => {
            class e {
            }
            return e.ngInjectableDef = Object(r.Qb)({
                token: e,
                providedIn: "root",
                factory: () => new be(Object(r.Rb)(he),window,Object(r.Rb)(r.l))
            }),
            e
        }
        )();
        class be {
            constructor(e, t, n) {
                this.document = e,
                this.window = t,
                this.errorHandler = n,
                this.offset = () => [0, 0]
            }
            setOffset(e) {
                this.offset = Array.isArray(e) ? () => e : e
            }
            getScrollPosition() {
                return this.supportScrollRestoration() ? [this.window.scrollX, this.window.scrollY] : [0, 0]
            }
            scrollToPosition(e) {
                this.supportScrollRestoration() && this.window.scrollTo(e[0], e[1])
            }
            scrollToAnchor(e) {
                if (this.supportScrollRestoration()) {
                    e = this.window.CSS && this.window.CSS.escape ? this.window.CSS.escape(e) : e.replace(/(\"|\'\ |:|\.|\[|\]|,|=)/g, "\\$1");
                    try {
                        const n = this.document.querySelector(`#${e}`);
                        if (n)
                            return void this.scrollToElement(n);
                        const r = this.document.querySelector(`[name='${e}']`);
                        if (r)
                            return void this.scrollToElement(r)
                    } catch (t) {
                        this.errorHandler.handleError(t)
                    }
                }
            }
            setHistoryScrollRestoration(e) {
                if (this.supportScrollRestoration()) {
                    const t = this.window.history;
                    t && t.scrollRestoration && (t.scrollRestoration = e)
                }
            }
            scrollToElement(e) {
                const t = e.getBoundingClientRect()
                  , n = t.left + this.window.pageXOffset
                  , r = t.top + this.window.pageYOffset
                  , s = this.offset();
                this.window.scrollTo(n - s[0], r - s[1])
            }
            supportScrollRestoration() {
                try {
                    return !!this.window && !!this.window.scrollTo
                } catch (e) {
                    return !1
                }
            }
        }
    },
    SeVD: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return f
        });
        var r = n("HDdC")
          , s = n("ngJS")
          , i = n("a7t3")
          , o = n("pLzU")
          , a = n("CRDf")
          , c = n("I55L")
          , l = n("c2HN")
          , u = n("XoHu")
          , h = n("Lhse")
          , d = n("kJWO");
        const f = e => {
            if (e instanceof r.a)
                return t => e._isScalar ? (t.next(e.value),
                void t.complete()) : e.subscribe(t);
            if (e && "function" == typeof e[d.a])
                return Object(a.a)(e);
            if (Object(c.a)(e))
                return Object(s.a)(e);
            if (Object(l.a)(e))
                return Object(i.a)(e);
            if (e && "function" == typeof e[h.a])
                return Object(o.a)(e);
            {
                const t = Object(u.a)(e) ? "an invalid object" : `'${e}'`;
                throw new TypeError(`You provided ${t} where a stream was expected.` + " You can provide an Observable, Promise, Array, or Iterable.")
            }
        }
    },
    Snpo: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        var r = n("IheW")
          , s = n("AytR");
        class i {
            constructor(e, t) {
                this.http = e,
                this.apiConfig = t
            }
            createPath(e, ...t) {
                const n = this.apiConfig.resourceMap.get(e);
                if (!n)
                    throw new Error("[Config] Failed to get api key");
                let r = `${this.apiConfig.root}${n}`;
                if (s.a.mock && (r = `${s.a.api}${n}`,
                t && t.length > 0)) {
                    const e = r.indexOf("?");
                    e >= 0 && (r = r.substr(0, e)),
                    r += `/${t.join("/")}`
                }
                return r
            }
            createHttpParams(e) {
                return new r.i({
                    fromObject: e
                })
            }
            request(e) {
                return this.http.request(e).toPromise()
            }
        }
    },
    SpAZ: function(e, t, n) {
        "use strict";
        function r(e) {
            return e
        }
        n.d(t, "a", function() {
            return r
        })
    },
    TOZH: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        var r = function(e) {
            return e.Core = "Core",
            e.Main = "Main",
            e.Diagram = "Diagram",
            e
        }({})
    },
    Toje: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        class r {
            constructor(e) {
                this.resourceService = e
            }
            transform(e, ...t) {
                return e ? this.resourceService.get(e, ...t) : ""
            }
        }
    },
    VPT0: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        var r = function(e) {
            return e.None = "None",
            e.Error = "Error",
            e.ComError = "ComError",
            e
        }({})
    },
    VRyK: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return a
        });
        var r = n("HDdC")
          , s = n("z+Ro")
          , i = n("bHdf")
          , o = n("yCtX");
        function a(...e) {
            let t = Number.POSITIVE_INFINITY
              , n = null
              , a = e[e.length - 1];
            return Object(s.a)(a) ? (n = e.pop(),
            e.length > 1 && "number" == typeof e[e.length - 1] && (t = e.pop())) : "number" == typeof a && (t = e.pop()),
            null === n && 1 === e.length && e[0]instanceof r.a ? e[0] : Object(i.a)(t)(Object(o.a)(e, n))
        }
    },
    WMd4: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o
        });
        var r = n("EY2u")
          , s = n("LRne")
          , i = n("z6cu");
        let o = ( () => {
            class e {
                constructor(e, t, n) {
                    this.kind = e,
                    this.value = t,
                    this.error = n,
                    this.hasValue = "N" === e
                }
                observe(e) {
                    switch (this.kind) {
                    case "N":
                        return e.next && e.next(this.value);
                    case "E":
                        return e.error && e.error(this.error);
                    case "C":
                        return e.complete && e.complete()
                    }
                }
                do(e, t, n) {
                    switch (this.kind) {
                    case "N":
                        return e && e(this.value);
                    case "E":
                        return t && t(this.error);
                    case "C":
                        return n && n()
                    }
                }
                accept(e, t, n) {
                    return e && "function" == typeof e.next ? this.observe(e) : this.do(e, t, n)
                }
                toObservable() {
                    switch (this.kind) {
                    case "N":
                        return Object(s.a)(this.value);
                    case "E":
                        return Object(i.a)(this.error);
                    case "C":
                        return Object(r.b)()
                    }
                    throw new Error("unexpected notification kind value")
                }
                static createNext(t) {
                    return void 0 !== t ? new e("N",t) : e.undefinedValueNotification
                }
                static createError(t) {
                    return new e("E",void 0,t)
                }
                static createComplete() {
                    return e.completeNotification
                }
            }
            return e.completeNotification = new e("C"),
            e.undefinedValueNotification = new e("N",void 0),
            e
        }
        )()
    },
    XNiG: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return l
        }),
        n.d(t, "a", function() {
            return u
        });
        var r = n("HDdC")
          , s = n("7o/Q")
          , i = n("quSY")
          , o = n("9ppp")
          , a = n("Ylt2")
          , c = n("2QA8");
        class l extends s.a {
            constructor(e) {
                super(e),
                this.destination = e
            }
        }
        let u = ( () => {
            class e extends r.a {
                constructor() {
                    super(),
                    this.observers = [],
                    this.closed = !1,
                    this.isStopped = !1,
                    this.hasError = !1,
                    this.thrownError = null
                }
                [c.a]() {
                    return new l(this)
                }
                lift(e) {
                    const t = new h(this,this);
                    return t.operator = e,
                    t
                }
                next(e) {
                    if (this.closed)
                        throw new o.a;
                    if (!this.isStopped) {
                        const {observers: t} = this
                          , n = t.length
                          , r = t.slice();
                        for (let s = 0; s < n; s++)
                            r[s].next(e)
                    }
                }
                error(e) {
                    if (this.closed)
                        throw new o.a;
                    this.hasError = !0,
                    this.thrownError = e,
                    this.isStopped = !0;
                    const {observers: t} = this
                      , n = t.length
                      , r = t.slice();
                    for (let s = 0; s < n; s++)
                        r[s].error(e);
                    this.observers.length = 0
                }
                complete() {
                    if (this.closed)
                        throw new o.a;
                    this.isStopped = !0;
                    const {observers: e} = this
                      , t = e.length
                      , n = e.slice();
                    for (let r = 0; r < t; r++)
                        n[r].complete();
                    this.observers.length = 0
                }
                unsubscribe() {
                    this.isStopped = !0,
                    this.closed = !0,
                    this.observers = null
                }
                _trySubscribe(e) {
                    if (this.closed)
                        throw new o.a;
                    return super._trySubscribe(e)
                }
                _subscribe(e) {
                    if (this.closed)
                        throw new o.a;
                    return this.hasError ? (e.error(this.thrownError),
                    i.a.EMPTY) : this.isStopped ? (e.complete(),
                    i.a.EMPTY) : (this.observers.push(e),
                    new a.a(this,e))
                }
                asObservable() {
                    const e = new r.a;
                    return e.source = this,
                    e
                }
            }
            return e.create = (e, t) => new h(e,t),
            e
        }
        )();
        class h extends u {
            constructor(e, t) {
                super(),
                this.destination = e,
                this.source = t
            }
            next(e) {
                const {destination: t} = this;
                t && t.next && t.next(e)
            }
            error(e) {
                const {destination: t} = this;
                t && t.error && this.destination.error(e)
            }
            complete() {
                const {destination: e} = this;
                e && e.complete && this.destination.complete()
            }
            _subscribe(e) {
                const {source: t} = this;
                return t ? this.source.subscribe(e) : i.a.EMPTY
            }
        }
    },
    XUOw: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("HDdC");
        function s(e) {
            const t = new r.a(t => {
                t.next(e),
                t.complete()
            }
            );
            return t._isScalar = !0,
            t.value = e,
            t
        }
    },
    Xd0L: function(e, t, n) {
        "use strict";
        var r = n("8Y7J")
          , s = n("cUpR");
        const i = new r.N("8.1.4");
        var o = n("KCVW")
          , a = (n("XNiG"),
        n("HDdC"),
        n("/HVE"))
          , c = (n("JX91"),
        n("5GAg"));
        n("dvZr"),
        n.d(t, "e", function() {
            return h
        }),
        n.d(t, "b", function() {
            return u
        }),
        n.d(t, "k", function() {
            return d
        }),
        n.d(t, "i", function() {
            return f
        }),
        n.d(t, "j", function() {
            return p
        }),
        n.d(t, "l", function() {
            return m
        }),
        n.d(t, "c", function() {
            return b
        }),
        n.d(t, "a", function() {
            return _
        }),
        n.d(t, "g", function() {
            return I
        }),
        n.d(t, "d", function() {
            return k
        }),
        n.d(t, "f", function() {
            return O
        }),
        n.d(t, "h", function() {
            return x
        });
        const l = new r.N("8.1.4")
          , u = new r.p("mat-sanity-checks",{
            providedIn: "root",
            factory: function() {
                return !0
            }
        });
        class h {
            constructor(e, t) {
                this._sanityChecksEnabled = e,
                this._hammerLoader = t,
                this._hasDoneGlobalChecks = !1,
                this._hasCheckedHammer = !1,
                this._document = "object" == typeof document && document ? document : null,
                this._window = "object" == typeof window && window ? window : null,
                this._areChecksEnabled() && !this._hasDoneGlobalChecks && (this._checkDoctypeIsDefined(),
                this._checkThemeIsPresent(),
                this._checkCdkVersionMatch(),
                this._hasDoneGlobalChecks = !0)
            }
            _areChecksEnabled() {
                return this._sanityChecksEnabled && Object(r.W)() && !this._isTestEnv()
            }
            _isTestEnv() {
                const e = this._window;
                return e && (e.__karma__ || e.jasmine)
            }
            _checkDoctypeIsDefined() {
                this._document && !this._document.doctype && console.warn("Current document does not have a doctype. This may cause some Angular Material components not to behave as expected.")
            }
            _checkThemeIsPresent() {
                if (!this._document || !this._document.body || "function" != typeof getComputedStyle)
                    return;
                const e = this._document.createElement("div");
                e.classList.add("mat-theme-loaded-marker"),
                this._document.body.appendChild(e);
                const t = getComputedStyle(e);
                t && "none" !== t.display && console.warn("Could not find Angular Material core theme. Most Material components may not work as expected. For more info refer to the theming guide: https://material.angular.io/guide/theming"),
                this._document.body.removeChild(e)
            }
            _checkCdkVersionMatch() {
                l.full !== i.full && console.warn("The Angular Material version (" + l.full + ") does not match the Angular CDK version (" + i.full + ").\nPlease ensure the versions of these two packages exactly match.")
            }
            _checkHammerIsAvailable() {
                !this._hasCheckedHammer && this._window && (!this._areChecksEnabled() || this._window.Hammer || this._hammerLoader || console.warn("Could not find HammerJS. Certain Angular Material components may not work correctly."),
                this._hasCheckedHammer = !0)
            }
        }
        function d(e) {
            return class extends e {
                constructor(...e) {
                    super(...e),
                    this._disabled = !1
                }
                get disabled() {
                    return this._disabled
                }
                set disabled(e) {
                    this._disabled = Object(o.b)(e)
                }
            }
        }
        function f(e, t) {
            return class extends e {
                get color() {
                    return this._color
                }
                set color(e) {
                    const n = e || t;
                    n !== this._color && (this._color && this._elementRef.nativeElement.classList.remove(`mat-${this._color}`),
                    n && this._elementRef.nativeElement.classList.add(`mat-${n}`),
                    this._color = n)
                }
                constructor(...e) {
                    super(...e),
                    this.color = t
                }
            }
        }
        function p(e) {
            return class extends e {
                constructor(...e) {
                    super(...e),
                    this._disableRipple = !1
                }
                get disableRipple() {
                    return this._disableRipple
                }
                set disableRipple(e) {
                    this._disableRipple = Object(o.b)(e)
                }
            }
        }
        function m(e, t=0) {
            return class extends e {
                constructor(...e) {
                    super(...e),
                    this._tabIndex = t
                }
                get tabIndex() {
                    return this.disabled ? -1 : this._tabIndex
                }
                set tabIndex(e) {
                    this._tabIndex = null != e ? e : t
                }
            }
        }
        let g;
        try {
            g = "undefined" != typeof Intl
        } catch (A) {
            g = !1
        }
        const b = new r.p("MAT_HAMMER_OPTIONS")
          , y = ["longpress", "slide", "slidestart", "slideend", "slideright", "slideleft"]
          , v = {
            on: () => {}
            ,
            off: () => {}
        };
        class _ extends s.g {
            constructor(e, t) {
                super(),
                this._hammerOptions = e,
                this.events = y,
                t && t._checkHammerIsAvailable()
            }
            buildHammer(e) {
                const t = "undefined" != typeof window ? window.Hammer : null;
                if (!t)
                    return v;
                const n = new t(e,this._hammerOptions || void 0)
                  , r = new t.Pan
                  , s = new t.Swipe
                  , i = new t.Press
                  , o = this._createRecognizer(r, {
                    event: "slide",
                    threshold: 0
                }, s)
                  , a = this._createRecognizer(i, {
                    event: "longpress",
                    time: 500
                });
                return r.recognizeWith(s),
                a.recognizeWith(o),
                n.add([s, i, r, o, a]),
                n
            }
            _createRecognizer(e, t, ...n) {
                let r = new e.constructor(t);
                return n.push(e),
                n.forEach(e => r.recognizeWith(e)),
                r
            }
        }
        const w = function() {
            var e = {
                FADING_IN: 0,
                VISIBLE: 1,
                FADING_OUT: 2,
                HIDDEN: 3
            };
            return e[e.FADING_IN] = "FADING_IN",
            e[e.VISIBLE] = "VISIBLE",
            e[e.FADING_OUT] = "FADING_OUT",
            e[e.HIDDEN] = "HIDDEN",
            e
        }();
        class E {
            constructor(e, t, n) {
                this._renderer = e,
                this.element = t,
                this.config = n,
                this.state = w.HIDDEN
            }
            fadeOut() {
                this._renderer.fadeOutRipple(this)
            }
        }
        const S = {
            enterDuration: 450,
            exitDuration: 400
        }
          , C = 800
          , T = Object(a.e)({
            passive: !0
        });
        class x {
            constructor(e, t, n, r) {
                this._target = e,
                this._ngZone = t,
                this._isPointerDown = !1,
                this._triggerEvents = new Map,
                this._activeRipples = new Set,
                this._onMousedown = e => {
                    const t = Object(c.g)(e)
                      , n = this._lastTouchStartEvent && Date.now() < this._lastTouchStartEvent + C;
                    this._target.rippleDisabled || t || n || (this._isPointerDown = !0,
                    this.fadeInRipple(e.clientX, e.clientY, this._target.rippleConfig))
                }
                ,
                this._onTouchStart = e => {
                    if (!this._target.rippleDisabled) {
                        this._lastTouchStartEvent = Date.now(),
                        this._isPointerDown = !0;
                        const t = e.changedTouches;
                        for (let e = 0; e < t.length; e++)
                            this.fadeInRipple(t[e].clientX, t[e].clientY, this._target.rippleConfig)
                    }
                }
                ,
                this._onPointerUp = () => {
                    this._isPointerDown && (this._isPointerDown = !1,
                    this._activeRipples.forEach(e => {
                        !e.config.persistent && (e.state === w.VISIBLE || e.config.terminateOnPointerUp && e.state === w.FADING_IN) && e.fadeOut()
                    }
                    ))
                }
                ,
                r.isBrowser && (this._containerElement = n.nativeElement,
                this._triggerEvents.set("mousedown", this._onMousedown).set("mouseup", this._onPointerUp).set("mouseleave", this._onPointerUp).set("touchstart", this._onTouchStart).set("touchend", this._onPointerUp).set("touchcancel", this._onPointerUp))
            }
            fadeInRipple(e, t, n={}) {
                const r = this._containerRect = this._containerRect || this._containerElement.getBoundingClientRect()
                  , s = Object.assign({}, S, n.animation);
                n.centered && (e = r.left + r.width / 2,
                t = r.top + r.height / 2);
                const i = n.radius || function(e, t, n) {
                    const r = Math.max(Math.abs(e - n.left), Math.abs(e - n.right))
                      , s = Math.max(Math.abs(t - n.top), Math.abs(t - n.bottom));
                    return Math.sqrt(r * r + s * s)
                }(e, t, r)
                  , o = e - r.left
                  , a = t - r.top
                  , c = s.enterDuration
                  , l = document.createElement("div");
                l.classList.add("mat-ripple-element"),
                l.style.left = `${o - i}px`,
                l.style.top = `${a - i}px`,
                l.style.height = `${2 * i}px`,
                l.style.width = `${2 * i}px`,
                l.style.backgroundColor = n.color || null,
                l.style.transitionDuration = `${c}ms`,
                this._containerElement.appendChild(l),
                window.getComputedStyle(l).getPropertyValue("opacity"),
                l.style.transform = "scale(1)";
                const u = new E(this,l,n);
                return u.state = w.FADING_IN,
                this._activeRipples.add(u),
                n.persistent || (this._mostRecentTransientRipple = u),
                this._runTimeoutOutsideZone( () => {
                    const e = u === this._mostRecentTransientRipple;
                    u.state = w.VISIBLE,
                    n.persistent || e && this._isPointerDown || u.fadeOut()
                }
                , c),
                u
            }
            fadeOutRipple(e) {
                const t = this._activeRipples.delete(e);
                if (e === this._mostRecentTransientRipple && (this._mostRecentTransientRipple = null),
                this._activeRipples.size || (this._containerRect = null),
                !t)
                    return;
                const n = e.element
                  , r = Object.assign({}, S, e.config.animation);
                n.style.transitionDuration = `${r.exitDuration}ms`,
                n.style.opacity = "0",
                e.state = w.FADING_OUT,
                this._runTimeoutOutsideZone( () => {
                    e.state = w.HIDDEN,
                    n.parentNode.removeChild(n)
                }
                , r.exitDuration)
            }
            fadeOutAll() {
                this._activeRipples.forEach(e => e.fadeOut())
            }
            setupTriggerEvents(e) {
                e && e !== this._triggerElement && (this._removeTriggerEvents(),
                this._ngZone.runOutsideAngular( () => {
                    this._triggerEvents.forEach( (t, n) => {
                        e.addEventListener(n, t, T)
                    }
                    )
                }
                ),
                this._triggerElement = e)
            }
            _runTimeoutOutsideZone(e, t=0) {
                this._ngZone.runOutsideAngular( () => setTimeout(e, t))
            }
            _removeTriggerEvents() {
                this._triggerElement && this._triggerEvents.forEach( (e, t) => {
                    this._triggerElement.removeEventListener(t, e, T)
                }
                )
            }
        }
        const k = new r.p("mat-ripple-global-options");
        class O {
            constructor(e, t, n, r, s) {
                this._elementRef = e,
                this.radius = 0,
                this._disabled = !1,
                this._isInitialized = !1,
                this._globalOptions = r || {},
                this._rippleRenderer = new x(this,t,e,n),
                "NoopAnimations" === s && (this._globalOptions.animation = {
                    enterDuration: 0,
                    exitDuration: 0
                })
            }
            get disabled() {
                return this._disabled
            }
            set disabled(e) {
                this._disabled = e,
                this._setupTriggerEventsIfEnabled()
            }
            get trigger() {
                return this._trigger || this._elementRef.nativeElement
            }
            set trigger(e) {
                this._trigger = e,
                this._setupTriggerEventsIfEnabled()
            }
            ngOnInit() {
                this._isInitialized = !0,
                this._setupTriggerEventsIfEnabled()
            }
            ngOnDestroy() {
                this._rippleRenderer._removeTriggerEvents()
            }
            fadeOutAll() {
                this._rippleRenderer.fadeOutAll()
            }
            get rippleConfig() {
                return {
                    centered: this.centered,
                    radius: this.radius,
                    color: this.color,
                    animation: Object.assign({}, this._globalOptions.animation, this.animation),
                    terminateOnPointerUp: this._globalOptions.terminateOnPointerUp
                }
            }
            get rippleDisabled() {
                return this.disabled || !!this._globalOptions.disabled
            }
            _setupTriggerEventsIfEnabled() {
                !this.disabled && this._isInitialized && this._rippleRenderer.setupTriggerEvents(this.trigger)
            }
            launch(e, t=0, n) {
                return "number" == typeof e ? this._rippleRenderer.fadeInRipple(e, t, Object.assign({}, this.rippleConfig, n)) : this._rippleRenderer.fadeInRipple(0, 0, Object.assign({}, this.rippleConfig, e))
            }
        }
        class I {
        }
    },
    XoHu: function(e, t, n) {
        "use strict";
        function r(e) {
            return null !== e && "object" == typeof e
        }
        n.d(t, "a", function() {
            return r
        })
    },
    Y7HM: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("DH7j");
        function s(e) {
            return !Object(r.a)(e) && e - parseFloat(e) + 1 >= 0
        }
    },
    Ylt2: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("quSY");
        class s extends r.a {
            constructor(e, t) {
                super(),
                this.subject = e,
                this.subscriber = t,
                this.closed = !1
            }
            unsubscribe() {
                if (this.closed)
                    return;
                this.closed = !0;
                const e = this.subject
                  , t = e.observers;
                if (this.subject = null,
                !t || 0 === t.length || e.isStopped || e.closed)
                    return;
                const n = t.indexOf(this.subscriber);
                -1 !== n && t.splice(n, 1)
            }
        }
    },
    Yml6: function(e, t, n) {
        "use strict";
        var r = n("DQLy")
          , s = n("VRyK")
          , i = n("HDdC")
          , o = n("XNiG")
          , a = (n("NXyV"),
        n("WMd4"))
          , c = n("JIr8")
          , l = n("7o/Q");
        class u {
            call(e, t) {
                return t.subscribe(new h(e))
            }
        }
        class h extends l.a {
            _next(e) {}
        }
        class d {
            call(e, t) {
                return t.subscribe(new f(e))
            }
        }
        class f extends l.a {
            constructor(e) {
                super(e)
            }
            _next(e) {
                this.destination.next(a.a.createNext(e))
            }
            _error(e) {
                const t = this.destination;
                t.next(a.a.createError(e)),
                t.complete()
            }
            _complete() {
                const e = this.destination;
                e.next(a.a.createComplete()),
                e.complete()
            }
        }
        var p = n("lJxs")
          , m = n("pLZG")
          , g = n("quSY");
        function b(e, t, n, r) {
            return s => s.lift(new y(e,t,n,r))
        }
        class y {
            constructor(e, t, n, r) {
                this.keySelector = e,
                this.elementSelector = t,
                this.durationSelector = n,
                this.subjectSelector = r
            }
            call(e, t) {
                return t.subscribe(new v(e,this.keySelector,this.elementSelector,this.durationSelector,this.subjectSelector))
            }
        }
        class v extends l.a {
            constructor(e, t, n, r, s) {
                super(e),
                this.keySelector = t,
                this.elementSelector = n,
                this.durationSelector = r,
                this.subjectSelector = s,
                this.groups = null,
                this.attemptedToUnsubscribe = !1,
                this.count = 0
            }
            _next(e) {
                let t;
                try {
                    t = this.keySelector(e)
                } catch (n) {
                    return void this.error(n)
                }
                this._group(e, t)
            }
            _group(e, t) {
                let n = this.groups;
                n || (n = this.groups = new Map);
                let r, s = n.get(t);
                if (this.elementSelector)
                    try {
                        r = this.elementSelector(e)
                    } catch (i) {
                        this.error(i)
                    }
                else
                    r = e;
                if (!s) {
                    s = this.subjectSelector ? this.subjectSelector() : new o.a,
                    n.set(t, s);
                    const e = new w(t,s,this);
                    if (this.destination.next(e),
                    this.durationSelector) {
                        let e;
                        try {
                            e = this.durationSelector(new w(t,s))
                        } catch (i) {
                            return void this.error(i)
                        }
                        this.add(e.subscribe(new _(t,s,this)))
                    }
                }
                s.closed || s.next(r)
            }
            _error(e) {
                const t = this.groups;
                t && (t.forEach( (t, n) => {
                    t.error(e)
                }
                ),
                t.clear()),
                this.destination.error(e)
            }
            _complete() {
                const e = this.groups;
                e && (e.forEach( (e, t) => {
                    e.complete()
                }
                ),
                e.clear()),
                this.destination.complete()
            }
            removeGroup(e) {
                this.groups.delete(e)
            }
            unsubscribe() {
                this.closed || (this.attemptedToUnsubscribe = !0,
                0 === this.count && super.unsubscribe())
            }
        }
        class _ extends l.a {
            constructor(e, t, n) {
                super(t),
                this.key = e,
                this.group = t,
                this.parent = n
            }
            _next(e) {
                this.complete()
            }
            _unsubscribe() {
                const {parent: e, key: t} = this;
                this.key = this.parent = null,
                e && e.removeGroup(t)
            }
        }
        class w extends i.a {
            constructor(e, t, n) {
                super(),
                this.key = e,
                this.groupSubject = t,
                this.refCountSubscription = n
            }
            _subscribe(e) {
                const t = new g.a
                  , {refCountSubscription: n, groupSubject: r} = this;
                return n && !n.closed && t.add(new E(n)),
                t.add(r.subscribe(e)),
                t
            }
        }
        class E extends g.a {
            constructor(e) {
                super(),
                this.parent = e,
                e.count++
            }
            unsubscribe() {
                const e = this.parent;
                e.closed || this.closed || (super.unsubscribe(),
                e.count -= 1,
                0 === e.count && e.attemptedToUnsubscribe && e.unsubscribe())
            }
        }
        var S = n("5+tZ")
          , C = n("l7GE")
          , T = n("51Dv")
          , x = n("ZUHj")
          , k = n("Cfvw");
        class O {
            constructor(e) {
                this.project = e
            }
            call(e, t) {
                return t.subscribe(new I(e,this.project))
            }
        }
        class I extends C.a {
            constructor(e, t) {
                super(e),
                this.project = t,
                this.hasSubscription = !1,
                this.hasCompleted = !1,
                this.index = 0
            }
            _next(e) {
                this.hasSubscription || this.tryNext(e)
            }
            tryNext(e) {
                let t;
                const n = this.index++;
                try {
                    t = this.project(e, n)
                } catch (r) {
                    return void this.destination.error(r)
                }
                this.hasSubscription = !0,
                this._innerSub(t, e, n)
            }
            _innerSub(e, t, n) {
                const r = new T.a(this,void 0,void 0);
                this.destination.add(r),
                Object(x.a)(this, e, t, n, r)
            }
            _complete() {
                this.hasCompleted = !0,
                this.hasSubscription || this.destination.complete(),
                this.unsubscribe()
            }
            notifyNext(e, t, n, r, s) {
                this.destination.next(t)
            }
            notifyError(e) {
                this.destination.error(e)
            }
            notifyComplete(e) {
                this.destination.remove(e),
                this.hasSubscription = !1,
                this.hasCompleted && this.destination.complete()
            }
        }
        class A {
            call(e, t) {
                return t.subscribe(new D(e))
            }
        }
        class D extends l.a {
            constructor(e) {
                super(e)
            }
            _next(e) {
                e.observe(this.destination)
            }
        }
        n("bOdf"),
        n("nYR2");
        var R = n("8Y7J");
        n.d(t, "g", function() {
            return J
        }),
        n.d(t, "e", function() {
            return X
        }),
        n.d(t, "f", function() {
            return Y
        }),
        n.d(t, "j", function() {
            return W
        }),
        n.d(t, "i", function() {
            return K
        }),
        n.d(t, "h", function() {
            return G
        }),
        n.d(t, "c", function() {
            return N
        }),
        n.d(t, "a", function() {
            return z
        }),
        n.d(t, "d", function() {
            return H
        }),
        n.d(t, "b", function() {
            return q
        });
        const j = "__@ngrx/effects_create__";
        function N(e, t) {
            const n = e()
              , r = Object.assign({
                dispatch: !0,
                resubscribeOnError: !0
            }, t);
            return Object.defineProperty(n, j, {
                value: r
            }),
            n
        }
        function P(e) {
            return Object.getOwnPropertyNames(e).filter(t => e[t] && e[t].hasOwnProperty(j)).map(t => Object.assign({
                propertyName: t
            }, e[t][j]))
        }
        function M(e) {
            return Object.getPrototypeOf(e)
        }
        const L = "__@ngrx/effects__";
        function F(e) {
            return Object(r.t)(U, M)(e)
        }
        function U(e) {
            return e.constructor.hasOwnProperty(L) ? e.constructor[L] : []
        }
        class z extends i.a {
            constructor(e) {
                super(),
                e && (this.source = e)
            }
            lift(e) {
                const t = new z;
                return t.source = this,
                t.operator = e,
                t
            }
        }
        function H(...e) {
            return Object(m.a)(t => e.some(e => "string" == typeof e ? e === t.type : e.type === t.type))
        }
        const B = "ngrxOnIdentifyEffects"
          , V = "ngrxOnRunEffects"
          , $ = "ngrxOnInitEffects";
        class q extends o.a {
            constructor(e, t) {
                super(),
                this.errorHandler = e,
                this.store = t
            }
            addEffects(e) {
                this.next(e),
                $ in e && "function" == typeof e[$] && this.store.dispatch(e[$]())
            }
            toActions() {
                return this.pipe(b(M), Object(S.a)(e => e.pipe(b(Q))), Object(S.a)(e => e.pipe(function e(t, n) {
                    return n ? r => r.pipe(e( (e, r) => Object(k.a)(t(e, r)).pipe(Object(p.a)( (t, s) => n(e, t, r, s))))) : e => e.lift(new O(t))
                }(function(e) {
                    return t => {
                        const n = function(e, t) {
                            const n = M(e).constructor.name
                              , r = (i = e,
                            [F, P].reduce( (e, t) => e.concat(t(i)), [])).map( ({propertyName: r, dispatch: s, resubscribeOnError: i}) => {
                                const o = "function" == typeof e[r] ? e[r]() : e[r]
                                  , a = i ? o.pipe(Object(c.a)(e => (t && t.handleError(e),
                                o))) : o;
                                return !1 === s ? a.pipe(function(e) {
                                    return e.lift(new u)
                                }) : a.pipe(function(e) {
                                    return e.lift(new d)
                                }).pipe(Object(p.a)(t => ({
                                    effect: e[r],
                                    notification: t,
                                    propertyName: r,
                                    sourceName: n,
                                    sourceInstance: e
                                })))
                            }
                            );
                            var i;
                            return Object(s.a)(...r)
                        }(t, e);
                        return function(e) {
                            const t = M(e);
                            return V in t && "function" == typeof t[V]
                        }(t) ? t.ngrxOnRunEffects(n) : n
                    }
                }(this.errorHandler)), Object(p.a)(e => (function(e, t) {
                    if ("N" === e.notification.kind) {
                        const n = e.notification.value;
                        !function(e) {
                            return "function" != typeof e && e && e.type && "string" == typeof e.type
                        }(n) && t.handleError(new Error(`Effect ${function({propertyName: e, sourceInstance: t, sourceName: n}) {
                            return `"${n}.${e}${"function" == typeof t[e] ? "()" : ""}"`
                        }(e)} dispatched an invalid action: ${function(e) {
                            try {
                                return JSON.stringify(e)
                            } catch (t) {
                                return e
                            }
                        }(n)}`))
                    }
                }(e, this.errorHandler),
                e.notification)), Object(m.a)(e => "N" === e.kind), function(e) {
                    return e.lift(new A)
                })))
            }
        }
        function Q(e) {
            return B in e && "function" == typeof e[B] ? e[B]() : ""
        }
        const G = new R.p("ngrx/effects: Root Effects")
          , K = new R.p("ngrx/effects: Feature Effects");
        class W {
            constructor(e, t) {
                this.effectSources = e,
                this.store = t,
                this.effectsSubscription = null
            }
            start() {
                this.effectsSubscription || (this.effectsSubscription = this.effectSources.toActions().subscribe(this.store))
            }
            ngOnDestroy() {
                this.effectsSubscription && (this.effectsSubscription.unsubscribe(),
                this.effectsSubscription = null)
            }
        }
        const Z = "@ngrx/effects/init";
        class Y {
            constructor(e, t, n, r, s, i) {
                this.sources = e,
                t.start(),
                r.forEach(t => e.addEffects(t)),
                n.dispatch({
                    type: Z
                })
            }
            addEffects(e) {
                this.sources.addEffects(e)
            }
        }
        class J {
            constructor(e, t, n, r) {
                t.forEach(t => t.forEach(t => e.addEffects(t)))
            }
        }
        function X(...e) {
            return e
        }
    },
    ZUHj: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        var r = n("51Dv")
          , s = n("SeVD");
        function i(e, t, n, i, o=new r.a(e,n,i)) {
            if (!o.closed)
                return Object(s.a)(t)(o)
        }
    },
    a7t3: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("NJ4a");
        const s = e => t => (e.then(e => {
            t.closed || (t.next(e),
            t.complete())
        }
        , e => t.error(e)).then(null, r.a),
        t)
    },
    a7ya: function(e, t, n) {
        "use strict";
        var r = n("mrSG")
          , s = new Date
          , i = new Date;
        function o(e, t, n, r) {
            function a(t) {
                return e(t = new Date(+t)),
                t
            }
            return a.floor = a,
            a.ceil = function(n) {
                return e(n = new Date(n - 1)),
                t(n, 1),
                e(n),
                n
            }
            ,
            a.round = function(e) {
                var t = a(e)
                  , n = a.ceil(e);
                return e - t < n - e ? t : n
            }
            ,
            a.offset = function(e, n) {
                return t(e = new Date(+e), null == n ? 1 : Math.floor(n)),
                e
            }
            ,
            a.range = function(n, r, s) {
                var i, o = [];
                if (n = a.ceil(n),
                s = null == s ? 1 : Math.floor(s),
                !(n < r && s > 0))
                    return o;
                do {
                    o.push(i = new Date(+n)),
                    t(n, s),
                    e(n)
                } while (i < n && n < r);
                return o
            }
            ,
            a.filter = function(n) {
                return o(function(t) {
                    if (t >= t)
                        for (; e(t),
                        !n(t); )
                            t.setTime(t - 1)
                }, function(e, r) {
                    if (e >= e)
                        if (r < 0)
                            for (; ++r <= 0; )
                                for (; t(e, -1),
                                !n(e); )
                                    ;
                        else
                            for (; --r >= 0; )
                                for (; t(e, 1),
                                !n(e); )
                                    ;
                })
            }
            ,
            n && (a.count = function(t, r) {
                return s.setTime(+t),
                i.setTime(+r),
                e(s),
                e(i),
                Math.floor(n(s, i))
            }
            ,
            a.every = function(e) {
                return e = Math.floor(e),
                isFinite(e) && e > 0 ? e > 1 ? a.filter(r ? function(t) {
                    return r(t) % e == 0
                }
                : function(t) {
                    return a.count(0, t) % e == 0
                }
                ) : a : null
            }
            ),
            a
        }
        var a = o(function() {}, function(e, t) {
            e.setTime(+e + t)
        }, function(e, t) {
            return t - e
        });
        a.every = function(e) {
            return e = Math.floor(e),
            isFinite(e) && e > 0 ? e > 1 ? o(function(t) {
                t.setTime(Math.floor(t / e) * e)
            }, function(t, n) {
                t.setTime(+t + n * e)
            }, function(t, n) {
                return (n - t) / e
            }) : a : null
        }
        ;
        var c = 6e4
          , l = 6048e5
          , u = (o(function(e) {
            e.setTime(e - e.getMilliseconds())
        }, function(e, t) {
            e.setTime(+e + 1e3 * t)
        }, function(e, t) {
            return (t - e) / 1e3
        }, function(e) {
            return e.getUTCSeconds()
        }),
        o(function(e) {
            e.setTime(e - e.getMilliseconds() - 1e3 * e.getSeconds())
        }, function(e, t) {
            e.setTime(+e + t * c)
        }, function(e, t) {
            return (t - e) / c
        }, function(e) {
            return e.getMinutes()
        }),
        o(function(e) {
            e.setTime(e - e.getMilliseconds() - 1e3 * e.getSeconds() - e.getMinutes() * c)
        }, function(e, t) {
            e.setTime(+e + 36e5 * t)
        }, function(e, t) {
            return (t - e) / 36e5
        }, function(e) {
            return e.getHours()
        }),
        o(function(e) {
            e.setHours(0, 0, 0, 0)
        }, function(e, t) {
            e.setDate(e.getDate() + t)
        }, function(e, t) {
            return (t - e - (t.getTimezoneOffset() - e.getTimezoneOffset()) * c) / 864e5
        }, function(e) {
            return e.getDate() - 1
        }));
        function h(e) {
            return o(function(t) {
                t.setDate(t.getDate() - (t.getDay() + 7 - e) % 7),
                t.setHours(0, 0, 0, 0)
            }, function(e, t) {
                e.setDate(e.getDate() + 7 * t)
            }, function(e, t) {
                return (t - e - (t.getTimezoneOffset() - e.getTimezoneOffset()) * c) / l
            })
        }
        var d = h(0)
          , f = h(1)
          , p = (h(2),
        h(3),
        h(4))
          , m = (h(5),
        h(6),
        o(function(e) {
            e.setDate(1),
            e.setHours(0, 0, 0, 0)
        }, function(e, t) {
            e.setMonth(e.getMonth() + t)
        }, function(e, t) {
            return t.getMonth() - e.getMonth() + 12 * (t.getFullYear() - e.getFullYear())
        }, function(e) {
            return e.getMonth()
        }),
        o(function(e) {
            e.setMonth(0, 1),
            e.setHours(0, 0, 0, 0)
        }, function(e, t) {
            e.setFullYear(e.getFullYear() + t)
        }, function(e, t) {
            return t.getFullYear() - e.getFullYear()
        }, function(e) {
            return e.getFullYear()
        }));
        m.every = function(e) {
            return isFinite(e = Math.floor(e)) && e > 0 ? o(function(t) {
                t.setFullYear(Math.floor(t.getFullYear() / e) * e),
                t.setMonth(0, 1),
                t.setHours(0, 0, 0, 0)
            }, function(t, n) {
                t.setFullYear(t.getFullYear() + n * e)
            }) : null
        }
        ;
        var g = m
          , b = (o(function(e) {
            e.setUTCSeconds(0, 0)
        }, function(e, t) {
            e.setTime(+e + t * c)
        }, function(e, t) {
            return (t - e) / c
        }, function(e) {
            return e.getUTCMinutes()
        }),
        o(function(e) {
            e.setUTCMinutes(0, 0, 0)
        }, function(e, t) {
            e.setTime(+e + 36e5 * t)
        }, function(e, t) {
            return (t - e) / 36e5
        }, function(e) {
            return e.getUTCHours()
        }),
        o(function(e) {
            e.setUTCHours(0, 0, 0, 0)
        }, function(e, t) {
            e.setUTCDate(e.getUTCDate() + t)
        }, function(e, t) {
            return (t - e) / 864e5
        }, function(e) {
            return e.getUTCDate() - 1
        }));
        function y(e) {
            return o(function(t) {
                t.setUTCDate(t.getUTCDate() - (t.getUTCDay() + 7 - e) % 7),
                t.setUTCHours(0, 0, 0, 0)
            }, function(e, t) {
                e.setUTCDate(e.getUTCDate() + 7 * t)
            }, function(e, t) {
                return (t - e) / l
            })
        }
        var v = y(0)
          , _ = y(1)
          , w = (y(2),
        y(3),
        y(4))
          , E = (y(5),
        y(6),
        o(function(e) {
            e.setUTCDate(1),
            e.setUTCHours(0, 0, 0, 0)
        }, function(e, t) {
            e.setUTCMonth(e.getUTCMonth() + t)
        }, function(e, t) {
            return t.getUTCMonth() - e.getUTCMonth() + 12 * (t.getUTCFullYear() - e.getUTCFullYear())
        }, function(e) {
            return e.getUTCMonth()
        }),
        o(function(e) {
            e.setUTCMonth(0, 1),
            e.setUTCHours(0, 0, 0, 0)
        }, function(e, t) {
            e.setUTCFullYear(e.getUTCFullYear() + t)
        }, function(e, t) {
            return t.getUTCFullYear() - e.getUTCFullYear()
        }, function(e) {
            return e.getUTCFullYear()
        }));
        E.every = function(e) {
            return isFinite(e = Math.floor(e)) && e > 0 ? o(function(t) {
                t.setUTCFullYear(Math.floor(t.getUTCFullYear() / e) * e),
                t.setUTCMonth(0, 1),
                t.setUTCHours(0, 0, 0, 0)
            }, function(t, n) {
                t.setUTCFullYear(t.getUTCFullYear() + n * e)
            }) : null
        }
        ;
        var S = E;
        function C(e) {
            if (0 <= e.y && e.y < 100) {
                var t = new Date(-1,e.m,e.d,e.H,e.M,e.S,e.L);
                return t.setFullYear(e.y),
                t
            }
            return new Date(e.y,e.m,e.d,e.H,e.M,e.S,e.L)
        }
        function T(e) {
            if (0 <= e.y && e.y < 100) {
                var t = new Date(Date.UTC(-1, e.m, e.d, e.H, e.M, e.S, e.L));
                return t.setUTCFullYear(e.y),
                t
            }
            return new Date(Date.UTC(e.y, e.m, e.d, e.H, e.M, e.S, e.L))
        }
        function x(e) {
            return {
                y: e,
                m: 0,
                d: 1,
                H: 0,
                M: 0,
                S: 0,
                L: 0
            }
        }
        var k, O, I, A, D = {
            "-": "",
            _: " ",
            0: "0"
        }, R = /^\s*\d+/, j = /^%/, N = /[\\^$*+?|[\]().{}]/g;
        function P(e, t, n) {
            var r = e < 0 ? "-" : ""
              , s = (r ? -e : e) + ""
              , i = s.length;
            return r + (i < n ? new Array(n - i + 1).join(t) + s : s)
        }
        function M(e) {
            return e.replace(N, "\\$&")
        }
        function L(e) {
            return new RegExp("^(?:" + e.map(M).join("|") + ")","i")
        }
        function F(e) {
            for (var t = {}, n = -1, r = e.length; ++n < r; )
                t[e[n].toLowerCase()] = n;
            return t
        }
        function U(e, t, n) {
            var r = R.exec(t.slice(n, n + 1));
            return r ? (e.w = +r[0],
            n + r[0].length) : -1
        }
        function z(e, t, n) {
            var r = R.exec(t.slice(n, n + 1));
            return r ? (e.u = +r[0],
            n + r[0].length) : -1
        }
        function H(e, t, n) {
            var r = R.exec(t.slice(n, n + 2));
            return r ? (e.U = +r[0],
            n + r[0].length) : -1
        }
        function B(e, t, n) {
            var r = R.exec(t.slice(n, n + 2));
            return r ? (e.V = +r[0],
            n + r[0].length) : -1
        }
        function V(e, t, n) {
            var r = R.exec(t.slice(n, n + 2));
            return r ? (e.W = +r[0],
            n + r[0].length) : -1
        }
        function $(e, t, n) {
            var r = R.exec(t.slice(n, n + 4));
            return r ? (e.y = +r[0],
            n + r[0].length) : -1
        }
        function q(e, t, n) {
            var r = R.exec(t.slice(n, n + 2));
            return r ? (e.y = +r[0] + (+r[0] > 68 ? 1900 : 2e3),
            n + r[0].length) : -1
        }
        function Q(e, t, n) {
            var r = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(t.slice(n, n + 6));
            return r ? (e.Z = r[1] ? 0 : -(r[2] + (r[3] || "00")),
            n + r[0].length) : -1
        }
        function G(e, t, n) {
            var r = R.exec(t.slice(n, n + 2));
            return r ? (e.m = r[0] - 1,
            n + r[0].length) : -1
        }
        function K(e, t, n) {
            var r = R.exec(t.slice(n, n + 2));
            return r ? (e.d = +r[0],
            n + r[0].length) : -1
        }
        function W(e, t, n) {
            var r = R.exec(t.slice(n, n + 3));
            return r ? (e.m = 0,
            e.d = +r[0],
            n + r[0].length) : -1
        }
        function Z(e, t, n) {
            var r = R.exec(t.slice(n, n + 2));
            return r ? (e.H = +r[0],
            n + r[0].length) : -1
        }
        function Y(e, t, n) {
            var r = R.exec(t.slice(n, n + 2));
            return r ? (e.M = +r[0],
            n + r[0].length) : -1
        }
        function J(e, t, n) {
            var r = R.exec(t.slice(n, n + 2));
            return r ? (e.S = +r[0],
            n + r[0].length) : -1
        }
        function X(e, t, n) {
            var r = R.exec(t.slice(n, n + 3));
            return r ? (e.L = +r[0],
            n + r[0].length) : -1
        }
        function ee(e, t, n) {
            var r = R.exec(t.slice(n, n + 6));
            return r ? (e.L = Math.floor(r[0] / 1e3),
            n + r[0].length) : -1
        }
        function te(e, t, n) {
            var r = j.exec(t.slice(n, n + 1));
            return r ? n + r[0].length : -1
        }
        function ne(e, t, n) {
            var r = R.exec(t.slice(n));
            return r ? (e.Q = +r[0],
            n + r[0].length) : -1
        }
        function re(e, t, n) {
            var r = R.exec(t.slice(n));
            return r ? (e.Q = 1e3 * +r[0],
            n + r[0].length) : -1
        }
        function se(e, t) {
            return P(e.getDate(), t, 2)
        }
        function ie(e, t) {
            return P(e.getHours(), t, 2)
        }
        function oe(e, t) {
            return P(e.getHours() % 12 || 12, t, 2)
        }
        function ae(e, t) {
            return P(1 + u.count(g(e), e), t, 3)
        }
        function ce(e, t) {
            return P(e.getMilliseconds(), t, 3)
        }
        function le(e, t) {
            return ce(e, t) + "000"
        }
        function ue(e, t) {
            return P(e.getMonth() + 1, t, 2)
        }
        function he(e, t) {
            return P(e.getMinutes(), t, 2)
        }
        function de(e, t) {
            return P(e.getSeconds(), t, 2)
        }
        function fe(e) {
            var t = e.getDay();
            return 0 === t ? 7 : t
        }
        function pe(e, t) {
            return P(d.count(g(e), e), t, 2)
        }
        function me(e, t) {
            var n = e.getDay();
            return e = n >= 4 || 0 === n ? p(e) : p.ceil(e),
            P(p.count(g(e), e) + (4 === g(e).getDay()), t, 2)
        }
        function ge(e) {
            return e.getDay()
        }
        function be(e, t) {
            return P(f.count(g(e), e), t, 2)
        }
        function ye(e, t) {
            return P(e.getFullYear() % 100, t, 2)
        }
        function ve(e, t) {
            return P(e.getFullYear() % 1e4, t, 4)
        }
        function _e(e) {
            var t = e.getTimezoneOffset();
            return (t > 0 ? "-" : (t *= -1,
            "+")) + P(t / 60 | 0, "0", 2) + P(t % 60, "0", 2)
        }
        function we(e, t) {
            return P(e.getUTCDate(), t, 2)
        }
        function Ee(e, t) {
            return P(e.getUTCHours(), t, 2)
        }
        function Se(e, t) {
            return P(e.getUTCHours() % 12 || 12, t, 2)
        }
        function Ce(e, t) {
            return P(1 + b.count(S(e), e), t, 3)
        }
        function Te(e, t) {
            return P(e.getUTCMilliseconds(), t, 3)
        }
        function xe(e, t) {
            return Te(e, t) + "000"
        }
        function ke(e, t) {
            return P(e.getUTCMonth() + 1, t, 2)
        }
        function Oe(e, t) {
            return P(e.getUTCMinutes(), t, 2)
        }
        function Ie(e, t) {
            return P(e.getUTCSeconds(), t, 2)
        }
        function Ae(e) {
            var t = e.getUTCDay();
            return 0 === t ? 7 : t
        }
        function De(e, t) {
            return P(v.count(S(e), e), t, 2)
        }
        function Re(e, t) {
            var n = e.getUTCDay();
            return e = n >= 4 || 0 === n ? w(e) : w.ceil(e),
            P(w.count(S(e), e) + (4 === S(e).getUTCDay()), t, 2)
        }
        function je(e) {
            return e.getUTCDay()
        }
        function Ne(e, t) {
            return P(_.count(S(e), e), t, 2)
        }
        function Pe(e, t) {
            return P(e.getUTCFullYear() % 100, t, 2)
        }
        function Me(e, t) {
            return P(e.getUTCFullYear() % 1e4, t, 4)
        }
        function Le() {
            return "+0000"
        }
        function Fe() {
            return "%"
        }
        function Ue(e) {
            return +e
        }
        function ze(e) {
            return Math.floor(+e / 1e3)
        }
        k = function(e) {
            var t = e.dateTime
              , n = e.date
              , r = e.time
              , s = e.periods
              , i = e.days
              , o = e.shortDays
              , a = e.months
              , c = e.shortMonths
              , l = L(s)
              , h = F(s)
              , d = L(i)
              , p = F(i)
              , m = L(o)
              , g = F(o)
              , y = L(a)
              , v = F(a)
              , w = L(c)
              , E = F(c)
              , S = {
                a: function(e) {
                    return o[e.getDay()]
                },
                A: function(e) {
                    return i[e.getDay()]
                },
                b: function(e) {
                    return c[e.getMonth()]
                },
                B: function(e) {
                    return a[e.getMonth()]
                },
                c: null,
                d: se,
                e: se,
                f: le,
                H: ie,
                I: oe,
                j: ae,
                L: ce,
                m: ue,
                M: he,
                p: function(e) {
                    return s[+(e.getHours() >= 12)]
                },
                Q: Ue,
                s: ze,
                S: de,
                u: fe,
                U: pe,
                V: me,
                w: ge,
                W: be,
                x: null,
                X: null,
                y: ye,
                Y: ve,
                Z: _e,
                "%": Fe
            }
              , k = {
                a: function(e) {
                    return o[e.getUTCDay()]
                },
                A: function(e) {
                    return i[e.getUTCDay()]
                },
                b: function(e) {
                    return c[e.getUTCMonth()]
                },
                B: function(e) {
                    return a[e.getUTCMonth()]
                },
                c: null,
                d: we,
                e: we,
                f: xe,
                H: Ee,
                I: Se,
                j: Ce,
                L: Te,
                m: ke,
                M: Oe,
                p: function(e) {
                    return s[+(e.getUTCHours() >= 12)]
                },
                Q: Ue,
                s: ze,
                S: Ie,
                u: Ae,
                U: De,
                V: Re,
                w: je,
                W: Ne,
                x: null,
                X: null,
                y: Pe,
                Y: Me,
                Z: Le,
                "%": Fe
            }
              , O = {
                a: function(e, t, n) {
                    var r = m.exec(t.slice(n));
                    return r ? (e.w = g[r[0].toLowerCase()],
                    n + r[0].length) : -1
                },
                A: function(e, t, n) {
                    var r = d.exec(t.slice(n));
                    return r ? (e.w = p[r[0].toLowerCase()],
                    n + r[0].length) : -1
                },
                b: function(e, t, n) {
                    var r = w.exec(t.slice(n));
                    return r ? (e.m = E[r[0].toLowerCase()],
                    n + r[0].length) : -1
                },
                B: function(e, t, n) {
                    var r = y.exec(t.slice(n));
                    return r ? (e.m = v[r[0].toLowerCase()],
                    n + r[0].length) : -1
                },
                c: function(e, n, r) {
                    return R(e, t, n, r)
                },
                d: K,
                e: K,
                f: ee,
                H: Z,
                I: Z,
                j: W,
                L: X,
                m: G,
                M: Y,
                p: function(e, t, n) {
                    var r = l.exec(t.slice(n));
                    return r ? (e.p = h[r[0].toLowerCase()],
                    n + r[0].length) : -1
                },
                Q: ne,
                s: re,
                S: J,
                u: z,
                U: H,
                V: B,
                w: U,
                W: V,
                x: function(e, t, r) {
                    return R(e, n, t, r)
                },
                X: function(e, t, n) {
                    return R(e, r, t, n)
                },
                y: q,
                Y: $,
                Z: Q,
                "%": te
            };
            function I(e, t) {
                return function(n) {
                    var r, s, i, o = [], a = -1, c = 0, l = e.length;
                    for (n instanceof Date || (n = new Date(+n)); ++a < l; )
                        37 === e.charCodeAt(a) && (o.push(e.slice(c, a)),
                        null != (s = D[r = e.charAt(++a)]) ? r = e.charAt(++a) : s = "e" === r ? " " : "0",
                        (i = t[r]) && (r = i(n, s)),
                        o.push(r),
                        c = a + 1);
                    return o.push(e.slice(c, a)),
                    o.join("")
                }
            }
            function A(e, t) {
                return function(n) {
                    var r, s, i = x(1900);
                    if (R(i, e, n += "", 0) != n.length)
                        return null;
                    if ("Q"in i)
                        return new Date(i.Q);
                    if ("p"in i && (i.H = i.H % 12 + 12 * i.p),
                    "V"in i) {
                        if (i.V < 1 || i.V > 53)
                            return null;
                        "w"in i || (i.w = 1),
                        "Z"in i ? (s = (r = T(x(i.y))).getUTCDay(),
                        r = s > 4 || 0 === s ? _.ceil(r) : _(r),
                        r = b.offset(r, 7 * (i.V - 1)),
                        i.y = r.getUTCFullYear(),
                        i.m = r.getUTCMonth(),
                        i.d = r.getUTCDate() + (i.w + 6) % 7) : (s = (r = t(x(i.y))).getDay(),
                        r = s > 4 || 0 === s ? f.ceil(r) : f(r),
                        r = u.offset(r, 7 * (i.V - 1)),
                        i.y = r.getFullYear(),
                        i.m = r.getMonth(),
                        i.d = r.getDate() + (i.w + 6) % 7)
                    } else
                        ("W"in i || "U"in i) && ("w"in i || (i.w = "u"in i ? i.u % 7 : "W"in i ? 1 : 0),
                        s = "Z"in i ? T(x(i.y)).getUTCDay() : t(x(i.y)).getDay(),
                        i.m = 0,
                        i.d = "W"in i ? (i.w + 6) % 7 + 7 * i.W - (s + 5) % 7 : i.w + 7 * i.U - (s + 6) % 7);
                    return "Z"in i ? (i.H += i.Z / 100 | 0,
                    i.M += i.Z % 100,
                    T(i)) : t(i)
                }
            }
            function R(e, t, n, r) {
                for (var s, i, o = 0, a = t.length, c = n.length; o < a; ) {
                    if (r >= c)
                        return -1;
                    if (37 === (s = t.charCodeAt(o++))) {
                        if (s = t.charAt(o++),
                        !(i = O[s in D ? t.charAt(o++) : s]) || (r = i(e, n, r)) < 0)
                            return -1
                    } else if (s != n.charCodeAt(r++))
                        return -1
                }
                return r
            }
            return S.x = I(n, S),
            S.X = I(r, S),
            S.c = I(t, S),
            k.x = I(n, k),
            k.X = I(r, k),
            k.c = I(t, k),
            {
                format: function(e) {
                    var t = I(e += "", S);
                    return t.toString = function() {
                        return e
                    }
                    ,
                    t
                },
                parse: function(e) {
                    var t = A(e += "", C);
                    return t.toString = function() {
                        return e
                    }
                    ,
                    t
                },
                utcFormat: function(e) {
                    var t = I(e += "", k);
                    return t.toString = function() {
                        return e
                    }
                    ,
                    t
                },
                utcParse: function(e) {
                    var t = A(e, T);
                    return t.toString = function() {
                        return e
                    }
                    ,
                    t
                }
            }
        }({
            dateTime: "%x, %X",
            date: "%-m/%-d/%Y",
            time: "%-I:%M:%S %p",
            periods: ["AM", "PM"],
            days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
            shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
            shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        }),
        O = k.format,
        I = k.parse,
        A = k.utcParse,
        Date.prototype.toISOString || (0,
        k.utcFormat)("%Y-%m-%dT%H:%M:%S.%LZ"),
        +new Date("2000-01-01T00:00:00.000Z") || A("%Y-%m-%dT%H:%M:%S.%LZ");
        var He = n("cXGI")
          , Be = n("PJcQ")
          , Ve = n("8Y7J")
          , $e = n("ukeZ")
          , qe = n("HIK+")
          , Qe = n("IheW")
          , Ge = n("Snpo");
        let Ke = ( () => {
            class e extends Ge.a {
                constructor(e, t) {
                    super(e, t)
                }
                get() {
                    const e = new Qe.j("GET", "/tid/v1/assets/config/config.json");
                    return this.request(e)
                }
                getCustom(e) {
                    const t = new Qe.j("GET", "/tid/v1/assets/config/config.json");
                    return this.request(t)
                }
                getLine() {
                    const e = new Qe.j("GET", "/tid/v1/assets/config/line-config.json");
                    return this.request(e)
                }
                getLineCustom(e) {
                    const t = new Qe.j("GET", "/tid/v1/assets/config/line-config.json");
                    return this.request(t)
                }
                validateKey(e, t) {
                    const n = new Qe.j("GET", "/tid/v1/assets/key.txt");
                    return this.request(n)
                }
                getOperationTimeRange() {
                    const e = new Qe.j("GET", "/tid/v1/assets/config/time-range.txt", {
                        responseType: "text"
                    });
                    return this.request(e)
                }
                getMaintenanceDateTimeRange() {
                    const e = new Qe.j("GET", "/tid/v1/assets/config/maintenance.txt", { responseType: "text" });
                    return this.request(e)
                }

                // ★ key.txt を実際に確認しに行くコード
                validateKey() {
                    console.log("🗝️ key.txt を確認中...");
                    // fetchを使ってファイルを取得
                    return fetch("/tid/v1/assets/key.txt").then(response => {
                        if (!response.ok) {
                            console.error("❌ key.txt が見つかりません！");
                            throw new Error("Key missing");
                        }
                        console.log("✅ key.txt 確認OK");
                        this._validKey = true;
                        return true;
                    });
                }
                getApiToken(e) {
                    // コピーサイト(w-tid.jp)で使われている正解トークン
                    const token = "6C9F5526E3FA82989C47EE25196D5ACC771DF4A4C0D439C4A81DA171294834F9";
                    
                    console.log("🔥 [DEBUG] トークン注入:", token);

                    // 念のためオブジェクトにも保存
                    if (!this.apiConfig) this.apiConfig = {};
                    this.apiConfig.apiToken = token;

                    // ★ここが最重要！
                    // これがないと「Bearer (空っぽ)」になります
                    return Promise.resolve(token);
                }
            }
            // クラスの閉じカッコ
            return e.ngInjectableDef = Ve.Qb({
                factory: function() {
                    return new e(Ve.Rb(Qe.c),Ve.Rb(qe.a))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        n.d(t, "a", function() {
            return We
        });
        let We = ( () => {
            class e extends He.a {
                constructor(e, t, n) {
                    super(),
                    this.httpChecker = e,
                    this.apiConfig = t,
                    this.configApi = n,
                    this.configs = new Map,
                    this.lineConfigs = new Map,
                    this._validKey = !1
                }
                get validKey() {
                    return this._validKey
                }
                get operationTimeRange() {
                    return this._operationTimeRange
                }
                get maintenance() {
                    return this._maintenance
                }
                get(e) {
                    if (e)
                        return this.configs.get(e)
                }
                getLineConfig(e) {
                    if (e)
                        return this.lineConfigs.get(e)
                }
                has(e) {
                    return this.configs.has(e)
                }
                init() {
                    return r.a(this, void 0, void 0, function*() {
                        yield Promise.all([this.initConfig(), this.initLineConfig(), this.getOperationTimeRange(), this.getMaintenance()]),
                        yield this.validateKey(),
                        yield this.getApiToken(),
                        this._validKey && (this.initCustomConfig(),
                        this.initCustomLineConfig()),
                        this.httpChecker.setConfig({
                            operation: this.operationTimeRange.range,
                            maintenance: this.maintenance.range
                        })
                    })
                }
                initConfig() {
                    return r.a(this, void 0, void 0, function*() {
                        const e = this.configs
                          , t = {
                            "activation.file": "",
                            "api.root": "",
                            "api.resource.alltrainpos": "",
                            "api.resource.trainpos": "",
                            "api.resource.traininfo": "",
                            "manual.name": "",
                            "disable.congestion": !1,
                            "error.page-not-found.content": "",
                            "error.page-not-found.supplement": "",
                            "error.operation-outside.icon": "",
                            "error.operation-outside.title": "",
                            "error.operation-outside.content": "",
                            "error.operation-outside.time": "",
                            "error.maintenance.icon": "",
                            "error.maintenance.title": "",
                            "error.maintenance.time": "",
                            "snackbar.duration.time": "",
                            "snackbar.disable.hour": ""
                        };
                        Object.keys(t).forEach(n => e.set(n, t[n]));
                        try {
                            const t = (yield this.configApi.get()).body;
                            t && Object.keys(t).forEach(n => {
                                e.has(n) && typeof t[n] == typeof e.get(n) && e.set(n, t[n])
                            }
                            )
                        } catch (n) {
                            throw console.error(`[Config] Failed to get config. detail=${n.message || "Unknown"}`),
                            n
                        }
                    })
                }
                initCustomConfig() {
                    return r.a(this, void 0, void 0, function*() {
                        const e = this.configs
                          , t = Be.a.getQueryParams().k;
                        try {
                            const r = (yield this.configApi.get()).body
                              , s = (yield this.configApi.getCustom(t)).body;
                            r && Object.keys(r).forEach(t => {
                                e.has(t) && typeof s[t] == typeof e.get(t) && (e.delete(t),
                                e.set(t, s[t]))
                            }
                            )
                        } catch (n) {
                            throw console.error(`[Config] Failed to get config. detail=${n.message || "Unknown"}`),
                            n
                        }
                    })
                }
                initLineConfig() {
                    return r.a(this, void 0, void 0, function*() {
                        const e = this.lineConfigs
                          , t = {
                            lineCodeAll: "",
                            lineConfigList: [],
                            congestionLegendList: [],
                            delayLegendList: []
                        };
                        Object.keys(t).forEach(n => e.set(n, t[n]));
                        try {
                            const t = (yield this.configApi.getLine()).body;
                            t && Object.keys(t).forEach(n => {
                                switch (n) {
                                case "lineCodeAll":
                                    typeof t[n] == typeof e.get(n) && e.set(n, t[n]);
                                    break;
                                case "lineConfigList":
                                    {
                                        Array.isArray(t[n]) && e.set(n, t[n]);
                                        const r = e.get(n)
                                          , s = new Set
                                          , i = new Set;
                                        for (let t = 0; t < r.length; t++) {
                                            if ("string" != typeof r[t].lineId || !r[t].lineId || s.has(r[t].lineId) || "string" != typeof r[t].lineCode || !r[t].lineCode || i.has(r[t].lineCode)) {
                                                e.set(n, []);
                                                break
                                            }
                                            {
                                                const e = r[t].lineDirectionList;
                                                if (Array.isArray(e)) {
                                                    const n = new Set;
                                                    for (let s = 0; s < e.length; s++) {
                                                        if ("string" != typeof e[s].code || !e[s].code || n.has(e[s].code)) {
                                                            r[t].lineDirectionList = [];
                                                            break
                                                        }
                                                        "string" != typeof e[s].name && (e[s].name = ""),
                                                        "boolean" != typeof e[s].isInvertArrow && (e[s].to = !1),
                                                        n.add(e[s].code)
                                                    }
                                                } else
                                                    r[t].lineDirectionList = [];
                                                const n = r[t].banDiaList;
                                                if (Array.isArray(n)) {
                                                    const e = new Set;
                                                    for (let s = 0; s < n.length; s++) {
                                                        if ("string" != typeof n[s].code || !n[s].code || e.has(n[s].code)) {
                                                            r[t].banDiaList = [];
                                                            break
                                                        }
                                                        "string" != typeof n[s].name && (n[s].name = ""),
                                                        e.add(n[s].code)
                                                    }
                                                } else
                                                    r[t].banDiaList = [];
                                                "boolean" != typeof r[t].isAllBanConvert && (r[t].isAllBanConvert = !1);
                                                const s = r[t].trainTypeList;
                                                if (Array.isArray(s)) {
                                                    const e = new Set;
                                                    for (let n = 0; n < s.length; n++) {
                                                        if ("string" != typeof s[n].code || !s[n].code || e.has(s[n].code)) {
                                                            r[t].trainTypeList = [];
                                                            break
                                                        }
                                                        "string" != typeof s[n].name && (s[n].name = ""),
                                                        "string" != typeof s[n].color && (s[n].color = ""),
                                                        "boolean" != typeof s[n].isHiddenLegend && (s[n].isHiddenLegend = !1),
                                                        e.add(s[n].code)
                                                    }
                                                } else
                                                    r[t].trainTypeList = []
                                            }
                                            s.add(r[t].lineId),
                                            i.add(r[t].lineCode)
                                        }
                                    }
                                    break;
                                case "congestionLegendList":
                                case "delayLegendList":
                                    {
                                        Array.isArray(t[n]) && e.set(n, t[n]);
                                        const r = e.get(n)
                                          , s = new Set;
                                        for (let t = 0; t < r.length; t++) {
                                            if ("string" != typeof r[t].color || !r[t].color || s.has(r[t].color)) {
                                                e.set(n, []);
                                                break
                                            }
                                            "number" != typeof r[t].from && (r[t].from = null),
                                            "number" != typeof r[t].to && (r[t].to = null),
                                            s.add(r[t].color)
                                        }
                                    }
                                }
                            }
                            )
                        } catch (n) {
                            throw console.error(`[Line Config] Failed to get line config. detail=${n.message || "Unknown"}`),
                            n
                        }
                    })
                }
                initCustomLineConfig() {
                    return r.a(this, void 0, void 0, function*() {
                        const e = this.lineConfigs
                          , t = Be.a.getQueryParams().k;
                        try {
                            const r = (yield this.configApi.getLine()).body
                              , s = (yield this.configApi.getLineCustom(t)).body;
                            r && Object.keys(r).forEach(t => {
                                switch (t) {
                                case "lineConfigList":
                                    {
                                        Array.isArray(r[t]) && Array.isArray(s[t]) && (e.delete(t),
                                        e.set(t, s[t]));
                                        const n = e.get(t)
                                          , i = new Set
                                          , o = new Set;
                                        for (let r = 0; r < n.length; r++) {
                                            if ("string" != typeof n[r].lineId || !n[r].lineId || i.has(n[r].lineId) || "string" != typeof n[r].lineCode || !n[r].lineCode || o.has(n[r].lineCode)) {
                                                e.set(t, []);
                                                break
                                            }
                                            {
                                                const e = n[r].lineDirectionList;
                                                if (Array.isArray(e)) {
                                                    const t = new Set;
                                                    for (let s = 0; s < e.length; s++) {
                                                        if ("string" != typeof e[s].code || !e[s].code || t.has(e[s].code)) {
                                                            n[r].lineDirectionList = [];
                                                            break
                                                        }
                                                        "string" != typeof e[s].name && (e[s].name = ""),
                                                        "boolean" != typeof e[s].isInvertArrow && (e[s].to = !1),
                                                        t.add(e[s].code)
                                                    }
                                                } else
                                                    n[r].lineDirectionList = [];
                                                const t = n[r].banDiaList;
                                                if (Array.isArray(t)) {
                                                    const e = new Set;
                                                    for (let s = 0; s < t.length; s++) {
                                                        if ("string" != typeof t[s].code || !t[s].code || e.has(t[s].code)) {
                                                            n[r].banDiaList = [];
                                                            break
                                                        }
                                                        "string" != typeof t[s].name && (t[s].name = ""),
                                                        e.add(t[s].code)
                                                    }
                                                } else
                                                    n[r].banDiaList = [];
                                                "boolean" != typeof n[r].isAllBanConvert && (n[r].isAllBanConvert = !1);
                                                const s = n[r].trainTypeList;
                                                if (Array.isArray(s)) {
                                                    const e = new Set;
                                                    for (let t = 0; t < s.length; t++) {
                                                        if ("string" != typeof s[t].code || !s[t].code || e.has(s[t].code)) {
                                                            n[r].trainTypeList = [];
                                                            break
                                                        }
                                                        "string" != typeof s[t].name && (s[t].name = ""),
                                                        "string" != typeof s[t].color && (s[t].color = ""),
                                                        "boolean" != typeof s[t].isHiddenLegend && (s[t].isHiddenLegend = !1),
                                                        e.add(s[t].code)
                                                    }
                                                } else
                                                    n[r].trainTypeList = []
                                            }
                                            i.add(n[r].lineId),
                                            o.add(n[r].lineCode)
                                        }
                                    }
                                }
                            }
                            )
                        } catch (n) {
                            throw console.error(`[Line Config] Failed to get line config. detail=${n.message || "Unknown"}`),
                            n
                        }
                    })
                }
                validateKey() {
                    return r.a(this, void 0, void 0, function*() {
                        try {
                            const t = Be.a.getQueryParams().k;
                            t && (yield this.configApi.validateKey(t, this.get("activation.file")),
                            this._validKey = !0)
                        } catch (e) {
                            return
                        }
                    })
                }
                getOperationTimeRange() {
                    return r.a(this, void 0, void 0, function*() {
                        try {
                            let t, n = !1;
                            const r = (yield this.configApi.getOperationTimeRange()).body;
                            if (r) {
                                const e = r.trim().split(",");
                                if (2 === e.length) {
                                    const r = this.convertDateString(e[0])
                                      , s = this.convertDateString(e[1]);
                                    r && s && (t = {
                                        from: r,
                                        to: s
                                    },
                                    n = !0)
                                }
                            } else
                                n = !0;
                            this._operationTimeRange = {
                                valid: n,
                                range: t
                            }
                        } catch (e) {
                            console.error(`[Config] Failed to get operation time range. detail=${e.message || "Unknown"}`),
                            this._operationTimeRange = {
                                valid: !1,
                                range: void 0
                            }
                        }
                    })
                }
                getMaintenance() {
                    return r.a(this, void 0, void 0, function*() {
                        try {
                            let t, n = !1;
                            const r = yield this.configApi.getMaintenanceDateTimeRange()
                              , s = r.body;
                            if (s) {
                                const e = Be.a.convertServerTime(r.headers.get("Date"))
                                  , i = s.trim().split(",");
                                if (2 === i.length) {
                                    const r = this.convertDate(i[0], "%Y/%m/%d %H:%M")
                                      , s = this.convertDate(i[1], "%Y/%m/%d %H:%M");
                                    r && s && (t = {
                                        from: r,
                                        to: s
                                    },
                                    n = r.getTime() > e.getTime())
                                }
                            } else
                                n = !0,
                                t = {
                                    from: new Date("9999-12-31"),
                                    to: null
                                };
                            this._maintenance = {
                                valid: n,
                                range: t
                            }
                        } catch (e) {
                            console.error(`[Config] Failed to get maintenance datetime range. detail=${e.message || "Unknown"}`),
                            this._maintenance = {
                                valid: !1,
                                range: void 0
                            }
                        }
                    })
                }
                getApiToken() {
                    return r.a(this, void 0, void 0, function*() {
                        try {
                            if (this._validKey) {
                                const e = Be.a.getQueryParams().k
                                  , t = yield this.configApi.getApiToken(e);
                                let n = "";
                                const r = 3;
                                (t.body || "").split("").forEach(e => {
                                    n += String.fromCharCode(e.charCodeAt(0) - r)
                                }
                                ),
                                this.apiConfig.root = this.get("api.root");
                                const s = new Map;
                                this.configs.forEach( (e, t) => {
                                    t.startsWith("api.resource.") && s.set(t, e)
                                }
                                ),
                                this.apiConfig.resourceMap = s,
                                this.apiConfig.apiToken = n
                            }
                        } catch (e) {
                            console.error(`[Api Token] Failed to get api token. detail=${e.message || "Unknown"}`)
                        }
                    })
                }
                convertDate(e, t) {
                    const n = I(t)(e);
                    return n && e === O(t)(n) ? n : null
                }
                convertDateString(e) {
                    const t = e.split(":");
                    return 2 !== t.length || 2 !== t[0].length || 2 !== t[1].length ? null : isNaN(+t[0]) || isNaN(+t[1]) ? null : e
                }
            }
            return e.ngInjectableDef = Ve.Qb({
                factory: function() {
                    return new e(Ve.Rb($e.a),Ve.Rb(qe.a),Ve.Rb(Ke))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )()
    },
    bHdf: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        var r = n("5+tZ")
          , s = n("SpAZ");
        function i(e=Number.POSITIVE_INFINITY) {
            return Object(r.a)(s.a, e)
        }
    },
    bOdf: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("5+tZ");
        function s(e, t) {
            return Object(r.a)(e, t, 1)
        }
    },
    bujt: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return a
        }),
        n.d(t, "d", function() {
            return c
        }),
        n.d(t, "a", function() {
            return l
        }),
        n.d(t, "c", function() {
            return u
        });
        var r = n("8Y7J")
          , s = (n("Fwaw"),
        n("SVse"),
        n("IP0z"),
        n("Xd0L"))
          , i = (n("cUpR"),
        n("/HVE"))
          , o = n("omvX")
          , a = (n("5GAg"),
        r.qb({
            encapsulation: 2,
            styles: [".mat-button .mat-button-focus-overlay,.mat-icon-button .mat-button-focus-overlay{opacity:0}.mat-button:hover .mat-button-focus-overlay,.mat-stroked-button:hover .mat-button-focus-overlay{opacity:.04}@media (hover:none){.mat-button:hover .mat-button-focus-overlay,.mat-stroked-button:hover .mat-button-focus-overlay{opacity:0}}.mat-button,.mat-flat-button,.mat-icon-button,.mat-stroked-button{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:64px;line-height:36px;padding:0 16px;border-radius:4px;overflow:visible}.mat-button::-moz-focus-inner,.mat-flat-button::-moz-focus-inner,.mat-icon-button::-moz-focus-inner,.mat-stroked-button::-moz-focus-inner{border:0}.mat-button[disabled],.mat-flat-button[disabled],.mat-icon-button[disabled],.mat-stroked-button[disabled]{cursor:default}.mat-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-button.cdk-program-focused .mat-button-focus-overlay,.mat-flat-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-flat-button.cdk-program-focused .mat-button-focus-overlay,.mat-icon-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-icon-button.cdk-program-focused .mat-button-focus-overlay,.mat-stroked-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-stroked-button.cdk-program-focused .mat-button-focus-overlay{opacity:.12}.mat-button::-moz-focus-inner,.mat-flat-button::-moz-focus-inner,.mat-icon-button::-moz-focus-inner,.mat-stroked-button::-moz-focus-inner{border:0}.mat-raised-button{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:64px;line-height:36px;padding:0 16px;border-radius:4px;overflow:visible;transform:translate3d(0,0,0);transition:background .4s cubic-bezier(.25,.8,.25,1),box-shadow 280ms cubic-bezier(.4,0,.2,1)}.mat-raised-button::-moz-focus-inner{border:0}.mat-raised-button[disabled]{cursor:default}.mat-raised-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-raised-button.cdk-program-focused .mat-button-focus-overlay{opacity:.12}.mat-raised-button::-moz-focus-inner{border:0}._mat-animation-noopable.mat-raised-button{transition:none;animation:none}.mat-stroked-button{border:1px solid currentColor;padding:0 15px;line-height:34px}.mat-stroked-button .mat-button-focus-overlay,.mat-stroked-button .mat-button-ripple.mat-ripple{top:-1px;left:-1px;right:-1px;bottom:-1px}.mat-fab{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:64px;line-height:36px;padding:0 16px;border-radius:4px;overflow:visible;transform:translate3d(0,0,0);transition:background .4s cubic-bezier(.25,.8,.25,1),box-shadow 280ms cubic-bezier(.4,0,.2,1);min-width:0;border-radius:50%;width:56px;height:56px;padding:0;flex-shrink:0}.mat-fab::-moz-focus-inner{border:0}.mat-fab[disabled]{cursor:default}.mat-fab.cdk-keyboard-focused .mat-button-focus-overlay,.mat-fab.cdk-program-focused .mat-button-focus-overlay{opacity:.12}.mat-fab::-moz-focus-inner{border:0}._mat-animation-noopable.mat-fab{transition:none;animation:none}.mat-fab .mat-button-wrapper{padding:16px 0;display:inline-block;line-height:24px}.mat-mini-fab{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:64px;line-height:36px;padding:0 16px;border-radius:4px;overflow:visible;transform:translate3d(0,0,0);transition:background .4s cubic-bezier(.25,.8,.25,1),box-shadow 280ms cubic-bezier(.4,0,.2,1);min-width:0;border-radius:50%;width:40px;height:40px;padding:0;flex-shrink:0}.mat-mini-fab::-moz-focus-inner{border:0}.mat-mini-fab[disabled]{cursor:default}.mat-mini-fab.cdk-keyboard-focused .mat-button-focus-overlay,.mat-mini-fab.cdk-program-focused .mat-button-focus-overlay{opacity:.12}.mat-mini-fab::-moz-focus-inner{border:0}._mat-animation-noopable.mat-mini-fab{transition:none;animation:none}.mat-mini-fab .mat-button-wrapper{padding:8px 0;display:inline-block;line-height:24px}.mat-icon-button{padding:0;min-width:0;width:40px;height:40px;flex-shrink:0;line-height:40px;border-radius:50%}.mat-icon-button .mat-icon,.mat-icon-button i{line-height:24px}.mat-button-focus-overlay,.mat-button-ripple.mat-ripple{top:0;left:0;right:0;bottom:0;position:absolute;pointer-events:none;border-radius:inherit}.mat-button-ripple.mat-ripple:not(:empty){transform:translateZ(0)}.mat-button-focus-overlay{opacity:0;transition:opacity .2s cubic-bezier(.35,0,.25,1),background-color .2s cubic-bezier(.35,0,.25,1)}._mat-animation-noopable .mat-button-focus-overlay{transition:none}@media (-ms-high-contrast:active){.mat-button-focus-overlay{background-color:#fff}}@media (-ms-high-contrast:black-on-white){.mat-button-focus-overlay{background-color:#000}}.mat-button-ripple-round{border-radius:50%;z-index:1}.mat-button .mat-button-wrapper>*,.mat-fab .mat-button-wrapper>*,.mat-flat-button .mat-button-wrapper>*,.mat-icon-button .mat-button-wrapper>*,.mat-mini-fab .mat-button-wrapper>*,.mat-raised-button .mat-button-wrapper>*,.mat-stroked-button .mat-button-wrapper>*{vertical-align:middle}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon-button,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon-button{display:block;font-size:inherit;width:2.5em;height:2.5em}@media (-ms-high-contrast:active){.mat-button,.mat-fab,.mat-flat-button,.mat-icon-button,.mat-mini-fab,.mat-raised-button{outline:solid 1px}}"],
            data: {}
        }));
        function c(e) {
            return r.Mb(2, [r.Ib(671088640, 1, {
                ripple: 0
            }), (e()(),
            r.sb(1, 0, null, null, 1, "span", [["class", "mat-button-wrapper"]], null, null, null, null, null)), r.Cb(null, 0), (e()(),
            r.sb(3, 0, null, null, 1, "div", [["class", "mat-button-ripple mat-ripple"], ["matRipple", ""]], [[2, "mat-button-ripple-round", null], [2, "mat-ripple-unbounded", null]], null, null, null, null)), r.rb(4, 212992, [[1, 4]], 0, s.f, [r.k, r.y, i.a, [2, s.d], [2, o.a]], {
                centered: [0, "centered"],
                disabled: [1, "disabled"],
                trigger: [2, "trigger"]
            }, null), (e()(),
            r.sb(5, 0, null, null, 0, "div", [["class", "mat-button-focus-overlay"]], null, null, null, null, null))], function(e, t) {
                var n = t.component;
                e(t, 4, 0, n.isIconButton, n._isRippleDisabled(), n._getHostElement())
            }, function(e, t) {
                var n = t.component;
                e(t, 3, 0, n.isRoundButton || n.isIconButton, r.Db(t, 4).unbounded)
            })
        }
        var l = r.qb({
            encapsulation: 2,
            styles: [".mat-button .mat-button-focus-overlay,.mat-icon-button .mat-button-focus-overlay{opacity:0}.mat-button:hover .mat-button-focus-overlay,.mat-stroked-button:hover .mat-button-focus-overlay{opacity:.04}@media (hover:none){.mat-button:hover .mat-button-focus-overlay,.mat-stroked-button:hover .mat-button-focus-overlay{opacity:0}}.mat-button,.mat-flat-button,.mat-icon-button,.mat-stroked-button{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:64px;line-height:36px;padding:0 16px;border-radius:4px;overflow:visible}.mat-button::-moz-focus-inner,.mat-flat-button::-moz-focus-inner,.mat-icon-button::-moz-focus-inner,.mat-stroked-button::-moz-focus-inner{border:0}.mat-button[disabled],.mat-flat-button[disabled],.mat-icon-button[disabled],.mat-stroked-button[disabled]{cursor:default}.mat-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-button.cdk-program-focused .mat-button-focus-overlay,.mat-flat-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-flat-button.cdk-program-focused .mat-button-focus-overlay,.mat-icon-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-icon-button.cdk-program-focused .mat-button-focus-overlay,.mat-stroked-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-stroked-button.cdk-program-focused .mat-button-focus-overlay{opacity:.12}.mat-button::-moz-focus-inner,.mat-flat-button::-moz-focus-inner,.mat-icon-button::-moz-focus-inner,.mat-stroked-button::-moz-focus-inner{border:0}.mat-raised-button{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:64px;line-height:36px;padding:0 16px;border-radius:4px;overflow:visible;transform:translate3d(0,0,0);transition:background .4s cubic-bezier(.25,.8,.25,1),box-shadow 280ms cubic-bezier(.4,0,.2,1)}.mat-raised-button::-moz-focus-inner{border:0}.mat-raised-button[disabled]{cursor:default}.mat-raised-button.cdk-keyboard-focused .mat-button-focus-overlay,.mat-raised-button.cdk-program-focused .mat-button-focus-overlay{opacity:.12}.mat-raised-button::-moz-focus-inner{border:0}._mat-animation-noopable.mat-raised-button{transition:none;animation:none}.mat-stroked-button{border:1px solid currentColor;padding:0 15px;line-height:34px}.mat-stroked-button .mat-button-focus-overlay,.mat-stroked-button .mat-button-ripple.mat-ripple{top:-1px;left:-1px;right:-1px;bottom:-1px}.mat-fab{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:64px;line-height:36px;padding:0 16px;border-radius:4px;overflow:visible;transform:translate3d(0,0,0);transition:background .4s cubic-bezier(.25,.8,.25,1),box-shadow 280ms cubic-bezier(.4,0,.2,1);min-width:0;border-radius:50%;width:56px;height:56px;padding:0;flex-shrink:0}.mat-fab::-moz-focus-inner{border:0}.mat-fab[disabled]{cursor:default}.mat-fab.cdk-keyboard-focused .mat-button-focus-overlay,.mat-fab.cdk-program-focused .mat-button-focus-overlay{opacity:.12}.mat-fab::-moz-focus-inner{border:0}._mat-animation-noopable.mat-fab{transition:none;animation:none}.mat-fab .mat-button-wrapper{padding:16px 0;display:inline-block;line-height:24px}.mat-mini-fab{box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;text-align:center;margin:0;min-width:64px;line-height:36px;padding:0 16px;border-radius:4px;overflow:visible;transform:translate3d(0,0,0);transition:background .4s cubic-bezier(.25,.8,.25,1),box-shadow 280ms cubic-bezier(.4,0,.2,1);min-width:0;border-radius:50%;width:40px;height:40px;padding:0;flex-shrink:0}.mat-mini-fab::-moz-focus-inner{border:0}.mat-mini-fab[disabled]{cursor:default}.mat-mini-fab.cdk-keyboard-focused .mat-button-focus-overlay,.mat-mini-fab.cdk-program-focused .mat-button-focus-overlay{opacity:.12}.mat-mini-fab::-moz-focus-inner{border:0}._mat-animation-noopable.mat-mini-fab{transition:none;animation:none}.mat-mini-fab .mat-button-wrapper{padding:8px 0;display:inline-block;line-height:24px}.mat-icon-button{padding:0;min-width:0;width:40px;height:40px;flex-shrink:0;line-height:40px;border-radius:50%}.mat-icon-button .mat-icon,.mat-icon-button i{line-height:24px}.mat-button-focus-overlay,.mat-button-ripple.mat-ripple{top:0;left:0;right:0;bottom:0;position:absolute;pointer-events:none;border-radius:inherit}.mat-button-ripple.mat-ripple:not(:empty){transform:translateZ(0)}.mat-button-focus-overlay{opacity:0;transition:opacity .2s cubic-bezier(.35,0,.25,1),background-color .2s cubic-bezier(.35,0,.25,1)}._mat-animation-noopable .mat-button-focus-overlay{transition:none}@media (-ms-high-contrast:active){.mat-button-focus-overlay{background-color:#fff}}@media (-ms-high-contrast:black-on-white){.mat-button-focus-overlay{background-color:#000}}.mat-button-ripple-round{border-radius:50%;z-index:1}.mat-button .mat-button-wrapper>*,.mat-fab .mat-button-wrapper>*,.mat-flat-button .mat-button-wrapper>*,.mat-icon-button .mat-button-wrapper>*,.mat-mini-fab .mat-button-wrapper>*,.mat-raised-button .mat-button-wrapper>*,.mat-stroked-button .mat-button-wrapper>*{vertical-align:middle}.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-prefix .mat-icon-button,.mat-form-field:not(.mat-form-field-appearance-legacy) .mat-form-field-suffix .mat-icon-button{display:block;font-size:inherit;width:2.5em;height:2.5em}@media (-ms-high-contrast:active){.mat-button,.mat-fab,.mat-flat-button,.mat-icon-button,.mat-mini-fab,.mat-raised-button{outline:solid 1px}}"],
            data: {}
        });
        function u(e) {
            return r.Mb(2, [r.Ib(671088640, 1, {
                ripple: 0
            }), (e()(),
            r.sb(1, 0, null, null, 1, "span", [["class", "mat-button-wrapper"]], null, null, null, null, null)), r.Cb(null, 0), (e()(),
            r.sb(3, 0, null, null, 1, "div", [["class", "mat-button-ripple mat-ripple"], ["matRipple", ""]], [[2, "mat-button-ripple-round", null], [2, "mat-ripple-unbounded", null]], null, null, null, null)), r.rb(4, 212992, [[1, 4]], 0, s.f, [r.k, r.y, i.a, [2, s.d], [2, o.a]], {
                centered: [0, "centered"],
                disabled: [1, "disabled"],
                trigger: [2, "trigger"]
            }, null), (e()(),
            r.sb(5, 0, null, null, 0, "div", [["class", "mat-button-focus-overlay"]], null, null, null, null, null))], function(e, t) {
                var n = t.component;
                e(t, 4, 0, n.isIconButton, n._isRippleDisabled(), n._getHostElement())
            }, function(e, t) {
                var n = t.component;
                e(t, 3, 0, n.isRoundButton || n.isIconButton, r.Db(t, 4).unbounded)
            })
        }
    },
    c2HN: function(e, t, n) {
        "use strict";
        function r(e) {
            return !!e && "function" != typeof e.subscribe && "function" == typeof e.then
        }
        n.d(t, "a", function() {
            return r
        })
    },
    cUpR: function(e, t, n) {
        "use strict";
        n.d(t, "p", function() {
            return x
        }),
        n.d(t, "a", function() {
            return Ee
        }),
        n.d(t, "h", function() {
            return we
        }),
        n.d(t, "c", function() {
            return k
        }),
        n.d(t, "d", function() {
            return O
        }),
        n.d(t, "e", function() {
            return ie
        }),
        n.d(t, "f", function() {
            return oe
        }),
        n.d(t, "g", function() {
            return ae
        }),
        n.d(t, "b", function() {
            return de
        }),
        n.d(t, "q", function() {
            return o
        }),
        n.d(t, "j", function() {
            return F
        }),
        n.d(t, "i", function() {
            return re
        }),
        n.d(t, "m", function() {
            return ce
        }),
        n.d(t, "n", function() {
            return he
        }),
        n.d(t, "l", function() {
            return D
        }),
        n.d(t, "o", function() {
            return A
        }),
        n.d(t, "k", function() {
            return fe
        });
        var r = n("SVse")
          , s = n("8Y7J");
        let i = null;
        function o() {
            return i
        }
        class a {
            constructor() {
                this.resourceLoaderType = null
            }
            get attrToPropMap() {
                return this._attrToPropMap
            }
            set attrToPropMap(e) {
                this._attrToPropMap = e
            }
        }
        class c extends a {
            constructor() {
                super(),
                this._animationPrefix = null,
                this._transitionEnd = null;
                try {
                    const t = this.createElement("div", document);
                    if (null != this.getStyle(t, "animationName"))
                        this._animationPrefix = "";
                    else {
                        const e = ["Webkit", "Moz", "O", "ms"];
                        for (let n = 0; n < e.length; n++)
                            if (null != this.getStyle(t, e[n] + "AnimationName")) {
                                this._animationPrefix = "-" + e[n].toLowerCase() + "-";
                                break
                            }
                    }
                    const n = {
                        WebkitTransition: "webkitTransitionEnd",
                        MozTransition: "transitionend",
                        OTransition: "oTransitionEnd otransitionend",
                        transition: "transitionend"
                    };
                    Object.keys(n).forEach(e => {
                        null != this.getStyle(t, e) && (this._transitionEnd = n[e])
                    }
                    )
                } catch (e) {
                    this._animationPrefix = null,
                    this._transitionEnd = null
                }
            }
            getDistributedNodes(e) {
                return e.getDistributedNodes()
            }
            resolveAndSetHref(e, t, n) {
                e.href = null == n ? t : t + "/../" + n
            }
            supportsDOMEvents() {
                return !0
            }
            supportsNativeShadowDOM() {
                return "function" == typeof document.body.createShadowRoot
            }
            getAnimationPrefix() {
                return this._animationPrefix ? this._animationPrefix : ""
            }
            getTransitionEnd() {
                return this._transitionEnd ? this._transitionEnd : ""
            }
            supportsAnimation() {
                return null != this._animationPrefix && null != this._transitionEnd
            }
        }
        const l = {
            class: "className",
            innerHtml: "innerHTML",
            readonly: "readOnly",
            tabindex: "tabIndex"
        }
          , u = 3
          , h = {
            "\b": "Backspace",
            "\t": "Tab",
            "": "Delete",
            "": "Escape",
            Del: "Delete",
            Esc: "Escape",
            Left: "ArrowLeft",
            Right: "ArrowRight",
            Up: "ArrowUp",
            Down: "ArrowDown",
            Menu: "ContextMenu",
            Scroll: "ScrollLock",
            Win: "OS"
        }
          , d = {
            A: "1",
            B: "2",
            C: "3",
            D: "4",
            E: "5",
            F: "6",
            G: "7",
            H: "8",
            I: "9",
            J: "*",
            K: "+",
            M: "-",
            N: ".",
            O: "/",
            "`": "0",
            "": "NumLock"
        }
          , f = ( () => {
            if (s.vb.Node)
                return s.vb.Node.prototype.contains || function(e) {
                    return !!(16 & this.compareDocumentPosition(e))
                }
        }
        )();
        class p extends c {
            parse(e) {
                throw new Error("parse not implemented")
            }
            static makeCurrent() {
                var e;
                e = new p,
                i || (i = e)
            }
            hasProperty(e, t) {
                return t in e
            }
            setProperty(e, t, n) {
                e[t] = n
            }
            getProperty(e, t) {
                return e[t]
            }
            invoke(e, t, n) {
                e[t](...n)
            }
            logError(e) {
                window.console && (console.error ? console.error(e) : console.log(e))
            }
            log(e) {
                window.console && window.console.log && window.console.log(e)
            }
            logGroup(e) {
                window.console && window.console.group && window.console.group(e)
            }
            logGroupEnd() {
                window.console && window.console.groupEnd && window.console.groupEnd()
            }
            get attrToPropMap() {
                return l
            }
            contains(e, t) {
                return f.call(e, t)
            }
            querySelector(e, t) {
                return e.querySelector(t)
            }
            querySelectorAll(e, t) {
                return e.querySelectorAll(t)
            }
            on(e, t, n) {
                e.addEventListener(t, n, !1)
            }
            onAndCancel(e, t, n) {
                return e.addEventListener(t, n, !1),
                () => {
                    e.removeEventListener(t, n, !1)
                }
            }
            dispatchEvent(e, t) {
                e.dispatchEvent(t)
            }
            createMouseEvent(e) {
                const t = this.getDefaultDocument().createEvent("MouseEvent");
                return t.initEvent(e, !0, !0),
                t
            }
            createEvent(e) {
                const t = this.getDefaultDocument().createEvent("Event");
                return t.initEvent(e, !0, !0),
                t
            }
            preventDefault(e) {
                e.preventDefault(),
                e.returnValue = !1
            }
            isPrevented(e) {
                return e.defaultPrevented || null != e.returnValue && !e.returnValue
            }
            getInnerHTML(e) {
                return e.innerHTML
            }
            getTemplateContent(e) {
                return "content"in e && this.isTemplateElement(e) ? e.content : null
            }
            getOuterHTML(e) {
                return e.outerHTML
            }
            nodeName(e) {
                return e.nodeName
            }
            nodeValue(e) {
                return e.nodeValue
            }
            type(e) {
                return e.type
            }
            content(e) {
                return this.hasProperty(e, "content") ? e.content : e
            }
            firstChild(e) {
                return e.firstChild
            }
            nextSibling(e) {
                return e.nextSibling
            }
            parentElement(e) {
                return e.parentNode
            }
            childNodes(e) {
                return e.childNodes
            }
            childNodesAsList(e) {
                const t = e.childNodes
                  , n = new Array(t.length);
                for (let r = 0; r < t.length; r++)
                    n[r] = t[r];
                return n
            }
            clearNodes(e) {
                for (; e.firstChild; )
                    e.removeChild(e.firstChild)
            }
            appendChild(e, t) {
                e.appendChild(t)
            }
            removeChild(e, t) {
                e.removeChild(t)
            }
            replaceChild(e, t, n) {
                e.replaceChild(t, n)
            }
            remove(e) {
                return e.parentNode && e.parentNode.removeChild(e),
                e
            }
            insertBefore(e, t, n) {
                e.insertBefore(n, t)
            }
            insertAllBefore(e, t, n) {
                n.forEach(n => e.insertBefore(n, t))
            }
            insertAfter(e, t, n) {
                e.insertBefore(n, t.nextSibling)
            }
            setInnerHTML(e, t) {
                e.innerHTML = t
            }
            getText(e) {
                return e.textContent
            }
            setText(e, t) {
                e.textContent = t
            }
            getValue(e) {
                return e.value
            }
            setValue(e, t) {
                e.value = t
            }
            getChecked(e) {
                return e.checked
            }
            setChecked(e, t) {
                e.checked = t
            }
            createComment(e) {
                return this.getDefaultDocument().createComment(e)
            }
            createTemplate(e) {
                const t = this.getDefaultDocument().createElement("template");
                return t.innerHTML = e,
                t
            }
            createElement(e, t) {
                return (t = t || this.getDefaultDocument()).createElement(e)
            }
            createElementNS(e, t, n) {
                return (n = n || this.getDefaultDocument()).createElementNS(e, t)
            }
            createTextNode(e, t) {
                return (t = t || this.getDefaultDocument()).createTextNode(e)
            }
            createScriptTag(e, t, n) {
                const r = (n = n || this.getDefaultDocument()).createElement("SCRIPT");
                return r.setAttribute(e, t),
                r
            }
            createStyleElement(e, t) {
                const n = (t = t || this.getDefaultDocument()).createElement("style");
                return this.appendChild(n, this.createTextNode(e, t)),
                n
            }
            createShadowRoot(e) {
                return e.createShadowRoot()
            }
            getShadowRoot(e) {
                return e.shadowRoot
            }
            getHost(e) {
                return e.host
            }
            clone(e) {
                return e.cloneNode(!0)
            }
            getElementsByClassName(e, t) {
                return e.getElementsByClassName(t)
            }
            getElementsByTagName(e, t) {
                return e.getElementsByTagName(t)
            }
            classList(e) {
                return Array.prototype.slice.call(e.classList, 0)
            }
            addClass(e, t) {
                e.classList.add(t)
            }
            removeClass(e, t) {
                e.classList.remove(t)
            }
            hasClass(e, t) {
                return e.classList.contains(t)
            }
            setStyle(e, t, n) {
                e.style[t] = n
            }
            removeStyle(e, t) {
                e.style[t] = ""
            }
            getStyle(e, t) {
                return e.style[t]
            }
            hasStyle(e, t, n) {
                const r = this.getStyle(e, t) || "";
                return n ? r == n : r.length > 0
            }
            tagName(e) {
                return e.tagName
            }
            attributeMap(e) {
                const t = new Map
                  , n = e.attributes;
                for (let r = 0; r < n.length; r++) {
                    const e = n.item(r);
                    t.set(e.name, e.value)
                }
                return t
            }
            hasAttribute(e, t) {
                return e.hasAttribute(t)
            }
            hasAttributeNS(e, t, n) {
                return e.hasAttributeNS(t, n)
            }
            getAttribute(e, t) {
                return e.getAttribute(t)
            }
            getAttributeNS(e, t, n) {
                return e.getAttributeNS(t, n)
            }
            setAttribute(e, t, n) {
                e.setAttribute(t, n)
            }
            setAttributeNS(e, t, n, r) {
                e.setAttributeNS(t, n, r)
            }
            removeAttribute(e, t) {
                e.removeAttribute(t)
            }
            removeAttributeNS(e, t, n) {
                e.removeAttributeNS(t, n)
            }
            templateAwareRoot(e) {
                return this.isTemplateElement(e) ? this.content(e) : e
            }
            createHtmlDocument() {
                return document.implementation.createHTMLDocument("fakeTitle")
            }
            getDefaultDocument() {
                return document
            }
            getBoundingClientRect(e) {
                try {
                    return e.getBoundingClientRect()
                } catch (t) {
                    return {
                        top: 0,
                        bottom: 0,
                        left: 0,
                        right: 0,
                        width: 0,
                        height: 0
                    }
                }
            }
            getTitle(e) {
                return e.title
            }
            setTitle(e, t) {
                e.title = t || ""
            }
            elementMatches(e, t) {
                return !!this.isElementNode(e) && (e.matches && e.matches(t) || e.msMatchesSelector && e.msMatchesSelector(t) || e.webkitMatchesSelector && e.webkitMatchesSelector(t))
            }
            isTemplateElement(e) {
                return this.isElementNode(e) && "TEMPLATE" === e.nodeName
            }
            isTextNode(e) {
                return e.nodeType === Node.TEXT_NODE
            }
            isCommentNode(e) {
                return e.nodeType === Node.COMMENT_NODE
            }
            isElementNode(e) {
                return e.nodeType === Node.ELEMENT_NODE
            }
            hasShadowRoot(e) {
                return null != e.shadowRoot && e instanceof HTMLElement
            }
            isShadowRoot(e) {
                return e instanceof DocumentFragment
            }
            importIntoDoc(e) {
                return document.importNode(this.templateAwareRoot(e), !0)
            }
            adoptNode(e) {
                return document.adoptNode(e)
            }
            getHref(e) {
                return e.getAttribute("href")
            }
            getEventKey(e) {
                let t = e.key;
                if (null == t) {
                    if (null == (t = e.keyIdentifier))
                        return "Unidentified";
                    t.startsWith("U+") && (t = String.fromCharCode(parseInt(t.substring(2), 16)),
                    e.location === u && d.hasOwnProperty(t) && (t = d[t]))
                }
                return h[t] || t
            }
            getGlobalEventTarget(e, t) {
                return "window" === t ? window : "document" === t ? e : "body" === t ? e.body : null
            }
            getHistory() {
                return window.history
            }
            getLocation() {
                return window.location
            }
            getBaseHref(e) {
                const t = g || (g = document.querySelector("base")) ? g.getAttribute("href") : null;
                return null == t ? null : (n = t,
                m || (m = document.createElement("a")),
                m.setAttribute("href", n),
                "/" === m.pathname.charAt(0) ? m.pathname : "/" + m.pathname);
                var n
            }
            resetBaseElement() {
                g = null
            }
            getUserAgent() {
                return window.navigator.userAgent
            }
            setData(e, t, n) {
                this.setAttribute(e, "data-" + t, n)
            }
            getData(e, t) {
                return this.getAttribute(e, "data-" + t)
            }
            getComputedStyle(e) {
                return getComputedStyle(e)
            }
            supportsWebAnimation() {
                return "function" == typeof Element.prototype.animate
            }
            performanceNow() {
                return window.performance && window.performance.now ? window.performance.now() : (new Date).getTime()
            }
            supportsCookies() {
                return !0
            }
            getCookie(e) {
                return Object(r.y)(document.cookie, e)
            }
            setCookie(e, t) {
                document.cookie = encodeURIComponent(e) + "=" + encodeURIComponent(t)
            }
        }
        let m, g = null;
        function b() {
            return !!window.history.pushState
        }
        const y = new s.p("TRANSITION_ID")
          , v = [{
            provide: s.d,
            useFactory: function(e, t, n) {
                return () => {
                    n.get(s.e).donePromise.then( () => {
                        const n = o();
                        Array.prototype.slice.apply(n.querySelectorAll(t, "style[ng-transition]")).filter(t => n.getAttribute(t, "ng-transition") === e).forEach(e => n.remove(e))
                    }
                    )
                }
            },
            deps: [y, r.d, s.q],
            multi: !0
        }];
        class _ {
            static init() {
                Object(s.Y)(new _)
            }
            addToWindow(e) {
                s.vb.getAngularTestability = (t, n=!0) => {
                    const r = e.findTestabilityInTree(t, n);
                    if (null == r)
                        throw new Error("Could not find testability for element.");
                    return r
                }
                ,
                s.vb.getAllAngularTestabilities = () => e.getAllTestabilities(),
                s.vb.getAllAngularRootElements = () => e.getAllRootElements(),
                s.vb.frameworkStabilizers || (s.vb.frameworkStabilizers = []),
                s.vb.frameworkStabilizers.push(e => {
                    const t = s.vb.getAllAngularTestabilities();
                    let n = t.length
                      , r = !1;
                    const i = function(t) {
                        r = r || t,
                        0 == --n && e(r)
                    };
                    t.forEach(function(e) {
                        e.whenStable(i)
                    })
                }
                )
            }
            findTestabilityInTree(e, t, n) {
                if (null == t)
                    return null;
                const r = e.getTestability(t);
                return null != r ? r : n ? o().isShadowRoot(t) ? this.findTestabilityInTree(e, o().getHost(t), !0) : this.findTestabilityInTree(e, o().parentElement(t), !0) : null
            }
        }
        function w(e, t) {
            "undefined" != typeof COMPILED && COMPILED || ((s.vb.ng = s.vb.ng || {})[e] = t)
        }
        const E = ( () => ({
            ApplicationRef: s.g,
            NgZone: s.y
        }))()
          , S = "probe"
          , C = "coreTokens";
        function T(e) {
            return Object(s.U)(e)
        }
        function x(e) {
            return w(S, T),
            w(C, Object.assign({}, E, (e || []).reduce( (e, t) => (e[t.name] = t.token,
            e), {}))),
            () => T
        }
        const k = new s.p("EventManagerPlugins");
        class O {
            constructor(e, t) {
                this._zone = t,
                this._eventNameToPlugin = new Map,
                e.forEach(e => e.manager = this),
                this._plugins = e.slice().reverse()
            }
            addEventListener(e, t, n) {
                return this._findPluginFor(t).addEventListener(e, t, n)
            }
            addGlobalEventListener(e, t, n) {
                return this._findPluginFor(t).addGlobalEventListener(e, t, n)
            }
            getZone() {
                return this._zone
            }
            _findPluginFor(e) {
                const t = this._eventNameToPlugin.get(e);
                if (t)
                    return t;
                const n = this._plugins;
                for (let r = 0; r < n.length; r++) {
                    const t = n[r];
                    if (t.supports(e))
                        return this._eventNameToPlugin.set(e, t),
                        t
                }
                throw new Error(`No event manager plugin found for event ${e}`)
            }
        }
        class I {
            constructor(e) {
                this._doc = e
            }
            addGlobalEventListener(e, t, n) {
                const r = o().getGlobalEventTarget(this._doc, e);
                if (!r)
                    throw new Error(`Unsupported event target ${r} for event ${t}`);
                return this.addEventListener(r, t, n)
            }
        }
        class A {
            constructor() {
                this._stylesSet = new Set
            }
            addStyles(e) {
                const t = new Set;
                e.forEach(e => {
                    this._stylesSet.has(e) || (this._stylesSet.add(e),
                    t.add(e))
                }
                ),
                this.onStylesAdded(t)
            }
            onStylesAdded(e) {}
            getAllStyles() {
                return Array.from(this._stylesSet)
            }
        }
        class D extends A {
            constructor(e) {
                super(),
                this._doc = e,
                this._hostNodes = new Set,
                this._styleNodes = new Set,
                this._hostNodes.add(e.head)
            }
            _addStylesToHost(e, t) {
                e.forEach(e => {
                    const n = this._doc.createElement("style");
                    n.textContent = e,
                    this._styleNodes.add(t.appendChild(n))
                }
                )
            }
            addHost(e) {
                this._addStylesToHost(this._stylesSet, e),
                this._hostNodes.add(e)
            }
            removeHost(e) {
                this._hostNodes.delete(e)
            }
            onStylesAdded(e) {
                this._hostNodes.forEach(t => this._addStylesToHost(e, t))
            }
            ngOnDestroy() {
                this._styleNodes.forEach(e => o().remove(e))
            }
        }
        const R = {
            svg: "http://www.w3.org/2000/svg",
            xhtml: "http://www.w3.org/1999/xhtml",
            xlink: "http://www.w3.org/1999/xlink",
            xml: "http://www.w3.org/XML/1998/namespace",
            xmlns: "http://www.w3.org/2000/xmlns/"
        }
          , j = /%COMP%/g
          , N = "_nghost-%COMP%"
          , P = "_ngcontent-%COMP%";
        function M(e, t, n) {
            for (let r = 0; r < t.length; r++) {
                let s = t[r];
                Array.isArray(s) ? M(e, s, n) : (s = s.replace(j, e),
                n.push(s))
            }
            return n
        }
        function L(e) {
            return t => {
                !1 === e(t) && (t.preventDefault(),
                t.returnValue = !1)
            }
        }
        class F {
            constructor(e, t, n) {
                this.eventManager = e,
                this.sharedStylesHost = t,
                this.appId = n,
                this.rendererByCompId = new Map,
                this.defaultRenderer = new U(e)
            }
            createRenderer(e, t) {
                if (!e || !t)
                    return this.defaultRenderer;
                switch (t.encapsulation) {
                case s.P.Emulated:
                    {
                        let n = this.rendererByCompId.get(t.id);
                        return n || (n = new B(this.eventManager,this.sharedStylesHost,t,this.appId),
                        this.rendererByCompId.set(t.id, n)),
                        n.applyToHost(e),
                        n
                    }
                case s.P.Native:
                case s.P.ShadowDom:
                    return new V(this.eventManager,this.sharedStylesHost,e,t);
                default:
                    if (!this.rendererByCompId.has(t.id)) {
                        const e = M(t.id, t.styles, []);
                        this.sharedStylesHost.addStyles(e),
                        this.rendererByCompId.set(t.id, this.defaultRenderer)
                    }
                    return this.defaultRenderer
                }
            }
            begin() {}
            end() {}
        }
        class U {
            constructor(e) {
                this.eventManager = e,
                this.data = Object.create(null)
            }
            destroy() {}
            createElement(e, t) {
                return t ? document.createElementNS(R[t] || t, e) : document.createElement(e)
            }
            createComment(e) {
                return document.createComment(e)
            }
            createText(e) {
                return document.createTextNode(e)
            }
            appendChild(e, t) {
                e.appendChild(t)
            }
            insertBefore(e, t, n) {
                e && e.insertBefore(t, n)
            }
            removeChild(e, t) {
                e && e.removeChild(t)
            }
            selectRootElement(e, t) {
                let n = "string" == typeof e ? document.querySelector(e) : e;
                if (!n)
                    throw new Error(`The selector "${e}" did not match any elements`);
                return t || (n.textContent = ""),
                n
            }
            parentNode(e) {
                return e.parentNode
            }
            nextSibling(e) {
                return e.nextSibling
            }
            setAttribute(e, t, n, r) {
                if (r) {
                    t = r + ":" + t;
                    const s = R[r];
                    s ? e.setAttributeNS(s, t, n) : e.setAttribute(t, n)
                } else
                    e.setAttribute(t, n)
            }
            removeAttribute(e, t, n) {
                if (n) {
                    const r = R[n];
                    r ? e.removeAttributeNS(r, t) : e.removeAttribute(`${n}:${t}`)
                } else
                    e.removeAttribute(t)
            }
            addClass(e, t) {
                e.classList.add(t)
            }
            removeClass(e, t) {
                e.classList.remove(t)
            }
            setStyle(e, t, n, r) {
                r & s.F.DashCase ? e.style.setProperty(t, n, r & s.F.Important ? "important" : "") : e.style[t] = n
            }
            removeStyle(e, t, n) {
                n & s.F.DashCase ? e.style.removeProperty(t) : e.style[t] = ""
            }
            setProperty(e, t, n) {
                H(t, "property"),
                e[t] = n
            }
            setValue(e, t) {
                e.nodeValue = t
            }
            listen(e, t, n) {
                return H(t, "listener"),
                "string" == typeof e ? this.eventManager.addGlobalEventListener(e, t, L(n)) : this.eventManager.addEventListener(e, t, L(n))
            }
        }
        const z = ( () => "@".charCodeAt(0))();
        function H(e, t) {
            if (e.charCodeAt(0) === z)
                throw new Error(`Found the synthetic ${t} ${e}. Please include either "BrowserAnimationsModule" or "NoopAnimationsModule" in your application.`)
        }
        class B extends U {
            constructor(e, t, n, r) {
                super(e),
                this.component = n;
                const s = M(r + "-" + n.id, n.styles, []);
                t.addStyles(s),
                this.contentAttr = P.replace(j, r + "-" + n.id),
                this.hostAttr = N.replace(j, r + "-" + n.id)
            }
            applyToHost(e) {
                super.setAttribute(e, this.hostAttr, "")
            }
            createElement(e, t) {
                const n = super.createElement(e, t);
                return super.setAttribute(n, this.contentAttr, ""),
                n
            }
        }
        class V extends U {
            constructor(e, t, n, r) {
                super(e),
                this.sharedStylesHost = t,
                this.hostEl = n,
                this.component = r,
                this.shadowRoot = r.encapsulation === s.P.ShadowDom ? n.attachShadow({
                    mode: "open"
                }) : n.createShadowRoot(),
                this.sharedStylesHost.addHost(this.shadowRoot);
                const i = M(r.id, r.styles, []);
                for (let s = 0; s < i.length; s++) {
                    const e = document.createElement("style");
                    e.textContent = i[s],
                    this.shadowRoot.appendChild(e)
                }
            }
            nodeOrShadowRoot(e) {
                return e === this.hostEl ? this.shadowRoot : e
            }
            destroy() {
                this.sharedStylesHost.removeHost(this.shadowRoot)
            }
            appendChild(e, t) {
                return super.appendChild(this.nodeOrShadowRoot(e), t)
            }
            insertBefore(e, t, n) {
                return super.insertBefore(this.nodeOrShadowRoot(e), t, n)
            }
            removeChild(e, t) {
                return super.removeChild(this.nodeOrShadowRoot(e), t)
            }
            parentNode(e) {
                return this.nodeOrShadowRoot(super.parentNode(this.nodeOrShadowRoot(e)))
            }
        }
        const $ = ( () => "undefined" != typeof Zone && Zone.__symbol__ || function(e) {
            return "__zone_symbol__" + e
        }
        )()
          , q = $("addEventListener")
          , Q = $("removeEventListener")
          , G = {}
          , K = "FALSE"
          , W = "ANGULAR"
          , Z = "addEventListener"
          , Y = "removeEventListener"
          , J = "__zone_symbol__propagationStopped"
          , X = "__zone_symbol__stopImmediatePropagation"
          , ee = ( () => {
            const e = "undefined" != typeof Zone && Zone[$("BLACK_LISTED_EVENTS")];
            if (e) {
                const t = {};
                return e.forEach(e => {
                    t[e] = e
                }
                ),
                t
            }
        }
        )()
          , te = function(e) {
            return !!ee && ee.hasOwnProperty(e)
        }
          , ne = function(e) {
            const t = G[e.type];
            if (!t)
                return;
            const n = this[t];
            if (!n)
                return;
            const r = [e];
            if (1 === n.length) {
                const e = n[0];
                return e.zone !== Zone.current ? e.zone.run(e.handler, this, r) : e.handler.apply(this, r)
            }
            {
                const t = n.slice();
                for (let n = 0; n < t.length && !0 !== e[J]; n++) {
                    const e = t[n];
                    e.zone !== Zone.current ? e.zone.run(e.handler, this, r) : e.handler.apply(this, r)
                }
            }
        };
        class re extends I {
            constructor(e, t, n) {
                super(e),
                this.ngZone = t,
                n && Object(r.t)(n) || this.patchEvent()
            }
            patchEvent() {
                if ("undefined" == typeof Event || !Event || !Event.prototype)
                    return;
                if (Event.prototype[X])
                    return;
                const e = Event.prototype[X] = Event.prototype.stopImmediatePropagation;
                Event.prototype.stopImmediatePropagation = function() {
                    this && (this[J] = !0),
                    e && e.apply(this, arguments)
                }
            }
            supports(e) {
                return !0
            }
            addEventListener(e, t, n) {
                let r = n;
                if (!e[q] || s.y.isInAngularZone() && !te(t))
                    e[Z](t, r, !1);
                else {
                    let n = G[t];
                    n || (n = G[t] = $(W + t + K));
                    let s = e[n];
                    const i = s && s.length > 0;
                    s || (s = e[n] = []);
                    const o = te(t) ? Zone.root : Zone.current;
                    if (0 === s.length)
                        s.push({
                            zone: o,
                            handler: r
                        });
                    else {
                        let e = !1;
                        for (let t = 0; t < s.length; t++)
                            if (s[t].handler === r) {
                                e = !0;
                                break
                            }
                        e || s.push({
                            zone: o,
                            handler: r
                        })
                    }
                    i || e[q](t, ne, !1)
                }
                return () => this.removeEventListener(e, t, r)
            }
            removeEventListener(e, t, n) {
                let r = e[Q];
                if (!r)
                    return e[Y].apply(e, [t, n, !1]);
                let s = G[t]
                  , i = s && e[s];
                if (!i)
                    return e[Y].apply(e, [t, n, !1]);
                let o = !1;
                for (let a = 0; a < i.length; a++)
                    if (i[a].handler === n) {
                        o = !0,
                        i.splice(a, 1);
                        break
                    }
                o ? 0 === i.length && r.apply(e, [t, ne, !1]) : e[Y].apply(e, [t, n, !1])
            }
        }
        const se = {
            pan: !0,
            panstart: !0,
            panmove: !0,
            panend: !0,
            pancancel: !0,
            panleft: !0,
            panright: !0,
            panup: !0,
            pandown: !0,
            pinch: !0,
            pinchstart: !0,
            pinchmove: !0,
            pinchend: !0,
            pinchcancel: !0,
            pinchin: !0,
            pinchout: !0,
            press: !0,
            pressup: !0,
            rotate: !0,
            rotatestart: !0,
            rotatemove: !0,
            rotateend: !0,
            rotatecancel: !0,
            swipe: !0,
            swipeleft: !0,
            swiperight: !0,
            swipeup: !0,
            swipedown: !0,
            tap: !0
        }
          , ie = new s.p("HammerGestureConfig")
          , oe = new s.p("HammerLoader");
        class ae {
            constructor() {
                this.events = [],
                this.overrides = {}
            }
            buildHammer(e) {
                const t = new Hammer(e,this.options);
                t.get("pinch").set({
                    enable: !0
                }),
                t.get("rotate").set({
                    enable: !0
                });
                for (const n in this.overrides)
                    t.get(n).set(this.overrides[n]);
                return t
            }
        }
        class ce extends I {
            constructor(e, t, n, r) {
                super(e),
                this._config = t,
                this.console = n,
                this.loader = r
            }
            supports(e) {
                return !(!se.hasOwnProperty(e.toLowerCase()) && !this.isCustomEvent(e) || !window.Hammer && !this.loader && (this.console.warn(`The "${e}" event cannot be bound because Hammer.JS is not ` + "loaded and no custom loader has been specified."),
                1))
            }
            addEventListener(e, t, n) {
                const r = this.manager.getZone();
                if (t = t.toLowerCase(),
                !window.Hammer && this.loader) {
                    let r = !1
                      , s = () => {
                        r = !0
                    }
                    ;
                    return this.loader().then( () => {
                        if (!window.Hammer)
                            return this.console.warn("The custom HAMMER_LOADER completed, but Hammer.JS is not present."),
                            void (s = () => {}
                            );
                        r || (s = this.addEventListener(e, t, n))
                    }
                    ).catch( () => {
                        this.console.warn(`The "${t}" event cannot be bound because the custom ` + "Hammer.JS loader failed."),
                        s = () => {}
                    }
                    ),
                    () => {
                        s()
                    }
                }
                return r.runOutsideAngular( () => {
                    const s = this._config.buildHammer(e)
                      , i = function(e) {
                        r.runGuarded(function() {
                            n(e)
                        })
                    };
                    return s.on(t, i),
                    () => {
                        s.off(t, i),
                        "function" == typeof s.destroy && s.destroy()
                    }
                }
                )
            }
            isCustomEvent(e) {
                return this._config.events.indexOf(e) > -1
            }
        }
        const le = ["alt", "control", "meta", "shift"]
          , ue = {
            alt: e => e.altKey,
            control: e => e.ctrlKey,
            meta: e => e.metaKey,
            shift: e => e.shiftKey
        };
        class he extends I {
            constructor(e) {
                super(e)
            }
            supports(e) {
                return null != he.parseEventName(e)
            }
            addEventListener(e, t, n) {
                const r = he.parseEventName(t)
                  , s = he.eventCallback(r.fullKey, n, this.manager.getZone());
                return this.manager.getZone().runOutsideAngular( () => o().onAndCancel(e, r.domEventName, s))
            }
            static parseEventName(e) {
                const t = e.toLowerCase().split(".")
                  , n = t.shift();
                if (0 === t.length || "keydown" !== n && "keyup" !== n)
                    return null;
                const r = he._normalizeKey(t.pop());
                let s = "";
                if (le.forEach(e => {
                    const n = t.indexOf(e);
                    n > -1 && (t.splice(n, 1),
                    s += e + ".")
                }
                ),
                s += r,
                0 != t.length || 0 === r.length)
                    return null;
                const i = {};
                return i.domEventName = n,
                i.fullKey = s,
                i
            }
            static getEventFullKey(e) {
                let t = ""
                  , n = o().getEventKey(e);
                return " " === (n = n.toLowerCase()) ? n = "space" : "." === n && (n = "dot"),
                le.forEach(r => {
                    r != n && (0,
                    ue[r])(e) && (t += r + ".")
                }
                ),
                t += n
            }
            static eventCallback(e, t, n) {
                return r => {
                    he.getEventFullKey(r) === e && n.runGuarded( () => t(r))
                }
            }
            static _normalizeKey(e) {
                switch (e) {
                case "esc":
                    return "escape";
                default:
                    return e
                }
            }
        }
        class de {
        }
        class fe extends de {
            constructor(e) {
                super(),
                this._doc = e
            }
            sanitize(e, t) {
                if (null == t)
                    return null;
                switch (e) {
                case s.H.NONE:
                    return t;
                case s.H.HTML:
                    return t instanceof me ? t.changingThisBreaksApplicationSecurity : (this.checkNotSafeValue(t, "HTML"),
                    Object(s.eb)(this._doc, String(t)));
                case s.H.STYLE:
                    return t instanceof ge ? t.changingThisBreaksApplicationSecurity : (this.checkNotSafeValue(t, "Style"),
                    Object(s.fb)(t));
                case s.H.SCRIPT:
                    if (t instanceof be)
                        return t.changingThisBreaksApplicationSecurity;
                    throw this.checkNotSafeValue(t, "Script"),
                    new Error("unsafe value used in a script context");
                case s.H.URL:
                    return t instanceof ve || t instanceof ye ? t.changingThisBreaksApplicationSecurity : (this.checkNotSafeValue(t, "URL"),
                    Object(s.gb)(String(t)));
                case s.H.RESOURCE_URL:
                    if (t instanceof ve)
                        return t.changingThisBreaksApplicationSecurity;
                    throw this.checkNotSafeValue(t, "ResourceURL"),
                    new Error("unsafe value used in a resource URL context (see http://g.co/ng/security#xss)");
                default:
                    throw new Error(`Unexpected SecurityContext ${e} (see http://g.co/ng/security#xss)`)
                }
            }
            checkNotSafeValue(e, t) {
                if (e instanceof pe)
                    throw new Error(`Required a safe ${t}, got a ${e.getTypeName()} ` + "(see http://g.co/ng/security#xss)")
            }
            bypassSecurityTrustHtml(e) {
                return new me(e)
            }
            bypassSecurityTrustStyle(e) {
                return new ge(e)
            }
            bypassSecurityTrustScript(e) {
                return new be(e)
            }
            bypassSecurityTrustUrl(e) {
                return new ye(e)
            }
            bypassSecurityTrustResourceUrl(e) {
                return new ve(e)
            }
        }
        class pe {
            constructor(e) {
                this.changingThisBreaksApplicationSecurity = e
            }
            toString() {
                return `SafeValue must use [property]=binding: ${this.changingThisBreaksApplicationSecurity}` + " (see http://g.co/ng/security#xss)"
            }
        }
        class me extends pe {
            getTypeName() {
                return "HTML"
            }
        }
        class ge extends pe {
            getTypeName() {
                return "Style"
            }
        }
        class be extends pe {
            getTypeName() {
                return "Script"
            }
        }
        class ye extends pe {
            getTypeName() {
                return "URL"
            }
        }
        class ve extends pe {
            getTypeName() {
                return "ResourceURL"
            }
        }
        const _e = [{
            provide: s.A,
            useValue: r.w
        }, {
            provide: s.B,
            useValue: function() {
                p.makeCurrent(),
                _.init()
            },
            multi: !0
        }, {
            provide: r.p,
            useClass: class extends r.p {
                constructor(e) {
                    super(),
                    this._doc = e,
                    this._init()
                }
                _init() {
                    this.location = o().getLocation(),
                    this._history = o().getHistory()
                }
                getBaseHrefFromDOM() {
                    return o().getBaseHref(this._doc)
                }
                onPopState(e) {
                    o().getGlobalEventTarget(this._doc, "window").addEventListener("popstate", e, !1)
                }
                onHashChange(e) {
                    o().getGlobalEventTarget(this._doc, "window").addEventListener("hashchange", e, !1)
                }
                get href() {
                    return this.location.href
                }
                get protocol() {
                    return this.location.protocol
                }
                get hostname() {
                    return this.location.hostname
                }
                get port() {
                    return this.location.port
                }
                get pathname() {
                    return this.location.pathname
                }
                get search() {
                    return this.location.search
                }
                get hash() {
                    return this.location.hash
                }
                set pathname(e) {
                    this.location.pathname = e
                }
                pushState(e, t, n) {
                    b() ? this._history.pushState(e, t, n) : this.location.hash = n
                }
                replaceState(e, t, n) {
                    b() ? this._history.replaceState(e, t, n) : this.location.hash = n
                }
                forward() {
                    this._history.forward()
                }
                back() {
                    this._history.back()
                }
                getState() {
                    return this._history.state
                }
            }
            ,
            deps: [r.d]
        }, {
            provide: r.d,
            useFactory: function() {
                return document
            },
            deps: []
        }]
          , we = Object(s.R)(s.X, "browser", _e);
        class Ee {
            constructor(e) {
                if (e)
                    throw new Error("BrowserModule has already been loaded. If you need access to common directives such as NgIf and NgFor from a lazy loaded module, import CommonModule instead.")
            }
            static withServerTransition(e) {
                return {
                    ngModule: Ee,
                    providers: [{
                        provide: s.c,
                        useValue: e.appId
                    }, {
                        provide: y,
                        useExisting: s.c
                    }, v]
                }
            }
        }
        "undefined" != typeof window && window
    },
    cXGI: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        var r = n("PJcQ")
          , s = n("AytR");
        class i {
            constructor() {}
            resToError(e, t=!1) {
                return e ? r.a.isDefined(e.errorcode) ? e : e.error ? this.resToError(e.error) : e.body ? this.resToError(e.body) : e instanceof Error ? this.resToError(e.stack) : {
                    errorcode: void 0,
                    message: e.message || (r.a.isString(e) ? e : void 0),
                    description: e.description || (r.a.isString(e) ? e : void 0),
                    isUnknownWindow: t
                } : {
                    errorcode: void 0
                }
            }
            delayMock(e, t=500) {
                return s.a.mock ? new Promise(n => {
                    window.setTimeout( () => n(e), t)
                }
                ) : e
            }
        }
    },
    dvZr: function(e, t, n) {
        "use strict";
        n.d(t, "k", function() {
            return r
        }),
        n.d(t, "d", function() {
            return s
        }),
        n.d(t, "e", function() {
            return i
        }),
        n.d(t, "j", function() {
            return o
        }),
        n.d(t, "c", function() {
            return a
        }),
        n.d(t, "f", function() {
            return c
        }),
        n.d(t, "g", function() {
            return l
        }),
        n.d(t, "l", function() {
            return u
        }),
        n.d(t, "i", function() {
            return h
        }),
        n.d(t, "b", function() {
            return d
        }),
        n.d(t, "n", function() {
            return f
        }),
        n.d(t, "h", function() {
            return p
        }),
        n.d(t, "a", function() {
            return m
        }),
        n.d(t, "m", function() {
            return g
        }),
        n.d(t, "o", function() {
            return b
        });
        const r = 9
          , s = 13
          , i = 27
          , o = 32
          , a = 35
          , c = 36
          , l = 37
          , u = 38
          , h = 39
          , d = 40
          , f = 48
          , p = 57
          , m = 65
          , g = 90;
        function b(e, ...t) {
            return t.length ? t.some(t => e[t]) : e.altKey || e.shiftKey || e.ctrlKey || e.metaKey
        }
    },
    "eD/y": function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        }),
        n.d(t, "b", function() {
            return s
        });
        const r = "wTid";
        var s = function(e) {
            return e.IsDisplayService = "IsDisplayService",
            e.IsDisplayLegend = "IsDisplayLegend",
            e.IsDisplayCongestion = "IsDisplayCongestion",
            e.AutoUpdateSpan = "AutoUpdateSpan",
            e.LastCautionDate = "LastCautionDate",
            e
        }({})
    },
    eIep: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return c
        });
        var r = n("l7GE")
          , s = n("51Dv")
          , i = n("ZUHj")
          , o = n("lJxs")
          , a = n("Cfvw");
        function c(e, t) {
            return "function" == typeof t ? n => n.pipe(c( (n, r) => Object(a.a)(e(n, r)).pipe(Object(o.a)( (e, s) => t(n, e, r, s))))) : t => t.lift(new l(e))
        }
        class l {
            constructor(e) {
                this.project = e
            }
            call(e, t) {
                return t.subscribe(new u(e,this.project))
            }
        }
        class u extends r.a {
            constructor(e, t) {
                super(e),
                this.project = t,
                this.index = 0
            }
            _next(e) {
                let t;
                const n = this.index++;
                try {
                    t = this.project(e, n)
                } catch (r) {
                    return void this.destination.error(r)
                }
                this._innerSub(t, e, n)
            }
            _innerSub(e, t, n) {
                const r = this.innerSubscription;
                r && r.unsubscribe();
                const o = new s.a(this,void 0,void 0);
                this.destination.add(o),
                this.innerSubscription = Object(i.a)(this, e, t, n, o)
            }
            _complete() {
                const {innerSubscription: e} = this;
                e && !e.closed || super._complete(),
                this.unsubscribe()
            }
            _unsubscribe() {
                this.innerSubscription = null
            }
            notifyComplete(e) {
                this.destination.remove(e),
                this.innerSubscription = null,
                this.isStopped && super._complete()
            }
            notifyNext(e, t, n, r, s) {
                this.destination.next(t)
            }
        }
    },
    fDlF: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return C
        }),
        n.d(t, "c", function() {
            return Te
        }),
        n.d(t, "g", function() {
            return xe
        }),
        n.d(t, "e", function() {
            return S
        }),
        n.d(t, "b", function() {
            return at
        }),
        n.d(t, "d", function() {
            return It
        }),
        n.d(t, "f", function() {
            return Dt
        }),
        n.d(t, "h", function() {
            return Rt
        });
        var r = n("GS7A");
        function s() {
            return "undefined" != typeof process
        }
        function i(e) {
            switch (e.length) {
            case 0:
                return new r.d;
            case 1:
                return e[0];
            default:
                return new r.k(e)
            }
        }
        function o(e, t, n, s, i={}, o={}) {
            const a = []
              , c = [];
            let l = -1
              , u = null;
            if (s.forEach(e => {
                const n = e.offset
                  , s = n == l
                  , h = s && u || {};
                Object.keys(e).forEach(n => {
                    let s = n
                      , c = e[n];
                    if ("offset" !== n)
                        switch (s = t.normalizePropertyName(s, a),
                        c) {
                        case r.l:
                            c = i[n];
                            break;
                        case r.a:
                            c = o[n];
                            break;
                        default:
                            c = t.normalizeStyleValue(n, s, c, a)
                        }
                    h[s] = c
                }
                ),
                s || c.push(h),
                u = h,
                l = n
            }
            ),
            a.length) {
                const e = "\n - ";
                throw new Error(`Unable to animate due to the following errors:${e}${a.join(e)}`)
            }
            return c
        }
        function a(e, t, n, r) {
            switch (t) {
            case "start":
                e.onStart( () => r(n && c(n, "start", e)));
                break;
            case "done":
                e.onDone( () => r(n && c(n, "done", e)));
                break;
            case "destroy":
                e.onDestroy( () => r(n && c(n, "destroy", e)))
            }
        }
        function c(e, t, n) {
            const r = n.totalTime
              , s = l(e.element, e.triggerName, e.fromState, e.toState, t || e.phaseName, null == r ? e.totalTime : r, !!n.disabled)
              , i = e._data;
            return null != i && (s._data = i),
            s
        }
        function l(e, t, n, r, s="", i=0, o) {
            return {
                element: e,
                triggerName: t,
                fromState: n,
                toState: r,
                phaseName: s,
                totalTime: i,
                disabled: !!o
            }
        }
        function u(e, t, n) {
            let r;
            return e instanceof Map ? (r = e.get(t)) || e.set(t, r = n) : (r = e[t]) || (r = e[t] = n),
            r
        }
        function h(e) {
            const t = e.indexOf(":");
            return [e.substring(1, t), e.substr(t + 1)]
        }
        let d = (e, t) => !1
          , f = (e, t) => !1
          , p = (e, t, n) => [];
        const m = s();
        (m || "undefined" != typeof Element) && (d = (e, t) => e.contains(t),
        f = ( () => {
            if (m || Element.prototype.matches)
                return (e, t) => e.matches(t);
            {
                const e = Element.prototype
                  , t = e.matchesSelector || e.mozMatchesSelector || e.msMatchesSelector || e.oMatchesSelector || e.webkitMatchesSelector;
                return t ? (e, n) => t.apply(e, [n]) : f
            }
        }
        )(),
        p = (e, t, n) => {
            let r = [];
            if (n)
                r.push(...e.querySelectorAll(t));
            else {
                const n = e.querySelector(t);
                n && r.push(n)
            }
            return r
        }
        );
        let g = null
          , b = !1;
        function y(e) {
            g || (g = ("undefined" != typeof document ? document.body : null) || {},
            b = !!g.style && "WebkitAppearance"in g.style);
            let t = !0;
            return g.style && !function(e) {
                return "ebkit" == e.substring(1, 6)
            }(e) && !(t = e in g.style) && b && (t = "Webkit" + e.charAt(0).toUpperCase() + e.substr(1)in g.style),
            t
        }
        const v = f
          , _ = d
          , w = p;
        function E(e) {
            const t = {};
            return Object.keys(e).forEach(n => {
                const r = n.replace(/([a-z])([A-Z])/g, "$1-$2");
                t[r] = e[n]
            }
            ),
            t
        }
        class S {
            validateStyleProperty(e) {
                return y(e)
            }
            matchesElement(e, t) {
                return v(e, t)
            }
            containsElement(e, t) {
                return _(e, t)
            }
            query(e, t, n) {
                return w(e, t, n)
            }
            computeStyle(e, t, n) {
                return n || ""
            }
            animate(e, t, n, s, i, o=[], a) {
                return new r.d(n,s)
            }
        }
        let C = ( () => {
            class e {
            }
            return e.NOOP = new S,
            e
        }
        )();
        const T = 1e3
          , x = "{{"
          , k = "ng-enter"
          , O = "ng-leave"
          , I = "ng-trigger"
          , A = ".ng-trigger"
          , D = "ng-animating"
          , R = ".ng-animating";
        function j(e) {
            if ("number" == typeof e)
                return e;
            const t = e.match(/^(-?[\.\d]+)(m?s)/);
            return !t || t.length < 2 ? 0 : N(parseFloat(t[1]), t[2])
        }
        function N(e, t) {
            switch (t) {
            case "s":
                return e * T;
            default:
                return e
            }
        }
        function P(e, t, n) {
            return e.hasOwnProperty("duration") ? e : function(e, t, n) {
                let r, s = 0, i = "";
                if ("string" == typeof e) {
                    const n = e.match(/^(-?[\.\d]+)(m?s)(?:\s+(-?[\.\d]+)(m?s))?(?:\s+([-a-z]+(?:\(.+?\))?))?$/i);
                    if (null === n)
                        return t.push(`The provided timing value "${e}" is invalid.`),
                        {
                            duration: 0,
                            delay: 0,
                            easing: ""
                        };
                    r = N(parseFloat(n[1]), n[2]);
                    const o = n[3];
                    null != o && (s = N(parseFloat(o), n[4]));
                    const a = n[5];
                    a && (i = a)
                } else
                    r = e;
                if (!n) {
                    let n = !1
                      , i = t.length;
                    r < 0 && (t.push("Duration values below 0 are not allowed for this animation step."),
                    n = !0),
                    s < 0 && (t.push("Delay values below 0 are not allowed for this animation step."),
                    n = !0),
                    n && t.splice(i, 0, `The provided timing value "${e}" is invalid.`)
                }
                return {
                    duration: r,
                    delay: s,
                    easing: i
                }
            }(e, t, n)
        }
        function M(e, t={}) {
            return Object.keys(e).forEach(n => {
                t[n] = e[n]
            }
            ),
            t
        }
        function L(e, t, n={}) {
            if (t)
                for (let r in e)
                    n[r] = e[r];
            else
                M(e, n);
            return n
        }
        function F(e, t, n) {
            return n ? t + ":" + n + ";" : ""
        }
        function U(e) {
            let t = "";
            for (let n = 0; n < e.style.length; n++) {
                const r = e.style.item(n);
                t += F(0, r, e.style.getPropertyValue(r))
            }
            for (const n in e.style)
                e.style.hasOwnProperty(n) && !n.startsWith("_") && (t += F(0, n.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase(), e.style[n]));
            e.setAttribute("style", t)
        }
        function z(e, t, n) {
            e.style && (Object.keys(t).forEach(r => {
                const s = K(r);
                n && !n.hasOwnProperty(r) && (n[r] = e.style[s]),
                e.style[s] = t[r]
            }
            ),
            s() && U(e))
        }
        function H(e, t) {
            e.style && (Object.keys(t).forEach(t => {
                const n = K(t);
                e.style[n] = ""
            }
            ),
            s() && U(e))
        }
        function B(e) {
            return Array.isArray(e) ? 1 == e.length ? e[0] : Object(r.f)(e) : e
        }
        const V = new RegExp(`${x}\\s*(.+?)\\s*}}`,"g");
        function $(e) {
            let t = [];
            if ("string" == typeof e) {
                const n = e.toString();
                let r;
                for (; r = V.exec(n); )
                    t.push(r[1]);
                V.lastIndex = 0
            }
            return t
        }
        function q(e, t, n) {
            const r = e.toString()
              , s = r.replace(V, (e, r) => {
                let s = t[r];
                return t.hasOwnProperty(r) || (n.push(`Please provide a value for the animation param ${r}`),
                s = ""),
                s.toString()
            }
            );
            return s == r ? e : s
        }
        function Q(e) {
            const t = [];
            let n = e.next();
            for (; !n.done; )
                t.push(n.value),
                n = e.next();
            return t
        }
        const G = /-+([a-z0-9])/g;
        function K(e) {
            return e.replace(G, (...e) => e[1].toUpperCase())
        }
        function W(e, t) {
            return 0 === e || 0 === t
        }
        function Z(e, t, n) {
            const r = Object.keys(n);
            if (r.length && t.length) {
                let i = t[0]
                  , o = [];
                if (r.forEach(e => {
                    i.hasOwnProperty(e) || o.push(e),
                    i[e] = n[e]
                }
                ),
                o.length)
                    for (var s = 1; s < t.length; s++) {
                        let n = t[s];
                        o.forEach(function(t) {
                            n[t] = J(e, t)
                        })
                    }
            }
            return t
        }
        function Y(e, t, n) {
            switch (t.type) {
            case 7:
                return e.visitTrigger(t, n);
            case 0:
                return e.visitState(t, n);
            case 1:
                return e.visitTransition(t, n);
            case 2:
                return e.visitSequence(t, n);
            case 3:
                return e.visitGroup(t, n);
            case 4:
                return e.visitAnimate(t, n);
            case 5:
                return e.visitKeyframes(t, n);
            case 6:
                return e.visitStyle(t, n);
            case 8:
                return e.visitReference(t, n);
            case 9:
                return e.visitAnimateChild(t, n);
            case 10:
                return e.visitAnimateRef(t, n);
            case 11:
                return e.visitQuery(t, n);
            case 12:
                return e.visitStagger(t, n);
            default:
                throw new Error(`Unable to resolve animation metadata node #${t.type}`)
            }
        }
        function J(e, t) {
            return window.getComputedStyle(e)[t]
        }
        const X = "*";
        function ee(e, t) {
            const n = [];
            return "string" == typeof e ? e.split(/\s*,\s*/).forEach(e => (function(e, t, n) {
                if (":" == e[0]) {
                    const r = function(e, t) {
                        switch (e) {
                        case ":enter":
                            return "void => *";
                        case ":leave":
                            return "* => void";
                        case ":increment":
                            return (e, t) => parseFloat(t) > parseFloat(e);
                        case ":decrement":
                            return (e, t) => parseFloat(t) < parseFloat(e);
                        default:
                            return t.push(`The transition alias value "${e}" is not supported`),
                            "* => *"
                        }
                    }(e, n);
                    if ("function" == typeof r)
                        return void t.push(r);
                    e = r
                }
                const r = e.match(/^(\*|[-\w]+)\s*(<?[=-]>)\s*(\*|[-\w]+)$/);
                if (null == r || r.length < 4)
                    return n.push(`The provided transition expression "${e}" is not supported`),
                    t;
                const s = r[1]
                  , i = r[2]
                  , o = r[3];
                t.push(re(s, o)),
                "<" != i[0] || s == X && o == X || t.push(re(o, s))
            }
            )(e, n, t)) : n.push(e),
            n
        }
        const te = new Set(["true", "1"])
          , ne = new Set(["false", "0"]);
        function re(e, t) {
            const n = te.has(e) || ne.has(e)
              , r = te.has(t) || ne.has(t);
            return (s, i) => {
                let o = e == X || e == s
                  , a = t == X || t == i;
                return !o && n && "boolean" == typeof s && (o = s ? te.has(e) : ne.has(e)),
                !a && r && "boolean" == typeof i && (a = i ? te.has(t) : ne.has(t)),
                o && a
            }
        }
        const se = ":self"
          , ie = new RegExp(`s*${se}s*,?`,"g");
        function oe(e, t, n) {
            return new ce(e).build(t, n)
        }
        const ae = "";
        class ce {
            constructor(e) {
                this._driver = e
            }
            build(e, t) {
                const n = new le(t);
                return this._resetContextStyleTimingState(n),
                Y(this, B(e), n)
            }
            _resetContextStyleTimingState(e) {
                e.currentQuerySelector = ae,
                e.collectedStyles = {},
                e.collectedStyles[ae] = {},
                e.currentTime = 0
            }
            visitTrigger(e, t) {
                let n = t.queryCount = 0
                  , r = t.depCount = 0;
                const s = []
                  , i = [];
                return "@" == e.name.charAt(0) && t.errors.push("animation triggers cannot be prefixed with an `@` sign (e.g. trigger('@foo', [...]))"),
                e.definitions.forEach(e => {
                    if (this._resetContextStyleTimingState(t),
                    0 == e.type) {
                        const n = e
                          , r = n.name;
                        r.toString().split(/\s*,\s*/).forEach(e => {
                            n.name = e,
                            s.push(this.visitState(n, t))
                        }
                        ),
                        n.name = r
                    } else if (1 == e.type) {
                        const s = this.visitTransition(e, t);
                        n += s.queryCount,
                        r += s.depCount,
                        i.push(s)
                    } else
                        t.errors.push("only state() and transition() definitions can sit inside of a trigger()")
                }
                ),
                {
                    type: 7,
                    name: e.name,
                    states: s,
                    transitions: i,
                    queryCount: n,
                    depCount: r,
                    options: null
                }
            }
            visitState(e, t) {
                const n = this.visitStyle(e.styles, t)
                  , r = e.options && e.options.params || null;
                if (n.containsDynamicStyles) {
                    const s = new Set
                      , i = r || {};
                    if (n.styles.forEach(e => {
                        if (ue(e)) {
                            const t = e;
                            Object.keys(t).forEach(e => {
                                $(t[e]).forEach(e => {
                                    i.hasOwnProperty(e) || s.add(e)
                                }
                                )
                            }
                            )
                        }
                    }
                    ),
                    s.size) {
                        const n = Q(s.values());
                        t.errors.push(`state("${e.name}", ...) must define default values for all the following style substitutions: ${n.join(", ")}`)
                    }
                }
                return {
                    type: 0,
                    name: e.name,
                    style: n,
                    options: r ? {
                        params: r
                    } : null
                }
            }
            visitTransition(e, t) {
                t.queryCount = 0,
                t.depCount = 0;
                const n = Y(this, B(e.animation), t);
                return {
                    type: 1,
                    matchers: ee(e.expr, t.errors),
                    animation: n,
                    queryCount: t.queryCount,
                    depCount: t.depCount,
                    options: he(e.options)
                }
            }
            visitSequence(e, t) {
                return {
                    type: 2,
                    steps: e.steps.map(e => Y(this, e, t)),
                    options: he(e.options)
                }
            }
            visitGroup(e, t) {
                const n = t.currentTime;
                let r = 0;
                const s = e.steps.map(e => {
                    t.currentTime = n;
                    const s = Y(this, e, t);
                    return r = Math.max(r, t.currentTime),
                    s
                }
                );
                return t.currentTime = r,
                {
                    type: 3,
                    steps: s,
                    options: he(e.options)
                }
            }
            visitAnimate(e, t) {
                const n = function(e, t) {
                    let n = null;
                    if (e.hasOwnProperty("duration"))
                        n = e;
                    else if ("number" == typeof e)
                        return de(P(e, t).duration, 0, "");
                    const r = e;
                    if (r.split(/\s+/).some(e => "{" == e.charAt(0) && "{" == e.charAt(1))) {
                        const e = de(0, 0, "");
                        return e.dynamic = !0,
                        e.strValue = r,
                        e
                    }
                    return de((n = n || P(r, t)).duration, n.delay, n.easing)
                }(e.timings, t.errors);
                let s;
                t.currentAnimateTimings = n;
                let i = e.styles ? e.styles : Object(r.h)({});
                if (5 == i.type)
                    s = this.visitKeyframes(i, t);
                else {
                    let i = e.styles
                      , o = !1;
                    if (!i) {
                        o = !0;
                        const e = {};
                        n.easing && (e.easing = n.easing),
                        i = Object(r.h)(e)
                    }
                    t.currentTime += n.duration + n.delay;
                    const a = this.visitStyle(i, t);
                    a.isEmptyStep = o,
                    s = a
                }
                return t.currentAnimateTimings = null,
                {
                    type: 4,
                    timings: n,
                    style: s,
                    options: null
                }
            }
            visitStyle(e, t) {
                const n = this._makeStyleAst(e, t);
                return this._validateStyleAst(n, t),
                n
            }
            _makeStyleAst(e, t) {
                const n = [];
                Array.isArray(e.styles) ? e.styles.forEach(e => {
                    "string" == typeof e ? e == r.a ? n.push(e) : t.errors.push(`The provided style string value ${e} is not allowed.`) : n.push(e)
                }
                ) : n.push(e.styles);
                let s = !1
                  , i = null;
                return n.forEach(e => {
                    if (ue(e)) {
                        const t = e
                          , n = t.easing;
                        if (n && (i = n,
                        delete t.easing),
                        !s)
                            for (let e in t)
                                if (t[e].toString().indexOf(x) >= 0) {
                                    s = !0;
                                    break
                                }
                    }
                }
                ),
                {
                    type: 6,
                    styles: n,
                    easing: i,
                    offset: e.offset,
                    containsDynamicStyles: s,
                    options: null
                }
            }
            _validateStyleAst(e, t) {
                const n = t.currentAnimateTimings;
                let r = t.currentTime
                  , s = t.currentTime;
                n && s > 0 && (s -= n.duration + n.delay),
                e.styles.forEach(e => {
                    "string" != typeof e && Object.keys(e).forEach(n => {
                        if (!this._driver.validateStyleProperty(n))
                            return void t.errors.push(`The provided animation property "${n}" is not a supported CSS property for animations`);
                        const i = t.collectedStyles[t.currentQuerySelector]
                          , o = i[n];
                        let a = !0;
                        o && (s != r && s >= o.startTime && r <= o.endTime && (t.errors.push(`The CSS property "${n}" that exists between the times of "${o.startTime}ms" and "${o.endTime}ms" is also being animated in a parallel animation between the times of "${s}ms" and "${r}ms"`),
                        a = !1),
                        s = o.startTime),
                        a && (i[n] = {
                            startTime: s,
                            endTime: r
                        }),
                        t.options && function(r, s, i) {
                            const o = t.options.params || {}
                              , a = $(e[n]);
                            a.length && a.forEach(e => {
                                o.hasOwnProperty(e) || i.push(`Unable to resolve the local animation param ${e} in the given list of values`)
                            }
                            )
                        }(0, 0, t.errors)
                    }
                    )
                }
                )
            }
            visitKeyframes(e, t) {
                const n = {
                    type: 5,
                    styles: [],
                    options: null
                };
                if (!t.currentAnimateTimings)
                    return t.errors.push("keyframes() must be placed inside of a call to animate()"),
                    n;
                let r = 0;
                const s = [];
                let i = !1
                  , o = !1
                  , a = 0;
                const c = e.steps.map(e => {
                    const n = this._makeStyleAst(e, t);
                    let c = null != n.offset ? n.offset : function(e) {
                        if ("string" == typeof e)
                            return null;
                        let t = null;
                        if (Array.isArray(e))
                            e.forEach(e => {
                                if (ue(e) && e.hasOwnProperty("offset")) {
                                    const n = e;
                                    t = parseFloat(n.offset),
                                    delete n.offset
                                }
                            }
                            );
                        else if (ue(e) && e.hasOwnProperty("offset")) {
                            const n = e;
                            t = parseFloat(n.offset),
                            delete n.offset
                        }
                        return t
                    }(n.styles)
                      , l = 0;
                    return null != c && (r++,
                    l = n.offset = c),
                    o = o || l < 0 || l > 1,
                    i = i || l < a,
                    a = l,
                    s.push(l),
                    n
                }
                );
                o && t.errors.push("Please ensure that all keyframe offsets are between 0 and 1"),
                i && t.errors.push("Please ensure that all keyframe offsets are in order");
                const l = e.steps.length;
                let u = 0;
                r > 0 && r < l ? t.errors.push("Not all style() steps within the declared keyframes() contain offsets") : 0 == r && (u = 1 / (l - 1));
                const h = l - 1
                  , d = t.currentTime
                  , f = t.currentAnimateTimings
                  , p = f.duration;
                return c.forEach( (e, r) => {
                    const i = u > 0 ? r == h ? 1 : u * r : s[r]
                      , o = i * p;
                    t.currentTime = d + f.delay + o,
                    f.duration = o,
                    this._validateStyleAst(e, t),
                    e.offset = i,
                    n.styles.push(e)
                }
                ),
                n
            }
            visitReference(e, t) {
                return {
                    type: 8,
                    animation: Y(this, B(e.animation), t),
                    options: he(e.options)
                }
            }
            visitAnimateChild(e, t) {
                return t.depCount++,
                {
                    type: 9,
                    options: he(e.options)
                }
            }
            visitAnimateRef(e, t) {
                return {
                    type: 10,
                    animation: this.visitReference(e.animation, t),
                    options: he(e.options)
                }
            }
            visitQuery(e, t) {
                const n = t.currentQuerySelector
                  , r = e.options || {};
                t.queryCount++,
                t.currentQuery = e;
                const [s,i] = function(e) {
                    const t = !!e.split(/\s*,\s*/).find(e => e == se);
                    return t && (e = e.replace(ie, "")),
                    [e = e.replace(/@\*/g, A).replace(/@\w+/g, e => A + "-" + e.substr(1)).replace(/:animating/g, R), t]
                }(e.selector);
                t.currentQuerySelector = n.length ? n + " " + s : s,
                u(t.collectedStyles, t.currentQuerySelector, {});
                const o = Y(this, B(e.animation), t);
                return t.currentQuery = null,
                t.currentQuerySelector = n,
                {
                    type: 11,
                    selector: s,
                    limit: r.limit || 0,
                    optional: !!r.optional,
                    includeSelf: i,
                    animation: o,
                    originalSelector: e.selector,
                    options: he(e.options)
                }
            }
            visitStagger(e, t) {
                t.currentQuery || t.errors.push("stagger() can only be used inside of query()");
                const n = "full" === e.timings ? {
                    duration: 0,
                    delay: 0,
                    easing: "full"
                } : P(e.timings, t.errors, !0);
                return {
                    type: 12,
                    animation: Y(this, B(e.animation), t),
                    timings: n,
                    options: null
                }
            }
        }
        class le {
            constructor(e) {
                this.errors = e,
                this.queryCount = 0,
                this.depCount = 0,
                this.currentTransition = null,
                this.currentQuery = null,
                this.currentQuerySelector = null,
                this.currentAnimateTimings = null,
                this.currentTime = 0,
                this.collectedStyles = {},
                this.options = null
            }
        }
        function ue(e) {
            return !Array.isArray(e) && "object" == typeof e
        }
        function he(e) {
            var t;
            return e ? (e = M(e)).params && (e.params = (t = e.params) ? M(t) : null) : e = {},
            e
        }
        function de(e, t, n) {
            return {
                duration: e,
                delay: t,
                easing: n
            }
        }
        function fe(e, t, n, r, s, i, o=null, a=!1) {
            return {
                type: 1,
                element: e,
                keyframes: t,
                preStyleProps: n,
                postStyleProps: r,
                duration: s,
                delay: i,
                totalTime: s + i,
                easing: o,
                subTimeline: a
            }
        }
        class pe {
            constructor() {
                this._map = new Map
            }
            consume(e) {
                let t = this._map.get(e);
                return t ? this._map.delete(e) : t = [],
                t
            }
            append(e, t) {
                let n = this._map.get(e);
                n || this._map.set(e, n = []),
                n.push(...t)
            }
            has(e) {
                return this._map.has(e)
            }
            clear() {
                this._map.clear()
            }
        }
        const me = 1
          , ge = new RegExp(":enter","g")
          , be = new RegExp(":leave","g");
        function ye(e, t, n, r, s, i={}, o={}, a, c, l=[]) {
            return (new ve).buildKeyframes(e, t, n, r, s, i, o, a, c, l)
        }
        class ve {
            buildKeyframes(e, t, n, r, s, i, o, a, c, l=[]) {
                c = c || new pe;
                const u = new we(e,t,c,r,s,l,[]);
                u.options = a,
                u.currentTimeline.setStyles([i], null, u.errors, a),
                Y(this, n, u);
                const h = u.timelines.filter(e => e.containsAnimation());
                if (h.length && Object.keys(o).length) {
                    const e = h[h.length - 1];
                    e.allowOnlyTimelineStyles() || e.setStyles([o], null, u.errors, a)
                }
                return h.length ? h.map(e => e.buildKeyframes()) : [fe(t, [], [], [], 0, 0, "", !1)]
            }
            visitTrigger(e, t) {}
            visitState(e, t) {}
            visitTransition(e, t) {}
            visitAnimateChild(e, t) {
                const n = t.subInstructions.consume(t.element);
                if (n) {
                    const r = t.createSubContext(e.options)
                      , s = t.currentTimeline.currentTime
                      , i = this._visitSubInstructions(n, r, r.options);
                    s != i && t.transformIntoNewTimeline(i)
                }
                t.previousNode = e
            }
            visitAnimateRef(e, t) {
                const n = t.createSubContext(e.options);
                n.transformIntoNewTimeline(),
                this.visitReference(e.animation, n),
                t.transformIntoNewTimeline(n.currentTimeline.currentTime),
                t.previousNode = e
            }
            _visitSubInstructions(e, t, n) {
                let r = t.currentTimeline.currentTime;
                const s = null != n.duration ? j(n.duration) : null
                  , i = null != n.delay ? j(n.delay) : null;
                return 0 !== s && e.forEach(e => {
                    const n = t.appendInstructionToTimeline(e, s, i);
                    r = Math.max(r, n.duration + n.delay)
                }
                ),
                r
            }
            visitReference(e, t) {
                t.updateOptions(e.options, !0),
                Y(this, e.animation, t),
                t.previousNode = e
            }
            visitSequence(e, t) {
                const n = t.subContextCount;
                let r = t;
                const s = e.options;
                if (s && (s.params || s.delay) && ((r = t.createSubContext(s)).transformIntoNewTimeline(),
                null != s.delay)) {
                    6 == r.previousNode.type && (r.currentTimeline.snapshotCurrentStyles(),
                    r.previousNode = _e);
                    const e = j(s.delay);
                    r.delayNextStep(e)
                }
                e.steps.length && (e.steps.forEach(e => Y(this, e, r)),
                r.currentTimeline.applyStylesToKeyframe(),
                r.subContextCount > n && r.transformIntoNewTimeline()),
                t.previousNode = e
            }
            visitGroup(e, t) {
                const n = [];
                let r = t.currentTimeline.currentTime;
                const s = e.options && e.options.delay ? j(e.options.delay) : 0;
                e.steps.forEach(i => {
                    const o = t.createSubContext(e.options);
                    s && o.delayNextStep(s),
                    Y(this, i, o),
                    r = Math.max(r, o.currentTimeline.currentTime),
                    n.push(o.currentTimeline)
                }
                ),
                n.forEach(e => t.currentTimeline.mergeTimelineCollectedStyles(e)),
                t.transformIntoNewTimeline(r),
                t.previousNode = e
            }
            _visitTiming(e, t) {
                if (e.dynamic) {
                    const n = e.strValue;
                    return P(t.params ? q(n, t.params, t.errors) : n, t.errors)
                }
                return {
                    duration: e.duration,
                    delay: e.delay,
                    easing: e.easing
                }
            }
            visitAnimate(e, t) {
                const n = t.currentAnimateTimings = this._visitTiming(e.timings, t)
                  , r = t.currentTimeline;
                n.delay && (t.incrementTime(n.delay),
                r.snapshotCurrentStyles());
                const s = e.style;
                5 == s.type ? this.visitKeyframes(s, t) : (t.incrementTime(n.duration),
                this.visitStyle(s, t),
                r.applyStylesToKeyframe()),
                t.currentAnimateTimings = null,
                t.previousNode = e
            }
            visitStyle(e, t) {
                const n = t.currentTimeline
                  , r = t.currentAnimateTimings;
                !r && n.getCurrentStyleProperties().length && n.forwardFrame();
                const s = r && r.easing || e.easing;
                e.isEmptyStep ? n.applyEmptyStep(s) : n.setStyles(e.styles, s, t.errors, t.options),
                t.previousNode = e
            }
            visitKeyframes(e, t) {
                const n = t.currentAnimateTimings
                  , r = t.currentTimeline.duration
                  , s = n.duration
                  , i = t.createSubContext().currentTimeline;
                i.easing = n.easing,
                e.styles.forEach(e => {
                    i.forwardTime((e.offset || 0) * s),
                    i.setStyles(e.styles, e.easing, t.errors, t.options),
                    i.applyStylesToKeyframe()
                }
                ),
                t.currentTimeline.mergeTimelineCollectedStyles(i),
                t.transformIntoNewTimeline(r + s),
                t.previousNode = e
            }
            visitQuery(e, t) {
                const n = t.currentTimeline.currentTime
                  , r = e.options || {}
                  , s = r.delay ? j(r.delay) : 0;
                s && (6 === t.previousNode.type || 0 == n && t.currentTimeline.getCurrentStyleProperties().length) && (t.currentTimeline.snapshotCurrentStyles(),
                t.previousNode = _e);
                let i = n;
                const o = t.invokeQuery(e.selector, e.originalSelector, e.limit, e.includeSelf, !!r.optional, t.errors);
                t.currentQueryTotal = o.length;
                let a = null;
                o.forEach( (n, r) => {
                    t.currentQueryIndex = r;
                    const o = t.createSubContext(e.options, n);
                    s && o.delayNextStep(s),
                    n === t.element && (a = o.currentTimeline),
                    Y(this, e.animation, o),
                    o.currentTimeline.applyStylesToKeyframe(),
                    i = Math.max(i, o.currentTimeline.currentTime)
                }
                ),
                t.currentQueryIndex = 0,
                t.currentQueryTotal = 0,
                t.transformIntoNewTimeline(i),
                a && (t.currentTimeline.mergeTimelineCollectedStyles(a),
                t.currentTimeline.snapshotCurrentStyles()),
                t.previousNode = e
            }
            visitStagger(e, t) {
                const n = t.parentContext
                  , r = t.currentTimeline
                  , s = e.timings
                  , i = Math.abs(s.duration)
                  , o = i * (t.currentQueryTotal - 1);
                let a = i * t.currentQueryIndex;
                switch (s.duration < 0 ? "reverse" : s.easing) {
                case "reverse":
                    a = o - a;
                    break;
                case "full":
                    a = n.currentStaggerTime
                }
                const c = t.currentTimeline;
                a && c.delayNextStep(a);
                const l = c.currentTime;
                Y(this, e.animation, t),
                t.previousNode = e,
                n.currentStaggerTime = r.currentTime - l + (r.startTime - n.currentTimeline.startTime)
            }
        }
        const _e = {};
        class we {
            constructor(e, t, n, r, s, i, o, a) {
                this._driver = e,
                this.element = t,
                this.subInstructions = n,
                this._enterClassName = r,
                this._leaveClassName = s,
                this.errors = i,
                this.timelines = o,
                this.parentContext = null,
                this.currentAnimateTimings = null,
                this.previousNode = _e,
                this.subContextCount = 0,
                this.options = {},
                this.currentQueryIndex = 0,
                this.currentQueryTotal = 0,
                this.currentStaggerTime = 0,
                this.currentTimeline = a || new Ee(this._driver,t,0),
                o.push(this.currentTimeline)
            }
            get params() {
                return this.options.params
            }
            updateOptions(e, t) {
                if (!e)
                    return;
                const n = e;
                let r = this.options;
                null != n.duration && (r.duration = j(n.duration)),
                null != n.delay && (r.delay = j(n.delay));
                const s = n.params;
                if (s) {
                    let e = r.params;
                    e || (e = this.options.params = {}),
                    Object.keys(s).forEach(n => {
                        t && e.hasOwnProperty(n) || (e[n] = q(s[n], e, this.errors))
                    }
                    )
                }
            }
            _copyOptions() {
                const e = {};
                if (this.options) {
                    const t = this.options.params;
                    if (t) {
                        const n = e.params = {};
                        Object.keys(t).forEach(e => {
                            n[e] = t[e]
                        }
                        )
                    }
                }
                return e
            }
            createSubContext(e=null, t, n) {
                const r = t || this.element
                  , s = new we(this._driver,r,this.subInstructions,this._enterClassName,this._leaveClassName,this.errors,this.timelines,this.currentTimeline.fork(r, n || 0));
                return s.previousNode = this.previousNode,
                s.currentAnimateTimings = this.currentAnimateTimings,
                s.options = this._copyOptions(),
                s.updateOptions(e),
                s.currentQueryIndex = this.currentQueryIndex,
                s.currentQueryTotal = this.currentQueryTotal,
                s.parentContext = this,
                this.subContextCount++,
                s
            }
            transformIntoNewTimeline(e) {
                return this.previousNode = _e,
                this.currentTimeline = this.currentTimeline.fork(this.element, e),
                this.timelines.push(this.currentTimeline),
                this.currentTimeline
            }
            appendInstructionToTimeline(e, t, n) {
                const r = {
                    duration: null != t ? t : e.duration,
                    delay: this.currentTimeline.currentTime + (null != n ? n : 0) + e.delay,
                    easing: ""
                }
                  , s = new Se(this._driver,e.element,e.keyframes,e.preStyleProps,e.postStyleProps,r,e.stretchStartingKeyframe);
                return this.timelines.push(s),
                r
            }
            incrementTime(e) {
                this.currentTimeline.forwardTime(this.currentTimeline.duration + e)
            }
            delayNextStep(e) {
                e > 0 && this.currentTimeline.delayNextStep(e)
            }
            invokeQuery(e, t, n, r, s, i) {
                let o = [];
                if (r && o.push(this.element),
                e.length > 0) {
                    e = (e = e.replace(ge, "." + this._enterClassName)).replace(be, "." + this._leaveClassName);
                    let t = this._driver.query(this.element, e, 1 != n);
                    0 !== n && (t = n < 0 ? t.slice(t.length + n, t.length) : t.slice(0, n)),
                    o.push(...t)
                }
                return s || 0 != o.length || i.push(`\`query("${t}")\` returned zero elements. (Use \`query("${t}", { optional: true })\` if you wish to allow this.)`),
                o
            }
        }
        class Ee {
            constructor(e, t, n, r) {
                this._driver = e,
                this.element = t,
                this.startTime = n,
                this._elementTimelineStylesLookup = r,
                this.duration = 0,
                this._previousKeyframe = {},
                this._currentKeyframe = {},
                this._keyframes = new Map,
                this._styleSummary = {},
                this._pendingStyles = {},
                this._backFill = {},
                this._currentEmptyStepKeyframe = null,
                this._elementTimelineStylesLookup || (this._elementTimelineStylesLookup = new Map),
                this._localTimelineStyles = Object.create(this._backFill, {}),
                this._globalTimelineStyles = this._elementTimelineStylesLookup.get(t),
                this._globalTimelineStyles || (this._globalTimelineStyles = this._localTimelineStyles,
                this._elementTimelineStylesLookup.set(t, this._localTimelineStyles)),
                this._loadKeyframe()
            }
            containsAnimation() {
                switch (this._keyframes.size) {
                case 0:
                    return !1;
                case 1:
                    return this.getCurrentStyleProperties().length > 0;
                default:
                    return !0
                }
            }
            getCurrentStyleProperties() {
                return Object.keys(this._currentKeyframe)
            }
            get currentTime() {
                return this.startTime + this.duration
            }
            delayNextStep(e) {
                const t = 1 == this._keyframes.size && Object.keys(this._pendingStyles).length;
                this.duration || t ? (this.forwardTime(this.currentTime + e),
                t && this.snapshotCurrentStyles()) : this.startTime += e
            }
            fork(e, t) {
                return this.applyStylesToKeyframe(),
                new Ee(this._driver,e,t || this.currentTime,this._elementTimelineStylesLookup)
            }
            _loadKeyframe() {
                this._currentKeyframe && (this._previousKeyframe = this._currentKeyframe),
                this._currentKeyframe = this._keyframes.get(this.duration),
                this._currentKeyframe || (this._currentKeyframe = Object.create(this._backFill, {}),
                this._keyframes.set(this.duration, this._currentKeyframe))
            }
            forwardFrame() {
                this.duration += me,
                this._loadKeyframe()
            }
            forwardTime(e) {
                this.applyStylesToKeyframe(),
                this.duration = e,
                this._loadKeyframe()
            }
            _updateStyle(e, t) {
                this._localTimelineStyles[e] = t,
                this._globalTimelineStyles[e] = t,
                this._styleSummary[e] = {
                    time: this.currentTime,
                    value: t
                }
            }
            allowOnlyTimelineStyles() {
                return this._currentEmptyStepKeyframe !== this._currentKeyframe
            }
            applyEmptyStep(e) {
                e && (this._previousKeyframe.easing = e),
                Object.keys(this._globalTimelineStyles).forEach(e => {
                    this._backFill[e] = this._globalTimelineStyles[e] || r.a,
                    this._currentKeyframe[e] = r.a
                }
                ),
                this._currentEmptyStepKeyframe = this._currentKeyframe
            }
            setStyles(e, t, n, s) {
                t && (this._previousKeyframe.easing = t);
                const i = s && s.params || {}
                  , o = function(e, t) {
                    const n = {};
                    let s;
                    return e.forEach(e => {
                        "*" === e ? (s = s || Object.keys(t)).forEach(e => {
                            n[e] = r.a
                        }
                        ) : L(e, !1, n)
                    }
                    ),
                    n
                }(e, this._globalTimelineStyles);
                Object.keys(o).forEach(e => {
                    const t = q(o[e], i, n);
                    this._pendingStyles[e] = t,
                    this._localTimelineStyles.hasOwnProperty(e) || (this._backFill[e] = this._globalTimelineStyles.hasOwnProperty(e) ? this._globalTimelineStyles[e] : r.a),
                    this._updateStyle(e, t)
                }
                )
            }
            applyStylesToKeyframe() {
                const e = this._pendingStyles
                  , t = Object.keys(e);
                0 != t.length && (this._pendingStyles = {},
                t.forEach(t => {
                    this._currentKeyframe[t] = e[t]
                }
                ),
                Object.keys(this._localTimelineStyles).forEach(e => {
                    this._currentKeyframe.hasOwnProperty(e) || (this._currentKeyframe[e] = this._localTimelineStyles[e])
                }
                ))
            }
            snapshotCurrentStyles() {
                Object.keys(this._localTimelineStyles).forEach(e => {
                    const t = this._localTimelineStyles[e];
                    this._pendingStyles[e] = t,
                    this._updateStyle(e, t)
                }
                )
            }
            getFinalKeyframe() {
                return this._keyframes.get(this.duration)
            }
            get properties() {
                const e = [];
                for (let t in this._currentKeyframe)
                    e.push(t);
                return e
            }
            mergeTimelineCollectedStyles(e) {
                Object.keys(e._styleSummary).forEach(t => {
                    const n = this._styleSummary[t]
                      , r = e._styleSummary[t];
                    (!n || r.time > n.time) && this._updateStyle(t, r.value)
                }
                )
            }
            buildKeyframes() {
                this.applyStylesToKeyframe();
                const e = new Set
                  , t = new Set
                  , n = 1 === this._keyframes.size && 0 === this.duration;
                let s = [];
                this._keyframes.forEach( (i, o) => {
                    const a = L(i, !0);
                    Object.keys(a).forEach(n => {
                        const s = a[n];
                        s == r.l ? e.add(n) : s == r.a && t.add(n)
                    }
                    ),
                    n || (a.offset = o / this.duration),
                    s.push(a)
                }
                );
                const i = e.size ? Q(e.values()) : []
                  , o = t.size ? Q(t.values()) : [];
                if (n) {
                    const e = s[0]
                      , t = M(e);
                    e.offset = 0,
                    t.offset = 1,
                    s = [e, t]
                }
                return fe(this.element, s, i, o, this.duration, this.startTime, this.easing, !1)
            }
        }
        class Se extends Ee {
            constructor(e, t, n, r, s, i, o=!1) {
                super(e, t, i.delay),
                this.element = t,
                this.keyframes = n,
                this.preStyleProps = r,
                this.postStyleProps = s,
                this._stretchStartingKeyframe = o,
                this.timings = {
                    duration: i.duration,
                    delay: i.delay,
                    easing: i.easing
                }
            }
            containsAnimation() {
                return this.keyframes.length > 1
            }
            buildKeyframes() {
                let e = this.keyframes
                  , {delay: t, duration: n, easing: r} = this.timings;
                if (this._stretchStartingKeyframe && t) {
                    const s = []
                      , i = n + t
                      , o = t / i
                      , a = L(e[0], !1);
                    a.offset = 0,
                    s.push(a);
                    const c = L(e[0], !1);
                    c.offset = Ce(o),
                    s.push(c);
                    const l = e.length - 1;
                    for (let r = 1; r <= l; r++) {
                        let o = L(e[r], !1);
                        o.offset = Ce((t + o.offset * n) / i),
                        s.push(o)
                    }
                    n = i,
                    t = 0,
                    r = "",
                    e = s
                }
                return fe(this.element, e, this.preStyleProps, this.postStyleProps, n, t, r, !0)
            }
        }
        function Ce(e, t=3) {
            const n = Math.pow(10, t - 1);
            return Math.round(e * n) / n
        }
        class Te {
        }
        class xe extends Te {
            normalizePropertyName(e, t) {
                return K(e)
            }
            normalizeStyleValue(e, t, n, r) {
                let s = "";
                const i = n.toString().trim();
                if (ke[t] && 0 !== n && "0" !== n)
                    if ("number" == typeof n)
                        s = "px";
                    else {
                        const t = n.match(/^[+-]?[\d\.]+([a-z]*)$/);
                        t && 0 == t[1].length && r.push(`Please provide a CSS unit value for ${e}:${n}`)
                    }
                return i + s
            }
        }
        const ke = ( () => (function(e) {
            const t = {};
            return e.forEach(e => t[e] = !0),
            t
        }
        )("width,height,minWidth,minHeight,maxWidth,maxHeight,left,top,bottom,right,fontSize,outlineWidth,outlineOffset,paddingTop,paddingLeft,paddingBottom,paddingRight,marginTop,marginLeft,marginBottom,marginRight,borderRadius,borderWidth,borderTopWidth,borderLeftWidth,borderRightWidth,borderBottomWidth,textIndent,perspective".split(",")))();
        function Oe(e, t, n, r, s, i, o, a, c, l, u, h, d) {
            return {
                type: 0,
                element: e,
                triggerName: t,
                isRemovalTransition: s,
                fromState: n,
                fromStyles: i,
                toState: r,
                toStyles: o,
                timelines: a,
                queriedElements: c,
                preStyleProps: l,
                postStyleProps: u,
                totalTime: h,
                errors: d
            }
        }
        const Ie = {};
        class Ae {
            constructor(e, t, n) {
                this._triggerName = e,
                this.ast = t,
                this._stateStyles = n
            }
            match(e, t, n, r) {
                return function(e, t, n, r, s) {
                    return e.some(e => e(t, n, r, s))
                }(this.ast.matchers, e, t, n, r)
            }
            buildStyles(e, t, n) {
                const r = this._stateStyles["*"]
                  , s = this._stateStyles[e]
                  , i = r ? r.buildStyles(t, n) : {};
                return s ? s.buildStyles(t, n) : i
            }
            build(e, t, n, r, s, i, o, a, c, l) {
                const h = []
                  , d = this.ast.options && this.ast.options.params || Ie
                  , f = this.buildStyles(n, o && o.params || Ie, h)
                  , p = a && a.params || Ie
                  , m = this.buildStyles(r, p, h)
                  , g = new Set
                  , b = new Map
                  , y = new Map
                  , v = "void" === r
                  , _ = {
                    params: Object.assign({}, d, p)
                }
                  , w = l ? [] : ye(e, t, this.ast.animation, s, i, f, m, _, c, h);
                let E = 0;
                if (w.forEach(e => {
                    E = Math.max(e.duration + e.delay, E)
                }
                ),
                h.length)
                    return Oe(t, this._triggerName, n, r, v, f, m, [], [], b, y, E, h);
                w.forEach(e => {
                    const n = e.element
                      , r = u(b, n, {});
                    e.preStyleProps.forEach(e => r[e] = !0);
                    const s = u(y, n, {});
                    e.postStyleProps.forEach(e => s[e] = !0),
                    n !== t && g.add(n)
                }
                );
                const S = Q(g.values());
                return Oe(t, this._triggerName, n, r, v, f, m, w, S, b, y, E)
            }
        }
        class De {
            constructor(e, t) {
                this.styles = e,
                this.defaultParams = t
            }
            buildStyles(e, t) {
                const n = {}
                  , r = M(this.defaultParams);
                return Object.keys(e).forEach(t => {
                    const n = e[t];
                    null != n && (r[t] = n)
                }
                ),
                this.styles.styles.forEach(e => {
                    if ("string" != typeof e) {
                        const s = e;
                        Object.keys(s).forEach(e => {
                            let i = s[e];
                            i.length > 1 && (i = q(i, r, t)),
                            n[e] = i
                        }
                        )
                    }
                }
                ),
                n
            }
        }
        class Re {
            constructor(e, t) {
                this.name = e,
                this.ast = t,
                this.transitionFactories = [],
                this.states = {},
                t.states.forEach(e => {
                    this.states[e.name] = new De(e.style,e.options && e.options.params || {})
                }
                ),
                je(this.states, "true", "1"),
                je(this.states, "false", "0"),
                t.transitions.forEach(t => {
                    this.transitionFactories.push(new Ae(e,t,this.states))
                }
                ),
                this.fallbackTransition = new Ae(e,{
                    type: 1,
                    animation: {
                        type: 2,
                        steps: [],
                        options: null
                    },
                    matchers: [ (e, t) => !0],
                    options: null,
                    queryCount: 0,
                    depCount: 0
                },this.states)
            }
            get containsQueries() {
                return this.ast.queryCount > 0
            }
            matchTransition(e, t, n, r) {
                return this.transitionFactories.find(s => s.match(e, t, n, r)) || null
            }
            matchStyles(e, t, n) {
                return this.fallbackTransition.buildStyles(e, t, n)
            }
        }
        function je(e, t, n) {
            e.hasOwnProperty(t) ? e.hasOwnProperty(n) || (e[n] = e[t]) : e.hasOwnProperty(n) && (e[t] = e[n])
        }
        const Ne = new pe;
        class Pe {
            constructor(e, t, n) {
                this.bodyNode = e,
                this._driver = t,
                this._normalizer = n,
                this._animations = {},
                this._playersById = {},
                this.players = []
            }
            register(e, t) {
                const n = []
                  , r = oe(this._driver, t, n);
                if (n.length)
                    throw new Error(`Unable to build the animation due to the following errors: ${n.join("\n")}`);
                this._animations[e] = r
            }
            _buildPlayer(e, t, n) {
                const r = e.element
                  , s = o(0, this._normalizer, 0, e.keyframes, t, n);
                return this._driver.animate(r, s, e.duration, e.delay, e.easing, [], !0)
            }
            create(e, t, n={}) {
                const s = []
                  , o = this._animations[e];
                let a;
                const c = new Map;
                if (o ? (a = ye(this._driver, t, o, k, O, {}, {}, n, Ne, s)).forEach(e => {
                    const t = u(c, e.element, {});
                    e.postStyleProps.forEach(e => t[e] = null)
                }
                ) : (s.push("The requested animation doesn't exist or has already been destroyed"),
                a = []),
                s.length)
                    throw new Error(`Unable to create the animation due to the following errors: ${s.join("\n")}`);
                c.forEach( (e, t) => {
                    Object.keys(e).forEach(n => {
                        e[n] = this._driver.computeStyle(t, n, r.a)
                    }
                    )
                }
                );
                const l = i(a.map(e => {
                    const t = c.get(e.element);
                    return this._buildPlayer(e, {}, t)
                }
                ));
                return this._playersById[e] = l,
                l.onDestroy( () => this.destroy(e)),
                this.players.push(l),
                l
            }
            destroy(e) {
                const t = this._getPlayer(e);
                t.destroy(),
                delete this._playersById[e];
                const n = this.players.indexOf(t);
                n >= 0 && this.players.splice(n, 1)
            }
            _getPlayer(e) {
                const t = this._playersById[e];
                if (!t)
                    throw new Error(`Unable to find the timeline player referenced by ${e}`);
                return t
            }
            listen(e, t, n, r) {
                const s = l(t, "", "", "");
                return a(this._getPlayer(e), n, s, r),
                () => {}
            }
            command(e, t, n, r) {
                if ("register" == n)
                    return void this.register(e, r[0]);
                if ("create" == n)
                    return void this.create(e, t, r[0] || {});
                const s = this._getPlayer(e);
                switch (n) {
                case "play":
                    s.play();
                    break;
                case "pause":
                    s.pause();
                    break;
                case "reset":
                    s.reset();
                    break;
                case "restart":
                    s.restart();
                    break;
                case "finish":
                    s.finish();
                    break;
                case "init":
                    s.init();
                    break;
                case "setPosition":
                    s.setPosition(parseFloat(r[0]));
                    break;
                case "destroy":
                    this.destroy(e)
                }
            }
        }
        const Me = "ng-animate-queued"
          , Le = ".ng-animate-queued"
          , Fe = "ng-animate-disabled"
          , Ue = ".ng-animate-disabled"
          , ze = "ng-star-inserted"
          , He = ".ng-star-inserted"
          , Be = []
          , Ve = {
            namespaceId: "",
            setForRemoval: !1,
            setForMove: !1,
            hasAnimation: !1,
            removedBeforeQueried: !1
        }
          , $e = {
            namespaceId: "",
            setForMove: !1,
            setForRemoval: !1,
            hasAnimation: !1,
            removedBeforeQueried: !0
        }
          , qe = "__ng_removed";
        class Qe {
            constructor(e, t="") {
                this.namespaceId = t;
                const n = e && e.hasOwnProperty("value");
                if (this.value = function(e) {
                    return null != e ? e : null
                }(n ? e.value : e),
                n) {
                    const t = M(e);
                    delete t.value,
                    this.options = t
                } else
                    this.options = {};
                this.options.params || (this.options.params = {})
            }
            get params() {
                return this.options.params
            }
            absorbOptions(e) {
                const t = e.params;
                if (t) {
                    const e = this.options.params;
                    Object.keys(t).forEach(n => {
                        null == e[n] && (e[n] = t[n])
                    }
                    )
                }
            }
        }
        const Ge = "void"
          , Ke = new Qe(Ge);
        class We {
            constructor(e, t, n) {
                this.id = e,
                this.hostElement = t,
                this._engine = n,
                this.players = [],
                this._triggers = {},
                this._queue = [],
                this._elementListeners = new Map,
                this._hostClassName = "ng-tns-" + e,
                rt(t, this._hostClassName)
            }
            listen(e, t, n, r) {
                if (!this._triggers.hasOwnProperty(t))
                    throw new Error(`Unable to listen on the animation trigger event "${n}" because the animation trigger "${t}" doesn't exist!`);
                if (null == n || 0 == n.length)
                    throw new Error(`Unable to listen on the animation trigger "${t}" because the provided event is undefined!`);
                if ("start" != (s = n) && "done" != s)
                    throw new Error(`The provided animation trigger event "${n}" for the animation trigger "${t}" is not supported!`);
                var s;
                const i = u(this._elementListeners, e, [])
                  , o = {
                    name: t,
                    phase: n,
                    callback: r
                };
                i.push(o);
                const a = u(this._engine.statesByElement, e, {});
                return a.hasOwnProperty(t) || (rt(e, I),
                rt(e, I + "-" + t),
                a[t] = Ke),
                () => {
                    this._engine.afterFlush( () => {
                        const e = i.indexOf(o);
                        e >= 0 && i.splice(e, 1),
                        this._triggers[t] || delete a[t]
                    }
                    )
                }
            }
            register(e, t) {
                return !this._triggers[e] && (this._triggers[e] = t,
                !0)
            }
            _getTrigger(e) {
                const t = this._triggers[e];
                if (!t)
                    throw new Error(`The provided animation trigger "${e}" has not been registered!`);
                return t
            }
            trigger(e, t, n, r=!0) {
                const s = this._getTrigger(t)
                  , i = new Ye(this.id,t,e);
                let o = this._engine.statesByElement.get(e);
                o || (rt(e, I),
                rt(e, I + "-" + t),
                this._engine.statesByElement.set(e, o = {}));
                let a = o[t];
                const c = new Qe(n,this.id);
                if (!(n && n.hasOwnProperty("value")) && a && c.absorbOptions(a.options),
                o[t] = c,
                a || (a = Ke),
                c.value !== Ge && a.value === c.value) {
                    if (!function(e, t) {
                        const n = Object.keys(e)
                          , r = Object.keys(t);
                        if (n.length != r.length)
                            return !1;
                        for (let s = 0; s < n.length; s++) {
                            const r = n[s];
                            if (!t.hasOwnProperty(r) || e[r] !== t[r])
                                return !1
                        }
                        return !0
                    }(a.params, c.params)) {
                        const t = []
                          , n = s.matchStyles(a.value, a.params, t)
                          , r = s.matchStyles(c.value, c.params, t);
                        t.length ? this._engine.reportError(t) : this._engine.afterFlush( () => {
                            H(e, n),
                            z(e, r)
                        }
                        )
                    }
                    return
                }
                const l = u(this._engine.playersByElement, e, []);
                l.forEach(e => {
                    e.namespaceId == this.id && e.triggerName == t && e.queued && e.destroy()
                }
                );
                let h = s.matchTransition(a.value, c.value, e, c.params)
                  , d = !1;
                if (!h) {
                    if (!r)
                        return;
                    h = s.fallbackTransition,
                    d = !0
                }
                return this._engine.totalQueuedPlayers++,
                this._queue.push({
                    element: e,
                    triggerName: t,
                    transition: h,
                    fromState: a,
                    toState: c,
                    player: i,
                    isFallbackTransition: d
                }),
                d || (rt(e, Me),
                i.onStart( () => {
                    st(e, Me)
                }
                )),
                i.onDone( () => {
                    let t = this.players.indexOf(i);
                    t >= 0 && this.players.splice(t, 1);
                    const n = this._engine.playersByElement.get(e);
                    if (n) {
                        let e = n.indexOf(i);
                        e >= 0 && n.splice(e, 1)
                    }
                }
                ),
                this.players.push(i),
                l.push(i),
                i
            }
            deregister(e) {
                delete this._triggers[e],
                this._engine.statesByElement.forEach( (t, n) => {
                    delete t[e]
                }
                ),
                this._elementListeners.forEach( (t, n) => {
                    this._elementListeners.set(n, t.filter(t => t.name != e))
                }
                )
            }
            clearElementCache(e) {
                this._engine.statesByElement.delete(e),
                this._elementListeners.delete(e);
                const t = this._engine.playersByElement.get(e);
                t && (t.forEach(e => e.destroy()),
                this._engine.playersByElement.delete(e))
            }
            _signalRemovalForInnerTriggers(e, t, n=!1) {
                this._engine.driver.query(e, A, !0).forEach(e => {
                    if (e[qe])
                        return;
                    const n = this._engine.fetchNamespacesByElement(e);
                    n.size ? n.forEach(n => n.triggerLeaveAnimation(e, t, !1, !0)) : this.clearElementCache(e)
                }
                )
            }
            triggerLeaveAnimation(e, t, n, r) {
                const s = this._engine.statesByElement.get(e);
                if (s) {
                    const o = [];
                    if (Object.keys(s).forEach(t => {
                        if (this._triggers[t]) {
                            const n = this.trigger(e, t, Ge, r);
                            n && o.push(n)
                        }
                    }
                    ),
                    o.length)
                        return this._engine.markElementAsRemoved(this.id, e, !0, t),
                        n && i(o).onDone( () => this._engine.processLeaveNode(e)),
                        !0
                }
                return !1
            }
            prepareLeaveAnimationListeners(e) {
                const t = this._elementListeners.get(e);
                if (t) {
                    const n = new Set;
                    t.forEach(t => {
                        const r = t.name;
                        if (n.has(r))
                            return;
                        n.add(r);
                        const s = this._triggers[r].fallbackTransition
                          , i = this._engine.statesByElement.get(e)[r] || Ke
                          , o = new Qe(Ge)
                          , a = new Ye(this.id,r,e);
                        this._engine.totalQueuedPlayers++,
                        this._queue.push({
                            element: e,
                            triggerName: r,
                            transition: s,
                            fromState: i,
                            toState: o,
                            player: a,
                            isFallbackTransition: !0
                        })
                    }
                    )
                }
            }
            removeNode(e, t) {
                const n = this._engine;
                if (e.childElementCount && this._signalRemovalForInnerTriggers(e, t, !0),
                this.triggerLeaveAnimation(e, t, !0))
                    return;
                let r = !1;
                if (n.totalAnimations) {
                    const t = n.players.length ? n.playersByQueriedElement.get(e) : [];
                    if (t && t.length)
                        r = !0;
                    else {
                        let t = e;
                        for (; t = t.parentNode; )
                            if (n.statesByElement.get(t)) {
                                r = !0;
                                break
                            }
                    }
                }
                this.prepareLeaveAnimationListeners(e),
                r ? n.markElementAsRemoved(this.id, e, !1, t) : (n.afterFlush( () => this.clearElementCache(e)),
                n.destroyInnerAnimations(e),
                n._onRemovalComplete(e, t))
            }
            insertNode(e, t) {
                rt(e, this._hostClassName)
            }
            drainQueuedTransitions(e) {
                const t = [];
                return this._queue.forEach(n => {
                    const r = n.player;
                    if (r.destroyed)
                        return;
                    const s = n.element
                      , i = this._elementListeners.get(s);
                    i && i.forEach(t => {
                        if (t.name == n.triggerName) {
                            const r = l(s, n.triggerName, n.fromState.value, n.toState.value);
                            r._data = e,
                            a(n.player, t.phase, r, t.callback)
                        }
                    }
                    ),
                    r.markedForDestroy ? this._engine.afterFlush( () => {
                        r.destroy()
                    }
                    ) : t.push(n)
                }
                ),
                this._queue = [],
                t.sort( (e, t) => {
                    const n = e.transition.ast.depCount
                      , r = t.transition.ast.depCount;
                    return 0 == n || 0 == r ? n - r : this._engine.driver.containsElement(e.element, t.element) ? 1 : -1
                }
                )
            }
            destroy(e) {
                this.players.forEach(e => e.destroy()),
                this._signalRemovalForInnerTriggers(this.hostElement, e)
            }
            elementContainsData(e) {
                let t = !1;
                return this._elementListeners.has(e) && (t = !0),
                !!this._queue.find(t => t.element === e) || t
            }
        }
        class Ze {
            constructor(e, t, n) {
                this.bodyNode = e,
                this.driver = t,
                this._normalizer = n,
                this.players = [],
                this.newHostElements = new Map,
                this.playersByElement = new Map,
                this.playersByQueriedElement = new Map,
                this.statesByElement = new Map,
                this.disabledNodes = new Set,
                this.totalAnimations = 0,
                this.totalQueuedPlayers = 0,
                this._namespaceLookup = {},
                this._namespaceList = [],
                this._flushFns = [],
                this._whenQuietFns = [],
                this.namespacesByHostElement = new Map,
                this.collectedEnterElements = [],
                this.collectedLeaveElements = [],
                this.onRemovalComplete = (e, t) => {}
            }
            _onRemovalComplete(e, t) {
                this.onRemovalComplete(e, t)
            }
            get queuedPlayers() {
                const e = [];
                return this._namespaceList.forEach(t => {
                    t.players.forEach(t => {
                        t.queued && e.push(t)
                    }
                    )
                }
                ),
                e
            }
            createNamespace(e, t) {
                const n = new We(e,t,this);
                return t.parentNode ? this._balanceNamespaceList(n, t) : (this.newHostElements.set(t, n),
                this.collectEnterElement(t)),
                this._namespaceLookup[e] = n
            }
            _balanceNamespaceList(e, t) {
                const n = this._namespaceList.length - 1;
                if (n >= 0) {
                    let r = !1;
                    for (let s = n; s >= 0; s--)
                        if (this.driver.containsElement(this._namespaceList[s].hostElement, t)) {
                            this._namespaceList.splice(s + 1, 0, e),
                            r = !0;
                            break
                        }
                    r || this._namespaceList.splice(0, 0, e)
                } else
                    this._namespaceList.push(e);
                return this.namespacesByHostElement.set(t, e),
                e
            }
            register(e, t) {
                let n = this._namespaceLookup[e];
                return n || (n = this.createNamespace(e, t)),
                n
            }
            registerTrigger(e, t, n) {
                let r = this._namespaceLookup[e];
                r && r.register(t, n) && this.totalAnimations++
            }
            destroy(e, t) {
                if (!e)
                    return;
                const n = this._fetchNamespace(e);
                this.afterFlush( () => {
                    this.namespacesByHostElement.delete(n.hostElement),
                    delete this._namespaceLookup[e];
                    const t = this._namespaceList.indexOf(n);
                    t >= 0 && this._namespaceList.splice(t, 1)
                }
                ),
                this.afterFlushAnimationsDone( () => n.destroy(t))
            }
            _fetchNamespace(e) {
                return this._namespaceLookup[e]
            }
            fetchNamespacesByElement(e) {
                const t = new Set
                  , n = this.statesByElement.get(e);
                if (n) {
                    const e = Object.keys(n);
                    for (let r = 0; r < e.length; r++) {
                        const s = n[e[r]].namespaceId;
                        if (s) {
                            const e = this._fetchNamespace(s);
                            e && t.add(e)
                        }
                    }
                }
                return t
            }
            trigger(e, t, n, r) {
                if (Je(t)) {
                    const s = this._fetchNamespace(e);
                    if (s)
                        return s.trigger(t, n, r),
                        !0
                }
                return !1
            }
            insertNode(e, t, n, r) {
                if (!Je(t))
                    return;
                const s = t[qe];
                if (s && s.setForRemoval) {
                    s.setForRemoval = !1,
                    s.setForMove = !0;
                    const e = this.collectedLeaveElements.indexOf(t);
                    e >= 0 && this.collectedLeaveElements.splice(e, 1)
                }
                if (e) {
                    const r = this._fetchNamespace(e);
                    r && r.insertNode(t, n)
                }
                r && this.collectEnterElement(t)
            }
            collectEnterElement(e) {
                this.collectedEnterElements.push(e)
            }
            markElementAsDisabled(e, t) {
                t ? this.disabledNodes.has(e) || (this.disabledNodes.add(e),
                rt(e, Fe)) : this.disabledNodes.has(e) && (this.disabledNodes.delete(e),
                st(e, Fe))
            }
            removeNode(e, t, n, r) {
                if (Je(t)) {
                    const s = e ? this._fetchNamespace(e) : null;
                    if (s ? s.removeNode(t, r) : this.markElementAsRemoved(e, t, !1, r),
                    n) {
                        const n = this.namespacesByHostElement.get(t);
                        n && n.id !== e && n.removeNode(t, r)
                    }
                } else
                    this._onRemovalComplete(t, r)
            }
            markElementAsRemoved(e, t, n, r) {
                this.collectedLeaveElements.push(t),
                t[qe] = {
                    namespaceId: e,
                    setForRemoval: r,
                    hasAnimation: n,
                    removedBeforeQueried: !1
                }
            }
            listen(e, t, n, r, s) {
                return Je(t) ? this._fetchNamespace(e).listen(t, n, r, s) : () => {}
            }
            _buildInstruction(e, t, n, r, s) {
                return e.transition.build(this.driver, e.element, e.fromState.value, e.toState.value, n, r, e.fromState.options, e.toState.options, t, s)
            }
            destroyInnerAnimations(e) {
                let t = this.driver.query(e, A, !0);
                t.forEach(e => this.destroyActiveAnimationsForElement(e)),
                0 != this.playersByQueriedElement.size && (t = this.driver.query(e, R, !0)).forEach(e => this.finishActiveQueriedAnimationOnElement(e))
            }
            destroyActiveAnimationsForElement(e) {
                const t = this.playersByElement.get(e);
                t && t.forEach(e => {
                    e.queued ? e.markedForDestroy = !0 : e.destroy()
                }
                )
            }
            finishActiveQueriedAnimationOnElement(e) {
                const t = this.playersByQueriedElement.get(e);
                t && t.forEach(e => e.finish())
            }
            whenRenderingDone() {
                return new Promise(e => {
                    if (this.players.length)
                        return i(this.players).onDone( () => e());
                    e()
                }
                )
            }
            processLeaveNode(e) {
                const t = e[qe];
                if (t && t.setForRemoval) {
                    if (e[qe] = Ve,
                    t.namespaceId) {
                        this.destroyInnerAnimations(e);
                        const n = this._fetchNamespace(t.namespaceId);
                        n && n.clearElementCache(e)
                    }
                    this._onRemovalComplete(e, t.setForRemoval)
                }
                this.driver.matchesElement(e, Ue) && this.markElementAsDisabled(e, !1),
                this.driver.query(e, Ue, !0).forEach(e => {
                    this.markElementAsDisabled(e, !1)
                }
                )
            }
            flush(e=-1) {
                let t = [];
                if (this.newHostElements.size && (this.newHostElements.forEach( (e, t) => this._balanceNamespaceList(e, t)),
                this.newHostElements.clear()),
                this.totalAnimations && this.collectedEnterElements.length)
                    for (let n = 0; n < this.collectedEnterElements.length; n++)
                        rt(this.collectedEnterElements[n], ze);
                if (this._namespaceList.length && (this.totalQueuedPlayers || this.collectedLeaveElements.length)) {
                    const n = [];
                    try {
                        t = this._flushAnimations(n, e)
                    } finally {
                        for (let e = 0; e < n.length; e++)
                            n[e]()
                    }
                } else
                    for (let n = 0; n < this.collectedLeaveElements.length; n++)
                        this.processLeaveNode(this.collectedLeaveElements[n]);
                if (this.totalQueuedPlayers = 0,
                this.collectedEnterElements.length = 0,
                this.collectedLeaveElements.length = 0,
                this._flushFns.forEach(e => e()),
                this._flushFns = [],
                this._whenQuietFns.length) {
                    const e = this._whenQuietFns;
                    this._whenQuietFns = [],
                    t.length ? i(t).onDone( () => {
                        e.forEach(e => e())
                    }
                    ) : e.forEach(e => e())
                }
            }
            reportError(e) {
                throw new Error(`Unable to process animations due to the following failed trigger transitions\n ${e.join("\n")}`)
            }
            _flushAnimations(e, t) {
                const n = new pe
                  , s = []
                  , o = new Map
                  , a = []
                  , c = new Map
                  , l = new Map
                  , h = new Map
                  , d = new Set;
                this.disabledNodes.forEach(e => {
                    d.add(e);
                    const t = this.driver.query(e, Le, !0);
                    for (let n = 0; n < t.length; n++)
                        d.add(t[n])
                }
                );
                const f = this.bodyNode
                  , p = Array.from(this.statesByElement.keys())
                  , m = tt(p, this.collectedEnterElements)
                  , g = new Map;
                let b = 0;
                m.forEach( (e, t) => {
                    const n = k + b++;
                    g.set(t, n),
                    e.forEach(e => rt(e, n))
                }
                );
                const y = []
                  , v = new Set
                  , _ = new Set;
                for (let r = 0; r < this.collectedLeaveElements.length; r++) {
                    const e = this.collectedLeaveElements[r]
                      , t = e[qe];
                    t && t.setForRemoval && (y.push(e),
                    v.add(e),
                    t.hasAnimation ? this.driver.query(e, He, !0).forEach(e => v.add(e)) : _.add(e))
                }
                const w = new Map
                  , E = tt(p, Array.from(v));
                E.forEach( (e, t) => {
                    const n = O + b++;
                    w.set(t, n),
                    e.forEach(e => rt(e, n))
                }
                ),
                e.push( () => {
                    m.forEach( (e, t) => {
                        const n = g.get(t);
                        e.forEach(e => st(e, n))
                    }
                    ),
                    E.forEach( (e, t) => {
                        const n = w.get(t);
                        e.forEach(e => st(e, n))
                    }
                    ),
                    y.forEach(e => {
                        this.processLeaveNode(e)
                    }
                    )
                }
                );
                const S = []
                  , C = [];
                for (let r = this._namespaceList.length - 1; r >= 0; r--)
                    this._namespaceList[r].drainQueuedTransitions(t).forEach(e => {
                        const t = e.player
                          , r = e.element;
                        if (S.push(t),
                        this.collectedEnterElements.length) {
                            const e = r[qe];
                            if (e && e.setForMove)
                                return void t.destroy()
                        }
                        const i = !f || !this.driver.containsElement(f, r)
                          , o = w.get(r)
                          , d = g.get(r)
                          , p = this._buildInstruction(e, n, d, o, i);
                        if (!p.errors || !p.errors.length)
                            return i ? (t.onStart( () => H(r, p.fromStyles)),
                            t.onDestroy( () => z(r, p.toStyles)),
                            void s.push(t)) : e.isFallbackTransition ? (t.onStart( () => H(r, p.fromStyles)),
                            t.onDestroy( () => z(r, p.toStyles)),
                            void s.push(t)) : (p.timelines.forEach(e => e.stretchStartingKeyframe = !0),
                            n.append(r, p.timelines),
                            a.push({
                                instruction: p,
                                player: t,
                                element: r
                            }),
                            p.queriedElements.forEach(e => u(c, e, []).push(t)),
                            p.preStyleProps.forEach( (e, t) => {
                                const n = Object.keys(e);
                                if (n.length) {
                                    let e = l.get(t);
                                    e || l.set(t, e = new Set),
                                    n.forEach(t => e.add(t))
                                }
                            }
                            ),
                            void p.postStyleProps.forEach( (e, t) => {
                                const n = Object.keys(e);
                                let r = h.get(t);
                                r || h.set(t, r = new Set),
                                n.forEach(e => r.add(e))
                            }
                            ));
                        C.push(p)
                    }
                    );
                if (C.length) {
                    const e = [];
                    C.forEach(t => {
                        e.push(`@${t.triggerName} has failed due to:\n`),
                        t.errors.forEach(t => e.push(`- ${t}\n`))
                    }
                    ),
                    S.forEach(e => e.destroy()),
                    this.reportError(e)
                }
                const T = new Map
                  , x = new Map;
                a.forEach(e => {
                    const t = e.element;
                    n.has(t) && (x.set(t, t),
                    this._beforeAnimationBuild(e.player.namespaceId, e.instruction, T))
                }
                ),
                s.forEach(e => {
                    const t = e.element;
                    this._getPreviousPlayers(t, !1, e.namespaceId, e.triggerName, null).forEach(e => {
                        u(T, t, []).push(e),
                        e.destroy()
                    }
                    )
                }
                );
                const I = y.filter(e => ot(e, l, h))
                  , A = new Map;
                et(A, this.driver, _, h, r.a).forEach(e => {
                    ot(e, l, h) && I.push(e)
                }
                );
                const D = new Map;
                m.forEach( (e, t) => {
                    et(D, this.driver, new Set(e), l, r.l)
                }
                ),
                I.forEach(e => {
                    const t = A.get(e)
                      , n = D.get(e);
                    A.set(e, Object.assign({}, t, n))
                }
                );
                const j = []
                  , N = []
                  , P = {};
                a.forEach(e => {
                    const {element: t, player: r, instruction: a} = e;
                    if (n.has(t)) {
                        if (d.has(t))
                            return r.onDestroy( () => z(t, a.toStyles)),
                            r.disabled = !0,
                            r.overrideTotalTime(a.totalTime),
                            void s.push(r);
                        let e = P;
                        if (x.size > 1) {
                            let n = t;
                            const r = [];
                            for (; n = n.parentNode; ) {
                                const t = x.get(n);
                                if (t) {
                                    e = t;
                                    break
                                }
                                r.push(n)
                            }
                            r.forEach(t => x.set(t, e))
                        }
                        const n = this._buildAnimation(r.namespaceId, a, T, o, D, A);
                        if (r.setRealPlayer(n),
                        e === P)
                            j.push(r);
                        else {
                            const t = this.playersByElement.get(e);
                            t && t.length && (r.parentPlayer = i(t)),
                            s.push(r)
                        }
                    } else
                        H(t, a.fromStyles),
                        r.onDestroy( () => z(t, a.toStyles)),
                        N.push(r),
                        d.has(t) && s.push(r)
                }
                ),
                N.forEach(e => {
                    const t = o.get(e.element);
                    if (t && t.length) {
                        const n = i(t);
                        e.setRealPlayer(n)
                    }
                }
                ),
                s.forEach(e => {
                    e.parentPlayer ? e.syncPlayerEvents(e.parentPlayer) : e.destroy()
                }
                );
                for (let r = 0; r < y.length; r++) {
                    const e = y[r]
                      , t = e[qe];
                    if (st(e, O),
                    t && t.hasAnimation)
                        continue;
                    let n = [];
                    if (c.size) {
                        let t = c.get(e);
                        t && t.length && n.push(...t);
                        let r = this.driver.query(e, R, !0);
                        for (let e = 0; e < r.length; e++) {
                            let t = c.get(r[e]);
                            t && t.length && n.push(...t)
                        }
                    }
                    const s = n.filter(e => !e.destroyed);
                    s.length ? it(this, e, s) : this.processLeaveNode(e)
                }
                return y.length = 0,
                j.forEach(e => {
                    this.players.push(e),
                    e.onDone( () => {
                        e.destroy();
                        const t = this.players.indexOf(e);
                        this.players.splice(t, 1)
                    }
                    ),
                    e.play()
                }
                ),
                j
            }
            elementContainsData(e, t) {
                let n = !1;
                const r = t[qe];
                return r && r.setForRemoval && (n = !0),
                this.playersByElement.has(t) && (n = !0),
                this.playersByQueriedElement.has(t) && (n = !0),
                this.statesByElement.has(t) && (n = !0),
                this._fetchNamespace(e).elementContainsData(t) || n
            }
            afterFlush(e) {
                this._flushFns.push(e)
            }
            afterFlushAnimationsDone(e) {
                this._whenQuietFns.push(e)
            }
            _getPreviousPlayers(e, t, n, r, s) {
                let i = [];
                if (t) {
                    const t = this.playersByQueriedElement.get(e);
                    t && (i = t)
                } else {
                    const t = this.playersByElement.get(e);
                    if (t) {
                        const e = !s || s == Ge;
                        t.forEach(t => {
                            t.queued || (e || t.triggerName == r) && i.push(t)
                        }
                        )
                    }
                }
                return (n || r) && (i = i.filter(e => !(n && n != e.namespaceId || r && r != e.triggerName))),
                i
            }
            _beforeAnimationBuild(e, t, n) {
                const r = t.element
                  , s = t.isRemovalTransition ? void 0 : e
                  , i = t.isRemovalTransition ? void 0 : t.triggerName;
                for (const o of t.timelines) {
                    const e = o.element
                      , a = e !== r
                      , c = u(n, e, []);
                    this._getPreviousPlayers(e, a, s, i, t.toState).forEach(e => {
                        const t = e.getRealPlayer();
                        t.beforeDestroy && t.beforeDestroy(),
                        e.destroy(),
                        c.push(e)
                    }
                    )
                }
                H(r, t.fromStyles)
            }
            _buildAnimation(e, t, n, s, a, c) {
                const l = t.triggerName
                  , h = t.element
                  , d = []
                  , f = new Set
                  , p = new Set
                  , m = t.timelines.map(t => {
                    const i = t.element;
                    f.add(i);
                    const u = i[qe];
                    if (u && u.removedBeforeQueried)
                        return new r.d(t.duration,t.delay);
                    const m = i !== h
                      , g = function(e) {
                        const t = [];
                        return function e(t, n) {
                            for (let s = 0; s < t.length; s++) {
                                const i = t[s];
                                i instanceof r.k ? e(i.players, n) : n.push(i)
                            }
                        }((n.get(i) || Be).map(e => e.getRealPlayer()), t),
                        t
                    }().filter(e => !!e.element && e.element === i)
                      , b = a.get(i)
                      , y = c.get(i)
                      , v = o(0, this._normalizer, 0, t.keyframes, b, y)
                      , _ = this._buildPlayer(t, v, g);
                    if (t.subTimeline && s && p.add(i),
                    m) {
                        const t = new Ye(e,l,i);
                        t.setRealPlayer(_),
                        d.push(t)
                    }
                    return _
                }
                );
                d.forEach(e => {
                    u(this.playersByQueriedElement, e.element, []).push(e),
                    e.onDone( () => (function(e, t, n) {
                        let r;
                        if (e instanceof Map) {
                            if (r = e.get(t)) {
                                if (r.length) {
                                    const e = r.indexOf(n);
                                    r.splice(e, 1)
                                }
                                0 == r.length && e.delete(t)
                            }
                        } else if (r = e[t]) {
                            if (r.length) {
                                const e = r.indexOf(n);
                                r.splice(e, 1)
                            }
                            0 == r.length && delete e[t]
                        }
                        return r
                    }
                    )(this.playersByQueriedElement, e.element, e))
                }
                ),
                f.forEach(e => rt(e, D));
                const g = i(m);
                return g.onDestroy( () => {
                    f.forEach(e => st(e, D)),
                    z(h, t.toStyles)
                }
                ),
                p.forEach(e => {
                    u(s, e, []).push(g)
                }
                ),
                g
            }
            _buildPlayer(e, t, n) {
                return t.length > 0 ? this.driver.animate(e.element, t, e.duration, e.delay, e.easing, n) : new r.d(e.duration,e.delay)
            }
        }
        class Ye {
            constructor(e, t, n) {
                this.namespaceId = e,
                this.triggerName = t,
                this.element = n,
                this._player = new r.d,
                this._containsRealPlayer = !1,
                this._queuedCallbacks = {},
                this.destroyed = !1,
                this.markedForDestroy = !1,
                this.disabled = !1,
                this.queued = !0,
                this.totalTime = 0
            }
            setRealPlayer(e) {
                this._containsRealPlayer || (this._player = e,
                Object.keys(this._queuedCallbacks).forEach(t => {
                    this._queuedCallbacks[t].forEach(n => a(e, t, void 0, n))
                }
                ),
                this._queuedCallbacks = {},
                this._containsRealPlayer = !0,
                this.overrideTotalTime(e.totalTime),
                this.queued = !1)
            }
            getRealPlayer() {
                return this._player
            }
            overrideTotalTime(e) {
                this.totalTime = e
            }
            syncPlayerEvents(e) {
                const t = this._player;
                t.triggerCallback && e.onStart( () => t.triggerCallback("start")),
                e.onDone( () => this.finish()),
                e.onDestroy( () => this.destroy())
            }
            _queueEvent(e, t) {
                u(this._queuedCallbacks, e, []).push(t)
            }
            onDone(e) {
                this.queued && this._queueEvent("done", e),
                this._player.onDone(e)
            }
            onStart(e) {
                this.queued && this._queueEvent("start", e),
                this._player.onStart(e)
            }
            onDestroy(e) {
                this.queued && this._queueEvent("destroy", e),
                this._player.onDestroy(e)
            }
            init() {
                this._player.init()
            }
            hasStarted() {
                return !this.queued && this._player.hasStarted()
            }
            play() {
                !this.queued && this._player.play()
            }
            pause() {
                !this.queued && this._player.pause()
            }
            restart() {
                !this.queued && this._player.restart()
            }
            finish() {
                this._player.finish()
            }
            destroy() {
                this.destroyed = !0,
                this._player.destroy()
            }
            reset() {
                !this.queued && this._player.reset()
            }
            setPosition(e) {
                this.queued || this._player.setPosition(e)
            }
            getPosition() {
                return this.queued ? 0 : this._player.getPosition()
            }
            triggerCallback(e) {
                const t = this._player;
                t.triggerCallback && t.triggerCallback(e)
            }
        }
        function Je(e) {
            return e && 1 === e.nodeType
        }
        function Xe(e, t) {
            const n = e.style.display;
            return e.style.display = null != t ? t : "none",
            n
        }
        function et(e, t, n, r, s) {
            const i = [];
            n.forEach(e => i.push(Xe(e)));
            const o = [];
            r.forEach( (n, r) => {
                const i = {};
                n.forEach(e => {
                    const n = i[e] = t.computeStyle(r, e, s);
                    n && 0 != n.length || (r[qe] = $e,
                    o.push(r))
                }
                ),
                e.set(r, i)
            }
            );
            let a = 0;
            return n.forEach(e => Xe(e, i[a++])),
            o
        }
        function tt(e, t) {
            const n = new Map;
            if (e.forEach(e => n.set(e, [])),
            0 == t.length)
                return n;
            const r = new Set(t)
              , s = new Map;
            return t.forEach(e => {
                const t = function e(t) {
                    if (!t)
                        return 1;
                    let i = s.get(t);
                    if (i)
                        return i;
                    const o = t.parentNode;
                    return i = n.has(o) ? o : r.has(o) ? 1 : e(o),
                    s.set(t, i),
                    i
                }(e);
                1 !== t && n.get(t).push(e)
            }
            ),
            n
        }
        const nt = "$$classes";
        function rt(e, t) {
            if (e.classList)
                e.classList.add(t);
            else {
                let n = e[nt];
                n || (n = e[nt] = {}),
                n[t] = !0
            }
        }
        function st(e, t) {
            if (e.classList)
                e.classList.remove(t);
            else {
                let n = e[nt];
                n && delete n[t]
            }
        }
        function it(e, t, n) {
            i(n).onDone( () => e.processLeaveNode(t))
        }
        function ot(e, t, n) {
            const r = n.get(e);
            if (!r)
                return !1;
            let s = t.get(e);
            return s ? r.forEach(e => s.add(e)) : t.set(e, r),
            n.delete(e),
            !0
        }
        class at {
            constructor(e, t, n) {
                this.bodyNode = e,
                this._driver = t,
                this._triggerCache = {},
                this.onRemovalComplete = (e, t) => {}
                ,
                this._transitionEngine = new Ze(e,t,n),
                this._timelineEngine = new Pe(e,t,n),
                this._transitionEngine.onRemovalComplete = (e, t) => this.onRemovalComplete(e, t)
            }
            registerTrigger(e, t, n, r, s) {
                const i = e + "-" + r;
                let o = this._triggerCache[i];
                if (!o) {
                    const e = []
                      , t = oe(this._driver, s, e);
                    if (e.length)
                        throw new Error(`The animation trigger "${r}" has failed to build due to the following errors:\n - ${e.join("\n - ")}`);
                    o = function(e, t) {
                        return new Re(e,t)
                    }(r, t),
                    this._triggerCache[i] = o
                }
                this._transitionEngine.registerTrigger(t, r, o)
            }
            register(e, t) {
                this._transitionEngine.register(e, t)
            }
            destroy(e, t) {
                this._transitionEngine.destroy(e, t)
            }
            onInsert(e, t, n, r) {
                this._transitionEngine.insertNode(e, t, n, r)
            }
            onRemove(e, t, n, r) {
                this._transitionEngine.removeNode(e, t, r || !1, n)
            }
            disableAnimations(e, t) {
                this._transitionEngine.markElementAsDisabled(e, t)
            }
            process(e, t, n, r) {
                if ("@" == n.charAt(0)) {
                    const [e,s] = h(n);
                    this._timelineEngine.command(e, t, s, r)
                } else
                    this._transitionEngine.trigger(e, t, n, r)
            }
            listen(e, t, n, r, s) {
                if ("@" == n.charAt(0)) {
                    const [e,r] = h(n);
                    return this._timelineEngine.listen(e, t, r, s)
                }
                return this._transitionEngine.listen(e, t, n, r, s)
            }
            flush(e=-1) {
                this._transitionEngine.flush(e)
            }
            get players() {
                return this._transitionEngine.players.concat(this._timelineEngine.players)
            }
            whenRenderingDone() {
                return this._transitionEngine.whenRenderingDone()
            }
        }
        function ct(e, t) {
            let n = null
              , r = null;
            return Array.isArray(t) && t.length ? (n = ut(t[0]),
            t.length > 1 && (r = ut(t[t.length - 1]))) : t && (n = ut(t)),
            n || r ? new lt(e,n,r) : null
        }
        let lt = ( () => {
            class e {
                constructor(t, n, r) {
                    this._element = t,
                    this._startStyles = n,
                    this._endStyles = r,
                    this._state = 0;
                    let s = e.initialStylesByElement.get(t);
                    s || e.initialStylesByElement.set(t, s = {}),
                    this._initialStyles = s
                }
                start() {
                    this._state < 1 && (this._startStyles && z(this._element, this._startStyles, this._initialStyles),
                    this._state = 1)
                }
                finish() {
                    this.start(),
                    this._state < 2 && (z(this._element, this._initialStyles),
                    this._endStyles && (z(this._element, this._endStyles),
                    this._endStyles = null),
                    this._state = 1)
                }
                destroy() {
                    this.finish(),
                    this._state < 3 && (e.initialStylesByElement.delete(this._element),
                    this._startStyles && (H(this._element, this._startStyles),
                    this._endStyles = null),
                    this._endStyles && (H(this._element, this._endStyles),
                    this._endStyles = null),
                    z(this._element, this._initialStyles),
                    this._state = 3)
                }
            }
            return e.initialStylesByElement = new WeakMap,
            e
        }
        )();
        function ut(e) {
            let t = null;
            const n = Object.keys(e);
            for (let r = 0; r < n.length; r++) {
                const s = n[r];
                ht(s) && ((t = t || {})[s] = e[s])
            }
            return t
        }
        function ht(e) {
            return "display" === e || "position" === e
        }
        const dt = 3
          , ft = "animation"
          , pt = "animationend"
          , mt = 1e3;
        class gt {
            constructor(e, t, n, r, s, i, o) {
                this._element = e,
                this._name = t,
                this._duration = n,
                this._delay = r,
                this._easing = s,
                this._fillMode = i,
                this._onDoneFn = o,
                this._finished = !1,
                this._destroyed = !1,
                this._startTime = 0,
                this._position = 0,
                this._eventFn = e => this._handleCallback(e)
            }
            apply() {
                !function(e, t) {
                    const n = Et(e, "").trim();
                    n.length && (function(e, t) {
                        let n = 0;
                        for (let r = 0; r < e.length; r++)
                            "," === e.charAt(r) && n++
                    }(n),
                    t = `${n}, ${t}`),
                    wt(e, "", t)
                }(this._element, `${this._duration}ms ${this._easing} ${this._delay}ms 1 normal ${this._fillMode} ${this._name}`),
                _t(this._element, this._eventFn, !1),
                this._startTime = Date.now()
            }
            pause() {
                bt(this._element, this._name, "paused")
            }
            resume() {
                bt(this._element, this._name, "running")
            }
            setPosition(e) {
                const t = yt(this._element, this._name);
                this._position = e * this._duration,
                wt(this._element, "Delay", `-${this._position}ms`, t)
            }
            getPosition() {
                return this._position
            }
            _handleCallback(e) {
                const t = e._ngTestManualTimestamp || Date.now()
                  , n = parseFloat(e.elapsedTime.toFixed(dt)) * mt;
                e.animationName == this._name && Math.max(t - this._startTime, 0) >= this._delay && n >= this._duration && this.finish()
            }
            finish() {
                this._finished || (this._finished = !0,
                this._onDoneFn(),
                _t(this._element, this._eventFn, !0))
            }
            destroy() {
                this._destroyed || (this._destroyed = !0,
                this.finish(),
                function(e, t) {
                    const n = Et(e, "").split(",")
                      , r = vt(n, t);
                    r >= 0 && (n.splice(r, 1),
                    wt(e, "", n.join(",")))
                }(this._element, this._name))
            }
        }
        function bt(e, t, n) {
            wt(e, "PlayState", n, yt(e, t))
        }
        function yt(e, t) {
            const n = Et(e, "");
            return n.indexOf(",") > 0 ? vt(n.split(","), t) : vt([n], t)
        }
        function vt(e, t) {
            for (let n = 0; n < e.length; n++)
                if (e[n].indexOf(t) >= 0)
                    return n;
            return -1
        }
        function _t(e, t, n) {
            n ? e.removeEventListener(pt, t) : e.addEventListener(pt, t)
        }
        function wt(e, t, n, r) {
            const s = ft + t;
            if (null != r) {
                const t = e.style[s];
                if (t.length) {
                    const e = t.split(",");
                    e[r] = n,
                    n = e.join(",")
                }
            }
            e.style[s] = n
        }
        function Et(e, t) {
            return e.style[ft + t]
        }
        const St = "forwards"
          , Ct = "linear";
        class Tt {
            constructor(e, t, n, r, s, i, o, a) {
                this.element = e,
                this.keyframes = t,
                this.animationName = n,
                this._duration = r,
                this._delay = s,
                this._finalStyles = o,
                this._specialStyles = a,
                this._onDoneFns = [],
                this._onStartFns = [],
                this._onDestroyFns = [],
                this._started = !1,
                this.currentSnapshot = {},
                this._state = 0,
                this.easing = i || Ct,
                this.totalTime = r + s,
                this._buildStyler()
            }
            onStart(e) {
                this._onStartFns.push(e)
            }
            onDone(e) {
                this._onDoneFns.push(e)
            }
            onDestroy(e) {
                this._onDestroyFns.push(e)
            }
            destroy() {
                this.init(),
                this._state >= 4 || (this._state = 4,
                this._styler.destroy(),
                this._flushStartFns(),
                this._flushDoneFns(),
                this._specialStyles && this._specialStyles.destroy(),
                this._onDestroyFns.forEach(e => e()),
                this._onDestroyFns = [])
            }
            _flushDoneFns() {
                this._onDoneFns.forEach(e => e()),
                this._onDoneFns = []
            }
            _flushStartFns() {
                this._onStartFns.forEach(e => e()),
                this._onStartFns = []
            }
            finish() {
                this.init(),
                this._state >= 3 || (this._state = 3,
                this._styler.finish(),
                this._flushStartFns(),
                this._specialStyles && this._specialStyles.finish(),
                this._flushDoneFns())
            }
            setPosition(e) {
                this._styler.setPosition(e)
            }
            getPosition() {
                return this._styler.getPosition()
            }
            hasStarted() {
                return this._state >= 2
            }
            init() {
                this._state >= 1 || (this._state = 1,
                this._styler.apply(),
                this._delay && this._styler.pause())
            }
            play() {
                this.init(),
                this.hasStarted() || (this._flushStartFns(),
                this._state = 2,
                this._specialStyles && this._specialStyles.start()),
                this._styler.resume()
            }
            pause() {
                this.init(),
                this._styler.pause()
            }
            restart() {
                this.reset(),
                this.play()
            }
            reset() {
                this._styler.destroy(),
                this._buildStyler(),
                this._styler.apply()
            }
            _buildStyler() {
                this._styler = new gt(this.element,this.animationName,this._duration,this._delay,this.easing,St, () => this.finish())
            }
            triggerCallback(e) {
                const t = "start" == e ? this._onStartFns : this._onDoneFns;
                t.forEach(e => e()),
                t.length = 0
            }
            beforeDestroy() {
                this.init();
                const e = {};
                if (this.hasStarted()) {
                    const t = this._state >= 3;
                    Object.keys(this._finalStyles).forEach(n => {
                        "offset" != n && (e[n] = t ? this._finalStyles[n] : J(this.element, n))
                    }
                    )
                }
                this.currentSnapshot = e
            }
        }
        class xt extends r.d {
            constructor(e, t) {
                super(),
                this.element = e,
                this._startingStyles = {},
                this.__initialized = !1,
                this._styles = E(t)
            }
            init() {
                !this.__initialized && this._startingStyles && (this.__initialized = !0,
                Object.keys(this._styles).forEach(e => {
                    this._startingStyles[e] = this.element.style[e]
                }
                ),
                super.init())
            }
            play() {
                this._startingStyles && (this.init(),
                Object.keys(this._styles).forEach(e => this.element.style.setProperty(e, this._styles[e])),
                super.play())
            }
            destroy() {
                this._startingStyles && (Object.keys(this._startingStyles).forEach(e => {
                    const t = this._startingStyles[e];
                    t ? this.element.style.setProperty(e, t) : this.element.style.removeProperty(e)
                }
                ),
                this._startingStyles = null,
                super.destroy())
            }
        }
        const kt = "gen_css_kf_"
          , Ot = " ";
        class It {
            constructor() {
                this._count = 0,
                this._head = document.querySelector("head"),
                this._warningIssued = !1
            }
            validateStyleProperty(e) {
                return y(e)
            }
            matchesElement(e, t) {
                return v(e, t)
            }
            containsElement(e, t) {
                return _(e, t)
            }
            query(e, t, n) {
                return w(e, t, n)
            }
            computeStyle(e, t, n) {
                return window.getComputedStyle(e)[t]
            }
            buildKeyframeElement(e, t, n) {
                n = n.map(e => E(e));
                let r = `@keyframes ${t} {\n`
                  , s = "";
                n.forEach(e => {
                    s = Ot;
                    const t = parseFloat(e.offset);
                    r += `${s}${100 * t}% {\n`,
                    s += Ot,
                    Object.keys(e).forEach(t => {
                        const n = e[t];
                        switch (t) {
                        case "offset":
                            return;
                        case "easing":
                            return void (n && (r += `${s}animation-timing-function: ${n};\n`));
                        default:
                            return void (r += `${s}${t}: ${n};\n`)
                        }
                    }
                    ),
                    r += `${s}}\n`
                }
                ),
                r += "}\n";
                const i = document.createElement("style");
                return i.innerHTML = r,
                i
            }
            animate(e, t, n, r, s, i=[], o) {
                o && this._notifyFaultyScrubber();
                const a = i.filter(e => e instanceof Tt)
                  , c = {};
                W(n, r) && a.forEach(e => {
                    let t = e.currentSnapshot;
                    Object.keys(t).forEach(e => c[e] = t[e])
                }
                );
                const l = function(e) {
                    let t = {};
                    return e && (Array.isArray(e) ? e : [e]).forEach(e => {
                        Object.keys(e).forEach(n => {
                            "offset" != n && "easing" != n && (t[n] = e[n])
                        }
                        )
                    }
                    ),
                    t
                }(t = Z(e, t, c));
                if (0 == n)
                    return new xt(e,l);
                const u = `${kt}${this._count++}`
                  , h = this.buildKeyframeElement(e, u, t);
                document.querySelector("head").appendChild(h);
                const d = ct(e, t)
                  , f = new Tt(e,t,u,n,r,s,l,d);
                return f.onDestroy( () => (function(e) {
                    h.parentNode.removeChild(h)
                }
                )()),
                f
            }
            _notifyFaultyScrubber() {
                this._warningIssued || (console.warn("@angular/animations: please load the web-animations.js polyfill to allow programmatic access...\n", "  visit http://bit.ly/IWukam to learn more about using the web-animation-js polyfill."),
                this._warningIssued = !0)
            }
        }
        class At {
            constructor(e, t, n, r) {
                this.element = e,
                this.keyframes = t,
                this.options = n,
                this._specialStyles = r,
                this._onDoneFns = [],
                this._onStartFns = [],
                this._onDestroyFns = [],
                this._initialized = !1,
                this._finished = !1,
                this._started = !1,
                this._destroyed = !1,
                this.time = 0,
                this.parentPlayer = null,
                this.currentSnapshot = {},
                this._duration = n.duration,
                this._delay = n.delay || 0,
                this.time = this._duration + this._delay
            }
            _onFinish() {
                this._finished || (this._finished = !0,
                this._onDoneFns.forEach(e => e()),
                this._onDoneFns = [])
            }
            init() {
                this._buildPlayer(),
                this._preparePlayerBeforeStart()
            }
            _buildPlayer() {
                if (this._initialized)
                    return;
                this._initialized = !0;
                const e = this.keyframes;
                this.domPlayer = this._triggerWebAnimation(this.element, e, this.options),
                this._finalKeyframe = e.length ? e[e.length - 1] : {},
                this.domPlayer.addEventListener("finish", () => this._onFinish())
            }
            _preparePlayerBeforeStart() {
                this._delay ? this._resetDomPlayerState() : this.domPlayer.pause()
            }
            _triggerWebAnimation(e, t, n) {
                return e.animate(t, n)
            }
            onStart(e) {
                this._onStartFns.push(e)
            }
            onDone(e) {
                this._onDoneFns.push(e)
            }
            onDestroy(e) {
                this._onDestroyFns.push(e)
            }
            play() {
                this._buildPlayer(),
                this.hasStarted() || (this._onStartFns.forEach(e => e()),
                this._onStartFns = [],
                this._started = !0,
                this._specialStyles && this._specialStyles.start()),
                this.domPlayer.play()
            }
            pause() {
                this.init(),
                this.domPlayer.pause()
            }
            finish() {
                this.init(),
                this._specialStyles && this._specialStyles.finish(),
                this._onFinish(),
                this.domPlayer.finish()
            }
            reset() {
                this._resetDomPlayerState(),
                this._destroyed = !1,
                this._finished = !1,
                this._started = !1
            }
            _resetDomPlayerState() {
                this.domPlayer && this.domPlayer.cancel()
            }
            restart() {
                this.reset(),
                this.play()
            }
            hasStarted() {
                return this._started
            }
            destroy() {
                this._destroyed || (this._destroyed = !0,
                this._resetDomPlayerState(),
                this._onFinish(),
                this._specialStyles && this._specialStyles.destroy(),
                this._onDestroyFns.forEach(e => e()),
                this._onDestroyFns = [])
            }
            setPosition(e) {
                this.domPlayer.currentTime = e * this.time
            }
            getPosition() {
                return this.domPlayer.currentTime / this.time
            }
            get totalTime() {
                return this._delay + this._duration
            }
            beforeDestroy() {
                const e = {};
                this.hasStarted() && Object.keys(this._finalKeyframe).forEach(t => {
                    "offset" != t && (e[t] = this._finished ? this._finalKeyframe[t] : J(this.element, t))
                }
                ),
                this.currentSnapshot = e
            }
            triggerCallback(e) {
                const t = "start" == e ? this._onStartFns : this._onDoneFns;
                t.forEach(e => e()),
                t.length = 0
            }
        }
        class Dt {
            constructor() {
                this._isNativeImpl = /\{\s*\[native\s+code\]\s*\}/.test(jt().toString()),
                this._cssKeyframesDriver = new It
            }
            validateStyleProperty(e) {
                return y(e)
            }
            matchesElement(e, t) {
                return v(e, t)
            }
            containsElement(e, t) {
                return _(e, t)
            }
            query(e, t, n) {
                return w(e, t, n)
            }
            computeStyle(e, t, n) {
                return window.getComputedStyle(e)[t]
            }
            overrideWebAnimationsSupport(e) {
                this._isNativeImpl = e
            }
            animate(e, t, n, r, s, i=[], o) {
                if (!o && !this._isNativeImpl)
                    return this._cssKeyframesDriver.animate(e, t, n, r, s, i);
                const a = {
                    duration: n,
                    delay: r,
                    fill: 0 == r ? "both" : "forwards"
                };
                s && (a.easing = s);
                const c = {}
                  , l = i.filter(e => e instanceof At);
                W(n, r) && l.forEach(e => {
                    let t = e.currentSnapshot;
                    Object.keys(t).forEach(e => c[e] = t[e])
                }
                );
                const u = ct(e, t = Z(e, t = t.map(e => L(e, !1)), c));
                return new At(e,t,a,u)
            }
        }
        function Rt() {
            return "function" == typeof jt()
        }
        function jt() {
            return "undefined" != typeof window && void 0 !== window.document && Element.prototype.animate || {}
        }
    },
    gJmp: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("PJcQ");
        class s {
            constructor() {
                this.initialized = !1,
                this.removeEventListeners = [],
                this.subscriptions = []
            }
            get fontSize() {
                let e = s.$fontSize;
                return e || (e = this.getFontSize(),
                s.$fontSize = e),
                e
            }
            static init(e) {
                s.resourceService || (s.resourceService = e)
            }
            ngAfterViewInit() {
                this.initialized = !0
            }
            ngOnDestroy() {
                if (this.removeEventListeners.length > 0) {
                    let e;
                    for (; e = this.removeEventListeners.pop(); )
                        e()
                }
                if (this.subscriptions.length > 0) {
                    let e;
                    for (; e = this.subscriptions.pop(); )
                        e.unsubscribe()
                }
                r.a.isDefined(this.resizeTimer) && (window.clearTimeout(this.resizeTimer),
                this.resizeTimer = void 0)
            }
            resizeHandler(e, t) {
                e.runOutsideAngular( () => {
                    r.a.isDefined(this.resizeTimer) && window.clearTimeout(this.resizeTimer),
                    this.resizeTimer = window.setTimeout( () => {
                        this.resizeTimer = void 0,
                        t.call(this)
                    }
                    , 50)
                }
                )
            }
            handleChangeDetection(e, t) {
                const n = e.onMicrotaskEmpty.subscribe( () => {
                    n.unsubscribe(),
                    t.call(this)
                }
                )
            }
            getResourceValue(e, ...t) {
                return s.resourceService.get(e, ...t)
            }
            getFontSize() {
                const e = getComputedStyle(document.body, "");
                return parseInt(e.fontSize.replace(/(px|pt)/, ""), 10)
            }
        }
    },
    gRHU: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        var r = n("2fFW")
          , s = n("NJ4a");
        const i = {
            closed: !0,
            next(e) {},
            error(e) {
                if (r.a.useDeprecatedSynchronousErrorHandling)
                    throw e;
                Object(s.a)(e)
            },
            complete() {}
        }
    },
    iInd: function(e, t, n) {
        "use strict";
        var r = n("SVse")
          , s = n("8Y7J")
          , i = n("LRne")
          , o = n("Cfvw")
          , a = n("2Vo4")
          , c = n("HDdC");
        function l() {
            return Error.call(this),
            this.message = "no elements in sequence",
            this.name = "EmptyError",
            this
        }
        l.prototype = Object.create(Error.prototype);
        const u = l;
        var h = n("itXk")
          , d = n("NXyV")
          , f = n("XNiG")
          , p = n("EY2u")
          , m = n("lJxs")
          , g = n("0EUg")
          , b = n("pLZG")
          , y = n("7o/Q")
          , v = n("4I5i");
        function _(e) {
            return function(t) {
                return 0 === e ? Object(p.b)() : t.lift(new w(e))
            }
        }
        class w {
            constructor(e) {
                if (this.total = e,
                this.total < 0)
                    throw new v.a
            }
            call(e, t) {
                return t.subscribe(new E(e,this.total))
            }
        }
        class E extends y.a {
            constructor(e, t) {
                super(e),
                this.total = t,
                this.ring = new Array,
                this.count = 0
            }
            _next(e) {
                const t = this.ring
                  , n = this.total
                  , r = this.count++;
                t.length < n ? t.push(e) : t[r % n] = e
            }
            _complete() {
                const e = this.destination;
                let t = this.count;
                if (t > 0) {
                    const n = this.count >= this.total ? this.total : this.count
                      , r = this.ring;
                    for (let s = 0; s < n; s++) {
                        const s = t++ % n;
                        e.next(r[s])
                    }
                }
                e.complete()
            }
        }
        var S = n("vkgz");
        const C = (e=function() {
            return new u
        }
        ) => Object(S.a)({
            hasValue: !1,
            next() {
                this.hasValue = !0
            },
            complete() {
                if (!this.hasValue)
                    throw e()
            }
        });
        function T(e=null) {
            return t => t.lift(new x(e))
        }
        class x {
            constructor(e) {
                this.defaultValue = e
            }
            call(e, t) {
                return t.subscribe(new k(e,this.defaultValue))
            }
        }
        class k extends y.a {
            constructor(e, t) {
                super(e),
                this.defaultValue = t,
                this.isEmpty = !0
            }
            _next(e) {
                this.isEmpty = !1,
                this.destination.next(e)
            }
            _complete() {
                this.isEmpty && this.destination.next(this.defaultValue),
                this.destination.complete()
            }
        }
        var O = n("SpAZ");
        function I(e, t) {
            const n = arguments.length >= 2;
            return r => r.pipe(e ? Object(b.a)( (t, n) => e(t, n, r)) : O.a, _(1), n ? T(t) : C( () => new u))
        }
        var A = n("JIr8")
          , D = n("IzEk");
        function R(e, t) {
            const n = arguments.length >= 2;
            return r => r.pipe(e ? Object(b.a)( (t, n) => e(t, n, r)) : O.a, Object(D.a)(1), n ? T(t) : C( () => new u))
        }
        var j = n("5+tZ");
        class N {
            constructor(e, t, n) {
                this.predicate = e,
                this.thisArg = t,
                this.source = n
            }
            call(e, t) {
                return t.subscribe(new P(e,this.predicate,this.thisArg,this.source))
            }
        }
        class P extends y.a {
            constructor(e, t, n, r) {
                super(e),
                this.predicate = t,
                this.thisArg = n,
                this.source = r,
                this.index = 0,
                this.thisArg = n || this
            }
            notifyComplete(e) {
                this.destination.next(e),
                this.destination.complete()
            }
            _next(e) {
                let t = !1;
                try {
                    t = this.predicate.call(this.thisArg, e, this.index++, this.source)
                } catch (n) {
                    return void this.destination.error(n)
                }
                t || this.notifyComplete(!1)
            }
            _complete() {
                this.notifyComplete(!0)
            }
        }
        var M = n("eIep")
          , L = n("JX91")
          , F = n("Kqap")
          , U = n("bOdf")
          , z = n("mCNh")
          , H = n("nYR2")
          , B = n("bHdf")
          , V = n("cUpR");
        n.d(t, "B", function() {
            return ae
        }),
        n.d(t, "r", function() {
            return wn
        }),
        n.d(t, "y", function() {
            return Dn
        }),
        n.d(t, "t", function() {
            return Tn
        }),
        n.d(t, "z", function() {
            return Rn
        }),
        n.d(t, "A", function() {
            return jn
        }),
        n.d(t, "v", function() {
            return kn
        }),
        n.d(t, "u", function() {
            return xn
        }),
        n.d(t, "x", function() {
            return An
        }),
        n.d(t, "s", function() {
            return Sn
        }),
        n.d(t, "w", function() {
            return In
        }),
        n.d(t, "C", function() {
            return vn
        }),
        n.d(t, "n", function() {
            return fn
        }),
        n.d(t, "d", function() {
            return Q
        }),
        n.d(t, "k", function() {
            return en
        }),
        n.d(t, "l", function() {
            return un
        }),
        n.d(t, "j", function() {
            return nn
        }),
        n.d(t, "h", function() {
            return _n
        }),
        n.d(t, "i", function() {
            return Nn
        }),
        n.d(t, "m", function() {
            return Cn
        }),
        n.d(t, "b", function() {
            return dn
        }),
        n.d(t, "e", function() {
            return bn
        }),
        n.d(t, "f", function() {
            return gn
        }),
        n.d(t, "g", function() {
            return mn
        }),
        n.d(t, "o", function() {
            return yn
        }),
        n.d(t, "a", function() {
            return Je
        }),
        n.d(t, "p", function() {
            return sn
        }),
        n.d(t, "c", function() {
            return De
        }),
        n.d(t, "q", function() {
            return Ae
        });
        class $ {
            constructor(e, t) {
                this.id = e,
                this.url = t
            }
        }
        class q extends $ {
            constructor(e, t, n="imperative", r=null) {
                super(e, t),
                this.navigationTrigger = n,
                this.restoredState = r
            }
            toString() {
                return `NavigationStart(id: ${this.id}, url: '${this.url}')`
            }
        }
        class Q extends $ {
            constructor(e, t, n) {
                super(e, t),
                this.urlAfterRedirects = n
            }
            toString() {
                return `NavigationEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}')`
            }
        }
        class G extends $ {
            constructor(e, t, n) {
                super(e, t),
                this.reason = n
            }
            toString() {
                return `NavigationCancel(id: ${this.id}, url: '${this.url}')`
            }
        }
        class K extends $ {
            constructor(e, t, n) {
                super(e, t),
                this.error = n
            }
            toString() {
                return `NavigationError(id: ${this.id}, url: '${this.url}', error: ${this.error})`
            }
        }
        class W extends $ {
            constructor(e, t, n, r) {
                super(e, t),
                this.urlAfterRedirects = n,
                this.state = r
            }
            toString() {
                return `RoutesRecognized(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
            }
        }
        class Z extends $ {
            constructor(e, t, n, r) {
                super(e, t),
                this.urlAfterRedirects = n,
                this.state = r
            }
            toString() {
                return `GuardsCheckStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
            }
        }
        class Y extends $ {
            constructor(e, t, n, r, s) {
                super(e, t),
                this.urlAfterRedirects = n,
                this.state = r,
                this.shouldActivate = s
            }
            toString() {
                return `GuardsCheckEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state}, shouldActivate: ${this.shouldActivate})`
            }
        }
        class J extends $ {
            constructor(e, t, n, r) {
                super(e, t),
                this.urlAfterRedirects = n,
                this.state = r
            }
            toString() {
                return `ResolveStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
            }
        }
        class X extends $ {
            constructor(e, t, n, r) {
                super(e, t),
                this.urlAfterRedirects = n,
                this.state = r
            }
            toString() {
                return `ResolveEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`
            }
        }
        class ee {
            constructor(e) {
                this.route = e
            }
            toString() {
                return `RouteConfigLoadStart(path: ${this.route.path})`
            }
        }
        class te {
            constructor(e) {
                this.route = e
            }
            toString() {
                return `RouteConfigLoadEnd(path: ${this.route.path})`
            }
        }
        class ne {
            constructor(e) {
                this.snapshot = e
            }
            toString() {
                return `ChildActivationStart(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`
            }
        }
        class re {
            constructor(e) {
                this.snapshot = e
            }
            toString() {
                return `ChildActivationEnd(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`
            }
        }
        class se {
            constructor(e) {
                this.snapshot = e
            }
            toString() {
                return `ActivationStart(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`
            }
        }
        class ie {
            constructor(e) {
                this.snapshot = e
            }
            toString() {
                return `ActivationEnd(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`
            }
        }
        class oe {
            constructor(e, t, n) {
                this.routerEvent = e,
                this.position = t,
                this.anchor = n
            }
            toString() {
                return `Scroll(anchor: '${this.anchor}', position: '${this.position ? `${this.position[0]}, ${this.position[1]}` : null}')`
            }
        }
        class ae {
        }
        const ce = "primary";
        class le {
            constructor(e) {
                this.params = e || {}
            }
            has(e) {
                return this.params.hasOwnProperty(e)
            }
            get(e) {
                if (this.has(e)) {
                    const t = this.params[e];
                    return Array.isArray(t) ? t[0] : t
                }
                return null
            }
            getAll(e) {
                if (this.has(e)) {
                    const t = this.params[e];
                    return Array.isArray(t) ? t : [t]
                }
                return []
            }
            get keys() {
                return Object.keys(this.params)
            }
        }
        function ue(e) {
            return new le(e)
        }
        const he = "ngNavigationCancelingError";
        function de(e) {
            const t = Error("NavigationCancelingError: " + e);
            return t[he] = !0,
            t
        }
        function fe(e, t, n) {
            const r = n.path.split("/");
            if (r.length > e.length)
                return null;
            if ("full" === n.pathMatch && (t.hasChildren() || r.length < e.length))
                return null;
            const s = {};
            for (let i = 0; i < r.length; i++) {
                const t = r[i]
                  , n = e[i];
                if (t.startsWith(":"))
                    s[t.substring(1)] = n;
                else if (t !== n.path)
                    return null
            }
            return {
                consumed: e.slice(0, r.length),
                posParams: s
            }
        }
        class pe {
            constructor(e, t) {
                this.routes = e,
                this.module = t
            }
        }
        function me(e, t="") {
            for (let n = 0; n < e.length; n++) {
                const r = e[n];
                ge(r, be(t, r))
            }
        }
        function ge(e, t) {
            if (!e)
                throw new Error(`\n      Invalid configuration of route '${t}': Encountered undefined route.\n      The reason might be an extra comma.\n\n      Example:\n      const routes: Routes = [\n        { path: '', redirectTo: '/dashboard', pathMatch: 'full' },\n        { path: 'dashboard',  component: DashboardComponent },, << two commas\n        { path: 'detail/:id', component: HeroDetailComponent }\n      ];\n    `);
            if (Array.isArray(e))
                throw new Error(`Invalid configuration of route '${t}': Array cannot be specified`);
            if (!e.component && !e.children && !e.loadChildren && e.outlet && e.outlet !== ce)
                throw new Error(`Invalid configuration of route '${t}': a componentless route without children or loadChildren cannot have a named outlet set`);
            if (e.redirectTo && e.children)
                throw new Error(`Invalid configuration of route '${t}': redirectTo and children cannot be used together`);
            if (e.redirectTo && e.loadChildren)
                throw new Error(`Invalid configuration of route '${t}': redirectTo and loadChildren cannot be used together`);
            if (e.children && e.loadChildren)
                throw new Error(`Invalid configuration of route '${t}': children and loadChildren cannot be used together`);
            if (e.redirectTo && e.component)
                throw new Error(`Invalid configuration of route '${t}': redirectTo and component cannot be used together`);
            if (e.path && e.matcher)
                throw new Error(`Invalid configuration of route '${t}': path and matcher cannot be used together`);
            if (void 0 === e.redirectTo && !e.component && !e.children && !e.loadChildren)
                throw new Error(`Invalid configuration of route '${t}'. One of the following must be provided: component, redirectTo, children or loadChildren`);
            if (void 0 === e.path && void 0 === e.matcher)
                throw new Error(`Invalid configuration of route '${t}': routes must have either a path or a matcher specified`);
            if ("string" == typeof e.path && "/" === e.path.charAt(0))
                throw new Error(`Invalid configuration of route '${t}': path cannot start with a slash`);
            if ("" === e.path && void 0 !== e.redirectTo && void 0 === e.pathMatch)
                throw new Error(`Invalid configuration of route '{path: "${t}", redirectTo: "${e.redirectTo}"}': please provide 'pathMatch'. The default value of 'pathMatch' is 'prefix', but often the intent is to use 'full'.`);
            if (void 0 !== e.pathMatch && "full" !== e.pathMatch && "prefix" !== e.pathMatch)
                throw new Error(`Invalid configuration of route '${t}': pathMatch can only be set to 'prefix' or 'full'`);
            e.children && me(e.children, t)
        }
        function be(e, t) {
            return t ? e || t.path ? e && !t.path ? `${e}/` : !e && t.path ? t.path : `${e}/${t.path}` : "" : e
        }
        function ye(e) {
            const t = e.children && e.children.map(ye)
              , n = t ? Object.assign({}, e, {
                children: t
            }) : Object.assign({}, e);
            return !n.component && (t || n.loadChildren) && n.outlet && n.outlet !== ce && (n.component = ae),
            n
        }
        function ve(e, t) {
            const n = Object.keys(e)
              , r = Object.keys(t);
            if (!n || !r || n.length != r.length)
                return !1;
            let s;
            for (let i = 0; i < n.length; i++)
                if (e[s = n[i]] !== t[s])
                    return !1;
            return !0
        }
        function _e(e) {
            return Array.prototype.concat.apply([], e)
        }
        function we(e) {
            return e.length > 0 ? e[e.length - 1] : null
        }
        function Ee(e, t) {
            for (const n in e)
                e.hasOwnProperty(n) && t(e[n], n)
        }
        function Se(e) {
            return Object(s.xb)(e) ? e : Object(s.yb)(e) ? Object(o.a)(Promise.resolve(e)) : Object(i.a)(e)
        }
        function Ce(e, t, n) {
            return n ? function(e, t) {
                return ve(e, t)
            }(e.queryParams, t.queryParams) && function e(t, n) {
                if (!Oe(t.segments, n.segments))
                    return !1;
                if (t.numberOfChildren !== n.numberOfChildren)
                    return !1;
                for (const r in n.children) {
                    if (!t.children[r])
                        return !1;
                    if (!e(t.children[r], n.children[r]))
                        return !1
                }
                return !0
            }(e.root, t.root) : function(e, t) {
                return Object.keys(t).length <= Object.keys(e).length && Object.keys(t).every(n => t[n] === e[n])
            }(e.queryParams, t.queryParams) && function e(t, n) {
                return function t(n, r, s) {
                    if (n.segments.length > s.length) {
                        return !!Oe(n.segments.slice(0, s.length), s) && !r.hasChildren()
                    }
                    if (n.segments.length === s.length) {
                        if (!Oe(n.segments, s))
                            return !1;
                        for (const t in r.children) {
                            if (!n.children[t])
                                return !1;
                            if (!e(n.children[t], r.children[t]))
                                return !1
                        }
                        return !0
                    }
                    {
                        const e = s.slice(0, n.segments.length)
                          , i = s.slice(n.segments.length);
                        return !!Oe(n.segments, e) && !!n.children[ce] && t(n.children[ce], r, i)
                    }
                }(t, n, n.segments)
            }(e.root, t.root)
        }
        class Te {
            constructor(e, t, n) {
                this.root = e,
                this.queryParams = t,
                this.fragment = n
            }
            get queryParamMap() {
                return this._queryParamMap || (this._queryParamMap = ue(this.queryParams)),
                this._queryParamMap
            }
            toString() {
                return Re.serialize(this)
            }
        }
        class xe {
            constructor(e, t) {
                this.segments = e,
                this.children = t,
                this.parent = null,
                Ee(t, (e, t) => e.parent = this)
            }
            hasChildren() {
                return this.numberOfChildren > 0
            }
            get numberOfChildren() {
                return Object.keys(this.children).length
            }
            toString() {
                return je(this)
            }
        }
        class ke {
            constructor(e, t) {
                this.path = e,
                this.parameters = t
            }
            get parameterMap() {
                return this._parameterMap || (this._parameterMap = ue(this.parameters)),
                this._parameterMap
            }
            toString() {
                return Ue(this)
            }
        }
        function Oe(e, t) {
            return e.length === t.length && e.every( (e, n) => e.path === t[n].path)
        }
        function Ie(e, t) {
            let n = [];
            return Ee(e.children, (e, r) => {
                r === ce && (n = n.concat(t(e, r)))
            }
            ),
            Ee(e.children, (e, r) => {
                r !== ce && (n = n.concat(t(e, r)))
            }
            ),
            n
        }
        class Ae {
        }
        class De {
            parse(e) {
                const t = new $e(e);
                return new Te(t.parseRootSegment(),t.parseQueryParams(),t.parseFragment())
            }
            serialize(e) {
                var t;
                return `${`/${function e(t, n) {
                    if (!t.hasChildren())
                        return je(t);
                    if (n) {
                        const n = t.children[ce] ? e(t.children[ce], !1) : ""
                          , r = [];
                        return Ee(t.children, (t, n) => {
                            n !== ce && r.push(`${n}:${e(t, !1)}`)
                        }
                        ),
                        r.length > 0 ? `${n}(${r.join("//")})` : n
                    }
                    {
                        const n = Ie(t, (n, r) => r === ce ? [e(t.children[ce], !1)] : [`${r}:${e(n, !1)}`]);
                        return `${je(t)}/(${n.join("//")})`
                    }
                }(e.root, !0)}`}${function(e) {
                    const t = Object.keys(e).map(t => {
                        const n = e[t];
                        return Array.isArray(n) ? n.map(e => `${Pe(t)}=${Pe(e)}`).join("&") : `${Pe(t)}=${Pe(n)}`
                    }
                    );
                    return t.length ? `?${t.join("&")}` : ""
                }(e.queryParams)}${"string" == typeof e.fragment ? `#${t = e.fragment,
                encodeURI(t)}` : ""}`
            }
        }
        const Re = new De;
        function je(e) {
            return e.segments.map(e => Ue(e)).join("/")
        }
        function Ne(e) {
            return encodeURIComponent(e).replace(/%40/g, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",")
        }
        function Pe(e) {
            return Ne(e).replace(/%3B/gi, ";")
        }
        function Me(e) {
            return Ne(e).replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/%26/gi, "&")
        }
        function Le(e) {
            return decodeURIComponent(e)
        }
        function Fe(e) {
            return Le(e.replace(/\+/g, "%20"))
        }
        function Ue(e) {
            return `${Me(e.path)}${t = e.parameters,
            Object.keys(t).map(e => `;${Me(e)}=${Me(t[e])}`).join("")}`;
            var t
        }
        const ze = /^[^\/()?;=#]+/;
        function He(e) {
            const t = e.match(ze);
            return t ? t[0] : ""
        }
        const Be = /^[^=?&#]+/
          , Ve = /^[^?&#]+/;
        class $e {
            constructor(e) {
                this.url = e,
                this.remaining = e
            }
            parseRootSegment() {
                return this.consumeOptional("/"),
                "" === this.remaining || this.peekStartsWith("?") || this.peekStartsWith("#") ? new xe([],{}) : new xe([],this.parseChildren())
            }
            parseQueryParams() {
                const e = {};
                if (this.consumeOptional("?"))
                    do {
                        this.parseQueryParam(e)
                    } while (this.consumeOptional("&"));
                return e
            }
            parseFragment() {
                return this.consumeOptional("#") ? decodeURIComponent(this.remaining) : null
            }
            parseChildren() {
                if ("" === this.remaining)
                    return {};
                this.consumeOptional("/");
                const e = [];
                for (this.peekStartsWith("(") || e.push(this.parseSegment()); this.peekStartsWith("/") && !this.peekStartsWith("//") && !this.peekStartsWith("/("); )
                    this.capture("/"),
                    e.push(this.parseSegment());
                let t = {};
                this.peekStartsWith("/(") && (this.capture("/"),
                t = this.parseParens(!0));
                let n = {};
                return this.peekStartsWith("(") && (n = this.parseParens(!1)),
                (e.length > 0 || Object.keys(t).length > 0) && (n[ce] = new xe(e,t)),
                n
            }
            parseSegment() {
                const e = He(this.remaining);
                if ("" === e && this.peekStartsWith(";"))
                    throw new Error(`Empty path url segment cannot have parameters: '${this.remaining}'.`);
                return this.capture(e),
                new ke(Le(e),this.parseMatrixParams())
            }
            parseMatrixParams() {
                const e = {};
                for (; this.consumeOptional(";"); )
                    this.parseParam(e);
                return e
            }
            parseParam(e) {
                const t = He(this.remaining);
                if (!t)
                    return;
                this.capture(t);
                let n = "";
                if (this.consumeOptional("=")) {
                    const e = He(this.remaining);
                    e && this.capture(n = e)
                }
                e[Le(t)] = Le(n)
            }
            parseQueryParam(e) {
                const t = function(e) {
                    const t = e.match(Be);
                    return t ? t[0] : ""
                }(this.remaining);
                if (!t)
                    return;
                this.capture(t);
                let n = "";
                if (this.consumeOptional("=")) {
                    const e = function(e) {
                        const t = e.match(Ve);
                        return t ? t[0] : ""
                    }(this.remaining);
                    e && this.capture(n = e)
                }
                const r = Fe(t)
                  , s = Fe(n);
                if (e.hasOwnProperty(r)) {
                    let t = e[r];
                    Array.isArray(t) || (e[r] = t = [t]),
                    t.push(s)
                } else
                    e[r] = s
            }
            parseParens(e) {
                const t = {};
                for (this.capture("("); !this.consumeOptional(")") && this.remaining.length > 0; ) {
                    const n = He(this.remaining)
                      , r = this.remaining[n.length];
                    if ("/" !== r && ")" !== r && ";" !== r)
                        throw new Error(`Cannot parse url '${this.url}'`);
                    let s = void 0;
                    n.indexOf(":") > -1 ? (s = n.substr(0, n.indexOf(":")),
                    this.capture(s),
                    this.capture(":")) : e && (s = ce);
                    const i = this.parseChildren();
                    t[s] = 1 === Object.keys(i).length ? i[ce] : new xe([],i),
                    this.consumeOptional("//")
                }
                return t
            }
            peekStartsWith(e) {
                return this.remaining.startsWith(e)
            }
            consumeOptional(e) {
                return !!this.peekStartsWith(e) && (this.remaining = this.remaining.substring(e.length),
                !0)
            }
            capture(e) {
                if (!this.consumeOptional(e))
                    throw new Error(`Expected "${e}".`)
            }
        }
        class qe {
            constructor(e) {
                this._root = e
            }
            get root() {
                return this._root.value
            }
            parent(e) {
                const t = this.pathFromRoot(e);
                return t.length > 1 ? t[t.length - 2] : null
            }
            children(e) {
                const t = Qe(e, this._root);
                return t ? t.children.map(e => e.value) : []
            }
            firstChild(e) {
                const t = Qe(e, this._root);
                return t && t.children.length > 0 ? t.children[0].value : null
            }
            siblings(e) {
                const t = Ge(e, this._root);
                return t.length < 2 ? [] : t[t.length - 2].children.map(e => e.value).filter(t => t !== e)
            }
            pathFromRoot(e) {
                return Ge(e, this._root).map(e => e.value)
            }
        }
        function Qe(e, t) {
            if (e === t.value)
                return t;
            for (const n of t.children) {
                const t = Qe(e, n);
                if (t)
                    return t
            }
            return null
        }
        function Ge(e, t) {
            if (e === t.value)
                return [t];
            for (const n of t.children) {
                const r = Ge(e, n);
                if (r.length)
                    return r.unshift(t),
                    r
            }
            return []
        }
        class Ke {
            constructor(e, t) {
                this.value = e,
                this.children = t
            }
            toString() {
                return `TreeNode(${this.value})`
            }
        }
        function We(e) {
            const t = {};
            return e && e.children.forEach(e => t[e.value.outlet] = e),
            t
        }
        class Ze extends qe {
            constructor(e, t) {
                super(e),
                this.snapshot = t,
                nt(this, e)
            }
            toString() {
                return this.snapshot.toString()
            }
        }
        function Ye(e, t) {
            const n = function(e, t) {
                const n = new et([],{},{},"",{},ce,t,null,e.root,-1,{});
                return new tt("",new Ke(n,[]))
            }(e, t)
              , r = new a.a([new ke("",{})])
              , s = new a.a({})
              , i = new a.a({})
              , o = new a.a({})
              , c = new a.a("")
              , l = new Je(r,s,o,c,i,ce,t,n.root);
            return l.snapshot = n.root,
            new Ze(new Ke(l,[]),n)
        }
        class Je {
            constructor(e, t, n, r, s, i, o, a) {
                this.url = e,
                this.params = t,
                this.queryParams = n,
                this.fragment = r,
                this.data = s,
                this.outlet = i,
                this.component = o,
                this._futureSnapshot = a
            }
            get routeConfig() {
                return this._futureSnapshot.routeConfig
            }
            get root() {
                return this._routerState.root
            }
            get parent() {
                return this._routerState.parent(this)
            }
            get firstChild() {
                return this._routerState.firstChild(this)
            }
            get children() {
                return this._routerState.children(this)
            }
            get pathFromRoot() {
                return this._routerState.pathFromRoot(this)
            }
            get paramMap() {
                return this._paramMap || (this._paramMap = this.params.pipe(Object(m.a)(e => ue(e)))),
                this._paramMap
            }
            get queryParamMap() {
                return this._queryParamMap || (this._queryParamMap = this.queryParams.pipe(Object(m.a)(e => ue(e)))),
                this._queryParamMap
            }
            toString() {
                return this.snapshot ? this.snapshot.toString() : `Future(${this._futureSnapshot})`
            }
        }
        function Xe(e, t="emptyOnly") {
            const n = e.pathFromRoot;
            let r = 0;
            if ("always" !== t)
                for (r = n.length - 1; r >= 1; ) {
                    const e = n[r]
                      , t = n[r - 1];
                    if (e.routeConfig && "" === e.routeConfig.path)
                        r--;
                    else {
                        if (t.component)
                            break;
                        r--
                    }
                }
            return function(e) {
                return e.reduce( (e, t) => ({
                    params: Object.assign({}, e.params, t.params),
                    data: Object.assign({}, e.data, t.data),
                    resolve: Object.assign({}, e.resolve, t._resolvedData)
                }), {
                    params: {},
                    data: {},
                    resolve: {}
                })
            }(n.slice(r))
        }
        class et {
            constructor(e, t, n, r, s, i, o, a, c, l, u) {
                this.url = e,
                this.params = t,
                this.queryParams = n,
                this.fragment = r,
                this.data = s,
                this.outlet = i,
                this.component = o,
                this.routeConfig = a,
                this._urlSegment = c,
                this._lastPathIndex = l,
                this._resolve = u
            }
            get root() {
                return this._routerState.root
            }
            get parent() {
                return this._routerState.parent(this)
            }
            get firstChild() {
                return this._routerState.firstChild(this)
            }
            get children() {
                return this._routerState.children(this)
            }
            get pathFromRoot() {
                return this._routerState.pathFromRoot(this)
            }
            get paramMap() {
                return this._paramMap || (this._paramMap = ue(this.params)),
                this._paramMap
            }
            get queryParamMap() {
                return this._queryParamMap || (this._queryParamMap = ue(this.queryParams)),
                this._queryParamMap
            }
            toString() {
                return `Route(url:'${this.url.map(e => e.toString()).join("/")}', path:'${this.routeConfig ? this.routeConfig.path : ""}')`
            }
        }
        class tt extends qe {
            constructor(e, t) {
                super(t),
                this.url = e,
                nt(this, t)
            }
            toString() {
                return rt(this._root)
            }
        }
        function nt(e, t) {
            t.value._routerState = e,
            t.children.forEach(t => nt(e, t))
        }
        function rt(e) {
            const t = e.children.length > 0 ? ` { ${e.children.map(rt).join(", ")} } ` : "";
            return `${e.value}${t}`
        }
        function st(e) {
            if (e.snapshot) {
                const t = e.snapshot
                  , n = e._futureSnapshot;
                e.snapshot = n,
                ve(t.queryParams, n.queryParams) || e.queryParams.next(n.queryParams),
                t.fragment !== n.fragment && e.fragment.next(n.fragment),
                ve(t.params, n.params) || e.params.next(n.params),
                function(e, t) {
                    if (e.length !== t.length)
                        return !1;
                    for (let n = 0; n < e.length; ++n)
                        if (!ve(e[n], t[n]))
                            return !1;
                    return !0
                }(t.url, n.url) || e.url.next(n.url),
                ve(t.data, n.data) || e.data.next(n.data)
            } else
                e.snapshot = e._futureSnapshot,
                e.data.next(e._futureSnapshot.data)
        }
        function it(e, t) {
            var n, r;
            return ve(e.params, t.params) && Oe(n = e.url, r = t.url) && n.every( (e, t) => ve(e.parameters, r[t].parameters)) && !(!e.parent != !t.parent) && (!e.parent || it(e.parent, t.parent))
        }
        function ot(e) {
            return "object" == typeof e && null != e && !e.outlets && !e.segmentPath
        }
        function at(e, t, n, r, s) {
            let i = {};
            return r && Ee(r, (e, t) => {
                i[t] = Array.isArray(e) ? e.map(e => `${e}`) : `${e}`
            }
            ),
            new Te(n.root === e ? t : function e(t, n, r) {
                const s = {};
                return Ee(t.children, (t, i) => {
                    s[i] = t === n ? r : e(t, n, r)
                }
                ),
                new xe(t.segments,s)
            }(n.root, e, t),i,s)
        }
        class ct {
            constructor(e, t, n) {
                if (this.isAbsolute = e,
                this.numberOfDoubleDots = t,
                this.commands = n,
                e && n.length > 0 && ot(n[0]))
                    throw new Error("Root segment cannot have matrix parameters");
                const r = n.find(e => "object" == typeof e && null != e && e.outlets);
                if (r && r !== we(n))
                    throw new Error("{outlets:{}} has to be the last command")
            }
            toRoot() {
                return this.isAbsolute && 1 === this.commands.length && "/" == this.commands[0]
            }
        }
        class lt {
            constructor(e, t, n) {
                this.segmentGroup = e,
                this.processChildren = t,
                this.index = n
            }
        }
        function ut(e) {
            return "object" == typeof e && null != e && e.outlets ? e.outlets[ce] : `${e}`
        }
        function ht(e, t, n) {
            if (e || (e = new xe([],{})),
            0 === e.segments.length && e.hasChildren())
                return dt(e, t, n);
            const r = function(e, t, n) {
                let r = 0
                  , s = t;
                const i = {
                    match: !1,
                    pathIndex: 0,
                    commandIndex: 0
                };
                for (; s < e.segments.length; ) {
                    if (r >= n.length)
                        return i;
                    const t = e.segments[s]
                      , o = ut(n[r])
                      , a = r < n.length - 1 ? n[r + 1] : null;
                    if (s > 0 && void 0 === o)
                        break;
                    if (o && a && "object" == typeof a && void 0 === a.outlets) {
                        if (!gt(o, a, t))
                            return i;
                        r += 2
                    } else {
                        if (!gt(o, {}, t))
                            return i;
                        r++
                    }
                    s++
                }
                return {
                    match: !0,
                    pathIndex: s,
                    commandIndex: r
                }
            }(e, t, n)
              , s = n.slice(r.commandIndex);
            if (r.match && r.pathIndex < e.segments.length) {
                const t = new xe(e.segments.slice(0, r.pathIndex),{});
                return t.children[ce] = new xe(e.segments.slice(r.pathIndex),e.children),
                dt(t, 0, s)
            }
            return r.match && 0 === s.length ? new xe(e.segments,{}) : r.match && !e.hasChildren() ? ft(e, t, n) : r.match ? dt(e, 0, s) : ft(e, t, n)
        }
        function dt(e, t, n) {
            if (0 === n.length)
                return new xe(e.segments,{});
            {
                const r = function(e) {
                    return "object" != typeof e[0] ? {
                        [ce]: e
                    } : void 0 === e[0].outlets ? {
                        [ce]: e
                    } : e[0].outlets
                }(n)
                  , s = {};
                return Ee(r, (n, r) => {
                    null !== n && (s[r] = ht(e.children[r], t, n))
                }
                ),
                Ee(e.children, (e, t) => {
                    void 0 === r[t] && (s[t] = e)
                }
                ),
                new xe(e.segments,s)
            }
        }
        function ft(e, t, n) {
            const r = e.segments.slice(0, t);
            let s = 0;
            for (; s < n.length; ) {
                if ("object" == typeof n[s] && void 0 !== n[s].outlets) {
                    const e = pt(n[s].outlets);
                    return new xe(r,e)
                }
                if (0 === s && ot(n[0])) {
                    r.push(new ke(e.segments[t].path,n[0])),
                    s++;
                    continue
                }
                const i = ut(n[s])
                  , o = s < n.length - 1 ? n[s + 1] : null;
                i && o && ot(o) ? (r.push(new ke(i,mt(o))),
                s += 2) : (r.push(new ke(i,{})),
                s++)
            }
            return new xe(r,{})
        }
        function pt(e) {
            const t = {};
            return Ee(e, (e, n) => {
                null !== e && (t[n] = ft(new xe([],{}), 0, e))
            }
            ),
            t
        }
        function mt(e) {
            const t = {};
            return Ee(e, (e, n) => t[n] = `${e}`),
            t
        }
        function gt(e, t, n) {
            return e == n.path && ve(t, n.parameters)
        }
        const bt = (e, t, n) => Object(m.a)(r => (new yt(t,r.targetRouterState,r.currentRouterState,n).activate(e),
        r));
        class yt {
            constructor(e, t, n, r) {
                this.routeReuseStrategy = e,
                this.futureState = t,
                this.currState = n,
                this.forwardEvent = r
            }
            activate(e) {
                const t = this.futureState._root
                  , n = this.currState ? this.currState._root : null;
                this.deactivateChildRoutes(t, n, e),
                st(this.futureState.root),
                this.activateChildRoutes(t, n, e)
            }
            deactivateChildRoutes(e, t, n) {
                const r = We(t);
                e.children.forEach(e => {
                    const t = e.value.outlet;
                    this.deactivateRoutes(e, r[t], n),
                    delete r[t]
                }
                ),
                Ee(r, (e, t) => {
                    this.deactivateRouteAndItsChildren(e, n)
                }
                )
            }
            deactivateRoutes(e, t, n) {
                const r = e.value
                  , s = t ? t.value : null;
                if (r === s)
                    if (r.component) {
                        const s = n.getContext(r.outlet);
                        s && this.deactivateChildRoutes(e, t, s.children)
                    } else
                        this.deactivateChildRoutes(e, t, n);
                else
                    s && this.deactivateRouteAndItsChildren(t, n)
            }
            deactivateRouteAndItsChildren(e, t) {
                this.routeReuseStrategy.shouldDetach(e.value.snapshot) ? this.detachAndStoreRouteSubtree(e, t) : this.deactivateRouteAndOutlet(e, t)
            }
            detachAndStoreRouteSubtree(e, t) {
                const n = t.getContext(e.value.outlet);
                if (n && n.outlet) {
                    const t = n.outlet.detach()
                      , r = n.children.onOutletDeactivated();
                    this.routeReuseStrategy.store(e.value.snapshot, {
                        componentRef: t,
                        route: e,
                        contexts: r
                    })
                }
            }
            deactivateRouteAndOutlet(e, t) {
                const n = t.getContext(e.value.outlet);
                if (n) {
                    const r = We(e)
                      , s = e.value.component ? n.children : t;
                    Ee(r, (e, t) => this.deactivateRouteAndItsChildren(e, s)),
                    n.outlet && (n.outlet.deactivate(),
                    n.children.onOutletDeactivated())
                }
            }
            activateChildRoutes(e, t, n) {
                const r = We(t);
                e.children.forEach(e => {
                    this.activateRoutes(e, r[e.value.outlet], n),
                    this.forwardEvent(new ie(e.value.snapshot))
                }
                ),
                e.children.length && this.forwardEvent(new re(e.value.snapshot))
            }
            activateRoutes(e, t, n) {
                const r = e.value
                  , s = t ? t.value : null;
                if (st(r),
                r === s)
                    if (r.component) {
                        const s = n.getOrCreateContext(r.outlet);
                        this.activateChildRoutes(e, t, s.children)
                    } else
                        this.activateChildRoutes(e, t, n);
                else if (r.component) {
                    const t = n.getOrCreateContext(r.outlet);
                    if (this.routeReuseStrategy.shouldAttach(r.snapshot)) {
                        const e = this.routeReuseStrategy.retrieve(r.snapshot);
                        this.routeReuseStrategy.store(r.snapshot, null),
                        t.children.onOutletReAttached(e.contexts),
                        t.attachRef = e.componentRef,
                        t.route = e.route.value,
                        t.outlet && t.outlet.attach(e.componentRef, e.route.value),
                        vt(e.route)
                    } else {
                        const n = function(e) {
                            for (let t = r.snapshot.parent; t; t = t.parent) {
                                const e = t.routeConfig;
                                if (e && e._loadedConfig)
                                    return e._loadedConfig;
                                if (e && e.component)
                                    return null
                            }
                            return null
                        }()
                          , s = n ? n.module.componentFactoryResolver : null;
                        t.attachRef = null,
                        t.route = r,
                        t.resolver = s,
                        t.outlet && t.outlet.activateWith(r, s),
                        this.activateChildRoutes(e, null, t.children)
                    }
                } else
                    this.activateChildRoutes(e, null, n)
            }
        }
        function vt(e) {
            st(e.value),
            e.children.forEach(vt)
        }
        function _t(e) {
            return "function" == typeof e
        }
        function wt(e) {
            return e instanceof Te
        }
        class Et {
            constructor(e) {
                this.segmentGroup = e || null
            }
        }
        class St {
            constructor(e) {
                this.urlTree = e
            }
        }
        function Ct(e) {
            return new c.a(t => t.error(new Et(e)))
        }
        function Tt(e) {
            return new c.a(t => t.error(new St(e)))
        }
        function xt(e) {
            return new c.a(t => t.error(new Error(`Only absolute redirects can have named outlets. redirectTo: '${e}'`)))
        }
        class kt {
            constructor(e, t, n, r, i) {
                this.configLoader = t,
                this.urlSerializer = n,
                this.urlTree = r,
                this.config = i,
                this.allowRedirects = !0,
                this.ngModule = e.get(s.w)
            }
            apply() {
                return this.expandSegmentGroup(this.ngModule, this.config, this.urlTree.root, ce).pipe(Object(m.a)(e => this.createUrlTree(e, this.urlTree.queryParams, this.urlTree.fragment))).pipe(Object(A.a)(e => {
                    if (e instanceof St)
                        return this.allowRedirects = !1,
                        this.match(e.urlTree);
                    if (e instanceof Et)
                        throw this.noMatchError(e);
                    throw e
                }
                ))
            }
            match(e) {
                return this.expandSegmentGroup(this.ngModule, this.config, e.root, ce).pipe(Object(m.a)(t => this.createUrlTree(t, e.queryParams, e.fragment))).pipe(Object(A.a)(e => {
                    if (e instanceof Et)
                        throw this.noMatchError(e);
                    throw e
                }
                ))
            }
            noMatchError(e) {
                return new Error(`Cannot match any routes. URL Segment: '${e.segmentGroup}'`)
            }
            createUrlTree(e, t, n) {
                const r = e.segments.length > 0 ? new xe([],{
                    [ce]: e
                }) : e;
                return new Te(r,t,n)
            }
            expandSegmentGroup(e, t, n, r) {
                return 0 === n.segments.length && n.hasChildren() ? this.expandChildren(e, t, n).pipe(Object(m.a)(e => new xe([],e))) : this.expandSegment(e, n, t, n.segments, r, !0)
            }
            expandChildren(e, t, n) {
                return function(e, t) {
                    if (0 === Object.keys(e).length)
                        return Object(i.a)({});
                    const n = []
                      , r = []
                      , s = {};
                    return Ee(e, (e, i) => {
                        const o = t(i, e).pipe(Object(m.a)(e => s[i] = e));
                        i === ce ? n.push(o) : r.push(o)
                    }
                    ),
                    i.a.apply(null, n.concat(r)).pipe(Object(g.a)(), I(), Object(m.a)( () => s))
                }(n.children, (n, r) => this.expandSegmentGroup(e, t, r, n))
            }
            expandSegment(e, t, n, r, s, o) {
                return Object(i.a)(...n).pipe(Object(m.a)(a => this.expandSegmentAgainstRoute(e, t, n, a, r, s, o).pipe(Object(A.a)(e => {
                    if (e instanceof Et)
                        return Object(i.a)(null);
                    throw e
                }
                ))), Object(g.a)(), R(e => !!e), Object(A.a)( (e, n) => {
                    if (e instanceof u || "EmptyError" === e.name) {
                        if (this.noLeftoversInUrl(t, r, s))
                            return Object(i.a)(new xe([],{}));
                        throw new Et(t)
                    }
                    throw e
                }
                ))
            }
            noLeftoversInUrl(e, t, n) {
                return 0 === t.length && !e.children[n]
            }
            expandSegmentAgainstRoute(e, t, n, r, s, i, o) {
                return Dt(r) !== i ? Ct(t) : void 0 === r.redirectTo ? this.matchSegmentAgainstRoute(e, t, r, s) : o && this.allowRedirects ? this.expandSegmentAgainstRouteUsingRedirect(e, t, n, r, s, i) : Ct(t)
            }
            expandSegmentAgainstRouteUsingRedirect(e, t, n, r, s, i) {
                return "**" === r.path ? this.expandWildCardWithParamsAgainstRouteUsingRedirect(e, n, r, i) : this.expandRegularSegmentAgainstRouteUsingRedirect(e, t, n, r, s, i)
            }
            expandWildCardWithParamsAgainstRouteUsingRedirect(e, t, n, r) {
                const s = this.applyRedirectCommands([], n.redirectTo, {});
                return n.redirectTo.startsWith("/") ? Tt(s) : this.lineralizeSegments(n, s).pipe(Object(j.a)(n => {
                    const s = new xe(n,{});
                    return this.expandSegment(e, s, t, n, r, !1)
                }
                ))
            }
            expandRegularSegmentAgainstRouteUsingRedirect(e, t, n, r, s, i) {
                const {matched: o, consumedSegments: a, lastChild: c, positionalParamSegments: l} = Ot(t, r, s);
                if (!o)
                    return Ct(t);
                const u = this.applyRedirectCommands(a, r.redirectTo, l);
                return r.redirectTo.startsWith("/") ? Tt(u) : this.lineralizeSegments(r, u).pipe(Object(j.a)(r => this.expandSegment(e, t, n, r.concat(s.slice(c)), i, !1)))
            }
            matchSegmentAgainstRoute(e, t, n, r) {
                if ("**" === n.path)
                    return n.loadChildren ? this.configLoader.load(e.injector, n).pipe(Object(m.a)(e => (n._loadedConfig = e,
                    new xe(r,{})))) : Object(i.a)(new xe(r,{}));
                const {matched: s, consumedSegments: o, lastChild: a} = Ot(t, n, r);
                if (!s)
                    return Ct(t);
                const c = r.slice(a);
                return this.getChildConfig(e, n, r).pipe(Object(j.a)(e => {
                    const n = e.module
                      , r = e.routes
                      , {segmentGroup: s, slicedSegments: a} = function(e, t, n, r) {
                        return n.length > 0 && function(e, t, n) {
                            return r.some(n => At(e, t, n) && Dt(n) !== ce)
                        }(e, n) ? {
                            segmentGroup: It(new xe(t,function(e, t) {
                                const n = {};
                                n[ce] = t;
                                for (const r of e)
                                    "" === r.path && Dt(r) !== ce && (n[Dt(r)] = new xe([],{}));
                                return n
                            }(r, new xe(n,e.children)))),
                            slicedSegments: []
                        } : 0 === n.length && function(e, t, n) {
                            return r.some(n => At(e, t, n))
                        }(e, n) ? {
                            segmentGroup: It(new xe(e.segments,function(e, t, n, r) {
                                const s = {};
                                for (const i of n)
                                    At(e, t, i) && !r[Dt(i)] && (s[Dt(i)] = new xe([],{}));
                                return Object.assign({}, r, s)
                            }(e, n, r, e.children))),
                            slicedSegments: n
                        } : {
                            segmentGroup: e,
                            slicedSegments: n
                        }
                    }(t, o, c, r);
                    return 0 === a.length && s.hasChildren() ? this.expandChildren(n, r, s).pipe(Object(m.a)(e => new xe(o,e))) : 0 === r.length && 0 === a.length ? Object(i.a)(new xe(o,{})) : this.expandSegment(n, s, r, a, ce, !0).pipe(Object(m.a)(e => new xe(o.concat(e.segments),e.children)))
                }
                ))
            }
            getChildConfig(e, t, n) {
                return t.children ? Object(i.a)(new pe(t.children,e)) : t.loadChildren ? void 0 !== t._loadedConfig ? Object(i.a)(t._loadedConfig) : function(e, t, n) {
                    const r = t.canLoad;
                    return r && 0 !== r.length ? Object(o.a)(r).pipe(Object(m.a)(r => {
                        const s = e.get(r);
                        let i;
                        if (function(e) {
                            return e && _t(e.canLoad)
                        }(s))
                            i = s.canLoad(t, n);
                        else {
                            if (!_t(s))
                                throw new Error("Invalid CanLoad guard");
                            i = s(t, n)
                        }
                        return Se(i)
                    }
                    )).pipe(Object(g.a)(), (s = e => !0 === e,
                    e => e.lift(new N(s,void 0,e)))) : Object(i.a)(!0);
                    var s
                }(e.injector, t, n).pipe(Object(j.a)(n => n ? this.configLoader.load(e.injector, t).pipe(Object(m.a)(e => (t._loadedConfig = e,
                e))) : function(e) {
                    return new c.a(t => t.error(de(`Cannot load children because the guard of the route "path: '${e.path}'" returned false`)))
                }(t))) : Object(i.a)(new pe([],e))
            }
            lineralizeSegments(e, t) {
                let n = []
                  , r = t.root;
                for (; ; ) {
                    if (n = n.concat(r.segments),
                    0 === r.numberOfChildren)
                        return Object(i.a)(n);
                    if (r.numberOfChildren > 1 || !r.children[ce])
                        return xt(e.redirectTo);
                    r = r.children[ce]
                }
            }
            applyRedirectCommands(e, t, n) {
                return this.applyRedirectCreatreUrlTree(t, this.urlSerializer.parse(t), e, n)
            }
            applyRedirectCreatreUrlTree(e, t, n, r) {
                const s = this.createSegmentGroup(e, t.root, n, r);
                return new Te(s,this.createQueryParams(t.queryParams, this.urlTree.queryParams),t.fragment)
            }
            createQueryParams(e, t) {
                const n = {};
                return Ee(e, (e, r) => {
                    if ("string" == typeof e && e.startsWith(":")) {
                        const s = e.substring(1);
                        n[r] = t[s]
                    } else
                        n[r] = e
                }
                ),
                n
            }
            createSegmentGroup(e, t, n, r) {
                const s = this.createSegments(e, t.segments, n, r);
                let i = {};
                return Ee(t.children, (t, s) => {
                    i[s] = this.createSegmentGroup(e, t, n, r)
                }
                ),
                new xe(s,i)
            }
            createSegments(e, t, n, r) {
                return t.map(t => t.path.startsWith(":") ? this.findPosParam(e, t, r) : this.findOrReturn(t, n))
            }
            findPosParam(e, t, n) {
                const r = n[t.path.substring(1)];
                if (!r)
                    throw new Error(`Cannot redirect to '${e}'. Cannot find '${t.path}'.`);
                return r
            }
            findOrReturn(e, t) {
                let n = 0;
                for (const r of t) {
                    if (r.path === e.path)
                        return t.splice(n),
                        r;
                    n++
                }
                return e
            }
        }
        function Ot(e, t, n) {
            if ("" === t.path)
                return "full" === t.pathMatch && (e.hasChildren() || n.length > 0) ? {
                    matched: !1,
                    consumedSegments: [],
                    lastChild: 0,
                    positionalParamSegments: {}
                } : {
                    matched: !0,
                    consumedSegments: [],
                    lastChild: 0,
                    positionalParamSegments: {}
                };
            const r = (t.matcher || fe)(n, e, t);
            return r ? {
                matched: !0,
                consumedSegments: r.consumed,
                lastChild: r.consumed.length,
                positionalParamSegments: r.posParams
            } : {
                matched: !1,
                consumedSegments: [],
                lastChild: 0,
                positionalParamSegments: {}
            }
        }
        function It(e) {
            if (1 === e.numberOfChildren && e.children[ce]) {
                const t = e.children[ce];
                return new xe(e.segments.concat(t.segments),t.children)
            }
            return e
        }
        function At(e, t, n) {
            return (!(e.hasChildren() || t.length > 0) || "full" !== n.pathMatch) && "" === n.path && void 0 !== n.redirectTo
        }
        function Dt(e) {
            return e.outlet || ce
        }
        class Rt {
            constructor(e) {
                this.path = e,
                this.route = this.path[this.path.length - 1]
            }
        }
        class jt {
            constructor(e, t) {
                this.component = e,
                this.route = t
            }
        }
        function Nt(e, t, n) {
            const r = e._root;
            return function e(t, n, r, s, i={
                canDeactivateChecks: [],
                canActivateChecks: []
            }) {
                const o = We(n);
                return t.children.forEach(t => {
                    !function(t, n, r, s, i={
                        canDeactivateChecks: [],
                        canActivateChecks: []
                    }) {
                        const o = t.value
                          , a = n ? n.value : null
                          , c = r ? r.getContext(t.value.outlet) : null;
                        if (a && o.routeConfig === a.routeConfig) {
                            const l = function(e, t, n) {
                                if ("function" == typeof n)
                                    return n(e, t);
                                switch (n) {
                                case "pathParamsChange":
                                    return !Oe(e.url, t.url);
                                case "pathParamsOrQueryParamsChange":
                                    return !Oe(e.url, t.url) || !ve(e.queryParams, t.queryParams);
                                case "always":
                                    return !0;
                                case "paramsOrQueryParamsChange":
                                    return !it(e, t) || !ve(e.queryParams, t.queryParams);
                                case "paramsChange":
                                default:
                                    return !it(e, t)
                                }
                            }(a, o, o.routeConfig.runGuardsAndResolvers);
                            l ? i.canActivateChecks.push(new Rt(s)) : (o.data = a.data,
                            o._resolvedData = a._resolvedData),
                            e(t, n, o.component ? c ? c.children : null : r, s, i),
                            l && i.canDeactivateChecks.push(new jt(c && c.outlet && c.outlet.component || null,a))
                        } else
                            a && Mt(n, c, i),
                            i.canActivateChecks.push(new Rt(s)),
                            e(t, null, o.component ? c ? c.children : null : r, s, i)
                    }(t, o[t.value.outlet], r, s.concat([t.value]), i),
                    delete o[t.value.outlet]
                }
                ),
                Ee(o, (e, t) => Mt(e, r.getContext(t), i)),
                i
            }(r, t ? t._root : null, n, [r.value])
        }
        function Pt(e, t, n) {
            const r = function(e) {
                if (!e)
                    return null;
                for (let t = e.parent; t; t = t.parent) {
                    const e = t.routeConfig;
                    if (e && e._loadedConfig)
                        return e._loadedConfig
                }
                return null
            }(t);
            return (r ? r.module.injector : n).get(e)
        }
        function Mt(e, t, n) {
            const r = We(e)
              , s = e.value;
            Ee(r, (e, r) => {
                Mt(e, s.component ? t ? t.children.getContext(r) : null : t, n)
            }
            ),
            n.canDeactivateChecks.push(new jt(s.component && t && t.outlet && t.outlet.isActivated ? t.outlet.component : null,s))
        }
        const Lt = Symbol("INITIAL_VALUE");
        function Ft() {
            return Object(M.a)(e => Object(h.a)(...e.map(e => e.pipe(Object(D.a)(1), Object(L.a)(Lt)))).pipe(Object(F.a)( (e, t) => {
                let n = !1;
                return t.reduce( (e, r, s) => {
                    if (e !== Lt)
                        return e;
                    if (r === Lt && (n = !0),
                    !n) {
                        if (!1 === r)
                            return r;
                        if (s === t.length - 1 || wt(r))
                            return r
                    }
                    return e
                }
                , e)
            }
            , Lt), Object(b.a)(e => e !== Lt), Object(m.a)(e => wt(e) ? e : !0 === e), Object(D.a)(1)))
        }
        function Ut(e, t) {
            return null !== e && t && t(new se(e)),
            Object(i.a)(!0)
        }
        function zt(e, t) {
            return null !== e && t && t(new ne(e)),
            Object(i.a)(!0)
        }
        function Ht(e, t, n) {
            const r = t.routeConfig ? t.routeConfig.canActivate : null;
            if (!r || 0 === r.length)
                return Object(i.a)(!0);
            const s = r.map(r => Object(d.a)( () => {
                const s = Pt(r, t, n);
                let i;
                if (function(e) {
                    return e && _t(e.canActivate)
                }(s))
                    i = Se(s.canActivate(t, e));
                else {
                    if (!_t(s))
                        throw new Error("Invalid CanActivate guard");
                    i = Se(s(t, e))
                }
                return i.pipe(R())
            }
            ));
            return Object(i.a)(s).pipe(Ft())
        }
        function Bt(e, t, n) {
            const r = t[t.length - 1]
              , s = t.slice(0, t.length - 1).reverse().map(e => (function(e) {
                const t = e.routeConfig ? e.routeConfig.canActivateChild : null;
                return t && 0 !== t.length ? {
                    node: e,
                    guards: t
                } : null
            }
            )(e)).filter(e => null !== e).map(t => Object(d.a)( () => {
                const s = t.guards.map(s => {
                    const i = Pt(s, t.node, n);
                    let o;
                    if (function(e) {
                        return e && _t(e.canActivateChild)
                    }(i))
                        o = Se(i.canActivateChild(r, e));
                    else {
                        if (!_t(i))
                            throw new Error("Invalid CanActivateChild guard");
                        o = Se(i(r, e))
                    }
                    return o.pipe(R())
                }
                );
                return Object(i.a)(s).pipe(Ft())
            }
            ));
            return Object(i.a)(s).pipe(Ft())
        }
        class Vt {
        }
        class $t {
            constructor(e, t, n, r, s, i) {
                this.rootComponentType = e,
                this.config = t,
                this.urlTree = n,
                this.url = r,
                this.paramsInheritanceStrategy = s,
                this.relativeLinkResolution = i
            }
            recognize() {
                try {
                    const t = Gt(this.urlTree.root, [], [], this.config, this.relativeLinkResolution).segmentGroup
                      , n = this.processSegmentGroup(this.config, t, ce)
                      , r = new et([],Object.freeze({}),Object.freeze(Object.assign({}, this.urlTree.queryParams)),this.urlTree.fragment,{},ce,this.rootComponentType,null,this.urlTree.root,-1,{})
                      , s = new Ke(r,n)
                      , o = new tt(this.url,s);
                    return this.inheritParamsAndData(o._root),
                    Object(i.a)(o)
                } catch (e) {
                    return new c.a(t => t.error(e))
                }
            }
            inheritParamsAndData(e) {
                const t = e.value
                  , n = Xe(t, this.paramsInheritanceStrategy);
                t.params = Object.freeze(n.params),
                t.data = Object.freeze(n.data),
                e.children.forEach(e => this.inheritParamsAndData(e))
            }
            processSegmentGroup(e, t, n) {
                return 0 === t.segments.length && t.hasChildren() ? this.processChildren(e, t) : this.processSegment(e, t, t.segments, n)
            }
            processChildren(e, t) {
                const n = Ie(t, (t, n) => this.processSegmentGroup(e, t, n));
                return function(e) {
                    const t = {};
                    n.forEach(e => {
                        const n = t[e.value.outlet];
                        if (n) {
                            const t = n.url.map(e => e.toString()).join("/")
                              , r = e.value.url.map(e => e.toString()).join("/");
                            throw new Error(`Two segments cannot have the same outlet name: '${t}' and '${r}'.`)
                        }
                        t[e.value.outlet] = e.value
                    }
                    )
                }(),
                n.sort( (e, t) => e.value.outlet === ce ? -1 : t.value.outlet === ce ? 1 : e.value.outlet.localeCompare(t.value.outlet)),
                n
            }
            processSegment(e, t, n, r) {
                for (const i of e)
                    try {
                        return this.processSegmentAgainstRoute(i, t, n, r)
                    } catch (s) {
                        if (!(s instanceof Vt))
                            throw s
                    }
                if (this.noLeftoversInUrl(t, n, r))
                    return [];
                throw new Vt
            }
            noLeftoversInUrl(e, t, n) {
                return 0 === t.length && !e.children[n]
            }
            processSegmentAgainstRoute(e, t, n, r) {
                if (e.redirectTo)
                    throw new Vt;
                if ((e.outlet || ce) !== r)
                    throw new Vt;
                let s, i = [], o = [];
                if ("**" === e.path) {
                    const i = n.length > 0 ? we(n).parameters : {};
                    s = new et(n,i,Object.freeze(Object.assign({}, this.urlTree.queryParams)),this.urlTree.fragment,Zt(e),r,e.component,e,qt(t),Qt(t) + n.length,Yt(e))
                } else {
                    const a = function(e, t, n) {
                        if ("" === t.path) {
                            if ("full" === t.pathMatch && (e.hasChildren() || n.length > 0))
                                throw new Vt;
                            return {
                                consumedSegments: [],
                                lastChild: 0,
                                parameters: {}
                            }
                        }
                        const r = (t.matcher || fe)(n, e, t);
                        if (!r)
                            throw new Vt;
                        const s = {};
                        Ee(r.posParams, (e, t) => {
                            s[t] = e.path
                        }
                        );
                        const i = r.consumed.length > 0 ? Object.assign({}, s, r.consumed[r.consumed.length - 1].parameters) : s;
                        return {
                            consumedSegments: r.consumed,
                            lastChild: r.consumed.length,
                            parameters: i
                        }
                    }(t, e, n);
                    i = a.consumedSegments,
                    o = n.slice(a.lastChild),
                    s = new et(i,a.parameters,Object.freeze(Object.assign({}, this.urlTree.queryParams)),this.urlTree.fragment,Zt(e),r,e.component,e,qt(t),Qt(t) + i.length,Yt(e))
                }
                const a = function(e) {
                    return e.children ? e.children : e.loadChildren ? e._loadedConfig.routes : []
                }(e)
                  , {segmentGroup: c, slicedSegments: l} = Gt(t, i, o, a, this.relativeLinkResolution);
                if (0 === l.length && c.hasChildren()) {
                    const e = this.processChildren(a, c);
                    return [new Ke(s,e)]
                }
                if (0 === a.length && 0 === l.length)
                    return [new Ke(s,[])];
                const u = this.processSegment(a, c, l, ce);
                return [new Ke(s,u)]
            }
        }
        function qt(e) {
            let t = e;
            for (; t._sourceSegment; )
                t = t._sourceSegment;
            return t
        }
        function Qt(e) {
            let t = e
              , n = t._segmentIndexShift ? t._segmentIndexShift : 0;
            for (; t._sourceSegment; )
                n += (t = t._sourceSegment)._segmentIndexShift ? t._segmentIndexShift : 0;
            return n - 1
        }
        function Gt(e, t, n, r, s) {
            if (n.length > 0 && function(e, t, n) {
                return r.some(n => Kt(e, t, n) && Wt(n) !== ce)
            }(e, n)) {
                const s = new xe(t,function(e, t, n, r) {
                    const s = {};
                    s[ce] = r,
                    r._sourceSegment = e,
                    r._segmentIndexShift = t.length;
                    for (const i of n)
                        if ("" === i.path && Wt(i) !== ce) {
                            const n = new xe([],{});
                            n._sourceSegment = e,
                            n._segmentIndexShift = t.length,
                            s[Wt(i)] = n
                        }
                    return s
                }(e, t, r, new xe(n,e.children)));
                return s._sourceSegment = e,
                s._segmentIndexShift = t.length,
                {
                    segmentGroup: s,
                    slicedSegments: []
                }
            }
            if (0 === n.length && function(e, t, n) {
                return r.some(n => Kt(e, t, n))
            }(e, n)) {
                const i = new xe(e.segments,function(e, t, n, r, s, i) {
                    const o = {};
                    for (const a of r)
                        if (Kt(e, n, a) && !s[Wt(a)]) {
                            const n = new xe([],{});
                            n._sourceSegment = e,
                            n._segmentIndexShift = "legacy" === i ? e.segments.length : t.length,
                            o[Wt(a)] = n
                        }
                    return Object.assign({}, s, o)
                }(e, t, n, r, e.children, s));
                return i._sourceSegment = e,
                i._segmentIndexShift = t.length,
                {
                    segmentGroup: i,
                    slicedSegments: n
                }
            }
            const i = new xe(e.segments,e.children);
            return i._sourceSegment = e,
            i._segmentIndexShift = t.length,
            {
                segmentGroup: i,
                slicedSegments: n
            }
        }
        function Kt(e, t, n) {
            return (!(e.hasChildren() || t.length > 0) || "full" !== n.pathMatch) && "" === n.path && void 0 === n.redirectTo
        }
        function Wt(e) {
            return e.outlet || ce
        }
        function Zt(e) {
            return e.data || {}
        }
        function Yt(e) {
            return e.resolve || {}
        }
        function Jt(e, t, n, r) {
            const s = Pt(e, t, r);
            return Se(s.resolve ? s.resolve(t, n) : s(t, n))
        }
        function Xt(e) {
            return function(t) {
                return t.pipe(Object(M.a)(t => {
                    const n = e(t);
                    return n ? Object(o.a)(n).pipe(Object(m.a)( () => t)) : Object(o.a)([t])
                }
                ))
            }
        }
        class en {
        }
        class tn {
            shouldDetach(e) {
                return !1
            }
            store(e, t) {}
            shouldAttach(e) {
                return !1
            }
            retrieve(e) {
                return null
            }
            shouldReuseRoute(e, t) {
                return e.routeConfig === t.routeConfig
            }
        }
        const nn = new s.p("ROUTES");
        class rn {
            constructor(e, t, n, r) {
                this.loader = e,
                this.compiler = t,
                this.onLoadStartListener = n,
                this.onLoadEndListener = r
            }
            load(e, t) {
                return this.onLoadStartListener && this.onLoadStartListener(t),
                this.loadModuleFactory(t.loadChildren).pipe(Object(m.a)(n => {
                    this.onLoadEndListener && this.onLoadEndListener(t);
                    const r = n.create(e);
                    return new pe(_e(r.injector.get(nn)).map(ye),r)
                }
                ))
            }
            loadModuleFactory(e) {
                return "string" == typeof e ? Object(o.a)(this.loader.load(e)) : Se(e()).pipe(Object(j.a)(e => e instanceof s.u ? Object(i.a)(e) : Object(o.a)(this.compiler.compileModuleAsync(e))))
            }
        }
        class sn {
        }
        class on {
            shouldProcessUrl(e) {
                return !0
            }
            extract(e) {
                return e
            }
            merge(e, t) {
                return e
            }
        }
        function an(e) {
            throw e
        }
        function cn(e, t, n) {
            return t.parse("/")
        }
        function ln(e, t) {
            return Object(i.a)(null)
        }
        class un {
            constructor(e, t, n, r, i, o, c, l) {
                this.rootComponentType = e,
                this.urlSerializer = t,
                this.rootContexts = n,
                this.location = r,
                this.config = l,
                this.lastSuccessfulNavigation = null,
                this.currentNavigation = null,
                this.navigationId = 0,
                this.isNgZoneEnabled = !1,
                this.events = new f.a,
                this.errorHandler = an,
                this.malformedUriErrorHandler = cn,
                this.navigated = !1,
                this.lastSuccessfulId = -1,
                this.hooks = {
                    beforePreactivation: ln,
                    afterPreactivation: ln
                },
                this.urlHandlingStrategy = new on,
                this.routeReuseStrategy = new tn,
                this.onSameUrlNavigation = "ignore",
                this.paramsInheritanceStrategy = "emptyOnly",
                this.urlUpdateStrategy = "deferred",
                this.relativeLinkResolution = "legacy",
                this.ngModule = i.get(s.w),
                this.console = i.get(s.bb);
                const u = i.get(s.y);
                this.isNgZoneEnabled = u instanceof s.y,
                this.resetConfig(l),
                this.currentUrlTree = new Te(new xe([],{}),{},null),
                this.rawUrlTree = this.currentUrlTree,
                this.browserUrlTree = this.currentUrlTree,
                this.configLoader = new rn(o,c,e => this.triggerEvent(new ee(e)),e => this.triggerEvent(new te(e))),
                this.routerState = Ye(this.currentUrlTree, this.rootComponentType),
                this.transitions = new a.a({
                    id: 0,
                    currentUrlTree: this.currentUrlTree,
                    currentRawUrl: this.currentUrlTree,
                    extractedUrl: this.urlHandlingStrategy.extract(this.currentUrlTree),
                    urlAfterRedirects: this.urlHandlingStrategy.extract(this.currentUrlTree),
                    rawUrl: this.currentUrlTree,
                    extras: {},
                    resolve: null,
                    reject: null,
                    promise: Promise.resolve(!0),
                    source: "imperative",
                    restoredState: null,
                    currentSnapshot: this.routerState.snapshot,
                    targetSnapshot: null,
                    currentRouterState: this.routerState,
                    targetRouterState: null,
                    guards: {
                        canActivateChecks: [],
                        canDeactivateChecks: []
                    },
                    guardsResult: null
                }),
                this.navigations = this.setupNavigations(this.transitions),
                this.processNavigations()
            }
            setupNavigations(e) {
                const t = this.events;
                return e.pipe(Object(b.a)(e => 0 !== e.id), Object(m.a)(e => Object.assign({}, e, {
                    extractedUrl: this.urlHandlingStrategy.extract(e.rawUrl)
                })), Object(M.a)(e => {
                    let n = !1
                      , r = !1;
                    return Object(i.a)(e).pipe(Object(S.a)(e => {
                        this.currentNavigation = {
                            id: e.id,
                            initialUrl: e.currentRawUrl,
                            extractedUrl: e.extractedUrl,
                            trigger: e.source,
                            extras: e.extras,
                            previousNavigation: this.lastSuccessfulNavigation ? Object.assign({}, this.lastSuccessfulNavigation, {
                                previousNavigation: null
                            }) : null
                        }
                    }
                    ), Object(M.a)(e => {
                        const n = !this.navigated || e.extractedUrl.toString() !== this.browserUrlTree.toString();
                        if (("reload" === this.onSameUrlNavigation || n) && this.urlHandlingStrategy.shouldProcessUrl(e.rawUrl))
                            return Object(i.a)(e).pipe(Object(M.a)(e => {
                                const n = this.transitions.getValue();
                                return t.next(new q(e.id,this.serializeUrl(e.extractedUrl),e.source,e.restoredState)),
                                n !== this.transitions.getValue() ? p.a : [e]
                            }
                            ), Object(M.a)(e => Promise.resolve(e)), function(e, t, n, r) {
                                return function(s) {
                                    return s.pipe(Object(M.a)(s => (function(e, t, n, r, i) {
                                        return new kt(e,t,n,s.extractedUrl,i).apply()
                                    }
                                    )(e, t, n, 0, r).pipe(Object(m.a)(e => Object.assign({}, s, {
                                        urlAfterRedirects: e
                                    })))))
                                }
                            }(this.ngModule.injector, this.configLoader, this.urlSerializer, this.config), Object(S.a)(e => {
                                this.currentNavigation = Object.assign({}, this.currentNavigation, {
                                    finalUrl: e.urlAfterRedirects
                                })
                            }
                            ), function(e, t, n, r, s) {
                                return function(i) {
                                    return i.pipe(Object(j.a)(i => (function(e, t, n, r, s="emptyOnly", i="legacy") {
                                        return new $t(e,t,n,r,s,i).recognize()
                                    }
                                    )(e, t, i.urlAfterRedirects, n(i.urlAfterRedirects), r, s).pipe(Object(m.a)(e => Object.assign({}, i, {
                                        targetSnapshot: e
                                    })))))
                                }
                            }(this.rootComponentType, this.config, e => this.serializeUrl(e), this.paramsInheritanceStrategy, this.relativeLinkResolution), Object(S.a)(e => {
                                "eager" === this.urlUpdateStrategy && (e.extras.skipLocationChange || this.setBrowserUrl(e.urlAfterRedirects, !!e.extras.replaceUrl, e.id, e.extras.state),
                                this.browserUrlTree = e.urlAfterRedirects)
                            }
                            ), Object(S.a)(e => {
                                const n = new W(e.id,this.serializeUrl(e.extractedUrl),this.serializeUrl(e.urlAfterRedirects),e.targetSnapshot);
                                t.next(n)
                            }
                            ));
                        if (n && this.rawUrlTree && this.urlHandlingStrategy.shouldProcessUrl(this.rawUrlTree)) {
                            const {id: n, extractedUrl: r, source: s, restoredState: o, extras: a} = e
                              , c = new q(n,this.serializeUrl(r),s,o);
                            t.next(c);
                            const l = Ye(r, this.rootComponentType).snapshot;
                            return Object(i.a)(Object.assign({}, e, {
                                targetSnapshot: l,
                                urlAfterRedirects: r,
                                extras: Object.assign({}, a, {
                                    skipLocationChange: !1,
                                    replaceUrl: !1
                                })
                            }))
                        }
                        return this.rawUrlTree = e.rawUrl,
                        this.browserUrlTree = e.urlAfterRedirects,
                        e.resolve(null),
                        p.a
                    }
                    ), Xt(e => {
                        const {targetSnapshot: t, id: n, extractedUrl: r, rawUrl: s, extras: {skipLocationChange: i, replaceUrl: o}} = e;
                        return this.hooks.beforePreactivation(t, {
                            navigationId: n,
                            appliedUrlTree: r,
                            rawUrlTree: s,
                            skipLocationChange: !!i,
                            replaceUrl: !!o
                        })
                    }
                    ), Object(S.a)(e => {
                        const t = new Z(e.id,this.serializeUrl(e.extractedUrl),this.serializeUrl(e.urlAfterRedirects),e.targetSnapshot);
                        this.triggerEvent(t)
                    }
                    ), Object(m.a)(e => Object.assign({}, e, {
                        guards: Nt(e.targetSnapshot, e.currentSnapshot, this.rootContexts)
                    })), function(e, t) {
                        return function(n) {
                            return n.pipe(Object(j.a)(n => {
                                const {targetSnapshot: r, currentSnapshot: s, guards: {canActivateChecks: a, canDeactivateChecks: c}} = n;
                                return 0 === c.length && 0 === a.length ? Object(i.a)(Object.assign({}, n, {
                                    guardsResult: !0
                                })) : function(e, t, n, r) {
                                    return Object(o.a)(e).pipe(Object(j.a)(e => (function(e, t, n, r, s) {
                                        const o = t && t.routeConfig ? t.routeConfig.canDeactivate : null;
                                        if (!o || 0 === o.length)
                                            return Object(i.a)(!0);
                                        const a = o.map(i => {
                                            const o = Pt(i, t, s);
                                            let a;
                                            if (function(e) {
                                                return e && _t(e.canDeactivate)
                                            }(o))
                                                a = Se(o.canDeactivate(e, t, n, r));
                                            else {
                                                if (!_t(o))
                                                    throw new Error("Invalid CanDeactivate guard");
                                                a = Se(o(e, t, n, r))
                                            }
                                            return a.pipe(R())
                                        }
                                        );
                                        return Object(i.a)(a).pipe(Ft())
                                    }
                                    )(e.component, e.route, n, t, r)), R(e => !0 !== e, !0))
                                }(c, r, s, e).pipe(Object(j.a)(n => n && function(e) {
                                    return "boolean" == typeof n
                                }() ? function(e, t, n, r) {
                                    return Object(o.a)(t).pipe(Object(U.a)(t => Object(o.a)([zt(t.route.parent, r), Ut(t.route, r), Bt(e, t.path, n), Ht(e, t.route, n)]).pipe(Object(g.a)(), R(e => !0 !== e, !0))), R(e => !0 !== e, !0))
                                }(r, a, e, t) : Object(i.a)(n)), Object(m.a)(e => Object.assign({}, n, {
                                    guardsResult: e
                                })))
                            }
                            ))
                        }
                    }(this.ngModule.injector, e => this.triggerEvent(e)), Object(S.a)(e => {
                        if (wt(e.guardsResult)) {
                            const t = de(`Redirecting to "${this.serializeUrl(e.guardsResult)}"`);
                            throw t.url = e.guardsResult,
                            t
                        }
                    }
                    ), Object(S.a)(e => {
                        const t = new Y(e.id,this.serializeUrl(e.extractedUrl),this.serializeUrl(e.urlAfterRedirects),e.targetSnapshot,!!e.guardsResult);
                        this.triggerEvent(t)
                    }
                    ), Object(b.a)(e => {
                        if (!e.guardsResult) {
                            this.resetUrlToCurrentUrlTree();
                            const n = new G(e.id,this.serializeUrl(e.extractedUrl),"");
                            return t.next(n),
                            e.resolve(!1),
                            !1
                        }
                        return !0
                    }
                    ), Xt(e => {
                        if (e.guards.canActivateChecks.length)
                            return Object(i.a)(e).pipe(Object(S.a)(e => {
                                const t = new J(e.id,this.serializeUrl(e.extractedUrl),this.serializeUrl(e.urlAfterRedirects),e.targetSnapshot);
                                this.triggerEvent(t)
                            }
                            ), function(e, t) {
                                return function(n) {
                                    return n.pipe(Object(j.a)(n => {
                                        const {targetSnapshot: r, guards: {canActivateChecks: s}} = n;
                                        return s.length ? Object(o.a)(s).pipe(Object(U.a)(n => (function(e, t, n, s) {
                                            return function(e, t, n, r) {
                                                const s = Object.keys(e);
                                                if (0 === s.length)
                                                    return Object(i.a)({});
                                                if (1 === s.length) {
                                                    const i = s[0];
                                                    return Jt(e[i], t, n, r).pipe(Object(m.a)(e => ({
                                                        [i]: e
                                                    })))
                                                }
                                                const a = {};
                                                return Object(o.a)(s).pipe(Object(j.a)(s => Jt(e[s], t, n, r).pipe(Object(m.a)(e => (a[s] = e,
                                                e))))).pipe(I(), Object(m.a)( () => a))
                                            }(e._resolve, e, r, s).pipe(Object(m.a)(t => (e._resolvedData = t,
                                            e.data = Object.assign({}, e.data, Xe(e, n).resolve),
                                            null)))
                                        }
                                        )(n.route, 0, e, t)), function(e, t) {
                                            return arguments.length >= 2 ? function(n) {
                                                return Object(z.a)(Object(F.a)(e, t), _(1), T(t))(n)
                                            }
                                            : function(t) {
                                                return Object(z.a)(Object(F.a)( (t, n, r) => e(t, n, r + 1)), _(1))(t)
                                            }
                                        }( (e, t) => e), Object(m.a)(e => n)) : Object(i.a)(n)
                                    }
                                    ))
                                }
                            }(this.paramsInheritanceStrategy, this.ngModule.injector), Object(S.a)(e => {
                                const t = new X(e.id,this.serializeUrl(e.extractedUrl),this.serializeUrl(e.urlAfterRedirects),e.targetSnapshot);
                                this.triggerEvent(t)
                            }
                            ))
                    }
                    ), Xt(e => {
                        const {targetSnapshot: t, id: n, extractedUrl: r, rawUrl: s, extras: {skipLocationChange: i, replaceUrl: o}} = e;
                        return this.hooks.afterPreactivation(t, {
                            navigationId: n,
                            appliedUrlTree: r,
                            rawUrlTree: s,
                            skipLocationChange: !!i,
                            replaceUrl: !!o
                        })
                    }
                    ), Object(m.a)(e => {
                        const t = function(e, t, n) {
                            const r = function e(t, n, r) {
                                if (r && t.shouldReuseRoute(n.value, r.value.snapshot)) {
                                    const s = r.value;
                                    s._futureSnapshot = n.value;
                                    const i = function(t, n, r) {
                                        return n.children.map(n => {
                                            for (const s of r.children)
                                                if (t.shouldReuseRoute(s.value.snapshot, n.value))
                                                    return e(t, n, s);
                                            return e(t, n)
                                        }
                                        )
                                    }(t, n, r);
                                    return new Ke(s,i)
                                }
                                {
                                    const r = t.retrieve(n.value);
                                    if (r) {
                                        const e = r.route;
                                        return function e(t, n) {
                                            if (t.value.routeConfig !== n.value.routeConfig)
                                                throw new Error("Cannot reattach ActivatedRouteSnapshot created from a different route");
                                            if (t.children.length !== n.children.length)
                                                throw new Error("Cannot reattach ActivatedRouteSnapshot with a different number of children");
                                            n.value._futureSnapshot = t.value;
                                            for (let r = 0; r < t.children.length; ++r)
                                                e(t.children[r], n.children[r])
                                        }(n, e),
                                        e
                                    }
                                    {
                                        const r = new Je(new a.a((s = n.value).url),new a.a(s.params),new a.a(s.queryParams),new a.a(s.fragment),new a.a(s.data),s.outlet,s.component,s)
                                          , i = n.children.map(n => e(t, n));
                                        return new Ke(r,i)
                                    }
                                }
                                var s
                            }(e, t._root, n ? n._root : void 0);
                            return new Ze(r,t)
                        }(this.routeReuseStrategy, e.targetSnapshot, e.currentRouterState);
                        return Object.assign({}, e, {
                            targetRouterState: t
                        })
                    }
                    ), Object(S.a)(e => {
                        this.currentUrlTree = e.urlAfterRedirects,
                        this.rawUrlTree = this.urlHandlingStrategy.merge(this.currentUrlTree, e.rawUrl),
                        this.routerState = e.targetRouterState,
                        "deferred" === this.urlUpdateStrategy && (e.extras.skipLocationChange || this.setBrowserUrl(this.rawUrlTree, !!e.extras.replaceUrl, e.id, e.extras.state),
                        this.browserUrlTree = e.urlAfterRedirects)
                    }
                    ), bt(this.rootContexts, this.routeReuseStrategy, e => this.triggerEvent(e)), Object(S.a)({
                        next() {
                            n = !0
                        },
                        complete() {
                            n = !0
                        }
                    }), Object(H.a)( () => {
                        if (!n && !r) {
                            this.resetUrlToCurrentUrlTree();
                            const n = new G(e.id,this.serializeUrl(e.extractedUrl),`Navigation ID ${e.id} is not equal to the current navigation id ${this.navigationId}`);
                            t.next(n),
                            e.resolve(!1)
                        }
                        this.currentNavigation = null
                    }
                    ), Object(A.a)(n => {
                        if (r = !0,
                        function(e) {
                            return n && n[he]
                        }()) {
                            const r = wt(n.url);
                            r || (this.navigated = !0,
                            this.resetStateAndUrl(e.currentRouterState, e.currentUrlTree, e.rawUrl));
                            const s = new G(e.id,this.serializeUrl(e.extractedUrl),n.message);
                            t.next(s),
                            e.resolve(!1),
                            r && this.navigateByUrl(n.url)
                        } else {
                            this.resetStateAndUrl(e.currentRouterState, e.currentUrlTree, e.rawUrl);
                            const r = new K(e.id,this.serializeUrl(e.extractedUrl),n);
                            t.next(r);
                            try {
                                e.resolve(this.errorHandler(n))
                            } catch (s) {
                                e.reject(s)
                            }
                        }
                        return p.a
                    }
                    ))
                }
                ))
            }
            resetRootComponentType(e) {
                this.rootComponentType = e,
                this.routerState.root.component = this.rootComponentType
            }
            getTransition() {
                const e = this.transitions.value;
                return e.urlAfterRedirects = this.browserUrlTree,
                e
            }
            setTransition(e) {
                this.transitions.next(Object.assign({}, this.getTransition(), e))
            }
            initialNavigation() {
                this.setUpLocationChangeListener(),
                0 === this.navigationId && this.navigateByUrl(this.location.path(!0), {
                    replaceUrl: !0
                })
            }
            setUpLocationChangeListener() {
                this.locationSubscription || (this.locationSubscription = this.location.subscribe(e => {
                    let t = this.parseUrl(e.url);
                    const n = "popstate" === e.type ? "popstate" : "hashchange"
                      , r = e.state && e.state.navigationId ? e.state : null;
                    setTimeout( () => {
                        this.scheduleNavigation(t, n, r, {
                            replaceUrl: !0
                        })
                    }
                    , 0)
                }
                ))
            }
            get url() {
                return this.serializeUrl(this.currentUrlTree)
            }
            getCurrentNavigation() {
                return this.currentNavigation
            }
            triggerEvent(e) {
                this.events.next(e)
            }
            resetConfig(e) {
                me(e),
                this.config = e.map(ye),
                this.navigated = !1,
                this.lastSuccessfulId = -1
            }
            ngOnDestroy() {
                this.dispose()
            }
            dispose() {
                this.locationSubscription && (this.locationSubscription.unsubscribe(),
                this.locationSubscription = null)
            }
            createUrlTree(e, t={}) {
                const {relativeTo: n, queryParams: r, fragment: i, preserveQueryParams: o, queryParamsHandling: a, preserveFragment: c} = t;
                Object(s.W)() && o && console && console.warn && console.warn("preserveQueryParams is deprecated, use queryParamsHandling instead.");
                const l = n || this.routerState.root
                  , u = c ? this.currentUrlTree.fragment : i;
                let h = null;
                if (a)
                    switch (a) {
                    case "merge":
                        h = Object.assign({}, this.currentUrlTree.queryParams, r);
                        break;
                    case "preserve":
                        h = this.currentUrlTree.queryParams;
                        break;
                    default:
                        h = r || null
                    }
                else
                    h = o ? this.currentUrlTree.queryParams : r || null;
                return null !== h && (h = this.removeEmptyProps(h)),
                function(e, t, n, r, s) {
                    if (0 === n.length)
                        return at(t.root, t.root, t, r, s);
                    const i = function(e) {
                        if ("string" == typeof e[0] && 1 === e.length && "/" === e[0])
                            return new ct(!0,0,e);
                        let t = 0
                          , n = !1;
                        const r = e.reduce( (e, r, s) => {
                            if ("object" == typeof r && null != r) {
                                if (r.outlets) {
                                    const t = {};
                                    return Ee(r.outlets, (e, n) => {
                                        t[n] = "string" == typeof e ? e.split("/") : e
                                    }
                                    ),
                                    [...e, {
                                        outlets: t
                                    }]
                                }
                                if (r.segmentPath)
                                    return [...e, r.segmentPath]
                            }
                            return "string" != typeof r ? [...e, r] : 0 === s ? (r.split("/").forEach( (r, s) => {
                                0 == s && "." === r || (0 == s && "" === r ? n = !0 : ".." === r ? t++ : "" != r && e.push(r))
                            }
                            ),
                            e) : [...e, r]
                        }
                        , []);
                        return new ct(n,t,r)
                    }(n);
                    if (i.toRoot())
                        return at(t.root, new xe([],{}), t, r, s);
                    const o = function(e, n, r) {
                        if (e.isAbsolute)
                            return new lt(t.root,!0,0);
                        if (-1 === r.snapshot._lastPathIndex)
                            return new lt(r.snapshot._urlSegment,!0,0);
                        const s = ot(e.commands[0]) ? 0 : 1;
                        return function(t, n, i) {
                            let o = r.snapshot._urlSegment
                              , a = r.snapshot._lastPathIndex + s
                              , c = e.numberOfDoubleDots;
                            for (; c > a; ) {
                                if (c -= a,
                                !(o = o.parent))
                                    throw new Error("Invalid number of '../'");
                                a = o.segments.length
                            }
                            return new lt(o,!1,a - c)
                        }()
                    }(i, 0, e)
                      , a = o.processChildren ? dt(o.segmentGroup, o.index, i.commands) : ht(o.segmentGroup, o.index, i.commands);
                    return at(o.segmentGroup, a, t, r, s)
                }(l, this.currentUrlTree, e, h, u)
            }
            navigateByUrl(e, t={
                skipLocationChange: !1
            }) {
                Object(s.W)() && this.isNgZoneEnabled && !s.y.isInAngularZone() && this.console.warn("Navigation triggered outside Angular zone, did you forget to call 'ngZone.run()'?");
                const n = wt(e) ? e : this.parseUrl(e)
                  , r = this.urlHandlingStrategy.merge(n, this.rawUrlTree);
                return this.scheduleNavigation(r, "imperative", null, t)
            }
            navigate(e, t={
                skipLocationChange: !1
            }) {
                return function(e) {
                    for (let t = 0; t < e.length; t++) {
                        const n = e[t];
                        if (null == n)
                            throw new Error(`The requested path contains ${n} segment at index ${t}`)
                    }
                }(e),
                this.navigateByUrl(this.createUrlTree(e, t), t)
            }
            serializeUrl(e) {
                return this.urlSerializer.serialize(e)
            }
            parseUrl(e) {
                let t;
                try {
                    t = this.urlSerializer.parse(e)
                } catch (n) {
                    t = this.malformedUriErrorHandler(n, this.urlSerializer, e)
                }
                return t
            }
            isActive(e, t) {
                if (wt(e))
                    return Ce(this.currentUrlTree, e, t);
                const n = this.parseUrl(e);
                return Ce(this.currentUrlTree, n, t)
            }
            removeEmptyProps(e) {
                return Object.keys(e).reduce( (t, n) => {
                    const r = e[n];
                    return null != r && (t[n] = r),
                    t
                }
                , {})
            }
            processNavigations() {
                this.navigations.subscribe(e => {
                    this.navigated = !0,
                    this.lastSuccessfulId = e.id,
                    this.events.next(new Q(e.id,this.serializeUrl(e.extractedUrl),this.serializeUrl(this.currentUrlTree))),
                    this.lastSuccessfulNavigation = this.currentNavigation,
                    this.currentNavigation = null,
                    e.resolve(!0)
                }
                , e => {
                    this.console.warn("Unhandled Navigation Error: ")
                }
                )
            }
            scheduleNavigation(e, t, n, r) {
                const s = this.getTransition();
                if (s && "imperative" !== t && "imperative" === s.source && s.rawUrl.toString() === e.toString())
                    return Promise.resolve(!0);
                if (s && "hashchange" == t && "popstate" === s.source && s.rawUrl.toString() === e.toString())
                    return Promise.resolve(!0);
                if (s && "popstate" == t && "hashchange" === s.source && s.rawUrl.toString() === e.toString())
                    return Promise.resolve(!0);
                let i = null
                  , o = null;
                const a = new Promise( (e, t) => {
                    i = e,
                    o = t
                }
                )
                  , c = ++this.navigationId;
                return this.setTransition({
                    id: c,
                    source: t,
                    restoredState: n,
                    currentUrlTree: this.currentUrlTree,
                    currentRawUrl: this.rawUrlTree,
                    rawUrl: e,
                    extras: r,
                    resolve: i,
                    reject: o,
                    promise: a,
                    currentSnapshot: this.routerState.snapshot,
                    currentRouterState: this.routerState
                }),
                a.catch(e => Promise.reject(e))
            }
            setBrowserUrl(e, t, n, r) {
                const s = this.urlSerializer.serialize(e);
                r = r || {},
                this.location.isCurrentPathEqualTo(s) || t ? this.location.replaceState(s, "", Object.assign({}, r, {
                    navigationId: n
                })) : this.location.go(s, "", Object.assign({}, r, {
                    navigationId: n
                }))
            }
            resetStateAndUrl(e, t, n) {
                this.routerState = e,
                this.currentUrlTree = t,
                this.rawUrlTree = this.urlHandlingStrategy.merge(this.currentUrlTree, n),
                this.resetUrlToCurrentUrlTree()
            }
            resetUrlToCurrentUrlTree() {
                this.location.replaceState(this.urlSerializer.serialize(this.rawUrlTree), "", {
                    navigationId: this.lastSuccessfulId
                })
            }
        }
        class hn {
            constructor() {
                this.outlet = null,
                this.route = null,
                this.resolver = null,
                this.children = new dn,
                this.attachRef = null
            }
        }
        class dn {
            constructor() {
                this.contexts = new Map
            }
            onChildOutletCreated(e, t) {
                const n = this.getOrCreateContext(e);
                n.outlet = t,
                this.contexts.set(e, n)
            }
            onChildOutletDestroyed(e) {
                const t = this.getContext(e);
                t && (t.outlet = null)
            }
            onOutletDeactivated() {
                const e = this.contexts;
                return this.contexts = new Map,
                e
            }
            onOutletReAttached(e) {
                this.contexts = e
            }
            getOrCreateContext(e) {
                let t = this.getContext(e);
                return t || (t = new hn,
                this.contexts.set(e, t)),
                t
            }
            getContext(e) {
                return this.contexts.get(e) || null
            }
        }
        class fn {
            constructor(e, t, n, r, i) {
                this.parentContexts = e,
                this.location = t,
                this.resolver = n,
                this.changeDetector = i,
                this.activated = null,
                this._activatedRoute = null,
                this.activateEvents = new s.m,
                this.deactivateEvents = new s.m,
                this.name = r || ce,
                e.onChildOutletCreated(this.name, this)
            }
            ngOnDestroy() {
                this.parentContexts.onChildOutletDestroyed(this.name)
            }
            ngOnInit() {
                if (!this.activated) {
                    const e = this.parentContexts.getContext(this.name);
                    e && e.route && (e.attachRef ? this.attach(e.attachRef, e.route) : this.activateWith(e.route, e.resolver || null))
                }
            }
            get isActivated() {
                return !!this.activated
            }
            get component() {
                if (!this.activated)
                    throw new Error("Outlet is not activated");
                return this.activated.instance
            }
            get activatedRoute() {
                if (!this.activated)
                    throw new Error("Outlet is not activated");
                return this._activatedRoute
            }
            get activatedRouteData() {
                return this._activatedRoute ? this._activatedRoute.snapshot.data : {}
            }
            detach() {
                if (!this.activated)
                    throw new Error("Outlet is not activated");
                this.location.detach();
                const e = this.activated;
                return this.activated = null,
                this._activatedRoute = null,
                e
            }
            attach(e, t) {
                this.activated = e,
                this._activatedRoute = t,
                this.location.insert(e.hostView)
            }
            deactivate() {
                if (this.activated) {
                    const e = this.component;
                    this.activated.destroy(),
                    this.activated = null,
                    this._activatedRoute = null,
                    this.deactivateEvents.emit(e)
                }
            }
            activateWith(e, t) {
                if (this.isActivated)
                    throw new Error("Cannot activate an already activated outlet");
                this._activatedRoute = e;
                const n = (t = t || this.resolver).resolveComponentFactory(e._futureSnapshot.routeConfig.component)
                  , r = this.parentContexts.getOrCreateContext(this.name).children
                  , s = new pn(e,r,this.location.injector);
                this.activated = this.location.createComponent(n, this.location.length, s),
                this.changeDetector.markForCheck(),
                this.activateEvents.emit(this.activated.instance)
            }
        }
        class pn {
            constructor(e, t, n) {
                this.route = e,
                this.childContexts = t,
                this.parent = n
            }
            get(e, t) {
                return e === Je ? this.route : e === dn ? this.childContexts : this.parent.get(e, t)
            }
        }
        class mn {
        }
        class gn {
            preload(e, t) {
                return t().pipe(Object(A.a)( () => Object(i.a)(null)))
            }
        }
        class bn {
            preload(e, t) {
                return Object(i.a)(null)
            }
        }
        class yn {
            constructor(e, t, n, r, s) {
                this.router = e,
                this.injector = r,
                this.preloadingStrategy = s,
                this.loader = new rn(t,n,t => e.triggerEvent(new ee(t)),t => e.triggerEvent(new te(t)))
            }
            setUpPreloading() {
                this.subscription = this.router.events.pipe(Object(b.a)(e => e instanceof Q), Object(U.a)( () => this.preload())).subscribe( () => {}
                )
            }
            preload() {
                const e = this.injector.get(s.w);
                return this.processRoutes(e, this.router.config)
            }
            ngOnDestroy() {
                this.subscription.unsubscribe()
            }
            processRoutes(e, t) {
                const n = [];
                for (const r of t)
                    if (r.loadChildren && !r.canLoad && r._loadedConfig) {
                        const e = r._loadedConfig;
                        n.push(this.processRoutes(e.module, e.routes))
                    } else
                        r.loadChildren && !r.canLoad ? n.push(this.preloadConfig(e, r)) : r.children && n.push(this.processRoutes(e, r.children));
                return Object(o.a)(n).pipe(Object(B.a)(), Object(m.a)(e => void 0))
            }
            preloadConfig(e, t) {
                return this.preloadingStrategy.preload(t, () => this.loader.load(e.injector, t).pipe(Object(j.a)(e => (t._loadedConfig = e,
                this.processRoutes(e.module, e.routes)))))
            }
        }
        class vn {
            constructor(e, t, n={}) {
                this.router = e,
                this.viewportScroller = t,
                this.options = n,
                this.lastId = 0,
                this.lastSource = "imperative",
                this.restoredId = 0,
                this.store = {},
                n.scrollPositionRestoration = n.scrollPositionRestoration || "disabled",
                n.anchorScrolling = n.anchorScrolling || "disabled"
            }
            init() {
                "disabled" !== this.options.scrollPositionRestoration && this.viewportScroller.setHistoryScrollRestoration("manual"),
                this.routerEventsSubscription = this.createScrollEvents(),
                this.scrollEventsSubscription = this.consumeScrollEvents()
            }
            createScrollEvents() {
                return this.router.events.subscribe(e => {
                    e instanceof q ? (this.store[this.lastId] = this.viewportScroller.getScrollPosition(),
                    this.lastSource = e.navigationTrigger,
                    this.restoredId = e.restoredState ? e.restoredState.navigationId : 0) : e instanceof Q && (this.lastId = e.id,
                    this.scheduleScrollEvent(e, this.router.parseUrl(e.urlAfterRedirects).fragment))
                }
                )
            }
            consumeScrollEvents() {
                return this.router.events.subscribe(e => {
                    e instanceof oe && (e.position ? "top" === this.options.scrollPositionRestoration ? this.viewportScroller.scrollToPosition([0, 0]) : "enabled" === this.options.scrollPositionRestoration && this.viewportScroller.scrollToPosition(e.position) : e.anchor && "enabled" === this.options.anchorScrolling ? this.viewportScroller.scrollToAnchor(e.anchor) : "disabled" !== this.options.scrollPositionRestoration && this.viewportScroller.scrollToPosition([0, 0]))
                }
                )
            }
            scheduleScrollEvent(e, t) {
                this.router.triggerEvent(new oe(e,"popstate" === this.lastSource ? this.store[this.restoredId] : null,t))
            }
            ngOnDestroy() {
                this.routerEventsSubscription && this.routerEventsSubscription.unsubscribe(),
                this.scrollEventsSubscription && this.scrollEventsSubscription.unsubscribe()
            }
        }
        const _n = new s.p("ROUTER_CONFIGURATION")
          , wn = new s.p("ROUTER_FORROOT_GUARD")
          , En = [r.h, {
            provide: Ae,
            useClass: De
        }, {
            provide: un,
            useFactory: In,
            deps: [s.g, Ae, dn, r.h, s.q, s.v, s.i, nn, _n, [sn, new s.z], [en, new s.z]]
        }, dn, {
            provide: Je,
            useFactory: An,
            deps: [un]
        }, {
            provide: s.v,
            useClass: s.J
        }, yn, bn, gn, {
            provide: _n,
            useValue: {
                enableTracing: !1
            }
        }];
        function Sn() {
            return new s.x("Router",un)
        }
        class Cn {
            constructor(e, t) {}
            static forRoot(e, t) {
                return {
                    ngModule: Cn,
                    providers: [En, On(e), {
                        provide: wn,
                        useFactory: kn,
                        deps: [[un, new s.z, new s.I]]
                    }, {
                        provide: _n,
                        useValue: t || {}
                    }, {
                        provide: r.i,
                        useFactory: xn,
                        deps: [r.p, [new s.o(r.a), new s.z], _n]
                    }, {
                        provide: vn,
                        useFactory: Tn,
                        deps: [un, r.q, _n]
                    }, {
                        provide: mn,
                        useExisting: t && t.preloadingStrategy ? t.preloadingStrategy : bn
                    }, {
                        provide: s.x,
                        multi: !0,
                        useFactory: Sn
                    }, [Dn, {
                        provide: s.d,
                        multi: !0,
                        useFactory: Rn,
                        deps: [Dn]
                    }, {
                        provide: Nn,
                        useFactory: jn,
                        deps: [Dn]
                    }, {
                        provide: s.b,
                        multi: !0,
                        useExisting: Nn
                    }]]
                }
            }
            static forChild(e) {
                return {
                    ngModule: Cn,
                    providers: [On(e)]
                }
            }
        }
        function Tn(e, t, n) {
            return n.scrollOffset && t.setOffset(n.scrollOffset),
            new vn(e,t,n)
        }
        function xn(e, t, n={}) {
            return n.useHash ? new r.f(e,t) : new r.o(e,t)
        }
        function kn(e) {
            if (e)
                throw new Error("RouterModule.forRoot() called twice. Lazy loaded modules should use RouterModule.forChild() instead.");
            return "guarded"
        }
        function On(e) {
            return [{
                provide: s.a,
                multi: !0,
                useValue: e
            }, {
                provide: nn,
                multi: !0,
                useValue: e
            }]
        }
        function In(e, t, n, r, s, i, o, a, c={}, l, u) {
            const h = new un(null,t,n,r,s,i,o,_e(a));
            if (l && (h.urlHandlingStrategy = l),
            u && (h.routeReuseStrategy = u),
            c.errorHandler && (h.errorHandler = c.errorHandler),
            c.malformedUriErrorHandler && (h.malformedUriErrorHandler = c.malformedUriErrorHandler),
            c.enableTracing) {
                const e = Object(V.q)();
                h.events.subscribe(t => {
                    e.logGroup(`Router Event: ${t.constructor.name}`),
                    e.log(t.toString()),
                    e.log(t),
                    e.logGroupEnd()
                }
                )
            }
            return c.onSameUrlNavigation && (h.onSameUrlNavigation = c.onSameUrlNavigation),
            c.paramsInheritanceStrategy && (h.paramsInheritanceStrategy = c.paramsInheritanceStrategy),
            c.urlUpdateStrategy && (h.urlUpdateStrategy = c.urlUpdateStrategy),
            c.relativeLinkResolution && (h.relativeLinkResolution = c.relativeLinkResolution),
            h
        }
        function An(e) {
            return e.routerState.root
        }
        class Dn {
            constructor(e) {
                this.injector = e,
                this.initNavigation = !1,
                this.resultOfPreactivationDone = new f.a
            }
            appInitializer() {
                return this.injector.get(r.g, Promise.resolve(null)).then( () => {
                    let e = null;
                    const t = new Promise(t => e = t)
                      , n = this.injector.get(un)
                      , r = this.injector.get(_n);
                    if (this.isLegacyDisabled(r) || this.isLegacyEnabled(r))
                        e(!0);
                    else if ("disabled" === r.initialNavigation)
                        n.setUpLocationChangeListener(),
                        e(!0);
                    else {
                        if ("enabled" !== r.initialNavigation)
                            throw new Error(`Invalid initialNavigation options: '${r.initialNavigation}'`);
                        n.hooks.afterPreactivation = () => this.initNavigation ? Object(i.a)(null) : (this.initNavigation = !0,
                        e(!0),
                        this.resultOfPreactivationDone),
                        n.initialNavigation()
                    }
                    return t
                }
                )
            }
            bootstrapListener(e) {
                const t = this.injector.get(_n)
                  , n = this.injector.get(yn)
                  , r = this.injector.get(vn)
                  , i = this.injector.get(un)
                  , o = this.injector.get(s.g);
                e === o.components[0] && (this.isLegacyEnabled(t) ? i.initialNavigation() : this.isLegacyDisabled(t) && i.setUpLocationChangeListener(),
                n.setUpPreloading(),
                r.init(),
                i.resetRootComponentType(o.componentTypes[0]),
                this.resultOfPreactivationDone.next(null),
                this.resultOfPreactivationDone.complete())
            }
            isLegacyEnabled(e) {
                return "legacy_enabled" === e.initialNavigation || !0 === e.initialNavigation || void 0 === e.initialNavigation
            }
            isLegacyDisabled(e) {
                return "legacy_disabled" === e.initialNavigation || !1 === e.initialNavigation
            }
        }
        function Rn(e) {
            return e.appInitializer.bind(e)
        }
        function jn(e) {
            return e.bootstrapListener.bind(e)
        }
        const Nn = new s.p("Router Initializer")
    },
    itXk: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return l
        });
        var r = n("z+Ro")
          , s = n("DH7j")
          , i = n("l7GE")
          , o = n("ZUHj")
          , a = n("yCtX");
        const c = {};
        function l(...e) {
            let t = null
              , n = null;
            return Object(r.a)(e[e.length - 1]) && (n = e.pop()),
            "function" == typeof e[e.length - 1] && (t = e.pop()),
            1 === e.length && Object(s.a)(e[0]) && (e = e[0]),
            Object(a.a)(e, n).lift(new u(t))
        }
        class u {
            constructor(e) {
                this.resultSelector = e
            }
            call(e, t) {
                return t.subscribe(new h(e,this.resultSelector))
            }
        }
        class h extends i.a {
            constructor(e, t) {
                super(e),
                this.resultSelector = t,
                this.active = 0,
                this.values = [],
                this.observables = []
            }
            _next(e) {
                this.values.push(c),
                this.observables.push(e)
            }
            _complete() {
                const e = this.observables
                  , t = e.length;
                if (0 === t)
                    this.destination.complete();
                else {
                    this.active = t,
                    this.toRespond = t;
                    for (let n = 0; n < t; n++) {
                        const t = e[n];
                        this.add(Object(o.a)(this, t, t, n))
                    }
                }
            }
            notifyComplete(e) {
                0 == (this.active -= 1) && this.destination.complete()
            }
            notifyNext(e, t, n, r, s) {
                const i = this.values
                  , o = this.toRespond ? i[n] === c ? --this.toRespond : this.toRespond : 0;
                i[n] = t,
                0 === o && (this.resultSelector ? this._tryResultSelector(i) : this.destination.next(i.slice()))
            }
            _tryResultSelector(e) {
                let t;
                try {
                    t = this.resultSelector.apply(this, e)
                } catch (n) {
                    return void this.destination.error(n)
                }
                this.destination.next(t)
            }
        }
    },
    kJWO: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        const r = "function" == typeof Symbol && Symbol.observable || "@@observable"
    },
    l5mm: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o
        });
        var r = n("HDdC")
          , s = n("D0XW")
          , i = n("Y7HM");
        function o(e=0, t=s.a) {
            return (!Object(i.a)(e) || e < 0) && (e = 0),
            t && "function" == typeof t.schedule || (t = s.a),
            new r.a(n => (n.add(t.schedule(a, e, {
                subscriber: n,
                counter: 0,
                period: e
            })),
            n))
        }
        function a(e) {
            const {subscriber: t, counter: n, period: r} = e;
            t.next(n),
            this.schedule({
                subscriber: t,
                counter: n + 1,
                period: r
            }, r)
        }
    },
    l7GE: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("7o/Q");
        class s extends r.a {
            notifyNext(e, t, n, r, s) {
                this.destination.next(t)
            }
            notifyError(e, t) {
                this.destination.error(e)
            }
            notifyComplete(e) {
                this.destination.complete()
            }
        }
    },
    lJxs: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("7o/Q");
        function s(e, t) {
            return function(n) {
                if ("function" != typeof e)
                    throw new TypeError("argument is not a function. Are you looking for `mapTo()`?");
                return n.lift(new i(e,t))
            }
        }
        class i {
            constructor(e, t) {
                this.project = e,
                this.thisArg = t
            }
            call(e, t) {
                return t.subscribe(new o(e,this.project,this.thisArg))
            }
        }
        class o extends r.a {
            constructor(e, t, n) {
                super(e),
                this.project = t,
                this.count = 0,
                this.thisArg = n || this
            }
            _next(e) {
                let t;
                try {
                    t = this.project.call(this.thisArg, e, this.count++)
                } catch (n) {
                    return void this.destination.error(n)
                }
                this.destination.next(t)
            }
        }
    },
    m73C: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        const r = {}
    },
    mCNh: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        }),
        n.d(t, "b", function() {
            return i
        });
        var r = n("KqfI");
        function s(...e) {
            return i(e)
        }
        function i(e) {
            return e ? 1 === e.length ? e[0] : function(t) {
                return e.reduce( (e, t) => t(e), t)
            }
            : r.a
        }
    },
    mHMc: function(e, t, n) {
        "use strict";
        var r = n("gJmp");
        class s extends r.a {
            constructor() {
                super(),
                this._closable = !0
            }
            set backdropClickable(e) {
                this.dialogRef.backdropClickable.next(e)
            }
            $close(e) {
                this._closable && this.dialogRef.close(e)
            }
        }
        var i = n("VPT0");
        n.d(t, "a", function() {
            return o
        });
        class o extends s {
            constructor() {
                super()
            }
            ngOnInit() {
                const e = this.params;
                switch (e.type) {
                case i.a.Error:
                    this.title = this.getResourceValue("Common_Error"),
                    this.class = "error";
                    break;
                case i.a.ComError:
                    this.title = this.getResourceValue("Common_ComError"),
                    this.class = "comError"
                }
                this.messageId = e.messageId,
                this.message = this.getResourceValue(`Message_${e.messageId}`),
                this.messageDetail = e.messageDetail,
                this.errorTime = e.errorTime,
                this.errorCode = e.errorCode ? e.errorCode : "",
                this.backdropClickable = !1
            }
        }
    },
    mrSG: function(e, t, n) {
        "use strict";
        function r(e, t, n, r) {
            return new (n || (n = Promise))(function(s, i) {
                function o(e) {
                    try {
                        c(r.next(e))
                    } catch (t) {
                        i(t)
                    }
                }
                function a(e) {
                    try {
                        c(r.throw(e))
                    } catch (t) {
                        i(t)
                    }
                }
                function c(e) {
                    e.done ? s(e.value) : new n(function(t) {
                        t(e.value)
                    }
                    ).then(o, a)
                }
                c((r = r.apply(e, t || [])).next())
            }
            )
        }
        n.d(t, "a", function() {
            return r
        })
    },
    n6bG: function(e, t, n) {
        "use strict";
        function r(e) {
            return "function" == typeof e
        }
        n.d(t, "a", function() {
            return r
        })
    },
    nYR2: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i
        });
        var r = n("7o/Q")
          , s = n("quSY");
        function i(e) {
            return t => t.lift(new o(e))
        }
        class o {
            constructor(e) {
                this.callback = e
            }
            call(e, t) {
                return t.subscribe(new a(e,this.callback))
            }
        }
        class a extends r.a {
            constructor(e, t) {
                super(e),
                this.add(new s.a(t))
            }
        }
    },
    ngJS: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        const r = e => t => {
            for (let n = 0, r = e.length; n < r && !t.closed; n++)
                t.next(e[n]);
            t.closed || t.complete()
        }
    },
    oTXU: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return a
        });
        var r = n("DQLy")
          , s = n("G4Cx");
        const i = {
            notice: {
                errorCode: void 0,
                message: void 0,
                messageDetail: void 0,
                messageId: void 0,
                messagePriority: 1e3,
                type: n("VPT0").a.None
            }
        }
          , o = Object(r.w)(i, Object(r.z)(s.e, (e, t) => Object.assign({}, e, {
            notice: t.payload.notice
        })), Object(r.z)(s.c, e => Object.assign({}, e, {
            notice: i.notice
        })));
        function a(e, t) {
            return o(e, t)
        }
    },
    omvX: function(e, t, n) {
        "use strict";
        n.d(t, "f", function() {
            return b
        }),
        n.d(t, "g", function() {
            return y
        }),
        n.d(t, "e", function() {
            return g
        }),
        n.d(t, "b", function() {
            return _
        }),
        n.d(t, "a", function() {
            return v
        }),
        n.d(t, "c", function() {
            return o
        }),
        n.d(t, "d", function() {
            return m
        });
        var r = n("8Y7J")
          , s = (n("cUpR"),
        n("GS7A"))
          , i = n("fDlF");
        class o extends s.b {
            constructor(e, t) {
                super(),
                this._nextAnimationId = 0,
                this._renderer = e.createRenderer(t.body, {
                    id: "0",
                    encapsulation: r.P.None,
                    styles: [],
                    data: {
                        animation: []
                    }
                })
            }
            build(e) {
                const t = this._nextAnimationId.toString();
                this._nextAnimationId++;
                const n = Array.isArray(e) ? Object(s.f)(e) : e;
                return l(this._renderer, null, t, "register", [n]),
                new a(t,this._renderer)
            }
        }
        class a extends s.c {
            constructor(e, t) {
                super(),
                this._id = e,
                this._renderer = t
            }
            create(e, t) {
                return new c(this._id,e,t || {},this._renderer)
            }
        }
        class c {
            constructor(e, t, n, r) {
                this.id = e,
                this.element = t,
                this._renderer = r,
                this.parentPlayer = null,
                this._started = !1,
                this.totalTime = 0,
                this._command("create", n)
            }
            _listen(e, t) {
                return this._renderer.listen(this.element, `@@${this.id}:${e}`, t)
            }
            _command(e, ...t) {
                return l(this._renderer, this.element, this.id, e, t)
            }
            onDone(e) {
                this._listen("done", e)
            }
            onStart(e) {
                this._listen("start", e)
            }
            onDestroy(e) {
                this._listen("destroy", e)
            }
            init() {
                this._command("init")
            }
            hasStarted() {
                return this._started
            }
            play() {
                this._command("play"),
                this._started = !0
            }
            pause() {
                this._command("pause")
            }
            restart() {
                this._command("restart")
            }
            finish() {
                this._command("finish")
            }
            destroy() {
                this._command("destroy")
            }
            reset() {
                this._command("reset")
            }
            setPosition(e) {
                this._command("setPosition", e)
            }
            getPosition() {
                return 0
            }
        }
        function l(e, t, n, r, s) {
            return e.setProperty(t, `@@${n}:${r}`, s)
        }
        const u = "@"
          , h = "@.disabled";
        class d {
            constructor(e, t, n) {
                this.delegate = e,
                this.engine = t,
                this._zone = n,
                this._currentId = 0,
                this._microtaskId = 1,
                this._animationCallbacksBuffer = [],
                this._rendererCache = new Map,
                this._cdRecurDepth = 0,
                this.promise = Promise.resolve(0),
                t.onRemovalComplete = (e, t) => {
                    t && t.parentNode(e) && t.removeChild(e.parentNode, e)
                }
            }
            createRenderer(e, t) {
                const n = this.delegate.createRenderer(e, t);
                if (!(e && t && t.data && t.data.animation)) {
                    let e = this._rendererCache.get(n);
                    return e || (e = new f("",n,this.engine),
                    this._rendererCache.set(n, e)),
                    e
                }
                const r = t.id
                  , s = t.id + "-" + this._currentId;
                return this._currentId++,
                this.engine.register(s, e),
                t.data.animation.forEach(t => this.engine.registerTrigger(r, s, e, t.name, t)),
                new p(this,s,n,this.engine)
            }
            begin() {
                this._cdRecurDepth++,
                this.delegate.begin && this.delegate.begin()
            }
            _scheduleCountTask() {
                this.promise.then( () => {
                    this._microtaskId++
                }
                )
            }
            scheduleListenerCallback(e, t, n) {
                e >= 0 && e < this._microtaskId ? this._zone.run( () => t(n)) : (0 == this._animationCallbacksBuffer.length && Promise.resolve(null).then( () => {
                    this._zone.run( () => {
                        this._animationCallbacksBuffer.forEach(e => {
                            const [t,n] = e;
                            t(n)
                        }
                        ),
                        this._animationCallbacksBuffer = []
                    }
                    )
                }
                ),
                this._animationCallbacksBuffer.push([t, n]))
            }
            end() {
                this._cdRecurDepth--,
                0 == this._cdRecurDepth && this._zone.runOutsideAngular( () => {
                    this._scheduleCountTask(),
                    this.engine.flush(this._microtaskId)
                }
                ),
                this.delegate.end && this.delegate.end()
            }
            whenRenderingDone() {
                return this.engine.whenRenderingDone()
            }
        }
        class f {
            constructor(e, t, n) {
                this.namespaceId = e,
                this.delegate = t,
                this.engine = n,
                this.destroyNode = this.delegate.destroyNode ? e => t.destroyNode(e) : null
            }
            get data() {
                return this.delegate.data
            }
            destroy() {
                this.engine.destroy(this.namespaceId, this.delegate),
                this.delegate.destroy()
            }
            createElement(e, t) {
                return this.delegate.createElement(e, t)
            }
            createComment(e) {
                return this.delegate.createComment(e)
            }
            createText(e) {
                return this.delegate.createText(e)
            }
            appendChild(e, t) {
                this.delegate.appendChild(e, t),
                this.engine.onInsert(this.namespaceId, t, e, !1)
            }
            insertBefore(e, t, n) {
                this.delegate.insertBefore(e, t, n),
                this.engine.onInsert(this.namespaceId, t, e, !0)
            }
            removeChild(e, t, n) {
                this.engine.onRemove(this.namespaceId, t, this.delegate, n)
            }
            selectRootElement(e, t) {
                return this.delegate.selectRootElement(e, t)
            }
            parentNode(e) {
                return this.delegate.parentNode(e)
            }
            nextSibling(e) {
                return this.delegate.nextSibling(e)
            }
            setAttribute(e, t, n, r) {
                this.delegate.setAttribute(e, t, n, r)
            }
            removeAttribute(e, t, n) {
                this.delegate.removeAttribute(e, t, n)
            }
            addClass(e, t) {
                this.delegate.addClass(e, t)
            }
            removeClass(e, t) {
                this.delegate.removeClass(e, t)
            }
            setStyle(e, t, n, r) {
                this.delegate.setStyle(e, t, n, r)
            }
            removeStyle(e, t, n) {
                this.delegate.removeStyle(e, t, n)
            }
            setProperty(e, t, n) {
                t.charAt(0) == u && t == h ? this.disableAnimations(e, !!n) : this.delegate.setProperty(e, t, n)
            }
            setValue(e, t) {
                this.delegate.setValue(e, t)
            }
            listen(e, t, n) {
                return this.delegate.listen(e, t, n)
            }
            disableAnimations(e, t) {
                this.engine.disableAnimations(e, t)
            }
        }
        class p extends f {
            constructor(e, t, n, r) {
                super(t, n, r),
                this.factory = e,
                this.namespaceId = t
            }
            setProperty(e, t, n) {
                t.charAt(0) == u ? "." == t.charAt(1) && t == h ? this.disableAnimations(e, n = void 0 === n || !!n) : this.engine.process(this.namespaceId, e, t.substr(1), n) : this.delegate.setProperty(e, t, n)
            }
            listen(e, t, n) {
                if (t.charAt(0) == u) {
                    const r = function(e) {
                        switch (e) {
                        case "body":
                            return document.body;
                        case "document":
                            return document;
                        case "window":
                            return window;
                        default:
                            return e
                        }
                    }(e);
                    let s = t.substr(1)
                      , i = "";
                    return s.charAt(0) != u && ([s,i] = function(e) {
                        const t = e.indexOf(".");
                        return [e.substring(0, t), e.substr(t + 1)]
                    }(s)),
                    this.engine.listen(this.namespaceId, r, s, i, e => {
                        this.factory.scheduleListenerCallback(e._data || -1, n, e)
                    }
                    )
                }
                return this.delegate.listen(e, t, n)
            }
        }
        class m extends i.b {
            constructor(e, t, n) {
                super(e.body, t, n)
            }
        }
        function g() {
            return Object(i.h)() ? new i.f : new i.d
        }
        function b() {
            return new i.g
        }
        function y(e, t, n) {
            return new d(e,t,n)
        }
        const v = new r.p("AnimationModuleType");
        class _ {
        }
    },
    pJnZ: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        var r = function(e) {
            return e.PageNotFound = "page-not-found",
            e.OperationOutside = "operation-outside",
            e.Maintenance = "maintenance",
            e
        }({})
    },
    pLZG: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("7o/Q");
        function s(e, t) {
            return function(n) {
                return n.lift(new i(e,t))
            }
        }
        class i {
            constructor(e, t) {
                this.predicate = e,
                this.thisArg = t
            }
            call(e, t) {
                return t.subscribe(new o(e,this.predicate,this.thisArg))
            }
        }
        class o extends r.a {
            constructor(e, t, n) {
                super(e),
                this.predicate = t,
                this.thisArg = n,
                this.count = 0
            }
            _next(e) {
                let t;
                try {
                    t = this.predicate.call(this.thisArg, e, this.count++)
                } catch (n) {
                    return void this.destination.error(n)
                }
                t && this.destination.next(e)
            }
        }
    },
    pLzU: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("Lhse");
        const s = e => t => {
            const n = e[r.a]();
            for (; ; ) {
                const e = n.next();
                if (e.done) {
                    t.complete();
                    break
                }
                if (t.next(e.value),
                t.closed)
                    break
            }
            return "function" == typeof n.return && t.add( () => {
                n.return && n.return()
            }
            ),
            t
        }
    },
    pMnS: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return c
        });
        var r = n("8Y7J")
          , s = n("iInd")
          , i = r.qb({
            encapsulation: 2,
            styles: [],
            data: {}
        });
        function o(e) {
            return r.Mb(0, [(e()(),
            r.sb(0, 16777216, null, null, 1, "router-outlet", [], null, null, null, null, null)), r.rb(1, 212992, null, 0, s.n, [s.b, r.O, r.j, [8, null], r.h], null, null)], function(e, t) {
                e(t, 1, 0)
            }, null)
        }
        function a(e) {
            return r.Mb(0, [(e()(),
            r.sb(0, 0, null, null, 1, "ng-component", [], null, null, null, o, i)), r.rb(1, 49152, null, 0, s.B, [], null, null)], null, null)
        }
        var c = r.ob("ng-component", s.B, a, {}, {}, [])
    },
    pxpQ: function(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return i
        }),
        n.d(t, "a", function() {
            return a
        });
        var r = n("7o/Q")
          , s = n("WMd4");
        function i(e, t=0) {
            return function(n) {
                return n.lift(new o(e,t))
            }
        }
        class o {
            constructor(e, t=0) {
                this.scheduler = e,
                this.delay = t
            }
            call(e, t) {
                return t.subscribe(new a(e,this.scheduler,this.delay))
            }
        }
        class a extends r.a {
            constructor(e, t, n=0) {
                super(e),
                this.scheduler = t,
                this.delay = n
            }
            static dispatch(e) {
                const {notification: t, destination: n} = e;
                t.observe(n),
                this.unsubscribe()
            }
            scheduleMessage(e) {
                this.destination.add(this.scheduler.schedule(a.dispatch, this.delay, new c(e,this.destination)))
            }
            _next(e) {
                this.scheduleMessage(s.a.createNext(e))
            }
            _error(e) {
                this.scheduleMessage(s.a.createError(e)),
                this.unsubscribe()
            }
            _complete() {
                this.scheduleMessage(s.a.createComplete()),
                this.unsubscribe()
            }
        }
        class c {
            constructor(e, t) {
                this.notification = e,
                this.destination = t
            }
        }
    },
    "qU/y": function(e, t, n) {
        "use strict";
        var r = n("wUVa")
          , s = n("XNiG");
        let i = 0;
        class o {
            constructor(e, t=`dialog-${i++}`) {
                this.dialog = e,
                this.id = t,
                this.closable = new s.a,
                this.backdropClickable = new s.a,
                this._afterClosed = new s.a,
                this._subscriptions = [],
                this.init(t)
            }
            get dialogId() {
                return this.id
            }
            close(e) {
                for (this._afterClosed.next(e),
                this._afterClosed.complete(),
                this.component.destroy(),
                this.component = null,
                this.dialog.destroy(),
                this.dialog = null; this._subscriptions.length > 0; )
                    this._subscriptions.pop().unsubscribe()
            }
            afterClosed() {
                return this._afterClosed.asObservable()
            }
            init(e) {
                this.dialog.instance.id = e;
                const t = this.dialog.instance.close.subscribe( () => {
                    t.unsubscribe(),
                    this.close()
                }
                );
                this._subscriptions.push(this.closable.subscribe(e => this.dialog.instance.closable = e)),
                this._subscriptions.push(this.backdropClickable.subscribe(e => this.dialog.instance.backdropClickable = e))
            }
        }
        n.d(t, "a", function() {
            return a
        });
        let a = ( () => {
            class e {
                constructor(e) {
                    this.resolver = e
                }
                set $dialogContainer(t) {
                    e.dialogContainer || (e.dialogContainer = t)
                }
                open(t, n) {
                    if (!e.dialogContainer)
                        throw new Error("Can not open before initialize app-dialog-container.");
                    const r = this.attachDialogContent(t, n);
                    return e.openDialogs.push(r),
                    r.afterClosed().subscribe( () => this.removeOpenDialog(r)),
                    r
                }
                close(t, n) {
                    const r = e.openDialogs.find(e => e.dialogId === t);
                    r && r.close(n)
                }
                closeAll() {
                    const t = e.openDialogs;
                    if (t.length > 0) {
                        const e = t.concat();
                        for (let t = e.length - 1; t >= 0; t--)
                            e[t].close()
                    }
                }
                attachDialogContent(t, n) {
                    const s = this.resolver.resolveComponentFactory(r.a)
                      , i = e.dialogContainer.createComponent(s)
                      , a = new o(i)
                      , c = i.instance.afterInit.subscribe(e => {
                        c.unsubscribe();
                        const r = this.resolver.resolveComponentFactory(t)
                          , s = e.createComponent(r);
                        s.instance.dialogRef = a,
                        s.instance.params = n,
                        a.component = s
                    }
                    );
                    return a
                }
                removeOpenDialog(t) {
                    const n = e.openDialogs.indexOf(t);
                    t.component.instance.dialogRef = null,
                    t.component.instance.params = null,
                    n > -1 && (e.dialogContainer.remove(n),
                    e.openDialogs.splice(n, 1))
                }
            }
            return e.openDialogs = [],
            e
        }
        )()
    },
    qgXg: function(e, t, n) {
        "use strict";
        var r = n("3N8a");
        class s extends r.a {
            constructor(e, t) {
                super(e, t),
                this.scheduler = e,
                this.work = t
            }
            schedule(e, t=0) {
                return t > 0 ? super.schedule(e, t) : (this.delay = t,
                this.state = e,
                this.scheduler.flush(this),
                this)
            }
            execute(e, t) {
                return t > 0 || this.closed ? super.execute(e, t) : this._execute(e, t)
            }
            requestAsyncId(e, t, n=0) {
                return null !== n && n > 0 || null === n && this.delay > 0 ? super.requestAsyncId(e, t, n) : e.flush(this)
            }
        }
        var i = n("IjjT");
        class o extends i.a {
        }
        n.d(t, "a", function() {
            return a
        });
        const a = new o(s)
    },
    quSY: function(e, t, n) {
        "use strict";
        var r = n("DH7j")
          , s = n("XoHu")
          , i = n("n6bG");
        function o(e) {
            return Error.call(this),
            this.message = e ? `${e.length} errors occurred during unsubscription:\n${e.map( (e, t) => `${t + 1}) ${e.toString()}`).join("\n  ")}` : "",
            this.name = "UnsubscriptionError",
            this.errors = e,
            this
        }
        o.prototype = Object.create(Error.prototype);
        const a = o;
        n.d(t, "a", function() {
            return c
        });
        let c = ( () => {
            class e {
                constructor(e) {
                    this.closed = !1,
                    this._parent = null,
                    this._parents = null,
                    this._subscriptions = null,
                    e && (this._unsubscribe = e)
                }
                unsubscribe() {
                    let e, t = !1;
                    if (this.closed)
                        return;
                    let {_parent: n, _parents: o, _unsubscribe: c, _subscriptions: u} = this;
                    this.closed = !0,
                    this._parent = null,
                    this._parents = null,
                    this._subscriptions = null;
                    let h = -1
                      , d = o ? o.length : 0;
                    for (; n; )
                        n.remove(this),
                        n = ++h < d && o[h] || null;
                    if (Object(i.a)(c))
                        try {
                            c.call(this)
                        } catch (f) {
                            t = !0,
                            e = f instanceof a ? l(f.errors) : [f]
                        }
                    if (Object(r.a)(u))
                        for (h = -1,
                        d = u.length; ++h < d; ) {
                            const n = u[h];
                            if (Object(s.a)(n))
                                try {
                                    n.unsubscribe()
                                } catch (f) {
                                    t = !0,
                                    e = e || [],
                                    f instanceof a ? e = e.concat(l(f.errors)) : e.push(f)
                                }
                        }
                    if (t)
                        throw new a(e)
                }
                add(t) {
                    let n = t;
                    switch (typeof t) {
                    case "function":
                        n = new e(t);
                    case "object":
                        if (n === this || n.closed || "function" != typeof n.unsubscribe)
                            return n;
                        if (this.closed)
                            return n.unsubscribe(),
                            n;
                        if (!(n instanceof e)) {
                            const t = n;
                            (n = new e)._subscriptions = [t]
                        }
                        break;
                    default:
                        if (!t)
                            return e.EMPTY;
                        throw new Error("unrecognized teardown " + t + " added to Subscription.")
                    }
                    if (n._addParent(this)) {
                        const e = this._subscriptions;
                        e ? e.push(n) : this._subscriptions = [n]
                    }
                    return n
                }
                remove(e) {
                    const t = this._subscriptions;
                    if (t) {
                        const n = t.indexOf(e);
                        -1 !== n && t.splice(n, 1)
                    }
                }
                _addParent(e) {
                    let {_parent: t, _parents: n} = this;
                    return t !== e && (t ? n ? -1 === n.indexOf(e) && (n.push(e),
                    !0) : (this._parents = [e],
                    !0) : (this._parent = e,
                    !0))
                }
            }
            return e.EMPTY = function(e) {
                return e.closed = !0,
                e
            }(new e),
            e
        }
        )();
        function l(e) {
            return e.reduce( (e, t) => e.concat(t instanceof a ? t.errors : t), [])
        }
    },
    ukeZ: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return c
        });
        var r = n("IheW")
          , s = n("wAL0")
          , i = n("pJnZ")
          , o = n("PJcQ")
          , a = n("8Y7J");
        let c = ( () => {
            class e {
                constructor() {}
                setConfig(e) {
                    e && (this.config = e)
                }
                check(e) {
                    if (!this.config)
                        return null;
                    const t = o.a.convertServerTime(e.headers.get("Date"))
                      , n = this.config.maintenance;
                    return false ? new r.f({
                        status: s.b.SERVER_TIME_ERROR,
                        headers: e.headers,
                        error: i.a.Maintenance
                    }) : null
                }
            }
            return e.ngInjectableDef = a.Qb({
                factory: function() {
                    return new e
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )()
    },
    veZf: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        });
        class r {
        }
    },
    vkgz: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o
        });
        var r = n("7o/Q")
          , s = n("KqfI")
          , i = n("n6bG");
        function o(e, t, n) {
            return function(r) {
                return r.lift(new a(e,t,n))
            }
        }
        class a {
            constructor(e, t, n) {
                this.nextOrObserver = e,
                this.error = t,
                this.complete = n
            }
            call(e, t) {
                return t.subscribe(new c(e,this.nextOrObserver,this.error,this.complete))
            }
        }
        class c extends r.a {
            constructor(e, t, n, r) {
                super(e),
                this._tapNext = s.a,
                this._tapError = s.a,
                this._tapComplete = s.a,
                this._tapError = n || s.a,
                this._tapComplete = r || s.a,
                Object(i.a)(t) ? (this._context = this,
                this._tapNext = t) : t && (this._context = t,
                this._tapNext = t.next || s.a,
                this._tapError = t.error || s.a,
                this._tapComplete = t.complete || s.a)
            }
            _next(e) {
                try {
                    this._tapNext.call(this._context, e)
                } catch (t) {
                    return void this.destination.error(t)
                }
                this.destination.next(e)
            }
            _error(e) {
                try {
                    this._tapError.call(this._context, e)
                } catch (e) {
                    return void this.destination.error(e)
                }
                this.destination.error(e)
            }
            _complete() {
                try {
                    this._tapComplete.call(this._context)
                } catch (e) {
                    return void this.destination.error(e)
                }
                return this.destination.complete()
            }
        }
    },
    wAL0: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return r
        }),
        n.d(t, "b", function() {
            return s
        });
        const r = {
            CONTENT_TYPE: "Content-Type",
            CACHE_CONTROL: "Cache-Control",
            AUTHORIZATION: "Authorization",
            X_REQUESTED_WITH: "X-Requested-With"
        }
          , s = {
            OK: 200,
            MULTIPLE_CHOICES: 300,
            BAD_REQUEST: 400,
            UNAUTHORIZED: 401,
            FORBIDDEN: 403,
            NOT_FOUND: 404,
            CONFLICT: 409,
            INTERNAL_SERVER_ERROR: 500,
            SERVICE_UNAVAILABLE: 503,
            DISCONNECT_NETWORK: 0,
            SERVER_TIME_ERROR: NaN
        }
    },
    wUVa: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return a
        });
        var r = n("8Y7J")
          , s = n("XNiG")
          , i = n("gJmp")
          , o = n("PJcQ");
        class a extends i.a {
            constructor(e, t, n, i) {
                super(),
                this.elRef = e,
                this.rd = t,
                this.zone = n,
                this.focusTrapFactory = i,
                this.close = new r.m,
                this.closable = !0,
                this.backdropClickable = !0,
                this._afterInit = new s.a,
                this._afterOpened = new s.a
            }
            ngOnInit() {
                this.zone.runOutsideAngular( () => {
                    this._removeEscKeyListener = this.rd.listen("document", "keyup.esc", this.onKeyupEscape.bind(this))
                }
                ),
                this._afterInit.next(this.container),
                this._afterInit.complete()
            }
            ngAfterViewInit() {
                super.ngAfterViewInit();
                const e = this.elRef.nativeElement;
                e.id = this.id,
                this.trapFocus(),
                window.setTimeout( () => {
                    this.trapBackdrop();
                    const t = o.a.addHandler(e.firstElementChild, "transitionend", () => {
                        t(),
                        this._afterOpened.next(),
                        this._afterOpened.complete()
                    }
                    );
                    this.rd.addClass(e, "show")
                }
                , 50)
            }
            ngOnDestroy() {
                this._removeEscKeyListener && (this._removeEscKeyListener(),
                this._removeEscKeyListener = void 0),
                this._focusTrap && (this._focusTrap.destroy(),
                this._focusTrap = void 0)
            }
            get afterInit() {
                return this._afterInit
            }
            get afterOpened() {
                return this._afterOpened
            }
            onKeyupEscape() {
                if (!this.closable || !this.id)
                    return;
                const e = this.elRef.nativeElement.parentElement;
                e && e.querySelector("app-dialog:last-of-type").id === this.id && this.zone.run( () => this.close.emit())
            }
            trapBackdrop() {
                this.backdropClickable && this.zone.runOutsideAngular( () => {
                    const e = this.elRef.nativeElement;
                    this.removeEventListeners.push(this.rd.listen(e, "click", () => {
                        this.zone.run( () => this.close.emit())
                    }
                    )),
                    this.removeEventListeners.push(this.rd.listen(e.firstElementChild, "click", e => {
                        e.stopPropagation()
                    }
                    ))
                }
                )
            }
            trapFocus() {
                this._focusTrap = this.focusTrapFactory.create(this.elRef.nativeElement),
                this._focusTrap.focusInitialElementWhenReady()
            }
        }
    },
    yCtX: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return o
        });
        var r = n("HDdC")
          , s = n("quSY")
          , i = n("ngJS");
        function o(e, t) {
            return new r.a(t ? n => {
                const r = new s.a;
                let i = 0;
                return r.add(t.schedule(function() {
                    i !== e.length ? (n.next(e[i++]),
                    n.closed || r.add(this.schedule())) : n.complete()
                })),
                r
            }
            : Object(i.a)(e))
        }
    },
    yLV6: function(e, t, n) {
        var r;
        !function(s, i, o, a) {
            "use strict";
            var c, l = ["", "webkit", "Moz", "MS", "ms", "o"], u = i.createElement("div"), h = "function", d = Math.round, f = Math.abs, p = Date.now;
            function m(e, t, n) {
                return setTimeout(E(e, n), t)
            }
            function g(e, t, n) {
                return !!Array.isArray(e) && (b(e, n[t], n),
                !0)
            }
            function b(e, t, n) {
                var r;
                if (e)
                    if (e.forEach)
                        e.forEach(t, n);
                    else if (e.length !== a)
                        for (r = 0; r < e.length; )
                            t.call(n, e[r], r, e),
                            r++;
                    else
                        for (r in e)
                            e.hasOwnProperty(r) && t.call(n, e[r], r, e)
            }
            function y(e, t, n) {
                var r = "DEPRECATED METHOD: " + t + "\n" + n + " AT \n";
                return function() {
                    var t = new Error("get-stack-trace")
                      , n = t && t.stack ? t.stack.replace(/^[^\(]+?[\n$]/gm, "").replace(/^\s+at\s+/gm, "").replace(/^Object.<anonymous>\s*\(/gm, "{anonymous}()@") : "Unknown Stack Trace"
                      , i = s.console && (s.console.warn || s.console.log);
                    return i && i.call(s.console, r, n),
                    e.apply(this, arguments)
                }
            }
            c = "function" != typeof Object.assign ? function(e) {
                if (e === a || null === e)
                    throw new TypeError("Cannot convert undefined or null to object");
                for (var t = Object(e), n = 1; n < arguments.length; n++) {
                    var r = arguments[n];
                    if (r !== a && null !== r)
                        for (var s in r)
                            r.hasOwnProperty(s) && (t[s] = r[s])
                }
                return t
            }
            : Object.assign;
            var v = y(function(e, t, n) {
                for (var r = Object.keys(t), s = 0; s < r.length; )
                    (!n || n && e[r[s]] === a) && (e[r[s]] = t[r[s]]),
                    s++;
                return e
            }, "extend", "Use `assign`.")
              , _ = y(function(e, t) {
                return v(e, t, !0)
            }, "merge", "Use `assign`.");
            function w(e, t, n) {
                var r, s = t.prototype;
                (r = e.prototype = Object.create(s)).constructor = e,
                r._super = s,
                n && c(r, n)
            }
            function E(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            }
            function S(e, t) {
                return typeof e == h ? e.apply(t && t[0] || a, t) : e
            }
            function C(e, t) {
                return e === a ? t : e
            }
            function T(e, t, n) {
                b(I(t), function(t) {
                    e.addEventListener(t, n, !1)
                })
            }
            function x(e, t, n) {
                b(I(t), function(t) {
                    e.removeEventListener(t, n, !1)
                })
            }
            function k(e, t) {
                for (; e; ) {
                    if (e == t)
                        return !0;
                    e = e.parentNode
                }
                return !1
            }
            function O(e, t) {
                return e.indexOf(t) > -1
            }
            function I(e) {
                return e.trim().split(/\s+/g)
            }
            function A(e, t, n) {
                if (e.indexOf && !n)
                    return e.indexOf(t);
                for (var r = 0; r < e.length; ) {
                    if (n && e[r][n] == t || !n && e[r] === t)
                        return r;
                    r++
                }
                return -1
            }
            function D(e) {
                return Array.prototype.slice.call(e, 0)
            }
            function R(e, t, n) {
                for (var r = [], s = [], i = 0; i < e.length; ) {
                    var o = t ? e[i][t] : e[i];
                    A(s, o) < 0 && r.push(e[i]),
                    s[i] = o,
                    i++
                }
                return n && (r = t ? r.sort(function(e, n) {
                    return e[t] > n[t]
                }) : r.sort()),
                r
            }
            function j(e, t) {
                for (var n, r, s = t[0].toUpperCase() + t.slice(1), i = 0; i < l.length; ) {
                    if ((r = (n = l[i]) ? n + s : t)in e)
                        return r;
                    i++
                }
                return a
            }
            var N = 1;
            function P(e) {
                var t = e.ownerDocument || e;
                return t.defaultView || t.parentWindow || s
            }
            var M = "ontouchstart"in s
              , L = j(s, "PointerEvent") !== a
              , F = M && /mobile|tablet|ip(ad|hone|od)|android/i.test(navigator.userAgent)
              , U = 25
              , z = 1
              , H = 4
              , B = 8
              , V = 1
              , $ = 2
              , q = 4
              , Q = 8
              , G = 16
              , K = $ | q
              , W = Q | G
              , Z = K | W
              , Y = ["x", "y"]
              , J = ["clientX", "clientY"];
            function X(e, t) {
                var n = this;
                this.manager = e,
                this.callback = t,
                this.element = e.element,
                this.target = e.options.inputTarget,
                this.domHandler = function(t) {
                    S(e.options.enable, [e]) && n.handler(t)
                }
                ,
                this.init()
            }
            function ee(e, t, n) {
                var r = n.pointers.length
                  , s = n.changedPointers.length
                  , i = t & z && r - s == 0
                  , o = t & (H | B) && r - s == 0;
                n.isFirst = !!i,
                n.isFinal = !!o,
                i && (e.session = {}),
                n.eventType = t,
                function(e, t) {
                    var n = e.session
                      , r = t.pointers
                      , s = r.length;
                    n.firstInput || (n.firstInput = te(t)),
                    s > 1 && !n.firstMultiple ? n.firstMultiple = te(t) : 1 === s && (n.firstMultiple = !1);
                    var i = n.firstInput
                      , o = n.firstMultiple
                      , c = o ? o.center : i.center
                      , l = t.center = ne(r);
                    t.timeStamp = p(),
                    t.deltaTime = t.timeStamp - i.timeStamp,
                    t.angle = oe(c, l),
                    t.distance = ie(c, l),
                    function(e, t) {
                        var n = t.center
                          , r = e.offsetDelta || {}
                          , s = e.prevDelta || {}
                          , i = e.prevInput || {};
                        t.eventType !== z && i.eventType !== H || (s = e.prevDelta = {
                            x: i.deltaX || 0,
                            y: i.deltaY || 0
                        },
                        r = e.offsetDelta = {
                            x: n.x,
                            y: n.y
                        }),
                        t.deltaX = s.x + (n.x - r.x),
                        t.deltaY = s.y + (n.y - r.y)
                    }(n, t),
                    t.offsetDirection = se(t.deltaX, t.deltaY);
                    var u, h, d = re(t.deltaTime, t.deltaX, t.deltaY);
                    t.overallVelocityX = d.x,
                    t.overallVelocityY = d.y,
                    t.overallVelocity = f(d.x) > f(d.y) ? d.x : d.y,
                    t.scale = o ? (u = o.pointers,
                    ie((h = r)[0], h[1], J) / ie(u[0], u[1], J)) : 1,
                    t.rotation = o ? function(e, t) {
                        return oe(r[1], r[0], J) + oe(e[1], e[0], J)
                    }(o.pointers) : 0,
                    t.maxPointers = n.prevInput ? t.pointers.length > n.prevInput.maxPointers ? t.pointers.length : n.prevInput.maxPointers : t.pointers.length,
                    function(e, t) {
                        var n, r, s, i, o = e.lastInterval || t, c = t.timeStamp - o.timeStamp;
                        if (t.eventType != B && (c > U || o.velocity === a)) {
                            var l = t.deltaX - o.deltaX
                              , u = t.deltaY - o.deltaY
                              , h = re(c, l, u);
                            r = h.x,
                            s = h.y,
                            n = f(h.x) > f(h.y) ? h.x : h.y,
                            i = se(l, u),
                            e.lastInterval = t
                        } else
                            n = o.velocity,
                            r = o.velocityX,
                            s = o.velocityY,
                            i = o.direction;
                        t.velocity = n,
                        t.velocityX = r,
                        t.velocityY = s,
                        t.direction = i
                    }(n, t);
                    var m = e.element;
                    k(t.srcEvent.target, m) && (m = t.srcEvent.target),
                    t.target = m
                }(e, n),
                e.emit("hammer.input", n),
                e.recognize(n),
                e.session.prevInput = n
            }
            function te(e) {
                for (var t = [], n = 0; n < e.pointers.length; )
                    t[n] = {
                        clientX: d(e.pointers[n].clientX),
                        clientY: d(e.pointers[n].clientY)
                    },
                    n++;
                return {
                    timeStamp: p(),
                    pointers: t,
                    center: ne(t),
                    deltaX: e.deltaX,
                    deltaY: e.deltaY
                }
            }
            function ne(e) {
                var t = e.length;
                if (1 === t)
                    return {
                        x: d(e[0].clientX),
                        y: d(e[0].clientY)
                    };
                for (var n = 0, r = 0, s = 0; s < t; )
                    n += e[s].clientX,
                    r += e[s].clientY,
                    s++;
                return {
                    x: d(n / t),
                    y: d(r / t)
                }
            }
            function re(e, t, n) {
                return {
                    x: t / e || 0,
                    y: n / e || 0
                }
            }
            function se(e, t) {
                return e === t ? V : f(e) >= f(t) ? e < 0 ? $ : q : t < 0 ? Q : G
            }
            function ie(e, t, n) {
                n || (n = Y);
                var r = t[n[0]] - e[n[0]]
                  , s = t[n[1]] - e[n[1]];
                return Math.sqrt(r * r + s * s)
            }
            function oe(e, t, n) {
                return n || (n = Y),
                180 * Math.atan2(t[n[1]] - e[n[1]], t[n[0]] - e[n[0]]) / Math.PI
            }
            X.prototype = {
                handler: function() {},
                init: function() {
                    this.evEl && T(this.element, this.evEl, this.domHandler),
                    this.evTarget && T(this.target, this.evTarget, this.domHandler),
                    this.evWin && T(P(this.element), this.evWin, this.domHandler)
                },
                destroy: function() {
                    this.evEl && x(this.element, this.evEl, this.domHandler),
                    this.evTarget && x(this.target, this.evTarget, this.domHandler),
                    this.evWin && x(P(this.element), this.evWin, this.domHandler)
                }
            };
            var ae = {
                mousedown: z,
                mousemove: 2,
                mouseup: H
            }
              , ce = "mousedown"
              , le = "mousemove mouseup";
            function ue() {
                this.evEl = ce,
                this.evWin = le,
                this.pressed = !1,
                X.apply(this, arguments)
            }
            w(ue, X, {
                handler: function(e) {
                    var t = ae[e.type];
                    t & z && 0 === e.button && (this.pressed = !0),
                    2 & t && 1 !== e.which && (t = H),
                    this.pressed && (t & H && (this.pressed = !1),
                    this.callback(this.manager, t, {
                        pointers: [e],
                        changedPointers: [e],
                        pointerType: "mouse",
                        srcEvent: e
                    }))
                }
            });
            var he = {
                pointerdown: z,
                pointermove: 2,
                pointerup: H,
                pointercancel: B,
                pointerout: B
            }
              , de = {
                2: "touch",
                3: "pen",
                4: "mouse",
                5: "kinect"
            }
              , fe = "pointerdown"
              , pe = "pointermove pointerup pointercancel";
            function me() {
                this.evEl = fe,
                this.evWin = pe,
                X.apply(this, arguments),
                this.store = this.manager.session.pointerEvents = []
            }
            s.MSPointerEvent && !s.PointerEvent && (fe = "MSPointerDown",
            pe = "MSPointerMove MSPointerUp MSPointerCancel"),
            w(me, X, {
                handler: function(e) {
                    var t = this.store
                      , n = !1
                      , r = e.type.toLowerCase().replace("ms", "")
                      , s = he[r]
                      , i = de[e.pointerType] || e.pointerType
                      , o = "touch" == i
                      , a = A(t, e.pointerId, "pointerId");
                    s & z && (0 === e.button || o) ? a < 0 && (t.push(e),
                    a = t.length - 1) : s & (H | B) && (n = !0),
                    a < 0 || (t[a] = e,
                    this.callback(this.manager, s, {
                        pointers: t,
                        changedPointers: [e],
                        pointerType: i,
                        srcEvent: e
                    }),
                    n && t.splice(a, 1))
                }
            });
            var ge = {
                touchstart: z,
                touchmove: 2,
                touchend: H,
                touchcancel: B
            }
              , be = "touchstart"
              , ye = "touchstart touchmove touchend touchcancel";
            function ve() {
                this.evTarget = be,
                this.evWin = ye,
                this.started = !1,
                X.apply(this, arguments)
            }
            w(ve, X, {
                handler: function(e) {
                    var t = ge[e.type];
                    if (t === z && (this.started = !0),
                    this.started) {
                        var n = (function(e, t) {
                            var n = D(e.touches)
                              , r = D(e.changedTouches);
                            return t & (H | B) && (n = R(n.concat(r), "identifier", !0)),
                            [n, r]
                        }
                        ).call(this, e, t);
                        t & (H | B) && n[0].length - n[1].length == 0 && (this.started = !1),
                        this.callback(this.manager, t, {
                            pointers: n[0],
                            changedPointers: n[1],
                            pointerType: "touch",
                            srcEvent: e
                        })
                    }
                }
            });
            var _e = {
                touchstart: z,
                touchmove: 2,
                touchend: H,
                touchcancel: B
            }
              , we = "touchstart touchmove touchend touchcancel";
            function Ee() {
                this.evTarget = we,
                this.targetIds = {},
                X.apply(this, arguments)
            }
            w(Ee, X, {
                handler: function(e) {
                    var t = _e[e.type]
                      , n = (function(e, t) {
                        var n = D(e.touches)
                          , r = this.targetIds;
                        if (t & (2 | z) && 1 === n.length)
                            return r[n[0].identifier] = !0,
                            [n, n];
                        var s, i, o = D(e.changedTouches), a = [], c = this.target;
                        if (i = n.filter(function(e) {
                            return k(e.target, c)
                        }),
                        t === z)
                            for (s = 0; s < i.length; )
                                r[i[s].identifier] = !0,
                                s++;
                        for (s = 0; s < o.length; )
                            r[o[s].identifier] && a.push(o[s]),
                            t & (H | B) && delete r[o[s].identifier],
                            s++;
                        return a.length ? [R(i.concat(a), "identifier", !0), a] : void 0
                    }
                    ).call(this, e, t);
                    n && this.callback(this.manager, t, {
                        pointers: n[0],
                        changedPointers: n[1],
                        pointerType: "touch",
                        srcEvent: e
                    })
                }
            });
            var Se = 2500;
            function Ce() {
                X.apply(this, arguments);
                var e = E(this.handler, this);
                this.touch = new Ee(this.manager,e),
                this.mouse = new ue(this.manager,e),
                this.primaryTouch = null,
                this.lastTouches = []
            }
            function Te(e) {
                var t = e.changedPointers[0];
                if (t.identifier === this.primaryTouch) {
                    var n = {
                        x: t.clientX,
                        y: t.clientY
                    };
                    this.lastTouches.push(n);
                    var r = this.lastTouches;
                    setTimeout(function() {
                        var e = r.indexOf(n);
                        e > -1 && r.splice(e, 1)
                    }, Se)
                }
            }
            w(Ce, X, {
                handler: function(e, t, n) {
                    var r = "mouse" == n.pointerType;
                    if (!(r && n.sourceCapabilities && n.sourceCapabilities.firesTouchEvents)) {
                        if ("touch" == n.pointerType)
                            (function(e, t) {
                                e & z ? (this.primaryTouch = t.changedPointers[0].identifier,
                                Te.call(this, t)) : e & (H | B) && Te.call(this, t)
                            }
                            ).call(this, t, n);
                        else if (r && (function(e) {
                            for (var t = e.srcEvent.clientX, n = e.srcEvent.clientY, r = 0; r < this.lastTouches.length; r++) {
                                var s = this.lastTouches[r]
                                  , i = Math.abs(t - s.x)
                                  , o = Math.abs(n - s.y);
                                if (i <= 25 && o <= 25)
                                    return !0
                            }
                            return !1
                        }
                        ).call(this, n))
                            return;
                        this.callback(e, t, n)
                    }
                },
                destroy: function() {
                    this.touch.destroy(),
                    this.mouse.destroy()
                }
            });
            var xe = j(u.style, "touchAction")
              , ke = xe !== a
              , Oe = function() {
                if (!ke)
                    return !1;
                var e = {}
                  , t = s.CSS && s.CSS.supports;
                return ["auto", "manipulation", "pan-y", "pan-x", "pan-x pan-y", "none"].forEach(function(n) {
                    e[n] = !t || s.CSS.supports("touch-action", n)
                }),
                e
            }();
            function Ie(e, t) {
                this.manager = e,
                this.set(t)
            }
            Ie.prototype = {
                set: function(e) {
                    "compute" == e && (e = this.compute()),
                    ke && this.manager.element.style && Oe[e] && (this.manager.element.style[xe] = e),
                    this.actions = e.toLowerCase().trim()
                },
                update: function() {
                    this.set(this.manager.options.touchAction)
                },
                compute: function() {
                    var e = [];
                    return b(this.manager.recognizers, function(t) {
                        S(t.options.enable, [t]) && (e = e.concat(t.getTouchAction()))
                    }),
                    function(e) {
                        if (O(e, "none"))
                            return "none";
                        var t = O(e, "pan-x")
                          , n = O(e, "pan-y");
                        return t && n ? "none" : t || n ? t ? "pan-x" : "pan-y" : O(e, "manipulation") ? "manipulation" : "auto"
                    }(e.join(" "))
                },
                preventDefaults: function(e) {
                    var t = e.srcEvent
                      , n = e.offsetDirection;
                    if (this.manager.session.prevented)
                        t.preventDefault();
                    else {
                        var r = this.actions
                          , s = O(r, "none") && !Oe.none
                          , i = O(r, "pan-y") && !Oe["pan-y"]
                          , o = O(r, "pan-x") && !Oe["pan-x"];
                        if (s && 1 === e.pointers.length && e.distance < 2 && e.deltaTime < 250)
                            return;
                        if (!o || !i)
                            return s || i && n & K || o && n & W ? this.preventSrc(t) : void 0
                    }
                },
                preventSrc: function(e) {
                    this.manager.session.prevented = !0,
                    e.preventDefault()
                }
            };
            var Ae = 1
              , De = 2
              , Re = 4
              , je = 8
              , Ne = je
              , Pe = 16;
            function Me(e) {
                this.options = c({}, this.defaults, e || {}),
                this.id = N++,
                this.manager = null,
                this.options.enable = C(this.options.enable, !0),
                this.state = Ae,
                this.simultaneous = {},
                this.requireFail = []
            }
            function Le(e) {
                return e & Pe ? "cancel" : e & je ? "end" : e & Re ? "move" : e & De ? "start" : ""
            }
            function Fe(e) {
                return e == G ? "down" : e == Q ? "up" : e == $ ? "left" : e == q ? "right" : ""
            }
            function Ue(e, t) {
                var n = t.manager;
                return n ? n.get(e) : e
            }
            function ze() {
                Me.apply(this, arguments)
            }
            function He() {
                ze.apply(this, arguments),
                this.pX = null,
                this.pY = null
            }
            function Be() {
                ze.apply(this, arguments)
            }
            function Ve() {
                Me.apply(this, arguments),
                this._timer = null,
                this._input = null
            }
            function $e() {
                ze.apply(this, arguments)
            }
            function qe() {
                ze.apply(this, arguments)
            }
            function Qe() {
                Me.apply(this, arguments),
                this.pTime = !1,
                this.pCenter = !1,
                this._timer = null,
                this._input = null,
                this.count = 0
            }
            function Ge(e, t) {
                return (t = t || {}).recognizers = C(t.recognizers, Ge.defaults.preset),
                new Ke(e,t)
            }
            function Ke(e, t) {
                var n;
                this.options = c({}, Ge.defaults, t || {}),
                this.options.inputTarget = this.options.inputTarget || e,
                this.handlers = {},
                this.session = {},
                this.recognizers = [],
                this.oldCssProps = {},
                this.element = e,
                this.input = new ((n = this).options.inputClass || (L ? me : F ? Ee : M ? Ce : ue))(n,ee),
                this.touchAction = new Ie(this,this.options.touchAction),
                We(this, !0),
                b(this.options.recognizers, function(e) {
                    var t = this.add(new e[0](e[1]));
                    e[2] && t.recognizeWith(e[2]),
                    e[3] && t.requireFailure(e[3])
                }, this)
            }
            function We(e, t) {
                var n, r = e.element;
                r.style && (b(e.options.cssProps, function(s, i) {
                    n = j(r.style, i),
                    t ? (e.oldCssProps[n] = r.style[n],
                    r.style[n] = s) : r.style[n] = e.oldCssProps[n] || ""
                }),
                t || (e.oldCssProps = {}))
            }
            Me.prototype = {
                defaults: {},
                set: function(e) {
                    return c(this.options, e),
                    this.manager && this.manager.touchAction.update(),
                    this
                },
                recognizeWith: function(e) {
                    if (g(e, "recognizeWith", this))
                        return this;
                    var t = this.simultaneous;
                    return t[(e = Ue(e, this)).id] || (t[e.id] = e,
                    e.recognizeWith(this)),
                    this
                },
                dropRecognizeWith: function(e) {
                    return g(e, "dropRecognizeWith", this) ? this : (e = Ue(e, this),
                    delete this.simultaneous[e.id],
                    this)
                },
                requireFailure: function(e) {
                    if (g(e, "requireFailure", this))
                        return this;
                    var t = this.requireFail;
                    return -1 === A(t, e = Ue(e, this)) && (t.push(e),
                    e.requireFailure(this)),
                    this
                },
                dropRequireFailure: function(e) {
                    if (g(e, "dropRequireFailure", this))
                        return this;
                    e = Ue(e, this);
                    var t = A(this.requireFail, e);
                    return t > -1 && this.requireFail.splice(t, 1),
                    this
                },
                hasRequireFailures: function() {
                    return this.requireFail.length > 0
                },
                canRecognizeWith: function(e) {
                    return !!this.simultaneous[e.id]
                },
                emit: function(e) {
                    var t = this
                      , n = this.state;
                    function r(n) {
                        t.manager.emit(n, e)
                    }
                    n < je && r(t.options.event + Le(n)),
                    r(t.options.event),
                    e.additionalEvent && r(e.additionalEvent),
                    n >= je && r(t.options.event + Le(n))
                },
                tryEmit: function(e) {
                    if (this.canEmit())
                        return this.emit(e);
                    this.state = 32
                },
                canEmit: function() {
                    for (var e = 0; e < this.requireFail.length; ) {
                        if (!(this.requireFail[e].state & (32 | Ae)))
                            return !1;
                        e++
                    }
                    return !0
                },
                recognize: function(e) {
                    var t = c({}, e);
                    if (!S(this.options.enable, [this, t]))
                        return this.reset(),
                        void (this.state = 32);
                    this.state & (Ne | Pe | 32) && (this.state = Ae),
                    this.state = this.process(t),
                    this.state & (De | Re | je | Pe) && this.tryEmit(t)
                },
                process: function(e) {},
                getTouchAction: function() {},
                reset: function() {}
            },
            w(ze, Me, {
                defaults: {
                    pointers: 1
                },
                attrTest: function(e) {
                    var t = this.options.pointers;
                    return 0 === t || e.pointers.length === t
                },
                process: function(e) {
                    var t = this.state
                      , n = e.eventType
                      , r = t & (De | Re)
                      , s = this.attrTest(e);
                    return r && (n & B || !s) ? t | Pe : r || s ? n & H ? t | je : t & De ? t | Re : De : 32
                }
            }),
            w(He, ze, {
                defaults: {
                    event: "pan",
                    threshold: 10,
                    pointers: 1,
                    direction: Z
                },
                getTouchAction: function() {
                    var e = this.options.direction
                      , t = [];
                    return e & K && t.push("pan-y"),
                    e & W && t.push("pan-x"),
                    t
                },
                directionTest: function(e) {
                    var t = this.options
                      , n = !0
                      , r = e.distance
                      , s = e.direction
                      , i = e.deltaX
                      , o = e.deltaY;
                    return s & t.direction || (t.direction & K ? (s = 0 === i ? V : i < 0 ? $ : q,
                    n = i != this.pX,
                    r = Math.abs(e.deltaX)) : (s = 0 === o ? V : o < 0 ? Q : G,
                    n = o != this.pY,
                    r = Math.abs(e.deltaY))),
                    e.direction = s,
                    n && r > t.threshold && s & t.direction
                },
                attrTest: function(e) {
                    return ze.prototype.attrTest.call(this, e) && (this.state & De || !(this.state & De) && this.directionTest(e))
                },
                emit: function(e) {
                    this.pX = e.deltaX,
                    this.pY = e.deltaY;
                    var t = Fe(e.direction);
                    t && (e.additionalEvent = this.options.event + t),
                    this._super.emit.call(this, e)
                }
            }),
            w(Be, ze, {
                defaults: {
                    event: "pinch",
                    threshold: 0,
                    pointers: 2
                },
                getTouchAction: function() {
                    return ["none"]
                },
                attrTest: function(e) {
                    return this._super.attrTest.call(this, e) && (Math.abs(e.scale - 1) > this.options.threshold || this.state & De)
                },
                emit: function(e) {
                    1 !== e.scale && (e.additionalEvent = this.options.event + (e.scale < 1 ? "in" : "out")),
                    this._super.emit.call(this, e)
                }
            }),
            w(Ve, Me, {
                defaults: {
                    event: "press",
                    pointers: 1,
                    time: 251,
                    threshold: 9
                },
                getTouchAction: function() {
                    return ["auto"]
                },
                process: function(e) {
                    var t = this.options
                      , n = e.pointers.length === t.pointers
                      , r = e.distance < t.threshold
                      , s = e.deltaTime > t.time;
                    if (this._input = e,
                    !r || !n || e.eventType & (H | B) && !s)
                        this.reset();
                    else if (e.eventType & z)
                        this.reset(),
                        this._timer = m(function() {
                            this.state = Ne,
                            this.tryEmit()
                        }, t.time, this);
                    else if (e.eventType & H)
                        return Ne;
                    return 32
                },
                reset: function() {
                    clearTimeout(this._timer)
                },
                emit: function(e) {
                    this.state === Ne && (e && e.eventType & H ? this.manager.emit(this.options.event + "up", e) : (this._input.timeStamp = p(),
                    this.manager.emit(this.options.event, this._input)))
                }
            }),
            w($e, ze, {
                defaults: {
                    event: "rotate",
                    threshold: 0,
                    pointers: 2
                },
                getTouchAction: function() {
                    return ["none"]
                },
                attrTest: function(e) {
                    return this._super.attrTest.call(this, e) && (Math.abs(e.rotation) > this.options.threshold || this.state & De)
                }
            }),
            w(qe, ze, {
                defaults: {
                    event: "swipe",
                    threshold: 10,
                    velocity: .3,
                    direction: K | W,
                    pointers: 1
                },
                getTouchAction: function() {
                    return He.prototype.getTouchAction.call(this)
                },
                attrTest: function(e) {
                    var t, n = this.options.direction;
                    return n & (K | W) ? t = e.overallVelocity : n & K ? t = e.overallVelocityX : n & W && (t = e.overallVelocityY),
                    this._super.attrTest.call(this, e) && n & e.offsetDirection && e.distance > this.options.threshold && e.maxPointers == this.options.pointers && f(t) > this.options.velocity && e.eventType & H
                },
                emit: function(e) {
                    var t = Fe(e.offsetDirection);
                    t && this.manager.emit(this.options.event + t, e),
                    this.manager.emit(this.options.event, e)
                }
            }),
            w(Qe, Me, {
                defaults: {
                    event: "tap",
                    pointers: 1,
                    taps: 1,
                    interval: 300,
                    time: 250,
                    threshold: 9,
                    posThreshold: 10
                },
                getTouchAction: function() {
                    return ["manipulation"]
                },
                process: function(e) {
                    var t = this.options
                      , n = e.pointers.length === t.pointers
                      , r = e.distance < t.threshold
                      , s = e.deltaTime < t.time;
                    if (this.reset(),
                    e.eventType & z && 0 === this.count)
                        return this.failTimeout();
                    if (r && s && n) {
                        if (e.eventType != H)
                            return this.failTimeout();
                        var i = !this.pTime || e.timeStamp - this.pTime < t.interval
                          , o = !this.pCenter || ie(this.pCenter, e.center) < t.posThreshold;
                        if (this.pTime = e.timeStamp,
                        this.pCenter = e.center,
                        o && i ? this.count += 1 : this.count = 1,
                        this._input = e,
                        0 == this.count % t.taps)
                            return this.hasRequireFailures() ? (this._timer = m(function() {
                                this.state = Ne,
                                this.tryEmit()
                            }, t.interval, this),
                            De) : Ne
                    }
                    return 32
                },
                failTimeout: function() {
                    return this._timer = m(function() {
                        this.state = 32
                    }, this.options.interval, this),
                    32
                },
                reset: function() {
                    clearTimeout(this._timer)
                },
                emit: function() {
                    this.state == Ne && (this._input.tapCount = this.count,
                    this.manager.emit(this.options.event, this._input))
                }
            }),
            Ge.VERSION = "2.0.7",
            Ge.defaults = {
                domEvents: !1,
                touchAction: "compute",
                enable: !0,
                inputTarget: null,
                inputClass: null,
                preset: [[$e, {
                    enable: !1
                }], [Be, {
                    enable: !1
                }, ["rotate"]], [qe, {
                    direction: K
                }], [He, {
                    direction: K
                }, ["swipe"]], [Qe], [Qe, {
                    event: "doubletap",
                    taps: 2
                }, ["tap"]], [Ve]],
                cssProps: {
                    userSelect: "none",
                    touchSelect: "none",
                    touchCallout: "none",
                    contentZooming: "none",
                    userDrag: "none",
                    tapHighlightColor: "rgba(0,0,0,0)"
                }
            },
            Ke.prototype = {
                set: function(e) {
                    return c(this.options, e),
                    e.touchAction && this.touchAction.update(),
                    e.inputTarget && (this.input.destroy(),
                    this.input.target = e.inputTarget,
                    this.input.init()),
                    this
                },
                stop: function(e) {
                    this.session.stopped = e ? 2 : 1
                },
                recognize: function(e) {
                    var t = this.session;
                    if (!t.stopped) {
                        var n;
                        this.touchAction.preventDefaults(e);
                        var r = this.recognizers
                          , s = t.curRecognizer;
                        (!s || s && s.state & Ne) && (s = t.curRecognizer = null);
                        for (var i = 0; i < r.length; )
                            n = r[i],
                            2 === t.stopped || s && n != s && !n.canRecognizeWith(s) ? n.reset() : n.recognize(e),
                            !s && n.state & (De | Re | je) && (s = t.curRecognizer = n),
                            i++
                    }
                },
                get: function(e) {
                    if (e instanceof Me)
                        return e;
                    for (var t = this.recognizers, n = 0; n < t.length; n++)
                        if (t[n].options.event == e)
                            return t[n];
                    return null
                },
                add: function(e) {
                    if (g(e, "add", this))
                        return this;
                    var t = this.get(e.options.event);
                    return t && this.remove(t),
                    this.recognizers.push(e),
                    e.manager = this,
                    this.touchAction.update(),
                    e
                },
                remove: function(e) {
                    if (g(e, "remove", this))
                        return this;
                    if (e = this.get(e)) {
                        var t = this.recognizers
                          , n = A(t, e);
                        -1 !== n && (t.splice(n, 1),
                        this.touchAction.update())
                    }
                    return this
                },
                on: function(e, t) {
                    if (e !== a && t !== a) {
                        var n = this.handlers;
                        return b(I(e), function(e) {
                            n[e] = n[e] || [],
                            n[e].push(t)
                        }),
                        this
                    }
                },
                off: function(e, t) {
                    if (e !== a) {
                        var n = this.handlers;
                        return b(I(e), function(e) {
                            t ? n[e] && n[e].splice(A(n[e], t), 1) : delete n[e]
                        }),
                        this
                    }
                },
                emit: function(e, t) {
                    this.options.domEvents && function(e, t) {
                        var n = i.createEvent("Event");
                        n.initEvent(e, !0, !0),
                        n.gesture = t,
                        t.target.dispatchEvent(n)
                    }(e, t);
                    var n = this.handlers[e] && this.handlers[e].slice();
                    if (n && n.length) {
                        t.type = e,
                        t.preventDefault = function() {
                            t.srcEvent.preventDefault()
                        }
                        ;
                        for (var r = 0; r < n.length; )
                            n[r](t),
                            r++
                    }
                },
                destroy: function() {
                    this.element && We(this, !1),
                    this.handlers = {},
                    this.session = {},
                    this.input.destroy(),
                    this.element = null
                }
            },
            c(Ge, {
                INPUT_START: z,
                INPUT_MOVE: 2,
                INPUT_END: H,
                INPUT_CANCEL: B,
                STATE_POSSIBLE: Ae,
                STATE_BEGAN: De,
                STATE_CHANGED: Re,
                STATE_ENDED: je,
                STATE_RECOGNIZED: Ne,
                STATE_CANCELLED: Pe,
                STATE_FAILED: 32,
                DIRECTION_NONE: V,
                DIRECTION_LEFT: $,
                DIRECTION_RIGHT: q,
                DIRECTION_UP: Q,
                DIRECTION_DOWN: G,
                DIRECTION_HORIZONTAL: K,
                DIRECTION_VERTICAL: W,
                DIRECTION_ALL: Z,
                Manager: Ke,
                Input: X,
                TouchAction: Ie,
                TouchInput: Ee,
                MouseInput: ue,
                PointerEventInput: me,
                TouchMouseInput: Ce,
                SingleTouchInput: ve,
                Recognizer: Me,
                AttrRecognizer: ze,
                Tap: Qe,
                Pan: He,
                Swipe: qe,
                Pinch: Be,
                Rotate: $e,
                Press: Ve,
                on: T,
                off: x,
                each: b,
                merge: _,
                extend: v,
                assign: c,
                inherit: w,
                bindFn: E,
                prefixed: j
            }),
            (void 0 !== s ? s : "undefined" != typeof self ? self : {}).Hammer = Ge,
            (r = (function() {
                return Ge
            }
            ).call(t, n, t, e)) === a || (e.exports = r)
        }(window, document)
    },
    "z+Ro": function(e, t, n) {
        "use strict";
        function r(e) {
            return e && "function" == typeof e.schedule
        }
        n.d(t, "a", function() {
            return r
        })
    },
    z6cu: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return s
        });
        var r = n("HDdC");
        function s(e, t) {
            return new r.a(t ? n => t.schedule(i, 0, {
                error: e,
                subscriber: n
            }) : t => t.error(e))
        }
        function i({error: e, subscriber: t}) {
            t.error(e)
        }
    },
    zUnb: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("8Y7J")
          , s = n("AytR")
          , i = (n("yLV6"),
        n("mrSG"))
          , o = n("gJmp")
          , a = n("a7ya")
          , c = n("/GRb")
          , l = n("cXGI")
          , u = n("Snpo")
          , h = n("IheW")
          , d = n("HIK+");
        let f = ( () => {
            class e extends u.a {
                constructor(e, t) {
                    super(e, t)
                }
                getImage(e) {
                    return new Promise( (t, n) => {
                        const r = new Image;
                        r.onload = () => {
                            t()
                        }
                        ,
                        r.onerror = () => {
                            n()
                        }
                        ,
                        r.src = e
                    }
                    )
                }
            }
            return e.ngInjectableDef = r.Qb({
                factory: function() {
                    return new e(r.Rb(h.c),r.Rb(d.a))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )()
          , p = ( () => {
            class e extends l.a {
                constructor(e) {
                    super(),
                    this.preloadApi = e
                }
                init() {
                    return i.a(this, void 0, void 0, function*() {
                        try {
                            const t = ["./assets/img/clock.svg", "./assets/img/delay.svg", "./assets/img/err-communication.svg", "./assets/img/err.svg", "./assets/img/exclamation-on.svg", "./assets/img/exclamation.svg", "./assets/img/home.svg", "./assets/img/left-arrow.svg", "./assets/img/link-manual.svg", "./assets/img/link-manual.svg", "./assets/img/logo-chiyoda.svg", "./assets/img/logo-fukutoshin.svg", "./assets/img/logo-ginza.svg", "./assets/img/logo-hanzoumon.svg", "./assets/img/logo-hibiya.svg", "./assets/img/logo-marunouchi.svg", "./assets/img/logo-nanboku.svg", "./assets/img/logo-touzai.svg", "./assets/img/logo-yurakucho.svg", "./assets/img/logo.svg", "./assets/img/maintenance.svg", "./assets/img/right-arrow.svg", "./assets/img/update.svg", "./assets/img/zoom-reset.svg", "./assets/img/toggle-attention.svg"];
                            yield Promise.all(t.map(e => this.preloadApi.getImage(e)))
                        } catch (e) {
                            console.error("[Preload] Failed to get image.")
                        }
                    })
                }
            }
            return e.ngInjectableDef = r.Qb({
                factory: function() {
                    return new e(r.Rb(f))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )()
          , m = ( () => {
            class e {
                constructor(e, t, n) {
                    this.configService = e,
                    this.resourceService = t,
                    this.preloadService = n
                }
                static startup(e) {
                    return () => e.startup()
                }
                startup() {
                    return i.a(this, void 0, void 0, function*() {
                        try {
                            yield Promise.all([this.preloadService.init(), this.resourceService.init(), this.configService.init()]),
                            o.a.init(this.resourceService)
                        } catch (e) {
                            const t = document.createElement("p");
                            throw t.textContent = "Application initialization error.",
                            document.body.appendChild(t),
                            e
                        }
                    })
                }
            }
            return e.ngInjectableDef = r.Qb({
                factory: function() {
                    return new e(r.Rb(a.a),r.Rb(c.a),r.Rb(p))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        const g = m.startup;
        class b {
        }
        var y = n("iInd")
          , v = n("pLZG")
          , _ = n("PcjG")
          , w = n("G4Cx")
          , E = n("VPT0")
          , S = n("PJcQ");
        class C extends o.a {
            constructor(e, t, n, r, s, i) {
                super(),
                this.router = e,
                this.rd = t,
                this.zone = n,
                this.platform = r,
                this.dialogService = s,
                this.store = i,
                this.noticeIconType$ = this.store.select(_.b),
                this.noticeType = E.a
            }
            ngOnInit() {
                this.dialogService.$dialogContainer = this.dialogContainer,
                this.router.events.pipe(Object(v.a)(e => e instanceof y.d)).subscribe(this.onNavigationEnd.bind(this)),
                S.a.disableDefaultTouchEvent(document.body, this.platform.SAFARI),
                this.removeEventListeners.push(this.rd.listen("window", "resize", this.onResize.bind(this))),
                this.onResize()
            }
            onClickNoticeIconButton() {
                this.store.dispatch(w.a()),
                this.store.dispatch(w.c())
            }
            onNavigationEnd(e) {
                this.dialogService.closeAll()
            }
            onResize() {
                this.zone.runOutsideAngular( () => {
                    window.scroll(0, 1),
                    document.documentElement.style.height = `${window.innerHeight}px`
                }
                )
            }
        }
        var T = n("BJVr")
          , x = n("FBHR")
          , k = n("pMnS")
          , O = n("bujt")
          , I = n("SVse")
          , A = n("Fwaw")
          , D = n("5GAg")
          , R = n("omvX")
          , j = n("/HVE")
          , N = n("qU/y")
          , P = n("DQLy")
          , M = r.qb({
            encapsulation: 0,
            styles: [['@charset "UTF-8";.main-container[_ngcontent-%COMP%], [_nghost-%COMP%]{width:100%;height:100%;display:block}[_nghost-%COMP%]{background-color:#333}.main-container[_ngcontent-%COMP%]{position:relative;overflow:hidden}.notice-icon-button[_ngcontent-%COMP%]{position:absolute;right:.5rem;bottom:.5rem;background-color:rgba(255,255,255,.8);z-index:1000;width:2.5rem;height:2.5rem}.notice-icon-button.None[_ngcontent-%COMP%]{display:none}.notice-icon-button.ComError[_ngcontent-%COMP%]{background-image:url(./assets/img/err-communication.svg);background-repeat:no-repeat;background-position:center;background-size:2rem}.notice-icon-button.Error[_ngcontent-%COMP%]{background-image:url(./assets/img/err.svg);background-repeat:no-repeat;background-position:50% 40%;background-size:1.7rem}']],
            data: {}
        });
        function L(e) {
            return r.Mb(2, [r.Ib(402653184, 1, {
                dialogContainer: 0
            }), (e()(),
            r.sb(1, 0, null, null, 2, "div", [["class", "main-container"]], null, null, null, null, null)), (e()(),
            r.sb(2, 16777216, null, null, 1, "router-outlet", [], null, null, null, null, null)), r.rb(3, 212992, null, 0, y.n, [y.b, r.O, r.j, [8, null], r.h], null, null), (e()(),
            r.sb(4, 0, null, null, 4, "button", [["class", "notice-icon-button"], ["mat-mini-fab", ""]], [[1, "disabled", 0], [2, "_mat-animation-noopable", null]], [[null, "click"]], function(e, t, n) {
                var r = !0;
                return "click" === t && (r = !1 !== e.component.onClickNoticeIconButton() && r),
                r
            }, O.d, O.b)), r.Hb(512, null, I.u, I.v, [r.r, r.s, r.k, r.D]), r.rb(6, 278528, null, 0, I.j, [I.u], {
                klass: [0, "klass"],
                ngClass: [1, "ngClass"]
            }, null), r.Eb(131072, I.b, [r.h]), r.rb(8, 180224, null, 0, A.b, [r.k, D.d, [2, R.a]], null, null), (e()(),
            r.sb(9, 16777216, [[1, 3], ["dialogContainer", 1]], null, 0, null, null, null, null, null, null, null))], function(e, t) {
                var n = t.component;
                e(t, 3, 0),
                e(t, 6, 0, "notice-icon-button", r.Lb(t, 6, 1, r.Db(t, 7).transform(n.noticeIconType$)))
            }, function(e, t) {
                e(t, 4, 0, r.Db(t, 8).disabled || null, "NoopAnimations" === r.Db(t, 8)._animationMode)
            })
        }
        function F(e) {
            return r.Mb(0, [(e()(),
            r.sb(0, 0, null, null, 1, "app-root", [], null, null, null, L, M)), r.rb(1, 4440064, null, 0, C, [y.l, r.D, r.y, j.a, N.a, P.n], null, null)], function(e, t) {
                e(t, 1, 0)
            }, null)
        }
        var U = r.ob("app-root", C, F, {}, {}, [])
          , z = n("cUpR")
          , H = n("Xd0L")
          , B = n("fDlF")
          , V = n("GS7A")
          , $ = n("z6cu")
          , q = n("LRne")
          , Q = n("5+tZ")
          , G = n("JIr8")
          , K = n("wAL0");
        class W {
            constructor(e, t) {
                this.httpChecker = e,
                this.apiConfig = t
            }
            intercept(e, t) {
                const n = this.isApi(e.url)
                  , r = s.a.mock
                  , i = {};
                
                // 既存のヘッダーをコピー
                e.headers && e.headers.keys().forEach(t => {
                    i[t] = e.headers.get(t)
                });

                // ★★★ ここが大手術のポイント！ ★★★
                // 変数 this.apiConfig.apiToken を使うのをやめて、
                // 直接、最強のトークン文字列を代入します。
                if (n) {
                    i[K.a.AUTHORIZATION] = "Bearer 6C9F5526E3FA82989C47EE25196D5ACC771DF4A4C0D439C4A81DA171294834F9";
                }

                // リクエストの複製を作成
                const o = e.clone(r ? {
                    method: "GET",
                    headers: new h.h(i)
                } : {
                    headers: new h.h(i)
                });

                // そのまま処理を続行
                return t.handle(o).pipe(Object(Q.a)(e => {
                    if (n && e instanceof h.k) {
                        const t = this.httpChecker.check(e);
                        if (t)
                            return Object($.a)(t)
                    }
                    return Object(q.a)(e)
                }
                ), Object(G.a)(e => {
                    if (n && e instanceof h.f) {
                        const t = this.httpChecker.check(e);
                        if (t)
                            return Object($.a)(t)
                    }
                    return Object($.a)(e)
                }
                ))
            }
            isApi(e) {
                const t = s.a.mock ? s.a.api : this.apiConfig.root;
                return !!t && new RegExp(`^${S.a.escapeRegExp(t)}`,"i").test(e)
            }
        }
        var Z = n("ukeZ")
          , Y = n("POq0");
        class J extends l.a {
            constructor(e) {
                super(),
                this.injector = e
            }
            handleError(e) {
                console.error(e ? e.stack || e : "Unknown error."),
                window.setTimeout( () => {
                    const t = this.injector.get(r.y)
                      , n = this.injector.get(P.n);
                    t.run( () => {
                        n.dispatch(e && e.rejection && "ChunkLoadError" === e.rejection.name ? Object(w.d)({
                            status: K.b.DISCONNECT_NETWORK,
                            error: this.resToError(void 0)
                        }) : Object(w.d)({
                            status: void 0,
                            error: this.resToError(e)
                        }))
                    }
                    )
                }
                )
            }
        }
        var X = n("Yml6")
          , ee = n("2mKN")
          , te = n("oTXU")
          , ne = n("IP0z")
          , re = n("Qrwk")
          , se = n("veZf")
          , ie = n("pJnZ");
        let oe = ( () => {
            class e {
                constructor(e, t) {
                    this.router = e,
                    this.configService = t,
                    this.isError = !1
                }
                canActivate(e, t) {
                    if (!this.configService.validKey)
                        return this.navigateErrorPage(ie.a.PageNotFound),
                        !1;
                    if (!this.configService.operationTimeRange.valid)
                        return this.navigateErrorPage(ie.a.OperationOutside),
                        !1;
                    if (!this.configService.maintenance.valid)
                        return this.navigateErrorPage(ie.a.Maintenance),
                        !1;
                    if ("diagram/:id" === e.routeConfig.path) {
                        const t = this.configService.getLineConfig("lineConfigList") || []
                          , n = e.paramMap.get("id");
                        if (t.every(e => e.lineId !== n))
                            return this.navigateErrorPage(ie.a.PageNotFound),
                            !1
                    }
                    return !0
                }
                navigateErrorPage(e) {
                    this.isError ? location.reload() : (this.isError = !0,
                    this.router.navigate(["/error", e], {
                        replaceUrl: !0
                    }))
                }
            }
            return e.ngInjectableDef = r.Qb({
                factory: function() {
                    return new e(r.Rb(y.l),r.Rb(a.a))
                },
                token: e,
                providedIn: "root"
            }),
            e
        }
        )();
        const ae = () => Promise.all([n.e(1), n.e(2), n.e(8)]).then(n.bind(null, "o1NI")).then(e => e.MainModuleNgFactory)
          , ce = () => Promise.all([n.e(1), n.e(2), n.e(6)]).then(n.bind(null, "xVD3")).then(e => e.DiagramModuleNgFactory)
          , le = () => Promise.all([n.e(1), n.e(7)]).then(n.bind(null, "NzVj")).then(e => e.ErrorModuleNgFactory);
        class ue {
        }
        var he = n("IzEk")
          , de = n("lJxs")
          , fe = n("eIep")
          , pe = n("vkgz")
          , me = n("mHMc");
        class ge {
            constructor(e, t, n, r, s) {
                this.router = e,
                this.actions$ = t,
                this.resourceService = n,
                this.dialogService = r,
                this.store = s,
                this.notifyError$ = Object(X.c)( () => this.actions$.pipe(Object(X.d)(w.d), Object(Q.a)(e => {
                    const {error: t} = e.payload;
                    if (t.status === K.b.SERVICE_UNAVAILABLE)
                        return Object(q.a)(w.b(ie.a.OperationOutside));
                    if (Number.isNaN(t.status))
                        return Object(q.a)(w.b(t.error.message));
                    {
                        const e = this.createNotice(t);
                        return this.store.select(_.a).pipe(Object(he.a)(1), Object(v.a)(t => t && (e.messagePriority < t.messagePriority || t.type === E.a.None)), Object(de.a)( () => w.e(e)))
                    }
                }
                ))),
                this.showErrorDialog$ = Object(X.c)( () => this.actions$.pipe(Object(X.d)(w.a), Object(fe.a)( () => this.store.select(_.a).pipe(Object(he.a)(1), Object(pe.a)(e => this.dialogService.open(me.a, e))))), {
                    dispatch: !1
                }),
                this.showErrorPage$ = Object(X.c)( () => this.actions$.pipe(Object(X.d)(w.b), Object(pe.a)(e => {
                    this.router.navigate(["/error", e.payload.errorPage], {
                        replaceUrl: !0
                    })
                }
                )), {
                    dispatch: !1
                })
            }
            createNotice(e) {
                const t = e.status
                  , n = e.error.message
                  , r = e.error.isUnknownWindow
                  , s = e.error.errorcode;
                let i;
                if (i = e.errortime ? e.errortime : new Date,
                isNaN(t))
                    return r ? {
                        messageId: "GMSGE003",
                        messageDetail: n,
                        type: E.a.Error,
                        messagePriority: 4,
                        errorTime: i
                    } : {
                        messageId: "GMSGE001",
                        messageDetail: n,
                        type: E.a.Error,
                        messagePriority: 1,
                        errorTime: i
                    };
                switch (t) {
                case K.b.INTERNAL_SERVER_ERROR:
                    return {
                        messageId: "GMSGE100",
                        type: E.a.Error,
                        messagePriority: 2,
                        errorTime: i
                    };
                case K.b.DISCONNECT_NETWORK:
                    return {
                        messageId: "GMSGE002",
                        type: E.a.ComError,
                        messagePriority: 5,
                        errorTime: i
                    };
                default:
                    let e;
                    return e = s ? this.resourceService.get("Notice_ErrorCode", s) : this.resourceService.get("Notice_HTTP_Status", t.toString()),
                    {
                        messageId: "GMSGE101",
                        type: E.a.Error,
                        messagePriority: 3,
                        errorCode: e,
                        errorTime: i
                    }
                }
            }
        }
        var be = n("l5mm")
          , ye = n("JX91")
          , ve = n("LPws")
          , _e = n("eD/y");
        class we {
            constructor(e, t, n) {
                this.actions$ = e,
                this.webStorageService = t,
                this.store = n,
                this.initEffects$ = Object(X.c)( () => this.actions$.pipe(Object(X.d)(ve.b), Object(he.a)(1), Object(de.a)( () => ve.c({
                    updateSpan: this.webStorageService.get(_e.b.AutoUpdateSpan)
                })))),
                this.updateNow$ = Object(X.c)( () => Object(be.a)(200).pipe(Object(ye.a)(0), Object(de.a)( () => ve.d(new Date)))),
                this.changeUpdateSpan$ = Object(X.c)( () => this.actions$.pipe(Object(X.d)(ve.a), Object(fe.a)( () => this.store.select(_.d).pipe(Object(he.a)(1), Object(pe.a)(e => this.webStorageService.set(_e.b.AutoUpdateSpan, e))))), {
                    dispatch: !1
                })
            }
            ngrxOnInitEffects() {
                return ve.b()
            }
        }
        var Ee = n("3kxW");
        class Se {
        }
        class Ce {
            constructor(e) {
                if (e)
                    throw new Error("CoreModule is already loaded. Import it in the AppModule only")
            }
        }
        var Te = r.pb(b, [C], function(e) {
            return r.Ab([r.Bb(512, r.j, r.ab, [[8, [T.a, x.a, k.a, U]], [3, r.j], r.w]), r.Bb(5120, r.t, r.mb, [[3, r.t]]), r.Bb(4608, I.n, I.m, [r.t, [2, I.x]]), r.Bb(5120, r.ib, r.nb, [r.y]), r.Bb(5120, r.c, r.jb, []), r.Bb(5120, r.r, r.kb, []), r.Bb(5120, r.s, r.lb, []), r.Bb(4608, z.b, z.k, [I.d]), r.Bb(6144, r.G, null, [z.b]), r.Bb(4608, z.e, H.a, [[2, H.c], [2, H.e]]), r.Bb(5120, z.c, function(e, t, n, r, s, i, o, a) {
                return [new z.i(e,t,n), new z.n(r), new z.m(s,i,o,a)]
            }, [I.d, r.y, r.A, I.d, I.d, z.e, r.bb, [2, z.f]]), r.Bb(4608, z.d, z.d, [z.c, r.y]), r.Bb(135680, z.l, z.l, [I.d]), r.Bb(4608, z.j, z.j, [z.d, z.l, r.c]), r.Bb(5120, B.a, R.e, []), r.Bb(5120, B.c, R.f, []), r.Bb(4608, B.b, R.d, [I.d, B.a, B.c]), r.Bb(5120, r.E, R.g, [z.j, B.b, r.y]), r.Bb(6144, z.o, null, [z.l]), r.Bb(4608, r.M, r.M, [r.y]), r.Bb(4608, V.b, R.c, [r.E, I.d]), r.Bb(4608, h.m, h.s, [I.d, r.A, h.q]), r.Bb(4608, h.t, h.t, [h.m, h.r]), r.Bb(5120, h.a, function(e, t, n) {
                return [e, new W(t,n)]
            }, [h.t, Z.a, d.a]), r.Bb(4608, h.p, h.p, []), r.Bb(6144, h.n, null, [h.p]), r.Bb(4608, h.l, h.l, [h.n]), r.Bb(6144, h.b, null, [h.l]), r.Bb(4608, h.g, h.o, [h.b, r.q]), r.Bb(4608, h.c, h.c, [h.g]), r.Bb(4608, Y.c, Y.c, []), r.Bb(5120, y.a, y.x, [y.l]), r.Bb(4608, y.e, y.e, []), r.Bb(6144, y.g, null, [y.e]), r.Bb(135680, y.o, y.o, [y.l, r.v, r.i, r.q, y.g]), r.Bb(4608, y.f, y.f, []), r.Bb(5120, y.C, y.t, [y.l, I.q, y.h]), r.Bb(5120, y.i, y.A, [y.y]), r.Bb(5120, r.b, function(e) {
                return [e]
            }, [y.i]), r.Bb(1073742336, I.c, I.c, []), r.Bb(512, r.l, J, [r.q]), r.Bb(1024, r.x, function() {
                return [y.s()]
            }, []), r.Bb(512, y.y, y.y, [r.q]), r.Bb(1024, r.d, function(e, t, n) {
                return [z.p(e), y.z(t), g(n)]
            }, [[2, r.x], y.y, m]), r.Bb(512, r.e, r.e, [[2, r.d]]), r.Bb(131584, r.g, r.g, [r.y, r.bb, r.q, r.l, r.j, r.e]), r.Bb(1073742336, r.f, r.f, [r.g]), r.Bb(1073742336, z.a, z.a, [[3, z.a]]), r.Bb(1073742336, R.b, R.b, []), r.Bb(131584, P.a, P.a, []), r.Bb(2048, P.h, null, [P.a]), r.Bb(256, P.B, void 0, []), r.Bb(1024, P.d, P.P, [P.B]), r.Bb(256, P.D, {}, []), r.Bb(2048, P.E, null, [P.D]), r.Bb(1024, P.c, P.M, [r.q, P.D, P.E]), r.Bb(256, P.C, P.s, []), r.Bb(256, P.K, {
                strictStateImmutability: !1,
                strictActionImmutability: !1
            }, []), r.Bb(1024, P.r, P.A, [P.K]), r.Bb(1024, P.L, P.R, [P.r]), r.Bb(1024, P.e, function(e, t) {
                return [P.T(e), P.S(t)]
            }, [P.L, P.L]), r.Bb(256, P.q, [], []), r.Bb(1024, P.J, P.Q, [P.e, P.q]), r.Bb(1024, P.f, P.x, [P.C, P.J]), r.Bb(131584, P.g, P.g, [P.h, P.d, P.c, P.f]), r.Bb(2048, P.i, null, [P.g]), r.Bb(131584, P.k, P.k, []), r.Bb(131584, P.l, P.l, [P.a, P.i, P.k, P.d]), r.Bb(2048, P.m, null, [P.l]), r.Bb(512, P.n, P.n, [P.m, P.a, P.g]), r.Bb(1073742336, P.p, P.p, [P.a, P.i, P.k, P.n]), r.Bb(512, X.b, X.b, [r.l, P.n]), r.Bb(131584, X.j, X.j, [X.b, P.n]), r.Bb(1024, X.h, X.e, []), r.Bb(1024, P.G, function() {
                return [{
                    metaReducers: []
                }]
            }, []), r.Bb(1024, P.j, function() {
                return [{
                    key: "Core",
                    reducerFactory: P.s,
                    metaReducers: [],
                    initialState: void 0
                }]
            }, []), r.Bb(1024, P.H, P.N, [r.q, P.G, P.j]), r.Bb(1024, P.F, function() {
                return [{
                    view: ee.a,
                    notice: te.a
                }]
            }, []), r.Bb(1024, P.I, function(e) {
                return [e]
            }, [P.F]), r.Bb(1024, P.b, function(e, t, n) {
                return [P.O(e, t, n)]
            }, [r.q, P.F, P.I]), r.Bb(1073873408, P.o, P.o, [P.H, P.b, P.g, P.p]), r.Bb(1073742336, X.f, X.f, [X.b, X.j, P.n, X.h, [2, P.p], [2, P.o]]), r.Bb(1073742336, h.e, h.e, []), r.Bb(1073742336, h.d, h.d, []), r.Bb(1073742336, j.b, j.b, []), r.Bb(1073742336, Y.d, Y.d, []), r.Bb(1073742336, D.a, D.a, []), r.Bb(1073742336, ne.a, ne.a, []), r.Bb(1073742336, H.e, H.e, [[2, H.b], [2, z.f]]), r.Bb(1073742336, H.g, H.g, []), r.Bb(1073742336, A.c, A.c, []), r.Bb(1073742336, re.a, re.a, []), r.Bb(1073742336, se.a, se.a, []), r.Bb(512, y.q, y.c, []), r.Bb(512, y.b, y.b, []), r.Bb(256, y.h, {
                useHash: !1
            }, []), r.Bb(1024, I.i, y.u, [I.p, [2, I.a], y.h]), r.Bb(512, I.h, I.h, [I.i, I.p]), r.Bb(512, r.i, r.i, []), r.Bb(512, r.v, r.J, [r.i, [2, r.K]]), r.Bb(1024, y.j, function() {
                return [[{
                    path: "",
                    pathMatch: "full",
                    loadChildren: ae
                }, {
                    path: "diagram/:id",
                    loadChildren: ce
                }, {
                    path: "error/:id",
                    loadChildren: le
                }, {
                    path: "**",
                    redirectTo: "/error/page-not-found"
                }]]
            }, []), r.Bb(1024, y.l, y.w, [r.g, y.q, y.b, I.h, r.q, r.v, r.i, y.j, y.h, [2, y.p], [2, y.k]]), r.Bb(512, X.a, X.a, [P.k]), r.Bb(512, N.a, N.a, [r.j]), r.Bb(512, ge, ge, [y.l, X.a, c.a, N.a, P.n]), r.Bb(512, we, we, [X.a, Ee.a, P.n]), r.Bb(1024, X.i, function(e, t) {
                return [X.e(e, t)]
            }, [ge, we]), r.Bb(1073742336, X.g, X.g, [X.f, X.i, [2, P.p], [2, P.o]]), r.Bb(1073742336, Se, Se, []), r.Bb(1073742336, Ce, Ce, [[3, Ce]]), r.Bb(1024, y.r, y.v, [[3, y.l]]), r.Bb(1073742336, y.m, y.m, [[2, y.r], [2, y.l]]), r.Bb(1073742336, ue, ue, []), r.Bb(1073742336, b, b, []), r.Bb(256, r.Z, !0, []), r.Bb(256, R.a, "BrowserAnimations", []), r.Bb(256, h.q, "XSRF-TOKEN", []), r.Bb(256, h.r, "X-XSRF-TOKEN", [])])
        });
        s.a.production && Object(r.S)(),
        z.h().bootstrapModuleFactory(Te).catch(e => console.error(e))
    },
    zn8P: function(e, t) {
        function n(e) {
            return Promise.resolve().then(function() {
                var t = new Error("Cannot find module '" + e + "'");
                throw t.code = "MODULE_NOT_FOUND",
                t
            })
        }
        n.keys = function() {
            return []
        }
        ,
        n.resolve = n,
        e.exports = n,
        n.id = "zn8P"
    }
}, [[0, 0]]]);